# Mobile Vela - Cloud Video Storage Guide

## Overview
Mobile Vela now includes comprehensive cloud storage integration for videos with automatic background sync, upload progress tracking, and cross-device access through Supabase.

## Features

### 1. Cloud Storage Integration
- **Automatic Background Sync**: Videos automatically upload to Supabase storage when online
- **Bandwidth Optimization**: Smart upload management with progress tracking
- **Cross-Device Access**: Access your videos from any device
- **Offline Support**: Record videos offline, auto-sync when connection restored

### 2. Video Library
- **Thumbnail View**: Grid layout with video thumbnails
- **Search Functionality**: Search videos by title
- **Quality Filtering**: Filter by 720p, 1080p, or 4K
- **Metadata Display**: Duration, file size, quality badges
- **Upload Status**: Real-time upload progress indicators

### 3. Upload Management
- **Progress Tracking**: Visual upload progress indicators
- **Online/Offline Status**: Clear indication of connection status
- **Retry Logic**: Automatic retry on failed uploads
- **Local Backup**: Videos saved locally before upload

## Database Schema

### Videos Table
```sql
- id: UUID (Primary Key)
- user_id: UUID (Foreign Key to auth.users)
- family_id: UUID (Foreign Key to families)
- title: TEXT
- description: TEXT
- storage_path: TEXT (Supabase storage path)
- thumbnail_path: TEXT
- duration: INTEGER (seconds)
- quality: TEXT ('720p', '1080p', '4K')
- orientation: TEXT ('portrait', 'landscape')
- file_size: BIGINT (bytes)
- upload_status: TEXT ('pending', 'uploading', 'completed', 'failed')
- upload_progress: INTEGER (0-100)
- synced_at: TIMESTAMP
- created_at: TIMESTAMP
- metadata: JSONB
```

## Usage Guide

### Recording Videos with Cloud Sync

1. **Start Recording**
   - Tap "Start Video Recording" button
   - Choose quality settings (720p, 1080p, 4K)
   - Switch between front/back camera
   - Record in portrait or landscape mode

2. **Automatic Upload**
   - When online: Video uploads automatically after recording
   - When offline: Video saved locally, uploads when connection restored
   - Upload progress shown in real-time

3. **Access Video Library**
   - Navigate to "Library" tab
   - Search videos by title
   - Filter by quality
   - View upload status and metadata

### Video Library Features

**Search**
- Type in search bar to filter videos by title
- Real-time search results

**Filtering**
- Select quality filter: All, 720p, 1080p, 4K
- Instantly updates displayed videos

**Video Cards**
- Thumbnail preview
- Title and duration
- Quality badge
- File size
- Upload status indicator

### Upload Status Indicators

- **Green "Online"**: Connected, uploads active
- **Orange "Offline"**: No connection, local storage only
- **Upload Progress**: Percentage shown during upload
- **"Uploading..."**: Active upload in progress
- **Completed**: Video successfully synced to cloud

## Technical Implementation

### Storage Bucket
- Bucket Name: `videos`
- Public Access: Yes (for playback)
- Path Structure: `{user_id}/{video_id}.mp4`

### Upload Process
1. Video recorded and saved to local storage
2. Metadata record created in database
3. Video uploaded to Supabase storage
4. Database updated with storage path
5. Upload status set to 'completed'

### Bandwidth Optimization
- Videos stored locally first
- Upload only when online
- Progress tracking prevents duplicate uploads
- Failed uploads automatically retry

## Best Practices

### For Users
1. **Check Connection**: Verify online status before recording important videos
2. **Quality Settings**: Use lower quality (720p) for faster uploads on slow connections
3. **Local Storage**: Videos always saved locally first as backup
4. **Library Management**: Regularly check library for upload status

### For Developers
1. **Error Handling**: All upload failures gracefully handled
2. **Progress Tracking**: Upload progress stored in database
3. **Retry Logic**: Failed uploads can be retried manually
4. **Storage Limits**: Monitor storage bucket size and implement cleanup

## Troubleshooting

### Video Not Uploading
- Check internet connection status
- Verify online indicator shows green
- Check browser console for errors
- Ensure sufficient storage space

### Upload Stuck
- Refresh the page
- Check network stability
- Video still in local storage as backup
- Can manually retry upload

### Can't Find Video
- Check quality filter settings
- Use search to find by title
- Verify upload completed successfully
- Check database for video record

### Cross-Device Access Issues
- Ensure logged in with same account
- Verify video upload completed
- Check RLS policies for family sharing
- Refresh video library

## Security & Privacy

### Row Level Security (RLS)
- Users can only access their own videos
- Family members can view family videos
- Secure upload and download paths
- Authentication required for all operations

### Data Protection
- Videos encrypted in transit (HTTPS)
- Secure storage in Supabase
- Local storage cleared after successful upload
- User-controlled deletion

## Performance Tips

1. **Quality Selection**: Choose appropriate quality for use case
   - 720p: Good for quick memos, fast upload
   - 1080p: Balanced quality and size
   - 4K: Best quality, larger files, slower upload

2. **Network Optimization**
   - Upload on WiFi for large files
   - Monitor upload progress
   - Pause other downloads during upload

3. **Storage Management**
   - Regularly review and delete old videos
   - Check storage usage in library
   - Archive important videos externally

## Future Enhancements

- Thumbnail generation from video frames
- Video compression before upload
- Batch upload management
- Download for offline viewing
- Video sharing with family members
- Advanced search with AI tags
- Video transcription integration

## Support

For issues or questions:
1. Check this guide first
2. Review browser console for errors
3. Verify Supabase connection
4. Contact support with video ID and error details
