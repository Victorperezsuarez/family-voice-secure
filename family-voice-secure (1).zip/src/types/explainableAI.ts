export interface ShapValue {
  feature: string;
  value: number;
  contribution: number;
  displayName: string;
}

export interface CounterfactualScenario {
  feature: string;
  currentValue: number | string;
  suggestedValue: number | string;
  predictedSegment: string;
  confidence: number;
  displayName: string;
}

export interface PredictionExplanation {
  userId: string;
  predictedSegment: string;
  confidence: number;
  shapValues: ShapValue[];
  counterfactuals: CounterfactualScenario[];
  naturalLanguageExplanation: string;
  timestamp: Date;
}

export interface FeatureContribution {
  feature: string;
  contribution: number;
  cumulativeValue: number;
  displayName: string;
}
