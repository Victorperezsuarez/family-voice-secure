export interface BayesianStats {
  id: string;
  test_id: string;
  combination_id: string;
  alpha: number;
  beta: number;
  samples_drawn: number;
  total_impressions: number;
  total_conversions: number;
  expected_value: number;
  variance: number;
  probability_best: number;
  regret: number;
  updated_at: string;
}

export interface TrafficAllocation {
  id: string;
  test_id: string;
  combination_id: string;
  allocation_percentage: number;
  reason: string;
  alpha: number;
  beta: number;
  expected_value: number;
  confidence_interval_lower: number;
  confidence_interval_upper: number;
  created_at: string;
}

export interface EarlyStoppingEvaluation {
  id: string;
  test_id: string;
  evaluated_at: string;
  should_stop: boolean;
  winning_combination_id: string | null;
  confidence_level: number;
  expected_loss: number;
  reason: string;
  recommendations: any;
}

export type OptimizationStrategy = 'fixed' | 'thompson_sampling' | 'ucb' | 'epsilon_greedy';

export interface ThompsonSamplingResult {
  combination_id: string;
  combination_name: string;
  allocation_percentage: number;
  alpha: number;
  beta: number;
  expected_value: number;
  probability_best: number;
  impressions: number;
  conversions: number;
}