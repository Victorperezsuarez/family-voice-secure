export interface MVTElement {
  id: string;
  test_id: string;
  element_name: string;
  element_type: 'image' | 'title' | 'body' | 'cta' | 'timing' | 'icon' | 'badge' | 'action_buttons';
  variants: MVTVariant[];
  created_at: string;
}

export interface MVTVariant {
  id: string;
  value: string;
  label: string;
  metadata?: Record<string, any>;
}

export interface MVTCombination {
  id: string;
  test_id: string;
  combination_id: string;
  element_values: Record<string, any>;
  traffic_allocation: number;
  impressions: number;
  deliveries: number;
  clicks: number;
  actions: number;
  conversions: number;
  created_at: string;
}

export interface MVTInteraction {
  id: string;
  test_id: string;
  element_a: string;
  element_b: string;
  interaction_effect: number;
  p_value: number;
  is_significant: boolean;
  effect_direction: 'positive' | 'negative' | 'neutral';
  analyzed_at: string;
}

export interface MainEffect {
  element: string;
  means: {
    variant: string;
    mean: number;
    count: number;
  }[];
}

export interface MVTAnalysisResult {
  interactions: MVTInteraction[];
  mainEffects: MainEffect[];
  bestCombination: string;
  totalCombinations: number;
}
