export interface PerformanceMetric {
  id: string;
  template_id: string;
  metric_type: 'load_time' | 'memory_usage' | 'permission_check' | 'render_time';
  value: number;
  unit: string;
  context?: any;
  created_at: string;
  user_id?: string;
}

export interface PerformanceBaseline {
  id: string;
  template_id: string;
  version_number: number;
  metric_type: string;
  baseline_value: number;
  p50_value?: number;
  p95_value?: number;
  p99_value?: number;
  sample_size: number;
  created_at: string;
}

export interface PerformanceAlert {
  id: string;
  template_id: string;
  alert_type: 'regression' | 'threshold_exceeded' | 'optimization_opportunity';
  severity: 'low' | 'medium' | 'high' | 'critical';
  metric_type: string;
  current_value?: number;
  baseline_value?: number;
  deviation_percent?: number;
  message?: string;
  status: 'active' | 'acknowledged' | 'resolved';
  created_at: string;
  resolved_at?: string;
  resolved_by?: string;
}

export interface OptimizationRecommendation {
  id: string;
  template_id: string;
  recommendation_type: string;
  priority: 'low' | 'medium' | 'high';
  title: string;
  description?: string;
  estimated_impact?: string;
  implementation_guide?: string;
  status: 'pending' | 'in_progress' | 'completed' | 'dismissed';
  created_at: string;
  updated_at: string;
}

export interface PerformanceStats {
  avg: number;
  p50: number;
  p95: number;
  p99: number;
  count: number;
  values: PerformanceMetric[];
}
