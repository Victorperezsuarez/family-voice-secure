export interface AuditRetentionPolicy {
  id: string;
  name: string;
  description?: string;
  category?: string;
  action_type?: string;
  severity?: string;
  retention_days: number;
  archive_enabled: boolean;
  archive_location: 'supabase_storage' | 'external_s3' | 'external_gcs';
  auto_delete_after_archive: boolean;
  is_active: boolean;
  priority: number;
  created_at: string;
  updated_at: string;
  created_by?: string;
}

export interface ArchivedAuditLog {
  id: string;
  original_log_id: string;
  user_id?: string;
  action: string;
  category: string;
  details?: any;
  ip_address?: string;
  user_agent?: string;
  status?: string;
  severity?: string;
  original_timestamp: string;
  archived_at: string;
  archived_by: string;
  retention_policy_id?: string;
  archive_location?: string;
  archive_path?: string;
  metadata?: any;
}

export interface AuditRetentionJob {
  id: string;
  job_type: 'archive' | 'cleanup' | 'both';
  status: 'pending' | 'running' | 'completed' | 'failed';
  started_at?: string;
  completed_at?: string;
  logs_processed: number;
  logs_archived: number;
  logs_deleted: number;
  error_message?: string;
  policy_id?: string;
  metadata?: any;
  created_at: string;
}
