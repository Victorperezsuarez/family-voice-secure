export type FeatureType = 'raw' | 'derived' | 'aggregated' | 'time_series';
export type DataType = 'numeric' | 'categorical' | 'boolean';
export type AggregationType = 'mean' | 'sum' | 'count' | 'max' | 'min' | 'std' | 'median';
export type SelectionMethod = 'mutual_info' | 'chi_square' | 'rfe' | 'lasso' | 'correlation';

export interface Feature {
  id: string;
  feature_name: string;
  feature_type: FeatureType;
  description?: string;
  data_type: DataType;
  generation_method?: string;
  source_features?: string[];
  is_active: boolean;
  importance_score?: number;
  created_at: string;
  updated_at: string;
}

export interface FeatureVersion {
  id: string;
  feature_id: string;
  version_number: number;
  definition: string;
  performance_metrics?: {
    accuracy?: number;
    correlation?: number;
    mutual_information?: number;
  };
  is_current: boolean;
  created_by?: string;
  created_at: string;
}

export interface FeatureCorrelation {
  id: string;
  feature_a_id: string;
  feature_b_id: string;
  feature_a_name?: string;
  feature_b_name?: string;
  correlation_coefficient: number;
  p_value?: number;
  sample_size?: number;
  calculated_at: string;
}

export interface FeatureSelectionResult {
  id: string;
  model_name: string;
  selection_method: SelectionMethod;
  selected_features: string[];
  feature_scores: Record<string, number>;
  selection_params?: Record<string, any>;
  created_at: string;
}

export interface TimeSeriesFeature {
  id: string;
  user_id: string;
  feature_name: string;
  time_window: string;
  aggregation_type: AggregationType;
  value: number;
  calculated_at: string;
}

export interface GeneratedFeature {
  name: string;
  type: FeatureType;
  description: string;
  importance: number;
  value?: number;
}

export interface CorrelationMatrix {
  features: string[];
  matrix: number[][];
}
