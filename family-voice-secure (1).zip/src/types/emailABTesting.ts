export interface EmailABTest {
  id: string;
  name: string;
  description?: string;
  template_type: string;
  variant_a_template_id: string;
  variant_b_template_id: string;
  status: 'draft' | 'active' | 'completed' | 'cancelled';
  traffic_split: number;
  start_date?: string;
  end_date?: string;
  min_sample_size: number;
  confidence_level: number;
  winner_variant?: 'a' | 'b';
  winner_selected_at?: string;
  auto_select_winner: boolean;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface EmailPerformanceMetrics {
  id: string;
  delivery_id: string;
  template_id: string;
  ab_test_id?: string;
  variant?: 'a' | 'b';
  sent_at: string;
  opened_at?: string;
  first_click_at?: string;
  bounced_at?: string;
  bounce_type?: 'hard' | 'soft' | 'complaint';
  unsubscribed_at?: string;
  converted_at?: string;
  conversion_value?: number;
  user_agent?: string;
  device_type?: string;
  email_client?: string;
}

export interface EmailClickHeatmap {
  id: string;
  performance_id: string;
  template_id: string;
  ab_test_id?: string;
  variant?: 'a' | 'b';
  click_x: number;
  click_y: number;
  element_id?: string;
  element_class?: string;
  link_url?: string;
  clicked_at: string;
}

export interface EmailABTestResults {
  id: string;
  ab_test_id: string;
  variant_a_sends: number;
  variant_a_opens: number;
  variant_a_clicks: number;
  variant_a_bounces: number;
  variant_a_conversions: number;
  variant_a_open_rate: number;
  variant_a_click_rate: number;
  variant_a_bounce_rate: number;
  variant_a_conversion_rate: number;
  variant_b_sends: number;
  variant_b_opens: number;
  variant_b_clicks: number;
  variant_b_bounces: number;
  variant_b_conversions: number;
  variant_b_open_rate: number;
  variant_b_click_rate: number;
  variant_b_bounce_rate: number;
  variant_b_conversion_rate: number;
  statistical_significance: number;
  confidence_level: number;
  recommended_winner?: 'a' | 'b';
  recommendation_reason?: string;
  analyzed_at: string;
}
