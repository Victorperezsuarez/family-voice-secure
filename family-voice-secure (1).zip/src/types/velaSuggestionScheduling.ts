export interface VelaSuggestionSchedule {
  id: string;
  user_id: string;
  persona_id?: string;
  schedule_type: 'daily' | 'weekly' | 'smart' | 'manual';
  frequency: 'once_daily' | 'twice_daily' | 'weekly' | 'as_needed';
  preferred_times?: string[];
  quiet_hours_start?: string;
  quiet_hours_end?: string;
  max_daily_suggestions: number;
  max_weekly_suggestions: number;
  enabled: boolean;
  timezone: string;
  last_delivery_at?: string;
  next_scheduled_at?: string;
  created_at: string;
  updated_at: string;
}

export interface VelaSuggestionDeliveryLog {
  id: string;
  suggestion_id: string;
  user_id: string;
  persona_id?: string;
  delivered_at: string;
  scheduled_for?: string;
  delivery_method: 'in_app' | 'push' | 'email';
  opened_at?: string;
  interacted_at?: string;
  response_time_seconds?: number;
  user_activity_score?: number;
  created_at: string;
}

export interface VelaOptimalTimingPattern {
  id: string;
  user_id: string;
  persona_id?: string;
  hour_of_day: number;
  day_of_week: number;
  acceptance_rate: number;
  total_delivered: number;
  total_accepted: number;
  total_dismissed: number;
  avg_response_time_seconds?: number;
  last_updated: string;
  created_at: string;
}

export interface VelaSuggestionQueue {
  id: string;
  suggestion_id: string;
  user_id: string;
  persona_id?: string;
  priority_score: number;
  urgency: 'low' | 'medium' | 'high' | 'critical';
  value_score: number;
  optimal_delivery_time: string;
  expires_at?: string;
  status: 'queued' | 'scheduled' | 'delivered' | 'expired' | 'cancelled';
  delivery_attempts: number;
  created_at: string;
  updated_at: string;
}
