export interface PushNotificationSubscription {
  id: string;
  user_id: string;
  family_id?: string;
  endpoint: string;
  p256dh_key: string;
  auth_key: string;
  user_agent?: string;
  is_active: boolean;
  last_used_at?: string;
  created_at: string;
  updated_at: string;
}

export interface VelaNotificationPreference {
  id: string;
  user_id: string;
  family_id?: string;
  suggestion_type: string;
  urgency_level: 'low' | 'medium' | 'high' | 'critical';
  enabled: boolean;
  sound_enabled: boolean;
  vibration_enabled: boolean;
  created_at: string;
  updated_at: string;
}

export interface VelaNotificationDelivery {
  id: string;
  suggestion_id?: string;
  subscription_id?: string;
  user_id: string;
  status: 'sent' | 'delivered' | 'failed' | 'clicked' | 'dismissed';
  error_message?: string;
  action_taken?: 'accepted' | 'dismissed' | 'ignored';
  delivered_at: string;
  clicked_at?: string;
  action_taken_at?: string;
  created_at: string;
}
