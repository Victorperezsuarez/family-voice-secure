export interface SearchFilters {
  speaker?: string;
  dateFrom?: string;
  dateTo?: string;
  topics?: string[];
  familyId?: string;
}

export interface SearchResult {
  id: string;
  recordingId: string;
  transcriptionId: string;
  title: string;
  content: string;
  speaker?: string;
  timestamp: number;
  startTime: number;
  endTime: number;
  matchScore: number;
  highlightedContent: string;
  createdAt: string;
}

export interface SearchHistoryItem {
  id: string;
  query: string;
  filters: SearchFilters;
  resultsCount: number;
  createdAt: string;
}

export interface TranscriptionSpeaker {
  id: string;
  transcriptionId: string;
  speakerName: string;
  startTime: number;
  endTime: number;
  content: string;
}

export interface TranscriptionTopic {
  id: string;
  transcriptionId: string;
  topic: string;
  confidence: number;
}
