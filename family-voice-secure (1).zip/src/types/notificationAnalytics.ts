export interface NotificationAnalytics {
  id: string;
  notification_instance_id: string;
  template_id: string;
  user_id: string;
  device_id: string;
  sent_at: string;
  delivered_at?: string;
  clicked_at?: string;
  action_taken?: 'accept' | 'snooze' | 'view_details' | 'dismiss';
  action_taken_at?: string;
  conversion_completed: boolean;
  conversion_completed_at?: string;
  suggestion_type: string;
  suggestion_priority: string;
  time_of_day: number;
  day_of_week: number;
  time_to_click_seconds?: number;
  time_to_action_seconds?: number;
  time_to_conversion_seconds?: number;
  ab_test_id?: string;
  variant_id?: string;
  created_at: string;
  updated_at: string;
}

export interface NotificationPerformanceMetrics {
  total_sent: number;
  total_delivered: number;
  total_clicked: number;
  total_actions: number;
  total_conversions: number;
  delivery_rate: number;
  click_through_rate: number;
  action_rate: number;
  conversion_rate: number;
  avg_time_to_click: number;
  avg_time_to_action: number;
  avg_time_to_conversion: number;
}

export interface TemplatePerformance {
  template_id: string;
  template_name: string;
  metrics: NotificationPerformanceMetrics;
  action_breakdown: Record<string, number>;
}

export interface EngagementHeatmap {
  hour: number;
  day: number;
  engagement_score: number;
  total_notifications: number;
  click_rate: number;
}
