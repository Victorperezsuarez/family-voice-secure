export interface EmailNotificationPreferences {
  id: string;
  user_id: string;
  family_id?: string;
  report_generated: boolean;
  certificate_expiring: boolean;
  weekly_digest: boolean;
  policy_violations: boolean;
  archival_failures: boolean;
  digest_frequency: 'daily' | 'weekly' | 'monthly';
  digest_day_of_week: number;
  expiry_warning_days: number;
  email_address?: string;
  include_attachments: boolean;
  pdf_format: boolean;
  created_at: string;
  updated_at: string;
}

export interface EmailDeliveryTracking {
  id: string;
  recipient_email: string;
  recipient_user_id?: string;
  subject: string;
  email_type: 'report_generated' | 'certificate_expiring' | 'weekly_digest' | 'policy_violation' | 'archival_failure';
  report_id?: string;
  certificate_id?: string;
  status: 'pending' | 'sent' | 'delivered' | 'opened' | 'failed' | 'bounced';
  sendgrid_message_id?: string;
  sent_at?: string;
  delivered_at?: string;
  opened_at?: string;
  failed_at?: string;
  error_message?: string;
  retry_count: number;
  has_attachments: boolean;
  attachment_names?: string[];
  created_at: string;
  updated_at: string;
}

export interface EmailTemplate {
  id: string;
  name: string;
  template_type: 'report_generated' | 'certificate_expiring' | 'weekly_digest' | 'policy_violation' | 'archival_failure';
  subject_template: string;
  html_template: string;
  text_template?: string;
  logo_url?: string;
  primary_color: string;
  secondary_color: string;
  available_variables: string[];
  is_active: boolean;
  is_default: boolean;
  created_at: string;
  updated_at: string;
  created_by?: string;
}
