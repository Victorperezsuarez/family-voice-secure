export interface UserBehaviorFeatures {
  // Signup features
  signupSource?: string;
  signupDevice?: string;
  signupLocation?: string;
  daysSinceSignup: number;
  
  // Engagement features
  totalSessions: number;
  avgSessionDuration: number;
  totalRecordings: number;
  totalPhotos: number;
  totalCollections: number;
  daysActive: number;
  lastActiveDaysAgo: number;
  
  // Interaction features
  notificationOpenRate: number;
  notificationClickRate: number;
  emailOpenRate: number;
  featureAdoptionScore: number;
  
  // Temporal features
  preferredTimeOfDay?: string;
  preferredDayOfWeek?: string;
  timezone?: string;
  
  // Demographic features
  ageGroup?: string;
  deviceType?: string;
  osType?: string;
  browserType?: string;
  
  // Calculated features
  engagementScore: number;
  retentionScore: number;
  activityFrequency: 'daily' | 'weekly' | 'monthly' | 'inactive';
}

export interface SegmentPrediction {
  userId: string;
  predictedSegment: string;
  confidenceScore: number;
  segmentProbabilities: Record<string, number>;
  featuresUsed: Partial<UserBehaviorFeatures>;
  modelVersion: string;
  predictionMethod: 'ml_model' | 'rule_based' | 'hybrid';
  timestamp: string;
}

export interface FeatureImportance {
  featureName: string;
  importanceScore: number;
  segment?: string;
  description: string;
}

export interface ModelMetrics {
  modelVersion: string;
  accuracy: number;
  precision: number;
  recall: number;
  f1Score: number;
  segmentMetrics: Record<string, {
    precision: number;
    recall: number;
    f1Score: number;
    support: number;
  }>;
  confusionMatrix: number[][];
  trainingSamples: number;
  validationSamples: number;
  trainingDate: string;
}

export interface SegmentDefinition {
  id: string;
  name: string;
  description: string;
  color: string;
  icon: string;
  characteristics: string[];
}
