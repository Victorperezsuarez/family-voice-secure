export interface CollaborationSession {
  id: string;
  recording_id: string;
  user_id: string;
  cursor_position: number | null;
  selection_start: number | null;
  selection_end: number | null;
  is_active: boolean;
  last_activity: string;
  user?: {
    id: string;
    full_name: string;
    avatar_url?: string;
  };
}

export interface TranscriptionEdit {
  id: string;
  recording_id: string;
  user_id: string;
  edit_type: 'insert' | 'delete' | 'replace';
  position: number;
  content?: string;
  length?: number;
  timestamp: string;
  applied: boolean;
}

export interface RecordingNote {
  id: string;
  recording_id: string;
  user_id: string;
  content: string;
  timestamp_start?: number;
  timestamp_end?: number;
  parent_note_id?: string;
  created_at: string;
  updated_at: string;
  user?: {
    id: string;
    full_name: string;
    avatar_url?: string;
  };
  replies?: RecordingNote[];
}

export interface TranscriptionVersion {
  id: string;
  recording_id: string;
  version_number: number;
  content: string;
  edited_by: string;
  edited_at: string;
  change_summary?: string;
  user?: {
    id: string;
    full_name: string;
  };
}

export interface RecordingTag {
  id: string;
  recording_id: string;
  tag: string;
  created_by: string;
  created_at: string;
}
