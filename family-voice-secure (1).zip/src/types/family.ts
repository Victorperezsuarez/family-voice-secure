export interface FamilyMember {
  id: string;
  name: string;
  relationship: string;
  birth_date?: string;
  death_date?: string;
  birth_place?: string;
  notes?: string;
  photo_url?: string;
  user_id: string;
  family_id?: string;
  created_at: string;
}

export interface Family {
  id: string;
  name: string;
  description?: string;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface FamilyUser {
  id: string;
  family_id: string;
  user_id: string;
  role: 'admin' | 'contributor' | 'view-only';
  joined_at: string;
  user_email?: string;
  user_name?: string;
}

export interface FamilyInvitation {
  id: string;
  family_id: string;
  invited_by: string;
  email: string;
  role: 'admin' | 'contributor' | 'view-only';
  token: string;
  status: 'pending' | 'accepted' | 'declined' | 'expired';
  created_at: string;
  expires_at: string;
}

export interface FamilyActivity {
  id: string;
  family_id: string;
  user_id: string;
  action_type: string;
  description: string;
  metadata?: any;
  created_at: string;
  user_email?: string;
}



export interface Recording {
  id: string;
  title: string;
  audio_url: string;
  duration: number;
  member_id: string;
  tags?: string[];
  transcription?: string;
  summary?: string;
  summary_generated_at?: string;
  created_at: string;
  family_id?: string;
  shared_with?: string[];
  created_by?: string;
  event_type?: string;
  related_recordings?: string[];
}

export interface RecordingWithMember extends Recording {
  family_member: FamilyMember;
}

export interface Milestone {
  id: string;
  family_id: string;
  title: string;
  description?: string;
  date: string;
  event_type: string;
  photo_url?: string;
  created_by: string;
  related_recordings?: string[];
  created_at: string;
  updated_at: string;
}


export interface Collection {
  id: string;
  family_id: string;
  name: string;
  description?: string;
  cover_image_url?: string;
  created_by: string;
  owner_id?: string;
  is_shared?: boolean;
  created_at: string;
  updated_at: string;
  recording_count?: number;
}

export interface RecordingCollection {
  id: string;
  recording_id: string;
  collection_id: string;
  added_at: string;
}

export interface CollectionContributor {
  id: string;
  collection_id: string;
  user_id: string;
  permission_level: 'view-only' | 'can-add' | 'can-edit';
  invited_by: string;
  joined_at: string;
  created_at: string;
  user_email?: string;
  user_name?: string;
}

export interface CollectionInvitation {
  id: string;
  collection_id: string;
  inviter_id: string;
  invitee_email: string;
  invitee_id?: string;
  permission_level: 'view-only' | 'can-add' | 'can-edit';
  status: 'pending' | 'accepted' | 'declined';
  created_at: string;
  responded_at?: string;
  collection_name?: string;
  inviter_name?: string;
}

export interface CollectionActivity {
  id: string;
  collection_id: string;
  user_id: string;
  action_type: 'created' | 'added_recording' | 'removed_recording' | 'updated' | 'added_comment' | 'invited_contributor';
  recording_id?: string;
  details?: any;
  created_at: string;
  user_email?: string;
  user_name?: string;
  recording_title?: string;
}

export interface CollectionComment {
  id: string;
  collection_id: string;
  user_id: string;
  comment_text: string;
  created_at: string;
  updated_at: string;
  user_email?: string;
  user_name?: string;
}
