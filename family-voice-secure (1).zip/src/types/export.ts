export type ExportFormat = 'zip' | 'pdf';

export interface ExportFilters {
  memberId?: string;
  collectionId?: string;
  startDate?: string;
  endDate?: string;
}

export interface ExportOptions {
  familyId: string;
  format: ExportFormat;
  filters?: ExportFilters;
  includePhotos?: boolean;
  includeTranscriptions?: boolean;
  includeAudio?: boolean;
}

export interface ExportResult {
  success: boolean;
  data?: any;
  filename?: string;
  error?: string;
}
