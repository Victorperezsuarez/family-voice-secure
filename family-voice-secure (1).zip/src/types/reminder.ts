export interface Reminder {
  id: string;
  family_id: string;
  family_member_id?: string;
  occasion: string;
  occasion_type: 'birthday' | 'anniversary' | 'holiday' | 'custom';
  occasion_date: string;
  recurrence: 'once' | 'yearly' | 'monthly' | 'weekly';
  suggested_topics: string[];
  reminder_days_before: number;
  send_email: boolean;
  send_sms: boolean;
  is_active: boolean;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface ReminderLog {
  id: string;
  reminder_id: string;
  family_member_id: string;
  sent_at: string;
  sent_via: 'email' | 'sms' | 'both';
  status: 'sent' | 'failed' | 'pending';
  error_message?: string;
  created_at: string;
}
