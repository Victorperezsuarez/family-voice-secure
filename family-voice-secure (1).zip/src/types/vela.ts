export interface VelaPersona {
  id: string;
  user_id: string;
  name: string;
  category: 'house' | 'work' | 'custom';
  profession?: string;
  description: string;
  personality_traits: Record<string, any>;
  expertise_areas: string[];
  voice_tone: string;
  prompt_template: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface VelaConversation {
  id: string;
  user_id: string;
  persona_id: string;
  message: string;
  response: string;
  context: Record<string, any>;
  user_rating?: number;
  user_feedback?: string;
  response_helpful?: boolean;
  conversation_topic?: string;
  sentiment?: 'positive' | 'neutral' | 'negative';
  response_time_ms?: number;
  created_at: string;
}

export interface VelaLearnedKnowledge {
  id: string;
  persona_id: string;
  user_id: string;
  knowledge_type: 'faq' | 'preference' | 'pattern' | 'insight';
  question?: string;
  answer?: string;
  confidence_score: number;
  usage_count: number;
  last_used_at?: string;
  metadata: Record<string, any>;
  created_at: string;
  updated_at: string;
}

export interface VelaConversationTopic {
  id: string;
  persona_id: string;
  user_id: string;
  topic: string;
  frequency: number;
  avg_rating?: number;
  last_discussed_at: string;
  created_at: string;
}

export interface VelaUserPreference {
  id: string;
  persona_id: string;

export interface VelaProactiveSuggestion {
  id: string;
  user_id: string;
  persona_id: string;
  suggestion_text: string;
  suggestion_type: 'tip' | 'reminder' | 'recommendation' | 'question';
  context?: {
    time_of_day?: string;
    recent_activity?: string;
    trigger_pattern?: string;
    day_of_week?: string;
  };
  priority: number;
  status: 'pending' | 'accepted' | 'dismissed' | 'expired';
  accepted_at?: string;
  dismissed_at?: string;
  expires_at?: string;
  created_at: string;
  updated_at: string;
}

export interface VelaSuggestionAnalytics {
  id: string;
  persona_id: string;
  suggestion_type: string;
  context_pattern?: string;
  total_shown: number;
  total_accepted: number;
  total_dismissed: number;
  acceptance_rate: number;
  avg_time_to_action?: string;
  last_shown_at?: string;
  created_at: string;
  updated_at: string;
}

  preference_key: string;
  preference_value: string;
  confidence_score: number;
  learned_from_conversations: number;
  created_at: string;
  updated_at: string;
}

export interface PersonaInsights {
  totalConversations: number;
  avgRating: number;
  topTopics: Array<{ topic: string; frequency: number }>;
  learnedFAQs: number;
  learnedPreferences: number;
  learnedPatterns: number;
  sentimentDistribution: {
    positive: number;
    neutral: number;
    negative: number;
  };
  mostHelpfulResponses: Array<{
    question: string;
    response: string;
    rating: number;
  }>;
}


export const VELA_PROFESSIONS = {
  teacher: {
    name: 'Teacher',
    icon: '👩‍🏫',
    expertise: ['education', 'lesson planning', 'student engagement', 'curriculum'],
    tone: 'encouraging and educational'
  },
  doctor: {
    name: 'Doctor',
    icon: '👨‍⚕️',
    expertise: ['health', 'medical advice', 'wellness', 'symptoms'],
    tone: 'caring and professional'
  },
  mechanic: {
    name: 'Mechanic',
    icon: '👨‍🔧',
    expertise: ['automotive', 'repairs', 'maintenance', 'diagnostics'],
    tone: 'practical and hands-on'
  },
  chef: {
    name: 'Chef',
    icon: '👨‍🍳',
    expertise: ['cooking', 'recipes', 'nutrition', 'meal planning'],
    tone: 'creative and passionate'
  },
  accountant: {
    name: 'Accountant',
    icon: '👨‍💼',
    expertise: ['finance', 'budgeting', 'taxes', 'accounting'],
    tone: 'precise and analytical'
  },
  lawyer: {
    name: 'Lawyer',
    icon: '👨‍⚖️',
    expertise: ['legal', 'contracts', 'rights', 'compliance'],
    tone: 'formal and thorough'
  }
} as const;
