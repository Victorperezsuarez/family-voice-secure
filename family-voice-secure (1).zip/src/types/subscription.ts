export interface Subscription {
  id: string;
  user_id: string;
  stripe_customer_id: string;
  stripe_subscription_id: string;
  stripe_price_id: string;
  plan_name: 'free' | 'family' | 'premium' | 'enterprise';
  status: 'active' | 'canceled' | 'past_due' | 'trialing' | 'incomplete' | 'incomplete_expired' | 'unpaid';
  current_period_start: string;
  current_period_end: string;
  cancel_at_period_end: boolean;
  canceled_at?: string;
  trial_end?: string;
  trial_reminder_sent?: boolean;
  created_at: string;
  updated_at: string;
}

export interface TrialConfig {
  id: string;
  trial_days: number;
  reminder_days_before: number;
  auto_cancel_on_trial_end: boolean;
  created_at: string;
  updated_at: string;
}


export interface Invoice {
  id: string;
  user_id: string;
  stripe_invoice_id: string;
  stripe_subscription_id: string;
  amount_paid: number;
  amount_due: number;
  currency: string;
  status: string;
  invoice_pdf?: string;
  hosted_invoice_url?: string;
  created_at: string;
}

export interface PaymentMethod {
  id: string;
  user_id: string;
  stripe_payment_method_id: string;
  type: string;
  card_brand?: string;
  card_last4?: string;
  card_exp_month?: number;
  card_exp_year?: number;
  is_default: boolean;
  created_at: string;
}
