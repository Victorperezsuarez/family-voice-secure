export type SyncOperationType = 
  | 'create_recording'
  | 'update_recording'
  | 'delete_recording'
  | 'create_milestone'
  | 'update_milestone'
  | 'create_collection'
  | 'update_collection'
  | 'create_comment'
  | 'update_profile'
  | 'upload_photo'
  | 'create_member'
  | 'update_member';


export type SyncStatus = 'pending' | 'syncing' | 'success' | 'error' | 'conflict';

export interface SyncQueueItem {
  id: string;
  type: SyncOperationType;
  data: any;
  timestamp: number;
  retryCount: number;
  status: SyncStatus;
  error?: string;
  conflictData?: any;
}

export interface SyncStats {
  pending: number;
  syncing: number;
  failed: number;
  lastSyncTime?: number;
}

export interface ConflictResolution {
  strategy: 'local' | 'remote' | 'merge' | 'manual';
  resolvedData?: any;
}
