export interface Audiobook {
  id: string;
  user_id: string;
  family_id?: string;
  title: string;
  description?: string;
  cover_image_url?: string;
  total_duration: number;
  narrator_voice_id?: string;
  background_music_id?: string;
  language?: string;
  status: 'draft' | 'generating' | 'completed' | 'failed';
  generation_progress: number;
  audio_url?: string;
  created_at: string;
  updated_at: string;
}

export interface AudiobookChapter {
  id: string;
  audiobook_id: string;
  chapter_number: number;
  title: string;
  content: string;
  audio_url?: string;
  duration?: number;
  narrator_voice_id?: string;
  voice_settings: VoiceSettings;
  background_music_id?: string;
  music_volume: number;
  status: 'pending' | 'generating' | 'completed' | 'failed';
  created_at: string;
}

export interface NarratorVoice {
  id: string;
  user_id: string;
  name: string;
  type: 'elevenlabs' | 'cloned' | 'original';
  voice_id?: string;
  sample_audio_url?: string;
  source_recording_id?: string;
  settings: VoiceSettings;
  language?: string;
  accent_quality_score?: number;
  pronunciation_notes?: string;
  is_public: boolean;
  created_at: string;
}

export interface VoiceSettings {
  model?: string;
  stability?: number;
  similarity_boost?: number;
  style?: number;
  use_speaker_boost?: boolean;
}

export interface BackgroundMusic {
  id: string;
  name: string;
  category?: string;
  audio_url: string;
  duration?: number;
  mood?: string;
  is_public: boolean;
  created_at: string;
}
