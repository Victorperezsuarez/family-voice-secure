export interface FamilyMember {
  id: string;
  name: string;
  photoUrl?: string;
  birthDate?: string;
  deathDate?: string;
  bio?: string;
  recordingCount: number;
  relationships: Relationship[];
}

export interface Relationship {
  id: string;
  type: 'parent' | 'child' | 'spouse' | 'sibling';
  memberId: string;
  relatedMemberId: string;
  startDate?: string;
  endDate?: string;
}

export interface FamilyTreeNode {
  member: FamilyMember;
  x: number;
  y: number;
  generation: number;
  children: FamilyTreeNode[];
  spouse?: FamilyTreeNode;
}

export interface TreeLayout {
  width: number;
  height: number;
  nodes: FamilyTreeNode[];
  connections: Connection[];
}

export interface Connection {
  from: string;
  to: string;
  type: 'parent-child' | 'spouse';
}
