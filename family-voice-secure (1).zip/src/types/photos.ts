export interface Photo {
  id: string;
  family_id: string;
  photo_url: string;
  thumbnail_url?: string;
  title?: string;
  description?: string;
  uploaded_by?: string;
  created_at: string;
}

export interface PhotoMetadata {
  id: string;
  photo_id: string;
  exif_data?: any;
  camera_make?: string;
  camera_model?: string;
  taken_at?: string;
  location_lat?: number;
  location_lng?: number;
  location_name?: string;
  width?: number;
  height?: number;
  file_size?: number;
  mime_type?: string;
  hash?: string;
}

export interface FaceTag {
  id: string;
  photo_id: string;
  family_member_id?: string;
  bounding_box: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  confidence: number;
  verified: boolean;
  tagged_by?: string;
}

export interface PhotoAlbum {
  id: string;
  family_id: string;
  name: string;
  description?: string;
  album_type: 'manual' | 'smart' | 'event' | 'person' | 'date';
  cover_photo_id?: string;
  smart_criteria?: any;
  photo_count?: number;
  created_at: string;
}

export interface PhotoEdit {
  crop?: { x: number; y: number; width: number; height: number };
  rotate?: number;
  filter?: string;
  brightness?: number;
  contrast?: number;
  saturation?: number;
}

export interface Slideshow {
  id: string;
  family_id: string;
  name: string;
  photo_ids: string[];
  recording_id?: string;
  duration_per_photo: number;
  transition_type: string;
  music_url?: string;
}

export interface PrintOrder {
  id: string;
  family_id: string;
  photo_ids: string[];
  print_sizes: Record<string, string>;
  quantities: Record<string, number>;
  shipping_address: any;
  total_price: number;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  order_number?: string;
}
