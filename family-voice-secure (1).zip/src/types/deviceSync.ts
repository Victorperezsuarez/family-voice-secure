export interface UserDevice {
  id: string;
  user_id: string;
  device_id: string;
  device_name: string;
  device_type: 'desktop' | 'mobile' | 'tablet';
  browser?: string;
  os?: string;
  last_active_at: string;
  push_subscription_id?: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface NotificationHistory {
  id: string;
  user_id: string;
  suggestion_id?: string;
  notification_type: string;
  title: string;
  body: string;
  data: Record<string, any>;
  urgency_level: 'low' | 'medium' | 'high' | 'critical';
  is_read: boolean;
  read_at?: string;
  read_on_device_id?: string;
  dismissed_at?: string;
  dismissed_on_device_id?: string;
  action_taken?: string;
  action_taken_at?: string;
  created_at: string;
  synced_at: string;
}

export interface DeviceNotificationPreferences {
  id: string;
  device_id: string;
  user_id: string;
  notification_type: string;
  enabled: boolean;
  min_urgency_level: 'low' | 'medium' | 'high' | 'critical';
  sound_enabled: boolean;
  vibration_enabled: boolean;
  quiet_hours_start?: string;
  quiet_hours_end?: string;
  created_at: string;
  updated_at: string;
}

export interface NotificationSyncEvent {
  id: string;
  notification_id: string;
  user_id: string;
  source_device_id?: string;
  event_type: 'read' | 'dismissed' | 'action_taken';
  synced_to_devices: string[];
  sync_status: 'pending' | 'completed' | 'failed';
  created_at: string;
  completed_at?: string;
}
