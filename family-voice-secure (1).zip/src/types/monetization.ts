export interface TemplatePricing {
  id: string;
  template_id: string;
  pricing_type: 'free' | 'one_time' | 'subscription';
  price: number;
  currency: string;
  license_type: 'personal' | 'commercial' | 'enterprise';
  stripe_price_id?: string;
  created_at: string;
  updated_at: string;
}

export interface SubscriptionTier {
  id: string;
  name: string;
  description: string;
  price: number;
  currency: string;
  billing_period: 'monthly' | 'yearly';
  features: string[];
  stripe_price_id?: string;
  active: boolean;
  created_at: string;
}

export interface TemplatePurchase {
  id: string;
  template_id: string;
  buyer_id: string;
  pricing_id: string;
  amount: number;
  currency: string;
  stripe_payment_intent_id?: string;
  status: 'pending' | 'completed' | 'failed' | 'refunded';
  license_type: string;
  purchased_at: string;
}

export interface CreatorEarnings {
  id: string;
  creator_user_id: string;
  template_id: string;
  purchase_id: string;
  gross_amount: number;
  platform_fee: number;
  net_amount: number;
  currency: string;
  status: 'pending' | 'available' | 'paid';
  payout_id?: string;
  earned_at: string;
}

export interface CreatorPayout {
  id: string;
  creator_user_id: string;
  amount: number;
  currency: string;
  stripe_payout_id?: string;
  status: 'pending' | 'processing' | 'paid' | 'failed';
  earnings_count: number;
  created_at: string;
  paid_at?: string;
}
