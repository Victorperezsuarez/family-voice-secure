export type VisibilityLevel = 'private' | 'family' | 'specific' | 'public';
export type ApprovalStatus = 'pending' | 'approved' | 'rejected';

export interface SharingLink {
  id: string;
  recording_id?: string;
  collection_id?: string;
  created_by: string;
  link_token: string;
  password_hash?: string;
  expires_at?: string;
  max_views?: number;
  current_views: number;
  allow_download: boolean;
  created_at: string;
  last_accessed_at?: string;
}

export interface RecordingApproval {
  id: string;
  recording_id: string;
  requested_by: string;
  approver_id?: string;
  status: ApprovalStatus;
  notes?: string;
  created_at: string;
  reviewed_at?: string;
}

export interface MemorialPage {
  id: string;
  family_member_id: string;
  created_by: string;
  slug: string;
  title: string;
  description?: string;
  birth_date?: string;
  death_date?: string;
  photo_url?: string;
  is_public: boolean;
  allow_tributes: boolean;
  custom_css?: string;
  created_at: string;
  updated_at: string;
}
