export interface AuditLog {
  id: string;
  created_at: string;
  user_id: string | null;
  user_email: string | null;
  action_type: string;
  action_category: 'role_change' | 'user_action' | 'system_event' | 'data_access' | 'security';
  resource_type: string | null;
  resource_id: string | null;
  description: string;
  metadata: Record<string, any>;
  ip_address: string | null;
  user_agent: string | null;
  status: 'success' | 'failure' | 'warning';
  severity: 'info' | 'warning' | 'error' | 'critical';
}

export interface AuditLogFilters {
  startDate: string | null;
  endDate: string | null;
  userId: string | null;
  actionCategory: string | null;
  actionType: string | null;
  status: string | null;
  severity: string | null;
  searchTerm: string;
}
