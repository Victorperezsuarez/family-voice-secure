export interface FeatureComputationJob {
  id: string;
  feature_name: string;
  job_status: 'pending' | 'running' | 'completed' | 'failed';
  computation_type: 'batch' | 'streaming' | 'incremental';
  started_at?: string;
  completed_at?: string;
  records_processed: number;
  error_message?: string;
  created_at: string;
}

export interface FeatureFreshness {
  id: string;
  feature_name: string;
  last_computed_at: string;
  last_updated_at: string;
  staleness_seconds: number;
  freshness_score: number;
  is_stale: boolean;
  created_at: string;
}

export interface FeatureDistributionSnapshot {
  id: string;
  feature_name: string;
  snapshot_date: string;
  mean_value: number;
  std_dev: number;
  min_value: number;
  max_value: number;
  percentile_25: number;
  percentile_50: number;
  percentile_75: number;
  sample_size: number;
  created_at: string;
}

export interface ModelRetrainingTrigger {
  id: string;
  model_name: string;
  trigger_type: 'distribution_drift' | 'performance_degradation' | 'scheduled' | 'manual';
  trigger_reason?: string;
  drift_score?: number;
  affected_features: string[];
  trigger_status: 'pending' | 'in_progress' | 'completed' | 'failed';
  triggered_at: string;
  completed_at?: string;
}

export interface StreamingFeatureUpdate {
  id: string;
  user_id: string;
  feature_name: string;
  feature_value: number;
  previous_value?: number;
  update_source?: string;
  processed_at: string;
  created_at: string;
}

export interface DriftDetectionResult {
  feature_name: string;
  drift_detected: boolean;
  drift_score: number;
  current_distribution: {
    mean: number;
    std_dev: number;
  };
  baseline_distribution: {
    mean: number;
    std_dev: number;
  };
  recommendation: string;
}
