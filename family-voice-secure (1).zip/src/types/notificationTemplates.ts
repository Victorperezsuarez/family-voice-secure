export interface NotificationTemplate {
  id: string;
  name: string;
  description?: string;
  suggestion_type: string;
  urgency_level: 'low' | 'medium' | 'high' | 'critical';
  
  // Visual elements
  title_template: string;
  body_template: string;
  icon_url?: string;
  image_url?: string;
  badge_url?: string;
  
  // Action buttons
  actions: NotificationAction[];
  
  // Progress indicators
  show_progress: boolean;
  progress_max: number;
  
  // Audio
  sound_url?: string;
  vibration_pattern?: number[];
  
  // Behavior
  require_interaction: boolean;
  auto_close_delay?: number;
  
  // Template variables
  template_variables: Record<string, string>;
  
  // Metadata
  is_active: boolean;
  is_default: boolean;
  created_by?: string;
  created_at: string;
  updated_at: string;
}

export interface NotificationAction {
  action: string;
  title: string;
  icon?: string;
}

export interface NotificationInstance {
  id: string;
  notification_id: string;
  template_id?: string;
  user_id: string;
  device_id?: string;
  
  // Rendered content
  rendered_title: string;
  rendered_body: string;
  rendered_icon?: string;
  rendered_image?: string;
  rendered_badge?: string;
  
  // Progress tracking
  current_progress: number;
  progress_max: number;
  progress_label?: string;
  
  // Action taken
  action_taken?: 'accept' | 'snooze' | 'view' | 'dismiss';
  action_timestamp?: string;
  
  created_at: string;
  updated_at: string;
}

export interface RichNotificationOptions {
  title: string;
  body: string;
  icon?: string;
  image?: string;
  badge?: string;
  actions?: NotificationAction[];
  progress?: number;
  progressMax?: number;
  progressLabel?: string;
  sound?: string;
  vibrate?: number[];
  requireInteraction?: boolean;
  autoCloseDelay?: number;
  data?: Record<string, any>;
}
