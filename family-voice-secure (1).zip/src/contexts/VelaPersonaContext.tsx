import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase-client';
import { useAuth } from './AuthContext';
import { VelaPersona, VelaProactiveSuggestion } from '@/types/vela';
import { toast } from 'sonner';
import { useDeviceSync } from '@/hooks/useDeviceSync';

interface VelaPersonaContextType {
  personas: VelaPersona[];
  activePersona: VelaPersona | null;
  suggestions: VelaProactiveSuggestion[];
  loading: boolean;
  createPersona: (persona: Partial<VelaPersona>) => Promise<void>;
  updatePersona: (id: string, updates: Partial<VelaPersona>) => Promise<void>;
  deletePersona: (id: string) => Promise<void>;
  setActivePersona: (personaId: string) => Promise<void>;
  generateSuggestions: () => Promise<void>;
  acceptSuggestion: (suggestionId: string) => Promise<void>;
  dismissSuggestion: (suggestionId: string) => Promise<void>;
  scheduleSuggestions: (config: any) => Promise<void>;
  addToQueue: (suggestion: Partial<VelaProactiveSuggestion>) => Promise<void>;
  sendPushNotification: (suggestion: VelaProactiveSuggestion, urgency: string) => Promise<void>;
  syncNotificationStatus: (notificationId: string, eventType: string) => Promise<void>;
}

const VelaPersonaContext = createContext<VelaPersonaContextType | undefined>(undefined);

export function VelaPersonaProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const { syncNotificationStatus: deviceSyncStatus } = useDeviceSync();
  const [personas, setPersonas] = useState<VelaPersona[]>([]);
  const [activePersona, setActivePersona] = useState<VelaPersona | null>(null);
  const [suggestions, setSuggestions] = useState<VelaProactiveSuggestion[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user) {
      loadPersonas();
    }
  }, [user]);

  const loadPersonas = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('vela_personas')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setPersonas(data || []);

      const active = data?.find(p => p.is_active);
      if (active) setActivePersona(active);
    } catch (error) {
      console.error('Error loading personas:', error);
    } finally {
      setLoading(false);
    }
  };

  const createPersona = async (persona: Partial<VelaPersona>) => {
    if (!user) return;
    try {
      const { data, error } = await supabase
        .from('vela_personas')
        .insert([{ ...persona, user_id: user.id }])
        .select()
        .single();

      if (error) throw error;
      setPersonas(prev => [data, ...prev]);
      toast.success('Persona created');
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  const updatePersona = async (id: string, updates: Partial<VelaPersona>) => {
    try {
      const { error } = await supabase
        .from('vela_personas')
        .update(updates)
        .eq('id', id);

      if (error) throw error;
      setPersonas(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p));
      toast.success('Persona updated');
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  const deletePersona = async (id: string) => {
    try {
      const { error } = await supabase
        .from('vela_personas')
        .delete()
        .eq('id', id);

      if (error) throw error;
      setPersonas(prev => prev.filter(p => p.id !== id));
      toast.success('Persona deleted');
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  const setActivePersonaById = async (personaId: string) => {
    const persona = personas.find(p => p.id === personaId);
    if (persona) setActivePersona(persona);
  };

  const generateSuggestions = async () => {
    if (!user) return;
    try {
      const { data, error } = await supabase.functions.invoke('generate-proactive-suggestions', {
        body: { userId: user.id, personaId: activePersona?.id }
      });
      if (error) throw error;
      setSuggestions(data.suggestions || []);
    } catch (error) {
      console.error('Error generating suggestions:', error);
    }
  };

  const acceptSuggestion = async (suggestionId: string) => {
    try {
      const { error } = await supabase
        .from('vela_proactive_suggestions')
        .update({ status: 'accepted' })
        .eq('id', suggestionId);
      if (error) throw error;
      toast.success('Suggestion accepted');
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  const dismissSuggestion = async (suggestionId: string) => {
    try {
      const { error } = await supabase
        .from('vela_proactive_suggestions')
        .update({ status: 'dismissed' })
        .eq('id', suggestionId);
      if (error) throw error;
      toast.success('Suggestion dismissed');
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  const scheduleSuggestions = async (config: any) => {
    if (!user) return;
    try {
      const { error } = await supabase.functions.invoke('schedule-vela-suggestions', {
        body: { userId: user.id, ...config }
      });
      if (error) throw error;
      toast.success('Suggestions scheduled');
    } catch (error: any) {
      toast.error('Failed to schedule');
    }
  };

  const addToQueue = async (suggestion: Partial<VelaProactiveSuggestion>) => {
    if (!user) return;
    try {
      const { error } = await supabase
        .from('vela_suggestion_queue')
        .insert({ ...suggestion, user_id: user.id });
      if (error) throw error;
      toast.success('Added to queue');
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  const sendPushNotification = async (suggestion: VelaProactiveSuggestion, urgency: string) => {
    if (!user) return;
    try {
      // Use rich notification template
      await supabase.functions.invoke('send-rich-notification', {
        body: { 
          userId: user.id,
          suggestionType: suggestion.suggestion_type,
          urgencyLevel: urgency,
          variables: {
            title: suggestion.title,
            description: suggestion.description,
            date: new Date().toLocaleDateString()
          }
        }
      });
      toast.success('Notification sent');
    } catch (error) {
      console.error('Error sending notification:', error);
      toast.error('Failed to send notification');
    }
  };


  const syncNotificationStatus = async (notificationId: string, eventType: string) => {
    await deviceSyncStatus(notificationId, eventType as any);
  };

  return (
    <VelaPersonaContext.Provider value={{
      personas,
      activePersona,
      suggestions,
      loading,
      createPersona,
      updatePersona,
      deletePersona,
      setActivePersona: setActivePersonaById,
      generateSuggestions,
      acceptSuggestion,
      dismissSuggestion,
      scheduleSuggestions,
      addToQueue,
      sendPushNotification,
      syncNotificationStatus
    }}>
      {children}
    </VelaPersonaContext.Provider>
  );
}

export function useVelaPersona() {
  const context = useContext(VelaPersonaContext);
  if (!context) throw new Error('useVelaPersona must be used within VelaPersonaProvider');
  return context;
}
