import { useState, useEffect } from 'react';
import { FamilyMember } from '@/types/familyTree';
import { FamilyTreeNode } from './FamilyTreeNode';
import { FamilyMemberDetailPanel } from './FamilyMemberDetailPanel';
import { AddRelationshipModal } from './AddRelationshipModal';
import { calculateTreeLayout } from '@/utils/familyTreeLayout';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, ZoomIn, ZoomOut, Maximize2 } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TimelineView } from './TimelineView';

const mockMembers: FamilyMember[] = [
  {
    id: '1',
    name: 'Margaret Wilson',
    photoUrl: 'https://d64gsuwffb70l.cloudfront.net/69010a7a5325e92f2828d404_1762566582762_d119a6a2.webp',
    birthDate: '1945-03-15',
    bio: 'Family matriarch, retired teacher',
    recordingCount: 12,
    relationships: [{ id: 'r1', type: 'parent', memberId: '1', relatedMemberId: '2' }]
  },
  {
    id: '2',
    name: 'Robert Wilson',
    photoUrl: 'https://d64gsuwffb70l.cloudfront.net/69010a7a5325e92f2828d404_1762566587085_3a384a46.webp',
    birthDate: '1970-06-20',
    recordingCount: 8,
    relationships: [
      { id: 'r2', type: 'child', memberId: '2', relatedMemberId: '1' },
      { id: 'r3', type: 'parent', memberId: '2', relatedMemberId: '4' }
    ]
  },
  {
    id: '3',
    name: 'Sarah Wilson',
    photoUrl: 'https://d64gsuwffb70l.cloudfront.net/69010a7a5325e92f2828d404_1762566588870_e4bb410b.webp',
    birthDate: '1972-09-10',
    recordingCount: 6,
    relationships: [{ id: 'r4', type: 'spouse', memberId: '3', relatedMemberId: '2' }]
  },
  {
    id: '4',
    name: 'Emily Wilson',
    photoUrl: 'https://d64gsuwffb70l.cloudfront.net/69010a7a5325e92f2828d404_1762566593526_4c06f476.webp',
    birthDate: '1995-12-05',
    recordingCount: 4,
    relationships: [{ id: 'r5', type: 'child', memberId: '4', relatedMemberId: '2' }]
  }
];

export function FamilyTreeVisualization() {
  const [members] = useState<FamilyMember[]>(mockMembers);
  const [selectedMember, setSelectedMember] = useState<FamilyMember | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [zoom, setZoom] = useState(1);
  const [showAddRelModal, setShowAddRelModal] = useState(false);
  const [activeTab, setActiveTab] = useState('tree');

  const layout = calculateTreeLayout(members);
  const filteredMembers = members.filter(m =>
    m.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const mockRecordings = selectedMember ? [
    { id: '1', title: 'Childhood Memories', date: '2024-01-15' },
    { id: '2', title: 'Family Stories', date: '2024-02-20' }
  ] : [];

  return (
    <div className="h-full flex gap-4">
      <div className="flex-1 flex flex-col gap-4">
        <Card className="p-4">
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search family members..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <Button variant="outline" size="icon" onClick={() => setZoom(z => Math.min(z + 0.1, 2))}>
              <ZoomIn className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="icon" onClick={() => setZoom(z => Math.max(z - 0.1, 0.5))}>
              <ZoomOut className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="icon" onClick={() => setZoom(1)}>
              <Maximize2 className="h-4 w-4" />
            </Button>
          </div>
        </Card>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1">
          <TabsList>
            <TabsTrigger value="tree">Family Tree</TabsTrigger>
            <TabsTrigger value="timeline">Timeline</TabsTrigger>
          </TabsList>
          <TabsContent value="tree" className="h-full">
            <Card className="h-full overflow-auto">
              <div
                className="relative"
                style={{
                  width: `${layout.width * zoom}px`,
                  height: `${layout.height * zoom}px`,
                  transform: `scale(${zoom})`,
                  transformOrigin: 'top left'
                }}
              >
                <svg className="absolute inset-0 pointer-events-none" style={{ width: '100%', height: '100%' }}>
                  {layout.connections.map((conn, idx) => {
                    const fromNode = layout.nodes.find(n => n.member.id === conn.from);
                    const toNode = layout.nodes.find(n => n.member.id === conn.to);
                    if (!fromNode || !toNode) return null;
                    return (
                      <line
                        key={idx}
                        x1={fromNode.x}
                        y1={fromNode.y}
                        x2={toNode.x}
                        y2={toNode.y}
                        stroke="#94a3b8"
                        strokeWidth="2"
                      />
                    );
                  })}
                </svg>
                {layout.nodes.map(node => (
                  <FamilyTreeNode
                    key={node.member.id}
                    member={node.member}
                    x={node.x}
                    y={node.y}
                    isSelected={selectedMember?.id === node.member.id}
                    onClick={() => setSelectedMember(node.member)}
                  />
                ))}
              </div>
            </Card>
          </TabsContent>
          <TabsContent value="timeline" className="h-full">
            <TimelineView />
          </TabsContent>
        </Tabs>
      </div>

      {selectedMember && (
        <div className="w-80">
          <FamilyMemberDetailPanel
            member={selectedMember}
            recordings={mockRecordings}
            onAddRelationship={() => setShowAddRelModal(true)}
            onPlayRecording={(id) => console.log('Play recording:', id)}
          />
        </div>
      )}

      {selectedMember && (
        <AddRelationshipModal
          isOpen={showAddRelModal}
          onClose={() => setShowAddRelModal(false)}
          sourceMember={selectedMember}
          availableMembers={members.filter(m => m.id !== selectedMember.id)}
          onAdd={(type, targetId) => console.log('Add relationship:', type, targetId)}
        />
      )}
    </div>
  );
}
