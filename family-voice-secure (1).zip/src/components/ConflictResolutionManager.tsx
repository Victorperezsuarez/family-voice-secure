import { useState, useEffect } from 'react';
import { useOfflineSync } from '@/contexts/OfflineSyncContext';
import { ConflictResolutionDialog } from '@/components/ConflictResolutionDialog';
import { syncQueue } from '@/utils/syncQueue';
import { toast } from 'sonner';

export function ConflictResolutionManager() {
  const { queueItems } = useOfflineSync();
  const [currentConflict, setCurrentConflict] = useState<any>(null);
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    const conflictItems = queueItems.filter(item => item.status === 'conflict');
    if (conflictItems.length > 0 && !isOpen) {
      const item = conflictItems[0];
      if (item.conflictData) {
        setCurrentConflict({
          id: item.id,
          recordingId: item.data?.id || '',
          conflictType: 'transcription_edit',
          conflictRange: item.conflictData.range || { start: 0, end: 100 },
          versionAText: item.data?.transcription || '',
          versionBText: item.conflictData.remoteVersion || '',
          userA: {
            id: item.data?.userId || '',
            name: 'You',
            avatar: item.data?.userAvatar
          },
          userB: {
            id: item.conflictData.userId || '',
            name: item.conflictData.userName || 'Other User',
            avatar: item.conflictData.userAvatar
          },
          createdAt: new Date(item.timestamp).toISOString()
        });
        setIsOpen(true);
      }
    }
  }, [queueItems, isOpen]);

  const handleResolve = async (
    conflictId: string,
    resolution: 'keep_a' | 'keep_b' | 'manual_merge',
    text?: string
  ) => {
    try {
      if (resolution === 'keep_a') {
        await syncQueue.resolveConflict(conflictId, { strategy: 'local' });
        toast.success('Conflict resolved - keeping your version');
      } else if (resolution === 'keep_b') {
        await syncQueue.resolveConflict(conflictId, { strategy: 'remote' });
        toast.success('Conflict resolved - keeping remote version');
      } else if (resolution === 'manual_merge' && text) {
        await syncQueue.resolveConflict(conflictId, { strategy: 'merge', resolvedData: text });
        toast.success('Conflict resolved - merged manually');
      }
      setIsOpen(false);
      setCurrentConflict(null);
    } catch (error) {
      toast.error('Failed to resolve conflict');
      throw error;
    }
  };

  return (
    <ConflictResolutionDialog
      open={isOpen}
      onOpenChange={setIsOpen}
      conflict={currentConflict}
      onResolve={handleResolve}
    />
  );
}
