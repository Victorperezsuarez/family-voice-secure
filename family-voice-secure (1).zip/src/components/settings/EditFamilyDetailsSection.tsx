import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase-client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';

interface EditFamilyDetailsSectionProps {
  familyId: string;
}

export function EditFamilyDetailsSection({ familyId }: EditFamilyDetailsSectionProps) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadFamilyDetails();
  }, [familyId]);

  const loadFamilyDetails = async () => {
    const { data } = await supabase
      .from('families')
      .select('name, description')
      .eq('id', familyId)
      .single();

    if (data) {
      setName(data.name || '');
      setDescription(data.description || '');
    }
  };

  const handleSave = async () => {
    setLoading(true);
    try {
      const { error } = await supabase
        .from('families')
        .update({ name, description, updated_at: new Date().toISOString() })
        .eq('id', familyId);

      if (error) throw error;

      // Log activity
      await supabase.from('family_activity_logs').insert({
        family_id: familyId,
        user_id: (await supabase.auth.getUser()).data.user?.id,
        action_type: 'family_updated',
        action_description: 'Updated family details',
        metadata: { name, description }
      });

      toast.success('Family details updated successfully');
    } catch (error: any) {
      toast.error('Failed to update family details');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Family Details</CardTitle>
        <CardDescription>Update your family name and description</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="name">Family Name</Label>
          <Input
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Enter family name"
          />
        </div>
        <div>
          <Label htmlFor="description">Description</Label>
          <Textarea
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Enter family description"
            rows={4}
          />
        </div>
        <Button onClick={handleSave} disabled={loading}>
          {loading ? 'Saving...' : 'Save Changes'}
        </Button>
      </CardContent>
    </Card>
  );
}
