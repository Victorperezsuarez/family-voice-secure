import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase-client';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { PermissionSelector } from './PermissionSelector';
import { PermissionTemplatesManager } from './PermissionTemplatesManager';
import { TemplateUpdateNotifications } from '../TemplateUpdateNotifications';
import { Plus, Edit, Trash2, BookTemplate } from 'lucide-react';
import { toast } from 'sonner';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';



interface CustomRole {
  id: string;
  name: string;
  description: string;
  is_system_role: boolean;
  permission_count?: number;
}

interface Permission {
  name: string;
  description: string;
  category: string;
}

interface CustomRolesManagerProps {
  familyId: string;
}

export function CustomRolesManager({ familyId }: CustomRolesManagerProps) {
  const [roles, setRoles] = useState<CustomRole[]>([]);
  const [permissions, setPermissions] = useState<Permission[]>([]);
  const [showDialog, setShowDialog] = useState(false);
  const [editingRole, setEditingRole] = useState<CustomRole | null>(null);
  const [roleName, setRoleName] = useState('');
  const [roleDesc, setRoleDesc] = useState('');
  const [selectedPerms, setSelectedPerms] = useState<Set<string>>(new Set());

  useEffect(() => {
    loadRoles();
    loadPermissions();
  }, [familyId]);

  const loadRoles = async () => {
    const { data, error } = await supabase
      .from('custom_roles')
      .select(`
        *,
        role_permissions(count)
      `)
      .eq('family_id', familyId)
      .order('is_system_role', { ascending: false })
      .order('name');

    if (!error && data) {
      setRoles(data.map(r => ({
        ...r,
        permission_count: r.role_permissions?.[0]?.count || 0
      })));
    }
  };

  const loadPermissions = async () => {
    const { data } = await supabase
      .from('permissions')
      .select('*')
      .order('category')
      .order('name');
    
    if (data) setPermissions(data);
  };

  const openCreateDialog = () => {
    setEditingRole(null);
    setRoleName('');
    setRoleDesc('');
    setSelectedPerms(new Set());
    setShowDialog(true);
  };

  const handleApplyTemplate = (permissions: Record<string, boolean>) => {
    const permNames = Object.entries(permissions)
      .filter(([_, granted]) => granted)
      .map(([name]) => name);
    setSelectedPerms(new Set(permNames));
  };


  const openEditDialog = async (role: CustomRole) => {
    setEditingRole(role);
    setRoleName(role.name);
    setRoleDesc(role.description || '');
    
    const { data } = await supabase
      .from('role_permissions')
      .select('permission_name')
      .eq('role_id', role.id);
    
    setSelectedPerms(new Set(data?.map(p => p.permission_name) || []));
    setShowDialog(true);
  };

  const handleSave = async () => {
    if (!roleName.trim()) {
      toast.error('Role name is required');
      return;
    }

    try {
      if (editingRole) {
        await supabase
          .from('custom_roles')
          .update({ name: roleName, description: roleDesc })
          .eq('id', editingRole.id);

        await supabase.from('role_permissions').delete().eq('role_id', editingRole.id);
        
        if (selectedPerms.size > 0) {
          await supabase.from('role_permissions').insert(
            Array.from(selectedPerms).map(p => ({
              role_id: editingRole.id,
              permission_name: p
            }))
          );
        }
        
        toast.success('Role updated');
      } else {
        const { data: newRole } = await supabase
          .from('custom_roles')
          .insert({ family_id: familyId, name: roleName, description: roleDesc })
          .select()
          .single();

        if (newRole && selectedPerms.size > 0) {
          await supabase.from('role_permissions').insert(
            Array.from(selectedPerms).map(p => ({
              role_id: newRole.id,
              permission_name: p
            }))
          );
        }
        
        toast.success('Role created');
      }

      setShowDialog(false);
      loadRoles();
    } catch (error) {
      toast.error('Failed to save role');
    }
  };

  const handleDelete = async (roleId: string) => {
    if (!confirm('Delete this role? Members will need to be reassigned.')) return;
    
    await supabase.from('custom_roles').delete().eq('id', roleId);
    toast.success('Role deleted');
    loadRoles();
  };

  return (
    <Tabs defaultValue="roles" className="space-y-4">
      <TabsList>
        <TabsTrigger value="roles">Custom Roles</TabsTrigger>
        <TabsTrigger value="templates">
          <BookTemplate className="w-4 h-4 mr-2" />
          Templates
        </TabsTrigger>
      </TabsList>

      <TabsContent value="roles" className="space-y-4">
        <div className="flex justify-between items-center">
          <p className="text-sm text-muted-foreground">
            Create custom roles with specific permissions
          </p>
          <Button onClick={openCreateDialog} size="sm">
            <Plus className="w-4 h-4 mr-2" />
            Create Role
          </Button>
        </div>

        <div className="grid gap-3">
          {roles.map(role => (
            <Card key={role.id} className="p-4">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h4 className="font-semibold">{role.name}</h4>
                    {role.is_system_role && (
                      <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded">
                        System
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">
                    {role.description}
                  </p>
                  <p className="text-xs text-muted-foreground mt-2">
                    {role.permission_count} permissions
                  </p>
                </div>
                {!role.is_system_role && (
                  <div className="flex gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => openEditDialog(role)}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDelete(role.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                )}
              </div>
            </Card>
          ))}
        </div>
      </TabsContent>

      <TabsContent value="templates" className="space-y-4">
        <TemplateUpdateNotifications familyId={familyId} />
        <PermissionTemplatesManager 
          familyId={familyId} 
          onApplyTemplate={handleApplyTemplate}
        />
      </TabsContent>


      <Dialog open={showDialog} onOpenChange={setShowDialog}>

        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingRole ? 'Edit Role' : 'Create Custom Role'}
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <Label>Role Name</Label>
              <Input
                value={roleName}
                onChange={(e) => setRoleName(e.target.value)}
                placeholder="e.g., Editor, Moderator"
              />
            </div>
            
            <div>
              <Label>Description</Label>
              <Textarea
                value={roleDesc}
                onChange={(e) => setRoleDesc(e.target.value)}
                placeholder="Describe what this role can do"
              />
            </div>

            <div>
              <Label>Permissions</Label>
              <PermissionSelector
                permissions={permissions}
                selectedPermissions={selectedPerms}
                onPermissionToggle={(perm) => {
                  const newPerms = new Set(selectedPerms);
                  if (newPerms.has(perm)) {
                    newPerms.delete(perm);
                  } else {
                    newPerms.add(perm);
                  }
                  setSelectedPerms(newPerms);
                }}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleSave}>
              {editingRole ? 'Update' : 'Create'} Role
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Tabs>
  );
}
