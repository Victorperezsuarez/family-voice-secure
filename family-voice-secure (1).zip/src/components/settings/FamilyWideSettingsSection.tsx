import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase-client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

interface FamilySettings {
  default_privacy: string;
  auto_backup_enabled: boolean;
  backup_frequency: string;
  notification_preferences: any;
}

export function FamilyWideSettingsSection({ familyId }: { familyId: string }) {
  const [settings, setSettings] = useState<FamilySettings>({
    default_privacy: 'family',
    auto_backup_enabled: false,
    backup_frequency: 'weekly',
    notification_preferences: {
      email_on_new_recording: true,
      email_on_backup: true,
      email_on_member_join: true
    }
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadSettings();
  }, [familyId]);

  const loadSettings = async () => {
    const { data } = await supabase
      .from('family_settings')
      .select('*')
      .eq('family_id', familyId)
      .single();

    if (data) setSettings(data);
  };

  const handleSave = async () => {
    setLoading(true);
    try {
      const { error } = await supabase
        .from('family_settings')
        .upsert({
          family_id: familyId,
          ...settings,
          updated_at: new Date().toISOString()
        });

      if (error) throw error;

      await supabase.from('family_activity_logs').insert({
        family_id: familyId,
        user_id: (await supabase.auth.getUser()).data.user?.id,
        action_type: 'settings_updated',
        action_description: 'Updated family-wide settings'
      });

      toast.success('Settings saved successfully');
    } catch (error) {
      toast.error('Failed to save settings');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Privacy Settings</CardTitle>
          <CardDescription>Default privacy level for new recordings</CardDescription>
        </CardHeader>
        <CardContent>
          <Select value={settings.default_privacy} onValueChange={(value) => setSettings({ ...settings, default_privacy: value })}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="private">Private (Creator Only)</SelectItem>
              <SelectItem value="family">Family (All Members)</SelectItem>
              <SelectItem value="public">Public (Anyone with Link)</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Backup Preferences</CardTitle>
          <CardDescription>Configure automatic backup settings</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <Label>Enable Auto-Backup</Label>
            <Switch checked={settings.auto_backup_enabled} onCheckedChange={(checked) => setSettings({ ...settings, auto_backup_enabled: checked })} />
          </div>
          <div>
            <Label>Backup Frequency</Label>
            <Select value={settings.backup_frequency} onValueChange={(value) => setSettings({ ...settings, backup_frequency: value })}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="daily">Daily</SelectItem>
                <SelectItem value="weekly">Weekly</SelectItem>
                <SelectItem value="monthly">Monthly</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Notification Preferences</CardTitle>
          <CardDescription>Choose which events trigger email notifications</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <Label>New Recording Added</Label>
            <Switch checked={settings.notification_preferences.email_on_new_recording} onCheckedChange={(checked) => setSettings({ ...settings, notification_preferences: { ...settings.notification_preferences, email_on_new_recording: checked } })} />
          </div>
          <div className="flex items-center justify-between">
            <Label>Backup Completed</Label>
            <Switch checked={settings.notification_preferences.email_on_backup} onCheckedChange={(checked) => setSettings({ ...settings, notification_preferences: { ...settings.notification_preferences, email_on_backup: checked } })} />
          </div>
          <div className="flex items-center justify-between">
            <Label>New Member Joined</Label>
            <Switch checked={settings.notification_preferences.email_on_member_join} onCheckedChange={(checked) => setSettings({ ...settings, notification_preferences: { ...settings.notification_preferences, email_on_member_join: checked } })} />
          </div>
        </CardContent>
      </Card>

      <Button onClick={handleSave} disabled={loading} className="w-full">
        {loading ? 'Saving...' : 'Save All Settings'}
      </Button>
    </div>
  );
}
