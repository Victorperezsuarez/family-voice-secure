import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase-client';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BookTemplate, Plus, Trash2, Copy, Check, Upload, Download, Share2, Globe, BarChart3 } from 'lucide-react';

import { toast } from 'sonner';
import { PermissionSelector } from './PermissionSelector';
import { TemplateMarketplace } from '../TemplateMarketplace';
import { PublishValidationDialog } from '../PublishValidationDialog';



interface Template {
  id: string;
  name: string;
  description: string;
  permissions: Record<string, boolean>;
  is_system_template: boolean;
}

interface Props {
  familyId: string;
  onApplyTemplate?: (permissions: Record<string, boolean>) => void;
}

export function PermissionTemplatesManager({ familyId, onApplyTemplate }: Props) {
  const [templates, setTemplates] = useState<Template[]>([]);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showPublishDialog, setShowPublishDialog] = useState(false);
  const [showValidationDialog, setShowValidationDialog] = useState(false);
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null);
  const [publishCategory, setPublishCategory] = useState('General');
  const [publishTags, setPublishTags] = useState('');
  const [importJson, setImportJson] = useState('');
  const [templateName, setTemplateName] = useState('');
  const [templateDesc, setTemplateDesc] = useState('');
  const [selectedPerms, setSelectedPerms] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(false);




  useEffect(() => {
    loadTemplates();
  }, [familyId]);

  const loadTemplates = async () => {
    const { data, error } = await supabase
      .from('permission_templates')
      .select('*')
      .or(`family_id.eq.${familyId},is_system_template.eq.true`)
      .order('is_system_template', { ascending: false })
      .order('name');

    if (!error && data) {
      setTemplates(data);
    }
  };

  const handleCreate = async () => {
    if (!templateName.trim()) {
      toast.error('Please enter a template name');
      return;
    }

    setLoading(true);
    const permissions = Object.fromEntries(
      Array.from(selectedPerms).map(p => [p, true])
    );

    const { error } = await supabase.from('permission_templates').insert({
      family_id: familyId,
      name: templateName,
      description: templateDesc,
      permissions
    });

    setLoading(false);

    if (error) {
      toast.error('Failed to create template');
    } else {
      toast.success('Template created successfully');
      setShowCreateDialog(false);
      setTemplateName('');
      setTemplateDesc('');
      setSelectedPerms(new Set());
      loadTemplates();
    }
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase
      .from('permission_templates')
      .delete()
      .eq('id', id);

    if (error) {
      toast.error('Failed to delete template');
    } else {
      toast.success('Template deleted');
      loadTemplates();
    }
  };

  const handleApply = (template: Template) => {
    if (onApplyTemplate) {
      onApplyTemplate(template.permissions);
      toast.success(`Applied "${template.name}" template`);
    }
  };

  const handleExport = (template: Template) => {
    const exportData = {
      name: template.name,
      description: template.description,
      permissions: template.permissions,
      version: 1,
      exported_at: new Date().toISOString()
    };
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${template.name.replace(/\s+/g, '_')}_template.json`;
    a.click();
    toast.success('Template exported');
  };

  const handleImportJson = async () => {
    try {
      const data = JSON.parse(importJson);
      const { error } = await supabase.from('permission_templates').insert({
        family_id: familyId,
        name: data.name,
        description: data.description,
        permissions: data.permissions
      });
      if (error) throw error;
      toast.success('Template imported successfully');
      setShowImportDialog(false);
      setImportJson('');
      loadTemplates();
    } catch (error) {
      toast.error('Invalid template JSON');
    }
  };

  const handlePublish = async () => {
    if (!selectedTemplate) return;
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('publish-template', {
        body: {
          templateId: selectedTemplate.id,
          familyId,
          category: publishCategory,
          tags: publishTags.split(',').map(t => t.trim()).filter(Boolean)
        }
      });
      if (error) throw error;
      toast.success('Template published to marketplace');
      setShowPublishDialog(false);
    } catch (error) {
      toast.error('Failed to publish template');
    } finally {
      setLoading(false);
    }
  };

  const handleImportFromMarketplace = async (template: any) => {
    const { error } = await supabase.from('permission_templates').insert({
      family_id: familyId,
      name: template.name,
      description: template.description,
      permissions: template.permissions
    });
    if (error) {
      toast.error('Failed to import template');
    } else {
      await supabase.from('template_subscriptions').insert({
        family_id: familyId,
        community_template_id: template.id,
        subscribed_version: template.current_version,
        current_version: template.current_version
      });
      loadTemplates();
    }
  };

  return (
    <Tabs defaultValue="my-templates" className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold">Permission Templates</h3>
          <p className="text-sm text-muted-foreground">
            Save and share permission combinations
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setShowImportDialog(true)}>
            <Upload className="w-4 h-4 mr-2" />
            Import
          </Button>
          <Button onClick={() => setShowCreateDialog(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Create
          </Button>
        </div>
      </div>

      <TabsList>
        <TabsTrigger value="my-templates">My Templates</TabsTrigger>
        <TabsTrigger value="marketplace">
          <Globe className="w-4 h-4 mr-2" />
          Marketplace
        </TabsTrigger>
      </TabsList>

      <TabsContent value="my-templates" className="space-y-4">
        <div className="grid gap-4 md:grid-cols-2">
          {templates.map(template => (
            <Card key={template.id} className="p-4">
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center gap-2">
                  <BookTemplate className="w-5 h-5 text-primary" />
                  <div>
                    <h4 className="font-semibold">{template.name}</h4>
                    {template.is_system_template && (
                      <Badge variant="secondary" className="text-xs mt-1">System</Badge>
                    )}
                  </div>
                </div>
                <div className="flex gap-1">
                  {!template.is_system_template && (
                    <>
                      <Button variant="ghost" size="sm" onClick={() => handleExport(template)}>
                        <Download className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="sm" onClick={() => {
                        setSelectedTemplate(template);
                        setShowPublishDialog(true);
                      }}>
                        <Share2 className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="sm" onClick={() => handleDelete(template.id)}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </>
                  )}
                </div>
              </div>
              
              <p className="text-sm text-muted-foreground mb-3">{template.description}</p>
              
              <div className="flex flex-wrap gap-1 mb-3">
                {Object.entries(template.permissions)
                  .filter(([_, granted]) => granted)
                  .map(([perm]) => (
                    <Badge key={perm} variant="outline" className="text-xs">
                      <Check className="w-3 h-3 mr-1" />
                      {perm.replace('can_', '').replace(/_/g, ' ')}
                    </Badge>
                  ))}
              </div>

              <Button variant="outline" size="sm" className="w-full" onClick={() => handleApply(template)}>
                <Copy className="w-4 h-4 mr-2" />
                Apply Template
              </Button>
            </Card>
          ))}
        </div>
      </TabsContent>

      <TabsContent value="marketplace">
        <TemplateMarketplace familyId={familyId} onImport={handleImportFromMarketplace} />
      </TabsContent>

      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Create Permission Template</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Template Name</Label>
              <Input value={templateName} onChange={(e) => setTemplateName(e.target.value)} placeholder="e.g., Content Editor" />
            </div>
            <div>
              <Label>Description</Label>
              <Textarea value={templateDesc} onChange={(e) => setTemplateDesc(e.target.value)} placeholder="Describe what this template is for..." rows={2} />
            </div>
            <div>
              <Label className="mb-2 block">Permissions</Label>
              <PermissionSelector selectedPermissions={selectedPerms} onPermissionChange={setSelectedPerms} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreateDialog(false)}>Cancel</Button>
            <Button onClick={handleCreate} disabled={loading}>Create Template</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Import Template from JSON</DialogTitle>
          </DialogHeader>
          <div>
            <Label>Paste Template JSON</Label>
            <Textarea value={importJson} onChange={(e) => setImportJson(e.target.value)} rows={10} placeholder='{"name": "...", "permissions": {...}}' />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowImportDialog(false)}>Cancel</Button>
            <Button onClick={handleImportJson} disabled={loading}>Import</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showPublishDialog} onOpenChange={setShowPublishDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Publish to Marketplace</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Category</Label>
              <Input value={publishCategory} onChange={(e) => setPublishCategory(e.target.value)} placeholder="e.g., Content Management" />
            </div>
            <div>
              <Label>Tags (comma-separated)</Label>
              <Input value={publishTags} onChange={(e) => setPublishTags(e.target.value)} placeholder="e.g., editor, content, basic" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowPublishDialog(false)}>Cancel</Button>
            <Button onClick={() => {
              setShowPublishDialog(false);
              setShowValidationDialog(true);
            }} disabled={loading}>
              Next: Validate
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <PublishValidationDialog
        open={showValidationDialog}
        onOpenChange={setShowValidationDialog}
        templateId={selectedTemplate?.id || ''}
        onPublish={handlePublish}
      />
    </Tabs>
  );
}
