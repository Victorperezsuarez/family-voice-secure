import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface QualityMetrics {
  before: {
    noise_level: number;
    clarity_score: number;
    volume_consistency: number;
    echo_level: number;
    speech_intelligibility: number;
  };
  after: {
    noise_level: number;
    clarity_score: number;
    volume_consistency: number;
    echo_level: number;
    speech_intelligibility: number;
  };
  improvements: {
    noise_reduction_db: number;
    clarity_improvement: number;
    volume_normalized: boolean;
    echo_reduced: boolean;
    voices_separated: number;
  };
  recommendations?: string[];
}

interface QualityMetricsDisplayProps {
  metrics: QualityMetrics;
}

export default function QualityMetricsDisplay({ metrics }: QualityMetricsDisplayProps) {
  const MetricRow = ({ label, before, after, inverse = false }: any) => {
    const improvement = inverse ? before - after : after - before;
    const improved = improvement > 0;
    
    return (
      <div className="space-y-2">
        <div className="flex items-center justify-between text-sm">
          <span className="font-medium">{label}</span>
          <div className="flex items-center gap-2">
            <span className="text-muted-foreground">{before}%</span>
            <span className="text-muted-foreground">→</span>
            <span className="font-semibold">{after}%</span>
            {improved && (
              <Badge variant="secondary" className="ml-1">
                {inverse ? <TrendingDown className="w-3 h-3" /> : <TrendingUp className="w-3 h-3" />}
                {Math.abs(improvement)}%
              </Badge>
            )}
          </div>
        </div>
        <div className="flex gap-2">
          <Progress value={before} className="h-2 opacity-50" />
          <Progress value={after} className="h-2" />
        </div>
      </div>
    );
  };

  return (
    <Card className="p-4 space-y-4">
      <h3 className="font-semibold text-lg">Quality Improvement Metrics</h3>
      
      <div className="space-y-4">
        <MetricRow label="Speech Clarity" before={metrics.before.clarity_score} 
          after={metrics.after.clarity_score} />
        <MetricRow label="Background Noise" before={metrics.before.noise_level} 
          after={metrics.after.noise_level} inverse />
        <MetricRow label="Volume Consistency" before={metrics.before.volume_consistency}
          after={metrics.after.volume_consistency} />
        <MetricRow label="Echo Level" before={metrics.before.echo_level}
          after={metrics.after.echo_level} inverse />
        <MetricRow label="Speech Intelligibility" before={metrics.before.speech_intelligibility}
          after={metrics.after.speech_intelligibility} />
      </div>

      {metrics.recommendations && metrics.recommendations.length > 0 && (
        <div className="pt-4 border-t">
          <h4 className="font-medium mb-2">Recommendations</h4>
          <ul className="space-y-1 text-sm text-muted-foreground">
            {metrics.recommendations.map((rec, i) => (
              <li key={i}>• {rec}</li>
            ))}
          </ul>
        </div>
      )}
    </Card>
  );
}
