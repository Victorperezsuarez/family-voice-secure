import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Card } from '@/components/ui/card';

interface EnhancementSettings {
  intensity: 'light' | 'medium' | 'aggressive';
  noise_reduction: boolean;
  volume_normalization: boolean;
  echo_reduction: boolean;
  clarity_enhancement: boolean;
  voice_separation: boolean;
}

interface AudioEnhancementSettingsProps {
  settings: EnhancementSettings;
  onChange: (settings: EnhancementSettings) => void;
}

export default function AudioEnhancementSettings({ settings, onChange }: AudioEnhancementSettingsProps) {
  const updateSetting = (key: keyof EnhancementSettings, value: any) => {
    onChange({ ...settings, [key]: value });
  };

  return (
    <Card className="p-4 space-y-4">
      <div>
        <Label className="text-base font-semibold mb-3 block">Enhancement Intensity</Label>
        <RadioGroup value={settings.intensity} onValueChange={(v) => updateSetting('intensity', v)}>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="light" id="light" />
            <Label htmlFor="light">Light - Minimal processing, preserve natural sound</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="medium" id="medium" />
            <Label htmlFor="medium">Medium - Balanced enhancement</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="aggressive" id="aggressive" />
            <Label htmlFor="aggressive">Aggressive - Maximum quality improvement</Label>
          </div>
        </RadioGroup>
      </div>

      <div className="space-y-3 pt-2">
        <Label className="text-base font-semibold">Enhancement Features</Label>
        
        <div className="flex items-center justify-between">
          <Label htmlFor="noise">Background Noise Reduction</Label>
          <Switch id="noise" checked={settings.noise_reduction} 
            onCheckedChange={(v) => updateSetting('noise_reduction', v)} />
        </div>

        <div className="flex items-center justify-between">
          <Label htmlFor="volume">Volume Normalization</Label>
          <Switch id="volume" checked={settings.volume_normalization}
            onCheckedChange={(v) => updateSetting('volume_normalization', v)} />
        </div>

        <div className="flex items-center justify-between">
          <Label htmlFor="echo">Echo Reduction</Label>
          <Switch id="echo" checked={settings.echo_reduction}
            onCheckedChange={(v) => updateSetting('echo_reduction', v)} />
        </div>

        <div className="flex items-center justify-between">
          <Label htmlFor="clarity">Speech Clarity Enhancement</Label>
          <Switch id="clarity" checked={settings.clarity_enhancement}
            onCheckedChange={(v) => updateSetting('clarity_enhancement', v)} />
        </div>

        <div className="flex items-center justify-between">
          <Label htmlFor="separation">Overlapping Voice Separation</Label>
          <Switch id="separation" checked={settings.voice_separation}
            onCheckedChange={(v) => updateSetting('voice_separation', v)} />
        </div>
      </div>
    </Card>
  );
}
