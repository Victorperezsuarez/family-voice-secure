import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { CheckCircle, XCircle, Settings, Sparkles, AlertCircle } from 'lucide-react';

interface EnhancementRecommendation {
  intensity: 'light' | 'medium' | 'aggressive';
  confidence: number;
  features: {
    [key: string]: {
      enabled: boolean;
      level?: string;
      target_db?: number;
      confidence: number;
    };
  };
  reasoning: string;
  user_preference_applied?: boolean;
}

interface RecordingAnalysis {
  environment: string;
  noise_type: string;
  noise_level: string;
  speaker_count: number;
  audio_quality: string;
  quality_issues: string[];
  recording_device: string;
}

interface Props {
  analysis: RecordingAnalysis;
  recommendation: EnhancementRecommendation;
  onAccept: () => void;
  onModify: () => void;
  onReject: () => void;
  isLoading?: boolean;
}

export function EnhancementRecommendationCard({
  analysis,
  recommendation,
  onAccept,
  onModify,
  onReject,
  isLoading = false
}: Props) {
  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.85) return 'text-green-600';
    if (confidence >= 0.7) return 'text-yellow-600';
    return 'text-orange-600';
  };

  const getIntensityColor = (intensity: string) => {
    switch (intensity) {
      case 'light': return 'bg-blue-100 text-blue-800';
      case 'medium': return 'bg-purple-100 text-purple-800';
      case 'aggressive': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card className="border-2 border-primary/20">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary" />
            <CardTitle>AI Enhancement Recommendation</CardTitle>
          </div>
          <Badge className={getIntensityColor(recommendation.intensity)}>
            {recommendation.intensity.toUpperCase()}
          </Badge>
        </div>
        <CardDescription>
          Confidence: <span className={getConfidenceColor(recommendation.confidence)}>
            {(recommendation.confidence * 100).toFixed(0)}%
          </span>
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Analysis Summary */}
        <div className="bg-muted/50 p-3 rounded-lg space-y-2">
          <h4 className="font-semibold text-sm">Recording Analysis</h4>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div>Environment: <Badge variant="outline">{analysis.environment}</Badge></div>
            <div>Quality: <Badge variant="outline">{analysis.audio_quality}</Badge></div>
            <div>Noise: <Badge variant="outline">{analysis.noise_level}</Badge></div>
            <div>Speakers: <Badge variant="outline">{analysis.speaker_count}</Badge></div>
          </div>
          {analysis.quality_issues.length > 0 && (
            <div className="flex items-start gap-2 mt-2">
              <AlertCircle className="h-4 w-4 text-orange-500 mt-0.5" />
              <div className="text-xs text-muted-foreground">
                Issues: {analysis.quality_issues.join(', ')}
              </div>
            </div>
          )}
        </div>

        {/* Recommended Features */}
        <div className="space-y-2">
          <h4 className="font-semibold text-sm">Recommended Settings</h4>
          {Object.entries(recommendation.features).map(([feature, config]) => (
            <div key={feature} className="flex items-center justify-between py-1">
              <div className="flex items-center gap-2">
                <div className={`h-2 w-2 rounded-full ${config.enabled ? 'bg-green-500' : 'bg-gray-300'}`} />
                <span className="text-sm capitalize">{feature.replace(/_/g, ' ')}</span>
              </div>
              <div className="flex items-center gap-2">
                {config.level && <Badge variant="secondary" className="text-xs">{config.level}</Badge>}
                <Progress value={config.confidence * 100} className="w-16 h-2" />
              </div>
            </div>
          ))}
        </div>

        {/* Reasoning */}
        <div className="bg-blue-50 dark:bg-blue-950/20 p-3 rounded-lg">
          <p className="text-sm text-muted-foreground">{recommendation.reasoning}</p>
        </div>

        {recommendation.user_preference_applied && (
          <Badge variant="outline" className="w-full justify-center">
            Based on your previous preferences
          </Badge>
        )}

        {/* Actions */}
        <div className="flex gap-2 pt-2">
          <Button onClick={onAccept} disabled={isLoading} className="flex-1">
            <CheckCircle className="h-4 w-4 mr-2" />
            Accept
          </Button>
          <Button onClick={onModify} variant="outline" disabled={isLoading} className="flex-1">
            <Settings className="h-4 w-4 mr-2" />
            Modify
          </Button>
          <Button onClick={onReject} variant="ghost" disabled={isLoading}>
            <XCircle className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}