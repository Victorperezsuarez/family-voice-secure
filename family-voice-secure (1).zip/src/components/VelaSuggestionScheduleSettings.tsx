import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/supabase-client';
import { useToast } from '@/hooks/use-toast';
import { Clock, Calendar, Moon, Bell } from 'lucide-react';
import type { VelaSuggestionSchedule } from '@/types/velaSuggestionScheduling';

export function VelaSuggestionScheduleSettings({ userId }: { userId: string }) {
  const [schedule, setSchedule] = useState<VelaSuggestionSchedule | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadSchedule();
  }, [userId]);

  const loadSchedule = async () => {
    try {
      const { data, error } = await supabase
        .from('vela_suggestion_schedules')
        .select('*')
        .eq('user_id', userId)
        .is('persona_id', null)
        .single();

      if (error && error.code !== 'PGRST116') throw error;

      if (data) {
        setSchedule(data);
      } else {
        // Create default schedule
        const defaultSchedule = {
          user_id: userId,
          schedule_type: 'smart' as const,
          frequency: 'once_daily' as const,
          preferred_times: ['09:00:00', '14:00:00'],
          quiet_hours_start: '22:00:00',
          quiet_hours_end: '08:00:00',
          max_daily_suggestions: 5,
          max_weekly_suggestions: 20,
          enabled: true,
          timezone: Intl.DateTimeFormat().resolvedOptions().timeZone
        };

        const { data: newSchedule, error: createError } = await supabase
          .from('vela_suggestion_schedules')
          .insert(defaultSchedule)
          .select()
          .single();

        if (createError) throw createError;
        setSchedule(newSchedule);
      }
    } catch (error) {
      console.error('Error loading schedule:', error);
      toast({ title: 'Error', description: 'Failed to load schedule settings', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const updateSchedule = async (updates: Partial<VelaSuggestionSchedule>) => {
    if (!schedule) return;

    try {
      const { error } = await supabase
        .from('vela_suggestion_schedules')
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq('id', schedule.id);

      if (error) throw error;

      setSchedule({ ...schedule, ...updates });
      toast({ title: 'Success', description: 'Schedule settings updated' });
    } catch (error) {
      console.error('Error updating schedule:', error);
      toast({ title: 'Error', description: 'Failed to update settings', variant: 'destructive' });
    }
  };

  if (loading) return <div>Loading...</div>;
  if (!schedule) return null;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5" />
            Suggestion Settings
          </CardTitle>
          <CardDescription>Configure when and how often Vela sends suggestions</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Enable Suggestions</Label>
              <p className="text-sm text-muted-foreground">Receive proactive suggestions from Vela</p>
            </div>
            <Switch
              checked={schedule.enabled}
              onCheckedChange={(enabled) => updateSchedule({ enabled })}
            />
          </div>

          <div className="space-y-2">
            <Label>Schedule Type</Label>
            <Select
              value={schedule.schedule_type}
              onValueChange={(value) => updateSchedule({ schedule_type: value as any })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="smart">Smart (AI learns best times)</SelectItem>
                <SelectItem value="daily">Daily at set times</SelectItem>
                <SelectItem value="weekly">Weekly schedule</SelectItem>
                <SelectItem value="manual">Manual only</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Frequency</Label>
            <Select
              value={schedule.frequency}
              onValueChange={(value) => updateSchedule({ frequency: value as any })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="once_daily">Once per day</SelectItem>
                <SelectItem value="twice_daily">Twice per day</SelectItem>
                <SelectItem value="weekly">Once per week</SelectItem>
                <SelectItem value="as_needed">As needed</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Timing Preferences
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Quiet Hours Start</Label>
              <Input
                type="time"
                value={schedule.quiet_hours_start || '22:00'}
                onChange={(e) => updateSchedule({ quiet_hours_start: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label>Quiet Hours End</Label>
              <Input
                type="time"
                value={schedule.quiet_hours_end || '08:00'}
                onChange={(e) => updateSchedule({ quiet_hours_end: e.target.value })}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Suggestion Limits
          </CardTitle>
          <CardDescription>Prevent suggestion fatigue with daily and weekly limits</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Max Daily Suggestions: {schedule.max_daily_suggestions}</Label>
            <Input
              type="range"
              min="1"
              max="10"
              value={schedule.max_daily_suggestions}
              onChange={(e) => updateSchedule({ max_daily_suggestions: parseInt(e.target.value) })}
            />
          </div>
          <div className="space-y-2">
            <Label>Max Weekly Suggestions: {schedule.max_weekly_suggestions}</Label>
            <Input
              type="range"
              min="5"
              max="50"
              value={schedule.max_weekly_suggestions}
              onChange={(e) => updateSchedule({ max_weekly_suggestions: parseInt(e.target.value) })}
            />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
