import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CalendarIcon } from 'lucide-react';
import { format } from 'date-fns';
import { FamilyMember } from '@/types/family';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onSave: (memorial: MemorialData) => Promise<void>;
  familyMembers: FamilyMember[];
}

export interface MemorialData {
  family_member_id: string;
  title: string;
  description: string;
  birth_date?: Date;
  death_date?: Date;
  photo_url?: string;
  is_public: boolean;
  allow_tributes: boolean;
}

export default function CreateMemorialModal({ isOpen, onClose, onSave, familyMembers }: Props) {
  const [memberId, setMemberId] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [birthDate, setBirthDate] = useState<Date>();
  const [deathDate, setDeathDate] = useState<Date>();
  const [photoUrl, setPhotoUrl] = useState('');
  const [isPublic, setIsPublic] = useState(true);
  const [allowTributes, setAllowTributes] = useState(true);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!memberId || !title) return;
    
    setLoading(true);
    try {
      await onSave({
        family_member_id: memberId,
        title,
        description,
        birth_date: birthDate,
        death_date: deathDate,
        photo_url: photoUrl,
        is_public: isPublic,
        allow_tributes: allowTributes,
      });
      onClose();
    } catch (error) {
      console.error('Error creating memorial:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create Memorial Page</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div>
            <Label htmlFor="member">Family Member</Label>
            <select
              id="member"
              value={memberId}
              onChange={(e) => setMemberId(e.target.value)}
              className="w-full mt-2 px-3 py-2 border rounded-md"
            >
              <option value="">Select a family member</option>
              {familyMembers.map(member => (
                <option key={member.id} value={member.id}>{member.name}</option>
              ))}
            </select>
          </div>

          <div>
            <Label htmlFor="title">Memorial Title</Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="In Loving Memory of..."
            />
          </div>

          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Share memories and stories..."
              rows={4}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Birth Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {birthDate ? format(birthDate, 'PPP') : 'Select date'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar mode="single" selected={birthDate} onSelect={setBirthDate} />
                </PopoverContent>
              </Popover>
            </div>

            <div>
              <Label>Death Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {deathDate ? format(deathDate, 'PPP') : 'Select date'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar mode="single" selected={deathDate} onSelect={setDeathDate} />
                </PopoverContent>
              </Popover>
            </div>
          </div>

          <div>
            <Label htmlFor="photo">Photo URL</Label>
            <Input
              id="photo"
              value={photoUrl}
              onChange={(e) => setPhotoUrl(e.target.value)}
              placeholder="https://..."
            />
          </div>

          <div className="flex items-center justify-between">
            <Label htmlFor="public">Make page public</Label>
            <Switch checked={isPublic} onCheckedChange={setIsPublic} id="public" />
          </div>

          <div className="flex items-center justify-between">
            <Label htmlFor="tributes">Allow tributes from visitors</Label>
            <Switch checked={allowTributes} onCheckedChange={setAllowTributes} id="tributes" />
          </div>

          <div className="flex gap-2 justify-end pt-4">
            <Button variant="outline" onClick={onClose}>Cancel</Button>
            <Button onClick={handleSubmit} disabled={loading || !memberId || !title}>
              {loading ? 'Creating...' : 'Create Memorial'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
