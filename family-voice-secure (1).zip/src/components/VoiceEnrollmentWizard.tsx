import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Mic, CheckCircle2, AlertCircle } from 'lucide-react';
import { useAudioRecorder } from '@/hooks/useAudioRecorder';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';

const ENROLLMENT_PROMPTS = [
  { emotion: 'neutral', style: 'normal', text: 'Hello, my name is [Your Name]. I am recording this to help preserve family memories.' },
  { emotion: 'happy', style: 'normal', text: 'I remember the wonderful times we spent together at the beach every summer.' },
  { emotion: 'storytelling', style: 'expressive', text: 'Let me tell you about the day I first met your grandmother. It was a beautiful spring morning.' },
  { emotion: 'calm', style: 'slow', text: 'Family is the most important thing in life. We must cherish every moment together.' },
  { emotion: 'excited', style: 'fast', text: 'You should have seen the surprise on their faces when we walked through the door!' },
  { emotion: 'conversational', style: 'normal', text: 'What was your favorite memory from childhood? Mine was playing in the backyard.' },
  { emotion: 'sad', style: 'slow', text: 'Sometimes I miss the old days, but I am grateful for all the time we had.' },
];

interface VoiceEnrollmentWizardProps {
  open: boolean;
  onClose: () => void;
  familyMemberId: string;
  voiceProfileId: string;
  onComplete: () => void;
}

export function VoiceEnrollmentWizard({ open, onClose, familyMemberId, voiceProfileId, onComplete }: VoiceEnrollmentWizardProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState<Set<number>>(new Set());
  const [processing, setProcessing] = useState(false);
  const { isRecording, startRecording, stopRecording } = useAudioRecorder();

  const currentPrompt = ENROLLMENT_PROMPTS[currentStep];
  const progress = (completedSteps.size / ENROLLMENT_PROMPTS.length) * 100;

  const handleRecord = async () => {
    if (isRecording) {
      const audioBlob = await stopRecording();
      if (!audioBlob) return;

      setProcessing(true);
      try {
        const fileName = `voice-sample-${Date.now()}.webm`;
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('recordings')
          .upload(fileName, audioBlob);

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage.from('recordings').getPublicUrl(fileName);

        const { data, error } = await supabase.functions.invoke('process-voice-sample', {
          body: {
            audioUrl: publicUrl,
            voiceProfileId,
            familyMemberId,
            promptText: currentPrompt.text,
            emotionType: currentPrompt.emotion,
            speakingStyle: currentPrompt.style,
            durationSeconds: audioBlob.size / 16000
          }
        });

        if (error) throw error;

        setCompletedSteps(prev => new Set([...prev, currentStep]));
        toast.success('Voice sample recorded successfully!');

        if (currentStep < ENROLLMENT_PROMPTS.length - 1) {
          setCurrentStep(currentStep + 1);
        } else {
          toast.success('Voice enrollment complete!');
          onComplete();
          onClose();
        }
      } catch (error) {
        toast.error('Failed to process voice sample');
      } finally {
        setProcessing(false);
      }
    } else {
      startRecording();
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Voice Training - Step {currentStep + 1} of {ENROLLMENT_PROMPTS.length}</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          <Progress value={progress} className="h-2" />

          <div className="bg-muted p-6 rounded-lg">
            <div className="flex items-start gap-3 mb-4">
              <Badge variant="outline">{currentPrompt.emotion}</Badge>
              <Badge variant="outline">{currentPrompt.style}</Badge>
            </div>
            <p className="text-lg leading-relaxed">{currentPrompt.text}</p>
          </div>

          <div className="flex flex-col items-center gap-4">
            <Button
              size="lg"
              onClick={handleRecord}
              disabled={processing}
              className={isRecording ? 'bg-red-500 hover:bg-red-600' : ''}
            >
              <Mic className="mr-2 h-5 w-5" />
              {isRecording ? 'Stop Recording' : 'Start Recording'}
            </Button>

            {completedSteps.has(currentStep) && (
              <div className="flex items-center gap-2 text-green-600">
                <CheckCircle2 className="h-5 w-5" />
                <span>Sample recorded</span>
              </div>
            )}
          </div>

          <div className="flex justify-between">
            <Button variant="outline" onClick={() => setCurrentStep(Math.max(0, currentStep - 1))} disabled={currentStep === 0}>
              Previous
            </Button>
            <Button variant="outline" onClick={() => setCurrentStep(Math.min(ENROLLMENT_PROMPTS.length - 1, currentStep + 1))} disabled={currentStep === ENROLLMENT_PROMPTS.length - 1}>
              Skip
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}