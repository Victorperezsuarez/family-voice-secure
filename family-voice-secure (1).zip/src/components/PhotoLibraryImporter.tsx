import { useState } from 'react';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Upload, Image as ImageIcon, X, Check } from 'lucide-react';
import { Progress } from './ui/progress';

interface PhotoLibraryImporterProps {
  open: boolean;
  onClose: () => void;
  onImport: (files: File[]) => Promise<void>;
  familyId: string;
}

export function PhotoLibraryImporter({ open, onClose, onImport, familyId }: PhotoLibraryImporterProps) {
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);
  const [importing, setImporting] = useState(false);
  const [progress, setProgress] = useState(0);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setSelectedFiles(files);
    
    // Generate previews
    const newPreviews = files.map(file => URL.createObjectURL(file));
    setPreviews(newPreviews);
  };

  const handleImport = async () => {
    if (selectedFiles.length === 0) return;
    
    setImporting(true);
    setProgress(0);
    
    try {
      // Simulate progress
      for (let i = 0; i <= 100; i += 10) {
        setProgress(i);
        await new Promise(resolve => setTimeout(resolve, 100));
      }
      
      await onImport(selectedFiles);
      
      // Cleanup
      previews.forEach(url => URL.revokeObjectURL(url));
      setSelectedFiles([]);
      setPreviews([]);
      onClose();
    } catch (error) {
      console.error('Import error:', error);
    } finally {
      setImporting(false);
      setProgress(0);
    }
  };

  const removeFile = (index: number) => {
    URL.revokeObjectURL(previews[index]);
    setSelectedFiles(files => files.filter((_, i) => i !== index));
    setPreviews(prev => prev.filter((_, i) => i !== index));
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Importar Fotos de la Galería
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
            <input
              type="file"
              accept="image/*"
              multiple
              onChange={handleFileSelect}
              className="hidden"
              id="photo-import"
            />
            <label htmlFor="photo-import" className="cursor-pointer">
              <ImageIcon className="h-12 w-12 mx-auto mb-4 text-gray-400" />
              <p className="text-sm text-gray-600 mb-2">
                Haz clic para seleccionar fotos de tu galería
              </p>
              <Button type="button" variant="outline">
                Seleccionar Fotos
              </Button>
            </label>
          </div>

          {selectedFiles.length > 0 && (
            <>
              <div className="grid grid-cols-3 gap-4">
                {previews.map((preview, index) => (
                  <div key={index} className="relative group">
                    <img src={preview} alt={`Preview ${index}`} className="w-full h-32 object-cover rounded-lg" />
                    <button
                      onClick={() => removeFile(index)}
                      className="absolute top-2 right-2 bg-red-600 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                ))}
              </div>

              <p className="text-sm text-gray-600">
                {selectedFiles.length} foto{selectedFiles.length !== 1 ? 's' : ''} seleccionada{selectedFiles.length !== 1 ? 's' : ''}
              </p>

              {importing && (
                <div className="space-y-2">
                  <Progress value={progress} />
                  <p className="text-sm text-center text-gray-600">Importando fotos... {progress}%</p>
                </div>
              )}

              <div className="flex gap-2 justify-end">
                <Button variant="outline" onClick={onClose} disabled={importing}>
                  Cancelar
                </Button>
                <Button onClick={handleImport} disabled={importing} className="bg-amber-600 hover:bg-amber-700">
                  <Check className="h-4 w-4 mr-2" />
                  Importar {selectedFiles.length} Foto{selectedFiles.length !== 1 ? 's' : ''}
                </Button>
              </div>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
