import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Loader2, Sparkles, Heart, Lightbulb, Tag, TrendingUp } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';

interface AIRecordingInsightsProps {
  recordingId: string;
  transcription: string;
  title: string;
}

interface Analysis {
  tags: string[];
  themes: string[];
  keyMoments: Array<{ time: string; description: string }>;
  sentiment: string;
  emotions: string[];
  suggestedQuestions: string[];
  summary: string;
}

export function AIRecordingInsights({ recordingId, transcription, title }: AIRecordingInsightsProps) {
  const [analysis, setAnalysis] = useState<Analysis | null>(null);
  const [loading, setLoading] = useState(false);

  const analyzeRecording = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('analyze-recording-ai', {
        body: { transcription, title, recordingId }
      });

      if (error) throw error;
      setAnalysis(data.analysis);
      toast.success('AI analysis complete!');
    } catch (error: any) {
      toast.error(error.message || 'Failed to analyze recording');
    } finally {
      setLoading(false);
    }
  };

  if (!analysis && !loading) {
    return (
      <Card className="p-6">
        <Button onClick={analyzeRecording} className="w-full">
          <Sparkles className="w-4 h-4 mr-2" />
          Analyze with AI
        </Button>
      </Card>
    );
  }

  if (loading) {
    return (
      <Card className="p-6 flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin mr-2" />
        <span>Analyzing recording...</span>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <Card className="p-6">
        <h3 className="font-semibold mb-2">Summary</h3>
        <p className="text-sm text-muted-foreground">{analysis?.summary}</p>
      </Card>

      <Card className="p-6">
        <div className="flex items-center gap-2 mb-3">
          <Tag className="w-4 h-4" />
          <h3 className="font-semibold">Tags</h3>
        </div>
        <div className="flex flex-wrap gap-2">
          {analysis?.tags.map((tag, i) => (
            <Badge key={i} variant="secondary">{tag}</Badge>
          ))}
        </div>
      </Card>

      <Card className="p-6">
        <div className="flex items-center gap-2 mb-3">
          <TrendingUp className="w-4 h-4" />
          <h3 className="font-semibold">Themes</h3>
        </div>
        <ul className="space-y-1">
          {analysis?.themes.map((theme, i) => (
            <li key={i} className="text-sm">• {theme}</li>
          ))}
        </ul>
      </Card>

      <Card className="p-6">
        <div className="flex items-center gap-2 mb-3">
          <Heart className="w-4 h-4" />
          <h3 className="font-semibold">Sentiment & Emotions</h3>
        </div>
        <div className="space-y-2">
          <Badge className="capitalize">{analysis?.sentiment}</Badge>
          <div className="flex flex-wrap gap-2">
            {analysis?.emotions.map((emotion, i) => (
              <Badge key={i} variant="outline">{emotion}</Badge>
            ))}
          </div>
        </div>
      </Card>

      <Card className="p-6">
        <div className="flex items-center gap-2 mb-3">
          <Lightbulb className="w-4 h-4" />
          <h3 className="font-semibold">Suggested Follow-up Questions</h3>
        </div>
        <ul className="space-y-2">
          {analysis?.suggestedQuestions.map((q, i) => (
            <li key={i} className="text-sm text-muted-foreground">• {q}</li>
          ))}
        </ul>
      </Card>
    </div>
  );
}