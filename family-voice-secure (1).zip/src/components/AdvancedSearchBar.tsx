import { useState } from 'react';
import { Search, Mic, Filter, X } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { Label } from '@/components/ui/label';
import { useVoiceSemanticSearch } from '@/hooks/useVoiceSemanticSearch';
import { SearchFilters } from '@/types/search';

interface AdvancedSearchBarProps {
  onSearch: (query: string, filters: SearchFilters) => void;
  speakers?: string[];
  topics?: string[];
}

export const AdvancedSearchBar = ({ onSearch, speakers = [], topics = [] }: AdvancedSearchBarProps) => {
  const [query, setQuery] = useState('');
  const [filters, setFilters] = useState<SearchFilters>({});
  const [showFilters, setShowFilters] = useState(false);
  const { isListening, startListening, stopListening } = useVoiceSemanticSearch();

  const handleVoiceSearch = () => {
    if (isListening) {
      stopListening();
    } else {
      startListening((text) => {
        setQuery(text);
        onSearch(text, filters);
      });
    }
  };

  const handleSearch = () => {
    onSearch(query, filters);
  };

  const removeFilter = (key: keyof SearchFilters) => {
    const newFilters = { ...filters };
    delete newFilters[key];
    setFilters(newFilters);
  };

  const activeFilterCount = Object.keys(filters).length;

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
            placeholder="Search transcriptions with natural language..."
            className="pl-10 pr-4"
          />
        </div>
        <Button
          variant={isListening ? 'destructive' : 'outline'}
          size="icon"
          onClick={handleVoiceSearch}
        >
          <Mic className={`h-4 w-4 ${isListening ? 'animate-pulse' : ''}`} />
        </Button>
        <Button variant="outline" size="icon" onClick={() => setShowFilters(!showFilters)}>
          <Filter className="h-4 w-4" />
          {activeFilterCount > 0 && (
            <Badge className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center">
              {activeFilterCount}
            </Badge>
          )}
        </Button>
        <Button onClick={handleSearch}>Search</Button>
      </div>

      {showFilters && (
        <div className="p-4 border rounded-lg space-y-3 bg-card">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Date From</Label>
              <Input
                type="date"
                value={filters.dateFrom || ''}
                onChange={(e) => setFilters({ ...filters, dateFrom: e.target.value })}
              />
            </div>
            <div>
              <Label>Date To</Label>
              <Input
                type="date"
                value={filters.dateTo || ''}
                onChange={(e) => setFilters({ ...filters, dateTo: e.target.value })}
              />
            </div>
          </div>
        </div>
      )}

      {activeFilterCount > 0 && (
        <div className="flex gap-2 flex-wrap">
          {filters.speaker && (
            <Badge variant="secondary">
              Speaker: {filters.speaker}
              <X className="ml-1 h-3 w-3 cursor-pointer" onClick={() => removeFilter('speaker')} />
            </Badge>
          )}
          {filters.dateFrom && (
            <Badge variant="secondary">
              From: {filters.dateFrom}
              <X className="ml-1 h-3 w-3 cursor-pointer" onClick={() => removeFilter('dateFrom')} />
            </Badge>
          )}
          {filters.dateTo && (
            <Badge variant="secondary">
              To: {filters.dateTo}
              <X className="ml-1 h-3 w-3 cursor-pointer" onClick={() => removeFilter('dateTo')} />
            </Badge>
          )}
        </div>
      )}
    </div>
  );
};
