import { SearchResult } from '@/types/search';
import { ComprehensiveSearchResults } from './ComprehensiveSearchResults';
import { Loader2, Search } from 'lucide-react';

interface SearchResultsProps {
  results: SearchResult[];
  isLoading: boolean;
  query: string;
  onPlayFromTimestamp: (recordingId: string, timestamp: number) => void;
  onViewTranscription: (transcriptionId: string, timestamp: number) => void;
}

export const SearchResults = ({
  results,
  isLoading,
  query,
  onPlayFromTimestamp,
  onViewTranscription,
}: SearchResultsProps) => {
  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-16 space-y-4">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="text-muted-foreground">Searching transcriptions...</p>
      </div>
    );
  }

  if (!query) {
    return (
      <div className="flex flex-col items-center justify-center py-16 space-y-4 text-center">
        <Search className="h-12 w-12 text-muted-foreground" />
        <div>
          <h3 className="text-lg font-semibold mb-2">Start Your Search</h3>
          <p className="text-muted-foreground max-w-md">
            Search through your family's recordings using natural language queries.
            Try asking about specific topics, people, or time periods.
          </p>
        </div>
      </div>
    );
  }

  if (results.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 space-y-4 text-center">
        <Search className="h-12 w-12 text-muted-foreground" />
        <div>
          <h3 className="text-lg font-semibold mb-2">No Results Found</h3>
          <p className="text-muted-foreground max-w-md">
            We couldn't find any matches for "{query}". Try using different keywords
            or adjusting your search filters.
          </p>
        </div>
      </div>
    );
  }

  return (
    <ComprehensiveSearchResults
      results={results}
      onPlayFromTimestamp={onPlayFromTimestamp}
      onViewTranscription={onViewTranscription}
    />
  );
};
