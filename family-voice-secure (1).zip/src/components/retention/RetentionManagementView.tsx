import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase-client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { RetentionPolicyCard } from './RetentionPolicyCard';
import { RetentionPolicyDialog } from './RetentionPolicyDialog';
import { AuditRetentionPolicy, AuditRetentionJob } from '@/types/retention';
import { Plus, Play, RefreshCw, Clock } from 'lucide-react';
import { toast } from 'sonner';

export function RetentionManagementView() {
  const [policies, setPolicies] = useState<AuditRetentionPolicy[]>([]);
  const [jobs, setJobs] = useState<AuditRetentionJob[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingPolicy, setEditingPolicy] = useState<AuditRetentionPolicy | undefined>();
  const [running, setRunning] = useState(false);

  useEffect(() => {
    loadPolicies();
    loadJobs();
  }, []);

  const loadPolicies = async () => {
    try {
      const { data, error } = await supabase
        .from('audit_retention_policies')
        .select('*')
        .order('priority', { ascending: false });

      if (error) throw error;
      setPolicies(data || []);
    } catch (error: any) {
      toast.error('Failed to load policies: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const loadJobs = async () => {
    try {
      const { data, error } = await supabase
        .from('audit_retention_jobs')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(10);

      if (error) throw error;
      setJobs(data || []);
    } catch (error: any) {
      console.error('Failed to load jobs:', error);
    }
  };

  const handleSavePolicy = async (policyData: Partial<AuditRetentionPolicy>) => {
    try {
      if (editingPolicy) {
        const { error } = await supabase
          .from('audit_retention_policies')
          .update(policyData)
          .eq('id', editingPolicy.id);

        if (error) throw error;
        toast.success('Policy updated successfully');
      } else {
        const { error } = await supabase
          .from('audit_retention_policies')
          .insert(policyData);

        if (error) throw error;
        toast.success('Policy created successfully');
      }

      loadPolicies();
      setEditingPolicy(undefined);
    } catch (error: any) {
      toast.error('Failed to save policy: ' + error.message);
    }
  };

  const handleDeletePolicy = async (id: string) => {
    if (!confirm('Are you sure you want to delete this policy?')) return;

    try {
      const { error } = await supabase
        .from('audit_retention_policies')
        .delete()
        .eq('id', id);

      if (error) throw error;
      toast.success('Policy deleted');
      loadPolicies();
    } catch (error: any) {
      toast.error('Failed to delete: ' + error.message);
    }
  };

  const handleToggleActive = async (id: string, active: boolean) => {
    try {
      const { error } = await supabase
        .from('audit_retention_policies')
        .update({ is_active: active })
        .eq('id', id);

      if (error) throw error;
      loadPolicies();
    } catch (error: any) {
      toast.error('Failed to update: ' + error.message);
    }
  };

  const runArchival = async (dryRun = false) => {
    setRunning(true);
    try {
      const { data, error } = await supabase.functions.invoke('archive-audit-logs', {
        body: { dryRun }
      });

      if (error) throw error;
      toast.success(dryRun ? 'Dry run completed' : 'Archival completed');
      loadJobs();
    } catch (error: any) {
      toast.error('Archival failed: ' + error.message);
    } finally {
      setRunning(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Audit Log Retention</h2>
          <p className="text-muted-foreground">Manage automated archival and cleanup policies</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => runArchival(true)} disabled={running}>
            <Play className="h-4 w-4 mr-2" />
            Dry Run
          </Button>
          <Button onClick={() => runArchival(false)} disabled={running}>
            <RefreshCw className={`h-4 w-4 mr-2 ${running ? 'animate-spin' : ''}`} />
            Run Now
          </Button>
          <Button onClick={() => { setEditingPolicy(undefined); setDialogOpen(true); }}>
            <Plus className="h-4 w-4 mr-2" />
            New Policy
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {policies.map(policy => (
          <RetentionPolicyCard
            key={policy.id}
            policy={policy}
            onEdit={(p) => { setEditingPolicy(p); setDialogOpen(true); }}
            onDelete={handleDeletePolicy}
            onToggleActive={handleToggleActive}
          />
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Jobs</CardTitle>
          <CardDescription>Last 10 archival jobs</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {jobs.map(job => (
              <div key={job.id} className="flex items-center justify-between p-3 border rounded">
                <div className="flex items-center gap-3">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <div className="font-medium">{job.job_type}</div>
                    <div className="text-sm text-muted-foreground">
                      {new Date(job.created_at).toLocaleString()}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-sm text-right">
                    <div>Processed: {job.logs_processed}</div>
                    <div>Archived: {job.logs_archived}</div>
                  </div>
                  <Badge variant={job.status === 'completed' ? 'default' : job.status === 'failed' ? 'destructive' : 'secondary'}>
                    {job.status}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <RetentionPolicyDialog
        open={dialogOpen}
        onClose={() => setDialogOpen(false)}
        onSave={handleSavePolicy}
        policy={editingPolicy}
      />
    </div>
  );
}
