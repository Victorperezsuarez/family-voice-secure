import { useOfflineSync } from '@/contexts/OfflineSyncContext';
import { Badge } from '@/components/ui/badge';
import { Cloud, CloudOff, RefreshCw, AlertCircle, CheckCircle2, Clock } from 'lucide-react';
import { cn } from '@/lib/utils';

interface SyncStatusBadgeProps {
  className?: string;
  showText?: boolean;
}

export function SyncStatusBadge({ className, showText = true }: SyncStatusBadgeProps) {
  const { isOnline, isSyncing, syncStats } = useOfflineSync();

  const getStatus = () => {
    if (!isOnline) {
      return {
        icon: CloudOff,
        text: 'Offline',
        variant: 'secondary' as const,
        color: 'text-muted-foreground'
      };
    }
    if (isSyncing) {
      return {
        icon: RefreshCw,
        text: `Syncing ${syncStats.syncing}`,
        variant: 'default' as const,
        color: 'text-blue-500',
        animate: true
      };
    }
    if (syncStats.failed > 0) {
      return {
        icon: AlertCircle,
        text: `${syncStats.failed} Failed`,
        variant: 'destructive' as const,
        color: 'text-destructive'
      };
    }
    if (syncStats.pending > 0) {
      return {
        icon: Clock,
        text: `${syncStats.pending} Pending`,
        variant: 'secondary' as const,
        color: 'text-yellow-500'
      };
    }
    return {
      icon: CheckCircle2,
      text: 'Synced',
      variant: 'outline' as const,
      color: 'text-green-500'
    };
  };

  const status = getStatus();
  const Icon = status.icon;

  return (
    <Badge variant={status.variant} className={cn('gap-1.5', className)}>
      <Icon className={cn('h-3.5 w-3.5', status.color, status.animate && 'animate-spin')} />
      {showText && <span>{status.text}</span>}
    </Badge>
  );
}
