import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { StarRating } from '@/components/StarRating';
import { supabase } from '@/lib/supabase-client';
import { useToast } from '@/hooks/use-toast';

interface TemplateReviewFormProps {
  templateId: string;
  familyId: string;
  existingReview?: {
    rating: number;
    reviewText: string;
  };
  onSuccess: () => void;
}

export function TemplateReviewForm({ 
  templateId, 
  familyId, 
  existingReview,
  onSuccess 
}: TemplateReviewFormProps) {
  const [rating, setRating] = useState(existingReview?.rating || 0);
  const [reviewText, setReviewText] = useState(existingReview?.reviewText || '');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (rating === 0) {
      toast({ title: 'Please select a rating', variant: 'destructive' });
      return;
    }

    setIsSubmitting(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      const { error } = await supabase.functions.invoke('submit-template-review', {
        body: { 
          templateId, 
          familyId, 
          userId: user?.id,
          rating, 
          reviewText 
        }
      });

      if (error) throw error;

      toast({ title: 'Review submitted successfully!' });
      onSuccess();
    } catch (error) {
      toast({ title: 'Failed to submit review', variant: 'destructive' });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="text-sm font-medium mb-2 block">Your Rating</label>
        <StarRating 
          rating={rating} 
          interactive 
          onRatingChange={setRating}
          size={32}
        />
      </div>
      
      <div>
        <label className="text-sm font-medium mb-2 block">Your Review</label>
        <Textarea
          value={reviewText}
          onChange={(e) => setReviewText(e.target.value)}
          placeholder="Share your experience with this template..."
          rows={4}
        />
      </div>

      <Button type="submit" disabled={isSubmitting}>
        {isSubmitting ? 'Submitting...' : 'Submit Review'}
      </Button>
    </form>
  );
}
