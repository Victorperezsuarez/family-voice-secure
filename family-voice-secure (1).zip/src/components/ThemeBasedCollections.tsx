import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Sparkles, Loader2, FolderOpen, Plus } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';

interface ThemeBasedCollectionsProps {
  familyId: string;
  recordings: any[];
  onCollectionCreated?: () => void;
}

export function ThemeBasedCollections({
  familyId,
  recordings,
  onCollectionCreated
}: ThemeBasedCollectionsProps) {
  const [loading, setLoading] = useState(false);
  const [suggestedCollections, setSuggestedCollections] = useState<any[]>([]);
  const [showDialog, setShowDialog] = useState(false);

  const generateCollections = async () => {
    setLoading(true);
    try {
      // Filter recordings with AI analysis
      const analyzedRecordings = recordings.filter(r => r.ai_themes && r.ai_summary);

      if (analyzedRecordings.length < 2) {
        toast.error('Need at least 2 analyzed recordings to create collections');
        return;
      }

      const { data, error } = await supabase.functions.invoke('find-similar-stories', {
        body: { recordings: analyzedRecordings, createCollections: true }
      });

      if (error) throw error;

      if (data.success) {
        setSuggestedCollections(data.collections);
        setShowDialog(true);
      }
    } catch (error: any) {
      toast.error('Failed to generate collections: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const createCollection = async (collection: any) => {
    try {
      const { data: newCollection, error } = await supabase
        .from('collections')
        .insert({
          family_id: familyId,
          title: collection.title,
          description: collection.description,
          is_public: false
        })
        .select()
        .single();

      if (error) throw error;

      // Add recordings to collection
      const recordingLinks = collection.recordingIds.map((rid: string) => ({
        collection_id: newCollection.id,
        recording_id: rid
      }));

      await supabase.from('collection_recordings').insert(recordingLinks);

      toast.success(`Created collection: ${collection.title}`);
      onCollectionCreated?.();
    } catch (error: any) {
      toast.error('Failed to create collection: ' + error.message);
    }
  };

  return (
    <>
      <Card className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold mb-2">AI Story Collections</h3>
            <p className="text-sm text-muted-foreground">
              Automatically group related stories by themes and connections
            </p>
          </div>
          <Sparkles className="h-8 w-8 text-primary" />
        </div>
        <Button onClick={generateCollections} disabled={loading}>
          {loading ? (
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <Sparkles className="h-4 w-4 mr-2" />
          )}
          Generate Collections
        </Button>
      </Card>

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Suggested Story Collections</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            {suggestedCollections.map((collection, index) => (
              <Card key={index} className="p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <FolderOpen className="h-5 w-5 text-primary" />
                      <h4 className="font-semibold">{collection.title}</h4>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">
                      {collection.description}
                    </p>
                    <div className="flex flex-wrap gap-2 mb-3">
                      <Badge variant="outline">{collection.theme}</Badge>
                      <Badge variant="secondary">{collection.mood}</Badge>
                      <Badge>{collection.recordingIds.length} stories</Badge>
                    </div>
                  </div>
                </div>
                <Button
                  size="sm"
                  onClick={() => createCollection(collection)}
                  className="w-full"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Create Collection
                </Button>
              </Card>
            ))}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}