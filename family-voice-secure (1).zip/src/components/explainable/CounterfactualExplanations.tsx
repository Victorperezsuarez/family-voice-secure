import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CounterfactualScenario } from '@/types/explainableAI';
import { ArrowRight, Lightbulb } from 'lucide-react';

interface Props {
  counterfactuals: CounterfactualScenario[];
}

export function CounterfactualExplanations({ counterfactuals }: Props) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Lightbulb className="w-5 h-5" />
          What-If Scenarios
        </CardTitle>
      </CardHeader>
      <CardContent>
        {counterfactuals.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            This user is already in the optimal segment based on their behavior.
          </p>
        ) : (
          <div className="space-y-4">
            {counterfactuals.map((cf, idx) => (
              <div key={idx} className="p-4 border rounded-lg space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium">{cf.displayName}</h4>
                  <Badge variant="outline">
                    {(cf.confidence * 100).toFixed(0)}% confidence
                  </Badge>
                </div>
                
                <div className="flex items-center gap-3 text-sm">
                  <div className="flex-1 p-2 bg-red-50 rounded">
                    <div className="text-xs text-muted-foreground">Current</div>
                    <div className="font-medium">{cf.currentValue}</div>
                  </div>
                  
                  <ArrowRight className="w-5 h-5 text-muted-foreground" />
                  
                  <div className="flex-1 p-2 bg-green-50 rounded">
                    <div className="text-xs text-muted-foreground">Suggested</div>
                    <div className="font-medium">{cf.suggestedValue}</div>
                  </div>
                </div>
                
                <div className="text-sm text-muted-foreground">
                  Would likely move user to <Badge className="ml-1">{cf.predictedSegment}</Badge>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
