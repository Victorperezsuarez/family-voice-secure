import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { FeatureContributionWaterfall } from './FeatureContributionWaterfall';
import { CounterfactualExplanations } from './CounterfactualExplanations';
import { NaturalLanguageExplanation } from './NaturalLanguageExplanation';
import { calculateShapValues, generateCounterfactuals } from '@/utils/shapCalculator';
import { UserBehaviorFeatures } from '@/types/segmentPrediction';
import { Brain, RefreshCw } from 'lucide-react';

const demoUsers: { id: string; name: string; features: UserBehaviorFeatures; segment: string; confidence: number }[] = [
  {
    id: 'user1',
    name: 'Alice Johnson',
    segment: 'power_user',
    confidence: 0.92,
    features: {
      engagementScore: 85,
      retentionScore: 90,
      daysSinceSignup: 120,
      totalSessions: 150,
      avgSessionDuration: 420,
      lastActivityDays: 1,
      featureUsageCount: 25,
      signupSource: 'organic',
      deviceType: 'desktop',
      location: 'US'
    }
  },
  {
    id: 'user2',
    name: 'Bob Smith',
    segment: 'at_risk',
    confidence: 0.78,
    features: {
      engagementScore: 25,
      retentionScore: 30,
      daysSinceSignup: 90,
      totalSessions: 15,
      avgSessionDuration: 120,
      lastActivityDays: 14,
      featureUsageCount: 3,
      signupSource: 'paid',
      deviceType: 'mobile',
      location: 'UK'
    }
  }
];

export function ExplainableAIDashboard() {
  const [selectedUser, setSelectedUser] = useState(demoUsers[0]);

  const shapValues = calculateShapValues(selectedUser.features);
  const counterfactuals = generateCounterfactuals(selectedUser.features, selectedUser.segment);
  const baseValue = 0.5;
  const finalValue = baseValue + shapValues.reduce((sum, sv) => sum + sv.contribution, 0);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="w-6 h-6" />
            Explainable AI Dashboard
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <Select value={selectedUser.id} onValueChange={(id) => setSelectedUser(demoUsers.find(u => u.id === id)!)}>
              <SelectTrigger className="w-64">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {demoUsers.map(user => (
                  <SelectItem key={user.id} value={user.id}>{user.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button variant="outline" size="sm">
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh Analysis
            </Button>
          </div>
        </CardContent>
      </Card>

      <NaturalLanguageExplanation 
        segment={selectedUser.segment}
        confidence={selectedUser.confidence}
        shapValues={shapValues}
      />

      <FeatureContributionWaterfall 
        shapValues={shapValues}
        baseValue={baseValue}
        finalValue={finalValue}
      />

      <CounterfactualExplanations counterfactuals={counterfactuals} />
    </div>
  );
}
