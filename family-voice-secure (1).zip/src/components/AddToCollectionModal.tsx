import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Collection } from '@/types/family';
import { supabase } from '@/lib/supabase-client';

interface AddToCollectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  recordingId: string;
  familyId: string;
}

export function AddToCollectionModal({ isOpen, onClose, recordingId, familyId }: AddToCollectionModalProps) {
  const [collections, setCollections] = useState<Collection[]>([]);
  const [selectedCollections, setSelectedCollections] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isOpen) {
      loadCollections();
      loadRecordingCollections();
    }
  }, [isOpen, familyId, recordingId]);

  const loadCollections = async () => {
    const { data } = await supabase
      .from('collections')
      .select('*')
      .eq('family_id', familyId)
      .order('created_at', { ascending: false });
    
    if (data) setCollections(data);
  };

  const loadRecordingCollections = async () => {
    const { data } = await supabase
      .from('recording_collections')
      .select('collection_id')
      .eq('recording_id', recordingId);
    
    if (data) {
      setSelectedCollections(new Set(data.map(rc => rc.collection_id)));
    }
  };

  const handleToggle = (collectionId: string) => {
    const newSelected = new Set(selectedCollections);
    if (newSelected.has(collectionId)) {
      newSelected.delete(collectionId);
    } else {
      newSelected.add(collectionId);
    }
    setSelectedCollections(newSelected);
  };

  const handleSave = async () => {
    setLoading(true);
    
    // Remove all existing links
    await supabase
      .from('recording_collections')
      .delete()
      .eq('recording_id', recordingId);
    
    // Add new links
    const links = Array.from(selectedCollections).map(collection_id => ({
      recording_id: recordingId,
      collection_id
    }));
    
    if (links.length > 0) {
      await supabase.from('recording_collections').insert(links);
    }
    
    setLoading(false);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Add to Collections</DialogTitle>
        </DialogHeader>
        <div className="space-y-3 max-h-96 overflow-y-auto">
          {collections.map((collection) => (
            <div key={collection.id} className="flex items-center space-x-2">
              <Checkbox
                id={collection.id}
                checked={selectedCollections.has(collection.id)}
                onCheckedChange={() => handleToggle(collection.id)}
              />
              <Label htmlFor={collection.id} className="flex-1 cursor-pointer">
                {collection.name}
              </Label>
            </div>
          ))}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave} disabled={loading}>Save</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
