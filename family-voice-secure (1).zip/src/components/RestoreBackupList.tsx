import { useState, useEffect } from 'react';
import { BackupHistory } from '@/types/backup';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase-client';
import { Download, Calendar, HardDrive } from 'lucide-react';

interface RestoreBackupListProps {
  familyId: string;
  onSelectBackup: (backup: BackupHistory) => void;
}

export function RestoreBackupList({ familyId, onSelectBackup }: RestoreBackupListProps) {
  const [backups, setBackups] = useState<BackupHistory[]>([]);

  useEffect(() => {
    loadBackups();
  }, [familyId]);

  const loadBackups = async () => {
    const { data } = await supabase
      .from('backup_history')
      .select('*')
      .eq('family_id', familyId)
      .eq('status', 'completed')
      .order('created_at', { ascending: false });
    if (data) setBackups(data);
  };

  return (
    <div className="space-y-3">
      {backups.map((backup) => (
        <Card key={backup.id} className="p-4">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Badge>{backup.provider}</Badge>
                <span className="text-sm text-muted-foreground flex items-center gap-1">
                  <Calendar className="h-3 w-3" />
                  {new Date(backup.created_at).toLocaleDateString()}
                </span>
              </div>
              <p className="text-sm flex items-center gap-1">
                <HardDrive className="h-3 w-3" />
                {backup.file_count} archivos
              </p>
            </div>
            <Button onClick={() => onSelectBackup(backup)} size="sm">
              <Download className="h-4 w-4 mr-2" />
              Restaurar
            </Button>
          </div>
        </Card>
      ))}
    </div>
  );
}
