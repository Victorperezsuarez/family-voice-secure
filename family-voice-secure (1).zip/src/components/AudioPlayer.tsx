import { useState, useRef, useEffect } from 'react';
import { Play, Pause, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { TranscriptionEditor } from './TranscriptionEditor';

interface AudioPlayerProps {
  audioUrl: string;
  title: string;
  recordingId: string;
  transcription?: string | null;
  transcriptionStatus?: string;
  onClose: () => void;
  onTranscriptionUpdate?: (transcription: string) => void;
}


export function AudioPlayer({ 
  audioUrl, 
  title, 
  recordingId,
  transcription,
  transcriptionStatus = 'pending',
  onClose,
  onTranscriptionUpdate 
}: AudioPlayerProps) {

  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [playbackRate, setPlaybackRate] = useState(1);
  const audioRef = useRef<HTMLAudioElement>(null);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const updateTime = () => setCurrentTime(audio.currentTime);
    const updateDuration = () => setDuration(audio.duration);
    const handleEnded = () => setIsPlaying(false);

    audio.addEventListener('timeupdate', updateTime);
    audio.addEventListener('loadedmetadata', updateDuration);
    audio.addEventListener('ended', handleEnded);

    return () => {
      audio.removeEventListener('timeupdate', updateTime);
      audio.removeEventListener('loadedmetadata', updateDuration);
      audio.removeEventListener('ended', handleEnded);
    };
  }, []);

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleSeek = (value: number[]) => {
    if (audioRef.current) {
      audioRef.current.currentTime = value[0];
      setCurrentTime(value[0]);
    }
  };

  const changeSpeed = () => {
    const speeds = [0.5, 1, 1.5, 2];
    const currentIndex = speeds.indexOf(playbackRate);
    const nextSpeed = speeds[(currentIndex + 1) % speeds.length];
    setPlaybackRate(nextSpeed);
    if (audioRef.current) {
      audioRef.current.playbackRate = nextSpeed;
    }
  };

  const formatTime = (time: number) => {
    const mins = Math.floor(time / 60);
    const secs = Math.floor(time % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-gradient-to-r from-amber-50 to-orange-50 border-t-2 border-amber-200 shadow-2xl p-6 z-50 max-h-[80vh] overflow-y-auto">
      <audio ref={audioRef} src={audioUrl} />
      
      <div className="max-w-4xl mx-auto space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-gray-900">{title}</h3>
          <Button onClick={onClose} size="sm" variant="ghost">
            <X className="w-5 h-5" />
          </Button>
        </div>

        <div className="flex items-center gap-4">
          <Button
            onClick={togglePlay}
            size="lg"
            className="w-12 h-12 rounded-full bg-gradient-to-r from-amber-500 to-orange-500"
          >
            {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
          </Button>

          <div className="flex-1">
            <Slider
              value={[currentTime]}
              max={duration || 100}
              step={0.1}
              onValueChange={handleSeek}
              className="cursor-pointer"
            />
            <div className="flex justify-between text-xs text-gray-600 mt-1">
              <span>{formatTime(currentTime)}</span>
              <span>{formatTime(duration)}</span>
            </div>
          </div>

          <Button
            onClick={changeSpeed}
            variant="outline"
            size="sm"
            className="min-w-[60px]"
          >
            {playbackRate}x
          </Button>
        </div>

        {/* Transcription Section */}
        <div className="pt-4 border-t border-amber-200">
          <TranscriptionEditor
            recordingId={recordingId}
            initialTranscription={transcription}
            transcriptionStatus={transcriptionStatus}
            onUpdate={onTranscriptionUpdate || (() => {})}
          />
        </div>
      </div>
    </div>
  );
}

