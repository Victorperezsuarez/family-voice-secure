import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Area, AreaChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';

interface AssignmentSuccessChartProps {
  data: Array<{
    date: string;
    successful: number;
    failed: number;
    total: number;
  }>;
}

export function AssignmentSuccessChart({ data }: AssignmentSuccessChartProps) {
  const chartData = data.map(d => ({
    date: d.date,
    'Success Rate': ((d.successful / d.total) * 100).toFixed(1),
    'Successful': d.successful,
    'Failed': d.failed
  }));

  return (
    <Card>
      <CardHeader>
        <CardTitle>Assignment Success Rate</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Area type="monotone" dataKey="Successful" stackId="1" stroke="#10b981" fill="#10b981" />
            <Area type="monotone" dataKey="Failed" stackId="1" stroke="#ef4444" fill="#ef4444" />
          </AreaChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
