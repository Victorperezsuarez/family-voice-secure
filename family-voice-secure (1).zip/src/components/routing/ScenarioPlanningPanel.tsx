import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Play, Plus, Trash2 } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

interface Scenario {
  id: string;
  name: string;
  description: string;
  scenario_config: {
    team_size: number;
    avg_alerts_per_day: number;
    skills_distribution: Record<string, number>;
  };
  predicted_outcomes?: {
    avg_response_time: number;
    coverage_percentage: number;
    workload_balance: number;
  };
}

interface ScenarioPlanningPanelProps {
  scenarios: Scenario[];
  onRunScenario: (scenarioId: string) => void;
  onCreateScenario: (scenario: Partial<Scenario>) => void;
  onDeleteScenario: (scenarioId: string) => void;
}

export default function ScenarioPlanningPanel({ 
  scenarios, 
  onRunScenario,
  onCreateScenario,
  onDeleteScenario
}: ScenarioPlanningPanelProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [newScenario, setNewScenario] = useState({
    name: '',
    description: '',
    team_size: 5,
    avg_alerts_per_day: 50
  });

  const handleCreate = () => {
    onCreateScenario({
      name: newScenario.name,
      description: newScenario.description,
      scenario_config: {
        team_size: newScenario.team_size,
        avg_alerts_per_day: newScenario.avg_alerts_per_day,
        skills_distribution: {}
      }
    });
    setIsOpen(false);
    setNewScenario({ name: '', description: '', team_size: 5, avg_alerts_per_day: 50 });
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>What-If Scenario Planning</CardTitle>
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button size="sm">
                <Plus className="h-4 w-4 mr-2" />
                New Scenario
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create Scenario</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label>Scenario Name</Label>
                  <Input
                    value={newScenario.name}
                    onChange={(e) => setNewScenario({...newScenario, name: e.target.value})}
                    placeholder="e.g., Increased Team Size"
                  />
                </div>
                <div>
                  <Label>Description</Label>
                  <Input
                    value={newScenario.description}
                    onChange={(e) => setNewScenario({...newScenario, description: e.target.value})}
                    placeholder="Describe the scenario"
                  />
                </div>
                <div>
                  <Label>Team Size</Label>
                  <Input
                    type="number"
                    value={newScenario.team_size}
                    onChange={(e) => setNewScenario({...newScenario, team_size: parseInt(e.target.value)})}
                  />
                </div>
                <div>
                  <Label>Avg Alerts/Day</Label>
                  <Input
                    type="number"
                    value={newScenario.avg_alerts_per_day}
                    onChange={(e) => setNewScenario({...newScenario, avg_alerts_per_day: parseInt(e.target.value)})}
                  />
                </div>
                <Button onClick={handleCreate} className="w-full">Create</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {scenarios.map((scenario) => (
            <div key={scenario.id} className="border rounded-lg p-4">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <div className="font-medium">{scenario.name}</div>
                  <div className="text-sm text-muted-foreground">{scenario.description}</div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onDeleteScenario(scenario.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
              
              <div className="flex gap-2 mb-3">
                <Badge variant="outline">Team: {scenario.scenario_config.team_size}</Badge>
                <Badge variant="outline">Alerts: {scenario.scenario_config.avg_alerts_per_day}/day</Badge>
              </div>

              {scenario.predicted_outcomes && (
                <div className="grid grid-cols-3 gap-2 mb-3 text-sm">
                  <div>
                    <div className="text-muted-foreground">Response Time</div>
                    <div className="font-medium">{scenario.predicted_outcomes.avg_response_time}m</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground">Coverage</div>
                    <div className="font-medium">{scenario.predicted_outcomes.coverage_percentage}%</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground">Balance</div>
                    <div className="font-medium">{scenario.predicted_outcomes.workload_balance}%</div>
                  </div>
                </div>
              )}

              <Button
                onClick={() => onRunScenario(scenario.id)}
                variant="outline"
                size="sm"
                className="w-full"
              >
                <Play className="h-4 w-4 mr-2" />
                Run Simulation
              </Button>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}