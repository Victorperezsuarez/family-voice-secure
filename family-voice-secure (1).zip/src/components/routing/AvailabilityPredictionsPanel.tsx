import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { User, TrendingUp, TrendingDown } from 'lucide-react';

interface AvailabilityPrediction {
  team_member_id: string;
  team_member_name: string;
  prediction_date: string;
  predicted_availability: number;
  confidence_score: number;
  factors: string[];
}

interface AvailabilityPredictionsPanelProps {
  predictions: AvailabilityPrediction[];
}

export default function AvailabilityPredictionsPanel({ predictions }: AvailabilityPredictionsPanelProps) {
  const getAvailabilityColor = (availability: number) => {
    if (availability >= 0.8) return 'text-green-600';
    if (availability >= 0.5) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getAvailabilityBadge = (availability: number) => {
    if (availability >= 0.8) return 'default';
    if (availability >= 0.5) return 'secondary';
    return 'destructive';
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Availability Predictions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {predictions.map((pred, idx) => (
            <div key={idx} className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <User className="h-4 w-4" />
                  <span className="font-medium">{pred.team_member_name}</span>
                </div>
                <Badge variant={getAvailabilityBadge(pred.predicted_availability)}>
                  {(pred.predicted_availability * 100).toFixed(0)}% Available
                </Badge>
              </div>
              
              <div className="space-y-2">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Availability</span>
                    <span className={getAvailabilityColor(pred.predicted_availability)}>
                      {(pred.predicted_availability * 100).toFixed(0)}%
                    </span>
                  </div>
                  <Progress value={pred.predicted_availability * 100} />
                </div>
                
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Confidence</span>
                    <span>{(pred.confidence_score * 100).toFixed(0)}%</span>
                  </div>
                  <Progress value={pred.confidence_score * 100} className="h-2" />
                </div>
              </div>

              {pred.factors && pred.factors.length > 0 && (
                <div className="mt-3 text-xs text-muted-foreground">
                  <div className="font-medium mb-1">Factors:</div>
                  <ul className="list-disc list-inside space-y-1">
                    {pred.factors.map((factor, i) => (
                      <li key={i}>{factor}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}