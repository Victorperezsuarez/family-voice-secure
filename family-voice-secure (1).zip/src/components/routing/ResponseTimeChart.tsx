import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';

interface ResponseTimeChartProps {
  data: Array<{
    memberName: string;
    avgResponseTime: number;
    avgResolutionTime: number;
  }>;
}

export function ResponseTimeChart({ data }: ResponseTimeChartProps) {
  const chartData = data.map(d => ({
    name: d.memberName,
    'Avg Response (min)': (d.avgResponseTime / 60).toFixed(1),
    'Avg Resolution (min)': (d.avgResolutionTime / 60).toFixed(1)
  }));

  return (
    <Card>
      <CardHeader>
        <CardTitle>Response & Resolution Times by Team Member</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis label={{ value: 'Minutes', angle: -90, position: 'insideLeft' }} />
            <Tooltip />
            <Legend />
            <Bar dataKey="Avg Response (min)" fill="#3b82f6" />
            <Bar dataKey="Avg Resolution (min)" fill="#8b5cf6" />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
