import { LineChart, Line, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ComposedChart } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface ForecastData {
  date: string;
  predicted_volume: number;
  confidence_lower: number;
  confidence_upper: number;
  actual_volume?: number;
}

interface AlertVolumeForecastChartProps {
  data: ForecastData[];
}

export default function AlertVolumeForecastChart({ data }: AlertVolumeForecastChartProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Alert Volume Forecast (7-Day)</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <ComposedChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Area
              type="monotone"
              dataKey="confidence_upper"
              stackId="1"
              stroke="none"
              fill="#93c5fd"
              fillOpacity={0.3}
              name="Upper Confidence"
            />
            <Area
              type="monotone"
              dataKey="confidence_lower"
              stackId="1"
              stroke="none"
              fill="#93c5fd"
              fillOpacity={0.3}
              name="Lower Confidence"
            />
            <Line
              type="monotone"
              dataKey="predicted_volume"
              stroke="#3b82f6"
              strokeWidth={2}
              name="Predicted"
            />
            {data.some(d => d.actual_volume) && (
              <Line
                type="monotone"
                dataKey="actual_volume"
                stroke="#10b981"
                strokeWidth={2}
                name="Actual"
              />
            )}
          </ComposedChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}