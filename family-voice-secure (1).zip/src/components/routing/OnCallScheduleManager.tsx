import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar, Plus, Edit, Clock } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';

export function OnCallScheduleManager() {
  const [schedules, setSchedules] = useState<any[]>([]);
  const [members, setMembers] = useState<any[]>([]);

  useEffect(() => {
    loadSchedules();
    loadMembers();
  }, []);

  const loadSchedules = async () => {
    const { data } = await supabase
      .from('on_call_schedules')
      .select('*')
      .order('created_at', { ascending: false });
    setSchedules(data || []);
  };

  const loadMembers = async () => {
    const { data } = await supabase.from('team_members').select('*');
    setMembers(data || []);
  };

  const getCurrentOnCall = (schedule: any) => {
    return members.find(m => m.id === schedule.current_on_call_id);
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>On-Call Schedules</CardTitle>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Create Schedule
          </Button>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {schedules.map((schedule) => {
              const currentOnCall = getCurrentOnCall(schedule);
              return (
                <div key={schedule.id} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <div className="font-medium text-lg">{schedule.name}</div>
                      <div className="text-sm text-muted-foreground flex items-center gap-2 mt-1">
                        <Calendar className="h-4 w-4" />
                        {schedule.rotation_type}
                      </div>
                    </div>
                    <Badge variant={schedule.is_active ? 'default' : 'secondary'}>
                      {schedule.is_active ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>

                  {currentOnCall && (
                    <div className="bg-muted p-3 rounded-lg mb-3">
                      <div className="text-sm text-muted-foreground mb-1">Currently On-Call</div>
                      <div className="font-medium">{currentOnCall.name}</div>
                      <div className="text-sm text-muted-foreground">{currentOnCall.email}</div>
                    </div>
                  )}

                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-4">
                      <div>
                        <span className="text-muted-foreground">Team Members:</span>
                        <span className="ml-2 font-medium">{schedule.team_member_ids?.length || 0}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <span className="text-muted-foreground">
                          {new Date(schedule.start_date).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">
                      <Edit className="h-4 w-4 mr-2" />
                      Edit
                    </Button>
                  </div>
                </div>
              );
            })}

            {schedules.length === 0 && (
              <div className="text-center py-12 text-muted-foreground">
                <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No on-call schedules configured</p>
                <p className="text-sm mt-2">Create a schedule to manage team rotations</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
