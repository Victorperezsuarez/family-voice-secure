import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { X } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';

interface TeamMemberDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  member: any;
  onSave: () => void;
}

export function TeamMemberDialog({ open, onOpenChange, member, onSave }: TeamMemberDialogProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    role: '',
    skills: [] as string[],
    max_concurrent_alerts: 5
  });
  const [skillInput, setSkillInput] = useState('');

  useEffect(() => {
    if (member) {
      setFormData({
        name: member.name || '',
        email: member.email || '',
        role: member.role || '',
        skills: member.skills || [],
        max_concurrent_alerts: member.max_concurrent_alerts || 5
      });
    } else {
      setFormData({ name: '', email: '', role: '', skills: [], max_concurrent_alerts: 5 });
    }
  }, [member]);

  const addSkill = () => {
    if (skillInput && !formData.skills.includes(skillInput)) {
      setFormData({ ...formData, skills: [...formData.skills, skillInput] });
      setSkillInput('');
    }
  };

  const removeSkill = (skill: string) => {
    setFormData({ ...formData, skills: formData.skills.filter(s => s !== skill) });
  };

  const handleSave = async () => {
    if (member) {
      await supabase.from('team_members').update(formData).eq('id', member.id);
    } else {
      await supabase.from('team_members').insert([{ ...formData, family_id: 'default' }]);
    }
    onSave();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>{member ? 'Edit' : 'Add'} Team Member</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label>Name</Label>
            <Input value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} />
          </div>
          <div>
            <Label>Email</Label>
            <Input type="email" value={formData.email} onChange={(e) => setFormData({ ...formData, email: e.target.value })} />
          </div>
          <div>
            <Label>Role</Label>
            <Input value={formData.role} onChange={(e) => setFormData({ ...formData, role: e.target.value })} />
          </div>
          <div>
            <Label>Max Concurrent Alerts</Label>
            <Input type="number" value={formData.max_concurrent_alerts} onChange={(e) => setFormData({ ...formData, max_concurrent_alerts: parseInt(e.target.value) })} />
          </div>
          <div>
            <Label>Skills</Label>
            <div className="flex gap-2 mb-2">
              <Input value={skillInput} onChange={(e) => setSkillInput(e.target.value)} onKeyPress={(e) => e.key === 'Enter' && addSkill()} placeholder="Add skill..." />
              <Button onClick={addSkill}>Add</Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {formData.skills.map((skill) => (
                <Badge key={skill} variant="secondary">
                  {skill}
                  <X className="h-3 w-3 ml-1 cursor-pointer" onClick={() => removeSkill(skill)} />
                </Badge>
              ))}
            </div>
          </div>
          <Button onClick={handleSave} className="w-full">Save</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
