import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Play, Save, Music } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { useToast } from '@/hooks/use-toast';

interface Photo {
  id: string;
  photo_url: string;
  title?: string;
}

export function PhotoSlideshowCreator({ familyId, selectedPhotos }: { familyId: string; selectedPhotos: string[] }) {
  const [name, setName] = useState('');
  const [duration, setDuration] = useState(5);
  const [transition, setTransition] = useState('fade');
  const [recordings, setRecordings] = useState<any[]>([]);
  const [selectedRecording, setSelectedRecording] = useState('');
  const [playing, setPlaying] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadRecordings();
  }, []);

  const loadRecordings = async () => {
    const { data } = await supabase
      .from('recordings')
      .select('id, title, audio_url')
      .eq('family_id', familyId);
    if (data) setRecordings(data);
  };

  const createSlideshow = async () => {
    try {
      const recording = recordings.find(r => r.id === selectedRecording);
      const { error } = await supabase.from('photo_slideshows').insert({
        family_id: familyId,
        name,
        photo_ids: selectedPhotos,
        recording_id: selectedRecording || null,
        duration_per_photo: duration,
        transition_type: transition,
        music_url: recording?.audio_url
      });

      if (error) throw error;
      toast({ title: 'Success', description: 'Slideshow created' });
    } catch (error: any) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    }
  };

  const transitions = [
    { value: 'fade', label: 'Fade' },
    { value: 'slide', label: 'Slide' },
    { value: 'zoom', label: 'Zoom' },
    { value: 'dissolve', label: 'Dissolve' }
  ];

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold mb-4">Create Slideshow</h3>
        <p className="text-sm text-gray-500">{selectedPhotos.length} photos selected</p>
      </div>

      <div className="space-y-4">
        <Input
          placeholder="Slideshow name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />

        <div>
          <label className="text-sm font-medium">Duration per photo (seconds)</label>
          <Slider
            value={[duration]}
            onValueChange={([v]) => setDuration(v)}
            min={2}
            max={10}
            step={1}
          />
          <p className="text-xs text-gray-500 mt-1">{duration}s per photo</p>
        </div>

        <div>
          <label className="text-sm font-medium">Transition</label>
          <Select value={transition} onValueChange={setTransition}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {transitions.map((t) => (
                <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <label className="text-sm font-medium flex items-center gap-2">
            <Music className="h-4 w-4" />
            Background Music (from recordings)
          </label>
          <Select value={selectedRecording} onValueChange={setSelectedRecording}>
            <SelectTrigger>
              <SelectValue placeholder="Select recording" />
            </SelectTrigger>
            <SelectContent>
              {recordings.map((r) => (
                <SelectItem key={r.id} value={r.id}>{r.title}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="flex gap-2">
          <Button onClick={createSlideshow} className="flex-1">
            <Save className="h-4 w-4 mr-2" />
            Save Slideshow
          </Button>
          <Button variant="outline" onClick={() => setPlaying(!playing)}>
            <Play className="h-4 w-4 mr-2" />
            Preview
          </Button>
        </div>
      </div>
    </div>
  );
}
