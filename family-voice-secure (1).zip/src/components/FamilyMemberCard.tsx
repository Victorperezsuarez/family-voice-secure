import { FamilyMember } from '@/types/family';
import { User } from 'lucide-react';

interface FamilyMemberCardProps {
  member: FamilyMember;
  isSelected?: boolean;
  onClick?: () => void;
}

export function FamilyMemberCard({ member, isSelected, onClick }: FamilyMemberCardProps) {
  return (
    <div
      onClick={onClick}
      className={`
        relative overflow-hidden rounded-2xl cursor-pointer transition-all duration-300
        ${isSelected 
          ? 'ring-4 ring-amber-500 shadow-xl scale-105' 
          : 'hover:shadow-lg hover:scale-102 bg-white/80 backdrop-blur-sm'
        }
      `}
    >
      <div className="aspect-square relative">
        {member.photo_url ? (
          <img
            src={member.photo_url}
            alt={member.name}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-amber-100 to-orange-100 flex items-center justify-center">
            <User className="w-16 h-16 text-amber-600" />
          </div>
        )}
        
        {isSelected && (
          <div className="absolute inset-0 bg-amber-500/20 flex items-center justify-center">
            <div className="w-12 h-12 rounded-full bg-amber-500 flex items-center justify-center">
              <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
              </svg>
            </div>
          </div>
        )}
      </div>
      
      <div className="p-4 bg-gradient-to-b from-white/90 to-amber-50/90 backdrop-blur-sm">
        <h3 className="font-semibold text-gray-900 truncate">{member.name}</h3>
        <p className="text-sm text-amber-700 capitalize">{member.relationship}</p>
      </div>
    </div>
  );
}
