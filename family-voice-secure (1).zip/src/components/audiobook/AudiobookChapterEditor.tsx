import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Plus, Trash2, GripVertical } from 'lucide-react';

interface Chapter {
  number: number;
  title: string;
  content: string;
}

interface AudiobookChapterEditorProps {
  chapters: Chapter[];
  onChange: (chapters: Chapter[]) => void;
}

export function AudiobookChapterEditor({ chapters, onChange }: AudiobookChapterEditorProps) {
  const addChapter = () => {
    onChange([...chapters, { number: chapters.length + 1, title: '', content: '' }]);
  };

  const updateChapter = (index: number, field: keyof Chapter, value: string) => {
    const updated = [...chapters];
    updated[index] = { ...updated[index], [field]: value };
    onChange(updated);
  };

  const removeChapter = (index: number) => {
    const updated = chapters.filter((_, i) => i !== index);
    onChange(updated.map((ch, i) => ({ ...ch, number: i + 1 })));
  };

  return (
    <Card className="p-6">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <Label className="text-lg">Chapters</Label>
          <Button variant="outline" size="sm" onClick={addChapter}>
            <Plus className="w-4 h-4 mr-2" />
            Add Chapter
          </Button>
        </div>
        {chapters.map((chapter, index) => (
          <Card key={index} className="p-4">
            <div className="flex items-start gap-3">
              <GripVertical className="w-5 h-5 text-muted-foreground mt-2" />
              <div className="flex-1 space-y-3">
                <div className="flex items-center gap-2">
                  <Label className="text-sm">Chapter {chapter.number}</Label>
                  <Input
                    value={chapter.title}
                    onChange={(e) => updateChapter(index, 'title', e.target.value)}
                    placeholder="Chapter Title"
                    className="flex-1"
                  />
                </div>
                <Textarea
                  value={chapter.content}
                  onChange={(e) => updateChapter(index, 'content', e.target.value)}
                  placeholder="Chapter content..."
                  rows={4}
                />
              </div>
              <Button variant="ghost" size="icon" onClick={() => removeChapter(index)}>
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          </Card>
        ))}
      </div>
    </Card>
  );
}
