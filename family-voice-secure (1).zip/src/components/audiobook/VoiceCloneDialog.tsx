import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { VoiceTrainingWizard } from './VoiceTrainingWizard';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';

interface VoiceCloneDialogProps {
  open: boolean;
  onClose: () => void;
}

export function VoiceCloneDialog({ open, onClose }: VoiceCloneDialogProps) {
  const [activeTab, setActiveTab] = useState('training');

  const handleTrainingComplete = async (voiceId: string) => {
    await supabase.from('narrator_voices').insert({
      name: `My Voice ${new Date().toLocaleDateString()}`,
      type: 'cloned',
      voice_id: voiceId
    });
    toast.success('Voice saved successfully!');
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Clone Your Voice</DialogTitle>
        </DialogHeader>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="training">Guided Training</TabsTrigger>
            <TabsTrigger value="upload">Upload Samples</TabsTrigger>
          </TabsList>
          <TabsContent value="training" className="mt-6">
            <VoiceTrainingWizard 
              onComplete={handleTrainingComplete}
              onCancel={onClose}
            />
          </TabsContent>
          <TabsContent value="upload" className="mt-6">
            <QuickUploadForm onClose={onClose} />
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}

function QuickUploadForm({ onClose }: { onClose: () => void }) {
  const [name, setName] = useState('');
  const [files, setFiles] = useState<File[]>([]);
  const [isCloning, setIsCloning] = useState(false);

  const handleClone = async () => {
    if (!name || files.length === 0) {
      toast.error('Please provide a name and audio files');
      return;
    }

    setIsCloning(true);
    try {
      const formData = new FormData();
      formData.append('name', name);
      files.forEach((file, i) => formData.append(`sample_${i}`, file));

      const { data, error } = await supabase.functions.invoke('clone-voice-elevenlabs', {
        body: formData
      });

      if (error) throw error;

      await supabase.from('narrator_voices').insert({
        name,
        type: 'cloned',
        voice_id: data.voiceId
      });

      toast.success('Voice cloned successfully!');
      onClose();
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setIsCloning(false);
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <Label>Voice Name</Label>
        <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Grandma's Voice" />
      </div>
      <div>
        <Label>Audio Files</Label>
        <Input type="file" accept="audio/*" multiple onChange={(e) => setFiles(Array.from(e.target.files || []))} />
        <p className="text-xs text-muted-foreground mt-1">Upload 3-5 clear audio samples (30s-3min each)</p>
      </div>
      <Button onClick={handleClone} disabled={isCloning} className="w-full">
        {isCloning ? 'Cloning...' : 'Clone Voice'}
      </Button>
    </div>
  );
}

