import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Mic, Check, X, Loader2, Volume2, Globe } from 'lucide-react';
import { analyzeAudioQuality, AudioQualityMetrics } from '@/utils/audioQualityAnalyzer';
import { LANGUAGE_TRAINING_SETS, MIN_REQUIRED_SAMPLES, LanguageTrainingSet } from '@/data/voiceTrainingPhrases';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';

interface VoiceSample {
  phraseId: number;
  audioBlob: Blob;
  quality: AudioQualityMetrics;
  pronunciationScore?: number;
}

interface VoiceTrainingWizardProps {
  onComplete: (voiceId: string) => void;
  onCancel: () => void;
}

type WizardStep = 'language' | 'intro' | 'recording' | 'processing' | 'complete';

export function VoiceTrainingWizard({ onComplete, onCancel }: VoiceTrainingWizardProps) {
  const [step, setStep] = useState<WizardStep>('language');
  const [selectedLanguage, setSelectedLanguage] = useState<LanguageTrainingSet | null>(null);
  const [currentPhraseIndex, setCurrentPhraseIndex] = useState(0);
  const [samples, setSamples] = useState<VoiceSample[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [currentQuality, setCurrentQuality] = useState<AudioQualityMetrics | null>(null);
  const [pronunciationFeedback, setPronunciationFeedback] = useState<string>('');
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  const currentPhrase = selectedLanguage?.phrases[currentPhraseIndex];
  const progress = (samples.length / MIN_REQUIRED_SAMPLES) * 100;
  const avgQuality = samples.length > 0 
    ? samples.reduce((sum, s) => sum + s.quality.overallScore, 0) / samples.length 
    : 0;

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data);
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        stream.getTracks().forEach(track => track.stop());
        await processRecording(audioBlob);
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (error) {
      toast.error('Failed to access microphone');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const analyzePronunciation = async (audioBlob: Blob): Promise<{ score: number; feedback: string }> => {
    // Simulate pronunciation analysis
    const baseScore = 75 + Math.random() * 20;
    const feedback = baseScore > 85 
      ? 'Excellent pronunciation! Clear and natural.'
      : baseScore > 70
      ? 'Good pronunciation. Minor accent detected.'
      : 'Acceptable. Try speaking more clearly.';
    
    return { score: baseScore, feedback };
  };

  const processRecording = async (audioBlob: Blob) => {
    setIsAnalyzing(true);
    try {
      const quality = await analyzeAudioQuality(audioBlob);
      const pronunciation = await analyzePronunciation(audioBlob);
      
      setCurrentQuality(quality);
      setPronunciationFeedback(pronunciation.feedback);

      if (quality.passed) {
        setSamples(prev => [...prev, {
          phraseId: currentPhrase!.id,
          audioBlob,
          quality,
          pronunciationScore: pronunciation.score
        }]);
        
        if (samples.length + 1 >= MIN_REQUIRED_SAMPLES) {
          setTimeout(() => triggerVoiceCloning([...samples, { 
            phraseId: currentPhrase!.id, 
            audioBlob, 
            quality,
            pronunciationScore: pronunciation.score 
          }]), 1500);
        } else {
          setTimeout(() => {
            setCurrentPhraseIndex(prev => prev + 1);
            setCurrentQuality(null);
            setPronunciationFeedback('');
          }, 2000);
        }
      }
    } catch (error) {
      toast.error('Failed to analyze audio quality');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const triggerVoiceCloning = async (allSamples: VoiceSample[]) => {
    setStep('processing');
    
    try {
      const formData = new FormData();
      allSamples.forEach((sample, index) => {
        formData.append(`sample_${index}`, sample.audioBlob, `sample_${index}.webm`);
      });
      
      const avgPronunciation = allSamples.reduce((sum, s) => sum + (s.pronunciationScore || 0), 0) / allSamples.length;
      
      formData.append('name', `${selectedLanguage?.name} Voice ${new Date().toLocaleDateString()}`);
      formData.append('language', selectedLanguage?.code || 'en');
      formData.append('accent_quality_score', avgPronunciation.toFixed(0));
      formData.append('pronunciation_notes', `Average pronunciation quality: ${avgPronunciation.toFixed(1)}%`);

      const { data, error } = await supabase.functions.invoke('clone-voice-elevenlabs', {
        body: formData
      });

      if (error) throw error;

      toast.success('Voice cloned successfully!');
      setStep('complete');
      setTimeout(() => onComplete(data.voiceId), 1500);
    } catch (error) {
      toast.error('Failed to clone voice');
      setStep('recording');
    }
  };

  if (step === 'language') {
    return (
      <Card className="p-6 max-w-3xl mx-auto">
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
          <Globe className="w-6 h-6" />
          Select Training Language
        </h2>
        <p className="text-muted-foreground mb-6">
          Choose the language for your voice clone. You'll record phrases in this language.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {LANGUAGE_TRAINING_SETS.map((lang) => (
            <Card
              key={lang.code}
              className={`p-4 cursor-pointer transition-all hover:shadow-md ${
                selectedLanguage?.code === lang.code ? 'ring-2 ring-primary' : ''
              }`}
              onClick={() => setSelectedLanguage(lang)}
            >
              <div className="flex items-center gap-3">
                <span className="text-3xl">{lang.flag}</span>
                <div>
                  <h3 className="font-semibold">{lang.name}</h3>
                  <p className="text-sm text-muted-foreground">{lang.nativeName}</p>
                  <p className="text-xs text-muted-foreground mt-1">{lang.phrases.length} phrases</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
        <div className="flex gap-3">
          <Button 
            onClick={() => setStep('intro')} 
            size="lg" 
            disabled={!selectedLanguage}
          >
            Continue
          </Button>
          <Button onClick={onCancel} variant="outline" size="lg">Cancel</Button>
        </div>
      </Card>
    );
  }

  if (step === 'intro') {
    return (
      <Card className="p-6 max-w-2xl mx-auto">
        <h2 className="text-2xl font-bold mb-2">Voice Training - {selectedLanguage?.name}</h2>
        <p className="text-muted-foreground mb-6">
          Record {MIN_REQUIRED_SAMPLES} voice samples to create your personalized AI narrator voice.
        </p>
        <div className="space-y-4 mb-6">
          <div className="flex items-start gap-3">
            <Volume2 className="w-5 h-5 mt-1 text-primary" />
            <div>
              <p className="font-medium">Clear Environment</p>
              <p className="text-sm text-muted-foreground">Find a quiet space with minimal background noise</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <Mic className="w-5 h-5 mt-1 text-primary" />
            <div>
              <p className="font-medium">Natural Voice</p>
              <p className="text-sm text-muted-foreground">Speak naturally at a comfortable pace</p>
            </div>
          </div>
        </div>
        <div className="flex gap-3">
          <Button onClick={() => setStep('recording')} size="lg">Start Training</Button>
          <Button onClick={() => setStep('language')} variant="outline" size="lg">Back</Button>
        </div>
      </Card>
    );
  }

  if (step === 'processing') {
    return (
      <Card className="p-8 max-w-2xl mx-auto text-center">
        <Loader2 className="w-12 h-12 animate-spin mx-auto mb-4 text-primary" />
        <h2 className="text-2xl font-bold mb-2">Creating Your Voice Clone</h2>
        <p className="text-muted-foreground">Processing {samples.length} voice samples in {selectedLanguage?.name}...</p>
      </Card>
    );
  }

  if (step === 'complete') {
    return (
      <Card className="p-8 max-w-2xl mx-auto text-center">
        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <Check className="w-8 h-8 text-green-600" />
        </div>
        <h2 className="text-2xl font-bold mb-2">Voice Clone Complete!</h2>
        <p className="text-muted-foreground">Your personalized {selectedLanguage?.name} narrator voice is ready.</p>
      </Card>
    );
  }

  return (
    <Card className="p-6 max-w-2xl mx-auto">
      <div className="mb-6">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm font-medium">Sample {samples.length + 1} of {MIN_REQUIRED_SAMPLES}</span>
          <span className="text-sm text-muted-foreground">Avg Quality: {avgQuality.toFixed(0)}%</span>
        </div>
        <Progress value={progress} className="h-2" />
      </div>

      <div className="bg-muted p-6 rounded-lg mb-6">
        <div className="flex gap-2 mb-3">
          <Badge>{currentPhrase?.phonemesFocus}</Badge>
          <Badge variant="outline">{selectedLanguage?.flag} {selectedLanguage?.name}</Badge>
        </div>
        <p className="text-lg leading-relaxed">{currentPhrase?.text}</p>
      </div>

      {currentQuality && (
        <div className="mb-6 p-4 border rounded-lg">
          <div className="flex items-center gap-2 mb-3">
            {currentQuality.passed ? (
              <Check className="w-5 h-5 text-green-600" />
            ) : (
              <X className="w-5 h-5 text-red-600" />
            )}
            <span className="font-medium">
              Quality Score: {currentQuality.overallScore.toFixed(0)}%
            </span>
          </div>
          {pronunciationFeedback && (
            <p className="text-sm text-muted-foreground mb-3">{pronunciationFeedback}</p>
          )}
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div>Volume: {currentQuality.volumeLevel.toFixed(0)}%</div>
            <div>Clarity: {currentQuality.clarity.toFixed(0)}%</div>
            <div>Noise: {currentQuality.backgroundNoise.toFixed(0)}%</div>
            <div>Duration: {currentQuality.duration.toFixed(1)}s</div>
          </div>
        </div>
      )}

      <div className="flex gap-3">
        {!isRecording && !isAnalyzing && (
          <Button onClick={startRecording} size="lg" className="flex-1">
            <Mic className="w-4 h-4 mr-2" />
            Start Recording
          </Button>
        )}
        {isRecording && (
          <Button onClick={stopRecording} size="lg" variant="destructive" className="flex-1">
            Stop Recording
          </Button>
        )}
        {isAnalyzing && (
          <Button disabled size="lg" className="flex-1">
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            Analyzing...
          </Button>
        )}
        <Button onClick={onCancel} variant="outline" size="lg">Cancel</Button>
      </div>
    </Card>
  );
}
