import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { BookOpen, Wand2, Globe } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';
import { VoiceSelectionPanel } from './VoiceSelectionPanel';
import { BackgroundMusicSelector } from './BackgroundMusicSelector';
import { AudiobookChapterEditor } from './AudiobookChapterEditor';

export function AIAudiobookGenerator({ recordingId }: { recordingId?: string }) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [language, setLanguage] = useState('en');
  const [chapters, setChapters] = useState<any[]>([]);
  const [selectedVoice, setSelectedVoice] = useState<string>('');
  const [selectedMusic, setSelectedMusic] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);

  const languages = [
    { code: 'en', name: 'English' },
    { code: 'es', name: 'Spanish (Español)' },
    { code: 'fr', name: 'French (Français)' },
    { code: 'de', name: 'German (Deutsch)' }
  ];

  const handleGenerate = async () => {
    if (!title || chapters.length === 0) {
      toast.error('Please provide a title and at least one chapter');
      return;
    }

    if (!selectedVoice) {
      toast.error('Please select a narrator voice');
      return;
    }

    setIsGenerating(true);
    try {
      const { data: audiobook, error } = await supabase
        .from('audiobooks')
        .insert({
          title,
          description,
          narrator_voice_id: selectedVoice,
          background_music_id: selectedMusic,
          language,
          status: 'generating'
        })
        .select()
        .single();

      if (error) throw error;

      for (const chapter of chapters) {
        await supabase.from('audiobook_chapters').insert({
          audiobook_id: audiobook.id,
          chapter_number: chapter.number,
          title: chapter.title,
          content: chapter.content,
          narrator_voice_id: selectedVoice,
          background_music_id: selectedMusic
        });
      }

      // Trigger narration generation
      await supabase.functions.invoke('generate-ai-narration', {
        body: { 
          audiobookId: audiobook.id,
          language 
        }
      });

      toast.success('Audiobook generation started!');
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <BookOpen className="w-5 h-5" />
          <h2 className="text-xl font-semibold">Create AI Audiobook</h2>
        </div>
        <div className="space-y-4">
          <div>
            <Label>Title</Label>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="My Family Story" />
          </div>
          <div>
            <Label>Description</Label>
            <Textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="A collection of family memories..." />
          </div>
          <div>
            <Label className="flex items-center gap-2">
              <Globe className="w-4 h-4" />
              Narration Language
            </Label>
            <Select value={language} onValueChange={setLanguage}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {languages.map(lang => (
                  <SelectItem key={lang.code} value={lang.code}>
                    {lang.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground mt-1">
              Select voices trained in this language for best results
            </p>
          </div>
        </div>
      </Card>

      <VoiceSelectionPanel onSelect={setSelectedVoice} selectedLanguage={language} />
      <BackgroundMusicSelector onSelect={setSelectedMusic} />
      <AudiobookChapterEditor chapters={chapters} onChange={setChapters} />

      <Button onClick={handleGenerate} disabled={isGenerating} className="w-full">
        <Wand2 className="w-4 h-4 mr-2" />
        {isGenerating ? 'Generating...' : 'Generate Audiobook'}
      </Button>
    </div>
  );
}
