import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Mic, Play, Plus, Globe } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { NarratorVoice } from '@/types/audiobook';
import { VoiceCloneDialog } from './VoiceCloneDialog';

interface VoiceSelectionPanelProps {
  onSelect: (voiceId: string) => void;
  selectedLanguage?: string;
}

export function VoiceSelectionPanel({ onSelect, selectedLanguage }: VoiceSelectionPanelProps) {
  const [voices, setVoices] = useState<NarratorVoice[]>([]);
  const [selected, setSelected] = useState<string>('');
  const [showCloneDialog, setShowCloneDialog] = useState(false);
  const [languageFilter, setLanguageFilter] = useState<string>(selectedLanguage || 'all');

  useEffect(() => {
    loadVoices();
  }, []);

  useEffect(() => {
    if (selectedLanguage) {
      setLanguageFilter(selectedLanguage);
    }
  }, [selectedLanguage]);

  const loadVoices = async () => {
    const { data } = await supabase
      .from('narrator_voices')
      .select('*')
      .order('created_at', { ascending: false });
    if (data) setVoices(data);
  };

  const filteredVoices = languageFilter === 'all' 
    ? voices 
    : voices.filter(v => v.language === languageFilter);

  const availableLanguages = Array.from(new Set(voices.map(v => v.language || 'en')));

  const handleSelect = (voiceId: string) => {
    setSelected(voiceId);
    onSelect(voiceId);
  };

  const playPreview = async (voice: NarratorVoice) => {
    if (voice.sample_audio_url) {
      const audio = new Audio(voice.sample_audio_url);
      audio.play();
    }
  };

  const getLanguageName = (code: string) => {
    const names: Record<string, string> = {
      'en': 'English',
      'es': 'Spanish',
      'fr': 'French',
      'de': 'German'
    };
    return names[code] || code.toUpperCase();
  };

  return (
    <>
      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <Label className="text-lg">Select Narrator Voice</Label>
          <div className="flex gap-2">
            <Select value={languageFilter} onValueChange={setLanguageFilter}>
              <SelectTrigger className="w-[140px]">
                <Globe className="w-4 h-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Languages</SelectItem>
                {availableLanguages.map(lang => (
                  <SelectItem key={lang} value={lang}>
                    {getLanguageName(lang)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button variant="outline" size="sm" onClick={() => setShowCloneDialog(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Clone Voice
            </Button>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {filteredVoices.map((voice) => (
            <div
              key={voice.id}
              className={`p-4 border rounded-lg cursor-pointer transition ${
                selected === voice.id ? 'border-primary bg-primary/5' : 'hover:border-primary/50'
              }`}
              onClick={() => handleSelect(voice.id)}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Mic className="w-4 h-4" />
                  <div>
                    <p className="font-medium">{voice.name}</p>
                    <p className="text-xs text-muted-foreground">{voice.type}</p>
                  </div>
                </div>
                {voice.sample_audio_url && (
                  <Button variant="ghost" size="sm" onClick={(e) => { e.stopPropagation(); playPreview(voice); }}>
                    <Play className="w-4 h-4" />
                  </Button>
                )}
              </div>
              <div className="flex gap-2">
                <Badge variant="secondary" className="text-xs">
                  {getLanguageName(voice.language || 'en')}
                </Badge>
                {voice.accent_quality_score && (
                  <Badge variant="outline" className="text-xs">
                    Quality: {voice.accent_quality_score}%
                  </Badge>
                )}
              </div>
            </div>
          ))}
        </div>
        {filteredVoices.length === 0 && (
          <p className="text-center text-muted-foreground py-8">
            No voices available for {getLanguageName(languageFilter)}. Clone a voice to get started.
          </p>
        )}
      </Card>
      {showCloneDialog && <VoiceCloneDialog open={showCloneDialog} onClose={() => { setShowCloneDialog(false); loadVoices(); }} />}
    </>
  );
}
