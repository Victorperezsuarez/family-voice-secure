import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase-client';
import { useAuth } from '@/contexts/AuthContext';
import { Family } from '@/types/family';
import { Button } from '@/components/ui/button';
import { Check, ChevronDown, Plus, Settings } from 'lucide-react';

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';

interface FamilySwitcherProps {
  onCreateFamily: () => void;
  onViewAllFamilies: () => void;
  onOpenSettings?: () => void;
}

export function FamilySwitcher({ onCreateFamily, onViewAllFamilies, onOpenSettings }: FamilySwitcherProps) {

  const { user } = useAuth();
  const { toast } = useToast();
  const [families, setFamilies] = useState<Family[]>([]);
  const [currentFamilyId, setCurrentFamilyId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadFamilies();
    }
  }, [user]);

  const loadFamilies = async () => {
    if (!user) return;
    
    try {
      const { data: familyUsers } = await supabase
        .from('family_users')
        .select('family_id, families(*)')
        .eq('user_id', user.id);

      if (familyUsers) {
        const fams = familyUsers.map(fu => fu.families).filter(Boolean);
        setFamilies(fams as Family[]);
      }

      const { data: profile } = await supabase
        .from('profiles')
        .select('current_family_id')
        .eq('id', user.id)
        .single();

      if (profile?.current_family_id) {
        setCurrentFamilyId(profile.current_family_id);
      } else if (fams.length > 0) {
        setCurrentFamilyId(fams[0].id);
      }
    } catch (error) {
      console.error('Error loading families:', error);
    } finally {
      setLoading(false);
    }
  };

  const switchFamily = async (familyId: string) => {
    if (!user) return;

    try {
      await supabase
        .from('profiles')
        .update({ current_family_id: familyId })
        .eq('id', user.id);

      setCurrentFamilyId(familyId);
      toast({ title: 'Family switched successfully' });
      window.location.reload();
    } catch (error) {
      toast({ title: 'Failed to switch family', variant: 'destructive' });
    }
  };

  const currentFamily = families.find(f => f.id === currentFamilyId);

  if (loading) return null;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" className="gap-2">
          {currentFamily?.name || 'Select Family'}
          <ChevronDown className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        {families.map(family => (
          <DropdownMenuItem
            key={family.id}
            onClick={() => switchFamily(family.id)}
            className="flex items-center justify-between"
          >
            <span>{family.name}</span>
            {family.id === currentFamilyId && <Check className="h-4 w-4" />}
          </DropdownMenuItem>
        ))}
        <DropdownMenuSeparator />
        {onOpenSettings && currentFamilyId && (
          <DropdownMenuItem onClick={onOpenSettings}>
            <Settings className="h-4 w-4 mr-2" />
            Family Settings
          </DropdownMenuItem>
        )}
        <DropdownMenuItem onClick={onCreateFamily}>
          <Plus className="h-4 w-4 mr-2" />
          Create Family
        </DropdownMenuItem>
        <DropdownMenuItem onClick={onViewAllFamilies}>
          View All Families
        </DropdownMenuItem>

      </DropdownMenuContent>
    </DropdownMenu>
  );
}
