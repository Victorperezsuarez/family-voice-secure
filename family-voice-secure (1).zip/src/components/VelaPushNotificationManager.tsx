import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase-client';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Bell, Send, CheckCircle, XCircle, Clock } from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import { useDeviceSync } from '@/hooks/useDeviceSync';

export function VelaPushNotificationManager() {
  const { user } = useAuth();
  const { isRegistered } = useDeviceSync();
  const [stats, setStats] = useState({ sent: 0, delivered: 0, failed: 0, clicked: 0, dismissed: 0 });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user) {
      loadStats();
    }
  }, [user]);

  const loadStats = async () => {
    try {
      const { data, error } = await supabase
        .from('vela_notification_delivery')
        .select('status')
        .eq('user_id', user!.id);

      if (error) throw error;

      const newStats = data?.reduce((acc, item) => {
        acc[item.status] = (acc[item.status] || 0) + 1;
        return acc;
      }, {} as any) || {};

      setStats({
        sent: newStats.sent || 0,
        delivered: newStats.delivered || 0,
        failed: newStats.failed || 0,
        clicked: newStats.clicked || 0,
        dismissed: newStats.dismissed || 0
      });
    } catch (error) {
      console.error('Error loading stats:', error);
    }
  };

  const sendTestNotification = async () => {
    setLoading(true);
    try {
      await supabase.functions.invoke('send-vela-push-notification', {
        body: {
          userId: user!.id,
          title: 'Test Notification',
          body: 'This is a test notification from Vela',
          urgency: 'medium',
          suggestionType: 'test'
        }
      });
      toast.success('Test notification sent');
      setTimeout(loadStats, 1000);
    } catch (error) {
      toast.error('Failed to send test notification');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bell className="h-5 w-5" />
          Push Notification Manager
        </CardTitle>
        <CardDescription>
          Manage and monitor push notification delivery
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <div className="p-4 bg-blue-50 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Send className="h-4 w-4 text-blue-600" />
              <span className="text-sm font-medium">Sent</span>
            </div>
            <p className="text-2xl font-bold text-blue-600">{stats.sent}</p>
          </div>
          <div className="p-4 bg-green-50 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span className="text-sm font-medium">Delivered</span>
            </div>
            <p className="text-2xl font-bold text-green-600">{stats.delivered}</p>
          </div>
          <div className="p-4 bg-red-50 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <XCircle className="h-4 w-4 text-red-600" />
              <span className="text-sm font-medium">Failed</span>
            </div>
            <p className="text-2xl font-bold text-red-600">{stats.failed}</p>
          </div>
          <div className="p-4 bg-purple-50 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Clock className="h-4 w-4 text-purple-600" />
              <span className="text-sm font-medium">Clicked</span>
            </div>
            <p className="text-2xl font-bold text-purple-600">{stats.clicked}</p>
          </div>
          <div className="p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <XCircle className="h-4 w-4 text-gray-600" />
              <span className="text-sm font-medium">Dismissed</span>
            </div>
            <p className="text-2xl font-bold text-gray-600">{stats.dismissed}</p>
          </div>
        </div>

        <div className="flex gap-2">
          <Button onClick={sendTestNotification} disabled={loading || !isRegistered}>
            <Send className="h-4 w-4 mr-2" />
            Send Test Notification
          </Button>
          <Button variant="outline" onClick={loadStats}>
            Refresh Stats
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

