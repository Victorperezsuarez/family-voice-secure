import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { Play, Pause, Volume2, Loader2 } from 'lucide-react';
import { useState } from 'react';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';

interface SpeakerSegment {
  id: string;
  speaker_label: string;
  text: string;
  start_time: number;
  end_time: number;
  identified_member_id?: string;
  identification_confidence?: number;
  emotion?: string;
  emotion_confidence?: number;
  translations?: Record<string, { text: string; emotion?: string }>;
  translated_audio_url?: string;
  voice_characteristics?: any;
  recording_id?: string;
}

interface BilingualTranscriptViewProps {
  segments: SpeakerSegment[];
  originalLanguage: string;
  targetLanguage: string;
  memberNames?: Record<string, string>;
  recordingUrl?: string;
}

const EMOTION_COLORS: Record<string, string> = {
  happy: 'bg-yellow-100 text-yellow-800 border-yellow-300',
  sad: 'bg-blue-100 text-blue-800 border-blue-300',
  excited: 'bg-orange-100 text-orange-800 border-orange-300',
  nostalgic: 'bg-purple-100 text-purple-800 border-purple-300',
  calm: 'bg-green-100 text-green-800 border-green-300',
  angry: 'bg-red-100 text-red-800 border-red-300',
};

export function BilingualTranscriptView({
  segments,
  originalLanguage,
  targetLanguage,
  memberNames = {},
  recordingUrl
}: BilingualTranscriptViewProps) {
  const [playingSegment, setPlayingSegment] = useState<string | null>(null);
  const [generatingAudio, setGeneratingAudio] = useState<string | null>(null);
  const [clonedAudioUrls, setClonedAudioUrls] = useState<Record<string, string>>({});

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const generateClonedAudio = async (segment: SpeakerSegment) => {
    const translation = segment.translations?.[targetLanguage];
    if (!translation) return;

    setGeneratingAudio(segment.id);
    try {
      const { data, error } = await supabase.functions.invoke('clone-voice-translation', {
        body: {
          segmentId: segment.id,
          translatedText: translation.text,
          targetLanguage,
          voiceCharacteristics: segment.voice_characteristics || {},
          originalAudioUrl: recordingUrl
        }
      });

      if (error) throw error;

      setClonedAudioUrls(prev => ({
        ...prev,
        [segment.id]: data.audioUrl
      }));

      toast.success('Voice-cloned audio generated!');
    } catch (error) {
      console.error('Error generating cloned audio:', error);
      toast.error('Failed to generate voice-cloned audio');
    } finally {
      setGeneratingAudio(null);
    }
  };

  const playSegment = (segmentId: string, isTranslated: boolean) => {
    if (playingSegment === `${segmentId}-${isTranslated}`) {
      setPlayingSegment(null);
    } else {
      setPlayingSegment(`${segmentId}-${isTranslated}`);
      toast.info(isTranslated ? 'Playing translated audio' : 'Playing original audio');
    }
  };

  return (
    <ScrollArea className="h-[600px] w-full">
      <div className="space-y-4 p-4">
        {segments.map((segment) => {
          const speakerName = segment.identified_member_id 
            ? memberNames[segment.identified_member_id] || segment.speaker_label
            : segment.speaker_label;
          
          const translation = segment.translations?.[targetLanguage];
          const emotionColor = segment.emotion 
            ? EMOTION_COLORS[segment.emotion.toLowerCase()] || 'bg-gray-100 text-gray-800'
            : 'bg-gray-100 text-gray-800';
          
          const hasClonedAudio = clonedAudioUrls[segment.id] || segment.translated_audio_url;
          const isGenerating = generatingAudio === segment.id;

          return (
            <Card key={segment.id} className="p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Badge variant="outline">{speakerName}</Badge>
                  <span className="text-xs text-muted-foreground">
                    {formatTime(segment.start_time)}
                  </span>
                  {segment.emotion && (
                    <Badge className={emotionColor} variant="outline">
                      {segment.emotion}
                    </Badge>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="border-r pr-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="text-xs font-semibold text-muted-foreground uppercase">
                      {originalLanguage}
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => playSegment(segment.id, false)}
                    >
                      {playingSegment === `${segment.id}-false` ? (
                        <Pause className="h-3 w-3" />
                      ) : (
                        <Play className="h-3 w-3" />
                      )}
                    </Button>
                  </div>
                  <p className="text-sm leading-relaxed">{segment.text}</p>
                </div>

                <div className="pl-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="text-xs font-semibold text-muted-foreground uppercase">
                      {targetLanguage}
                    </div>
                    {translation && (
                      <div className="flex items-center gap-1">
                        {hasClonedAudio ? (
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => playSegment(segment.id, true)}
                          >
                            {playingSegment === `${segment.id}-true` ? (
                              <Pause className="h-3 w-3" />
                            ) : (
                              <Volume2 className="h-3 w-3" />
                            )}
                          </Button>
                        ) : (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => generateClonedAudio(segment)}
                            disabled={isGenerating}
                          >
                            {isGenerating ? (
                              <Loader2 className="h-3 w-3 animate-spin" />
                            ) : (
                              <Volume2 className="h-3 w-3" />
                            )}
                          </Button>
                        )}
                      </div>
                    )}
                  </div>
                  {translation ? (
                    <p className="text-sm leading-relaxed">{translation.text}</p>
                  ) : (
                    <p className="text-sm text-muted-foreground italic">
                      Translation not available
                    </p>
                  )}
                </div>
              </div>
            </Card>
          );
        })}
      </div>
    </ScrollArea>
  );
}