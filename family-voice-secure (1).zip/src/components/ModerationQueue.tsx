import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/lib/supabase-client';
import { useToast } from '@/hooks/use-toast';
import { CheckCircle, XCircle, Flag, Trash2, AlertTriangle, Star } from 'lucide-react';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';


interface Report {
  id: string;
  content_type: string;
  content_id: string;
  reason: string;
  description: string;
  status: string;
  created_at: string;
  reporter_id: string;
}

export function ModerationQueue() {
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedReport, setSelectedReport] = useState<Report | null>(null);
  const [moderationNote, setModerationNote] = useState('');
  const [featuredOrder, setFeaturedOrder] = useState('');
  const [processing, setProcessing] = useState(false);
  const { toast } = useToast();


  useEffect(() => {
    loadReports();
  }, []);

  const loadReports = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('content_reports')
      .select('*')
      .order('created_at', { ascending: false });

    if (!error && data) setReports(data);
    setLoading(false);
  };

  const handleModerate = async (action: string) => {
    if (!selectedReport) return;
    setProcessing(true);

    try {
      const body: any = {
        contentType: selectedReport.content_type,
        contentId: selectedReport.content_id,
        action,
        reason: moderationNote,
        reportId: selectedReport.id
      };

      if (action === 'feature' && featuredOrder) {
        body.featuredOrder = parseInt(featuredOrder);
      }

      const { error } = await supabase.functions.invoke('moderate-content', { body });

      if (error) throw error;

      toast({ title: 'Action completed', description: `Content ${action}d successfully.` });
      setSelectedReport(null);
      setModerationNote('');
      setFeaturedOrder('');
      loadReports();
    } catch (error: any) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    } finally {
      setProcessing(false);
    }
  };


  const filterReports = (status: string) => {
    return reports.filter(r => status === 'all' || r.status === status);
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Moderation Queue</h2>
        <p className="text-muted-foreground">Review and manage reported content</p>
      </div>

      <Tabs defaultValue="pending">
        <TabsList>
          <TabsTrigger value="pending">Pending ({filterReports('pending').length})</TabsTrigger>
          <TabsTrigger value="reviewing">Reviewing ({filterReports('reviewing').length})</TabsTrigger>
          <TabsTrigger value="resolved">Resolved ({filterReports('resolved').length})</TabsTrigger>
          <TabsTrigger value="all">All Reports</TabsTrigger>
        </TabsList>

        {['pending', 'reviewing', 'resolved', 'all'].map(status => (
          <TabsContent key={status} value={status} className="space-y-4">
            {filterReports(status).map(report => (
              <Card key={report.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg flex items-center gap-2">
                        <AlertTriangle className="h-5 w-5 text-amber-500" />
                        {report.content_type === 'template' ? 'Template' : 'Review'} Report
                      </CardTitle>
                      <p className="text-sm text-muted-foreground mt-1">
                        Reported {new Date(report.created_at).toLocaleDateString()}
                      </p>
                    </div>
                    <Badge variant={report.status === 'pending' ? 'destructive' : 'secondary'}>
                      {report.status}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <strong>Reason:</strong> {report.reason}
                  </div>
                  {report.description && (
                    <div>
                      <strong>Details:</strong> {report.description}
                    </div>
                  )}
                  {report.status === 'pending' && (
                    <div className="flex gap-2">
                      <Button size="sm" onClick={() => setSelectedReport(report)}>
                        Review
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </TabsContent>
        ))}
      </Tabs>

      {selectedReport && (
        <Card className="border-2 border-primary">
          <CardHeader>
            <CardTitle>Moderate Content</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Moderation Notes</Label>
              <Textarea
                value={moderationNote}
                onChange={(e) => setModerationNote(e.target.value)}
                placeholder="Add notes about your decision..."
                rows={3}
              />
            </div>
            {selectedReport.content_type === 'template' && (
              <div>
                <Label>Featured Order (optional)</Label>
                <Input
                  type="number"
                  value={featuredOrder}
                  onChange={(e) => setFeaturedOrder(e.target.value)}
                  placeholder="e.g., 1 for first position"
                  min="1"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Lower numbers appear first in featured section
                </p>
              </div>
            )}
            <div className="flex gap-2 flex-wrap">
              <Button onClick={() => handleModerate('approve')} disabled={processing}>
                <CheckCircle className="h-4 w-4 mr-2" />
                Approve
              </Button>
              <Button variant="destructive" onClick={() => handleModerate('reject')} disabled={processing}>
                <XCircle className="h-4 w-4 mr-2" />
                Reject
              </Button>
              <Button variant="outline" onClick={() => handleModerate('flag')} disabled={processing}>
                <Flag className="h-4 w-4 mr-2" />
                Flag
              </Button>
              <Button variant="destructive" onClick={() => handleModerate('remove')} disabled={processing}>
                <Trash2 className="h-4 w-4 mr-2" />
                Remove
              </Button>
              {selectedReport.content_type === 'template' && (
                <>
                  <Button 
                    variant="default" 
                    className="bg-amber-600 hover:bg-amber-700"
                    onClick={() => handleModerate('feature')} 
                    disabled={processing}
                  >
                    <Star className="h-4 w-4 mr-2" />
                    Feature
                  </Button>
                  <Button 
                    variant="outline"
                    onClick={() => handleModerate('unfeature')} 
                    disabled={processing}
                  >
                    Unfeature
                  </Button>
                </>
              )}
              <Button variant="ghost" onClick={() => setSelectedReport(null)}>Cancel</Button>
            </div>
          </CardContent>

        </Card>
      )}
    </div>
  );
}