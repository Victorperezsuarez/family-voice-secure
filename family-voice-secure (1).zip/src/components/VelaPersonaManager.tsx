import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { VelaPersonaSelector } from './VelaPersonaSelector';
import { VelaPersonaCreator } from './VelaPersonaCreator';
import { VelaPersona } from '@/types/vela';
import { useVela } from '@/contexts/VelaContext';

interface VelaPersonaManagerProps {
  open: boolean;
  onClose: () => void;
}

export function VelaPersonaManager({ open, onClose }: VelaPersonaManagerProps) {
  const [showCreator, setShowCreator] = useState(false);
  const { setActivePersona } = useVela();

  const handlePersonaSelect = (persona: VelaPersona) => {
    setActivePersona(persona);
    onClose();
  };

  const handleCreateSuccess = () => {
    setShowCreator(false);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Manage Vela Personas</DialogTitle>
        </DialogHeader>
        
        {showCreator ? (
          <VelaPersonaCreator
            onSuccess={handleCreateSuccess}
            onCancel={() => setShowCreator(false)}
          />
        ) : (
          <VelaPersonaSelector
            onPersonaSelect={handlePersonaSelect}
            onCreateNew={() => setShowCreator(true)}
          />
        )}
      </DialogContent>
    </Dialog>
  );
}
