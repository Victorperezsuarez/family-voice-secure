import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { supabase } from '@/lib/supabase-client';
import { TrendingUp } from 'lucide-react';

interface AllocationHistory {
  created_at: string;
  combination_id: string;
  allocation_percentage: number;
  reason: string;
}

export function TrafficAllocationChart({ testId }: { testId: string }) {
  const [history, setHistory] = useState<any[]>([]);
  const [combinations, setCombinations] = useState<any[]>([]);

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 30000);
    return () => clearInterval(interval);
  }, [testId]);

  const loadData = async () => {
    const { data: combos } = await supabase
      .from('notification_mvt_combinations')
      .select('id, name')
      .eq('test_id', testId);
    
    const { data: allocHistory } = await supabase
      .from('notification_traffic_allocation_history')
      .select('*')
      .eq('test_id', testId)
      .order('created_at', { ascending: true });

    if (combos) setCombinations(combos);
    if (allocHistory) {
      const grouped = allocHistory.reduce((acc: any, item: any) => {
        const time = new Date(item.created_at).toLocaleTimeString();
        if (!acc[time]) acc[time] = { time };
        const combo = combos?.find(c => c.id === item.combination_id);
        if (combo) acc[time][combo.name] = item.allocation_percentage;
        return acc;
      }, {});
      setHistory(Object.values(grouped));
    }
  };

  const colors = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="h-5 w-5" />
          Traffic Allocation Over Time
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={history}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="time" />
            <YAxis label={{ value: 'Allocation %', angle: -90, position: 'insideLeft' }} />
            <Tooltip />
            <Legend />
            {combinations.map((combo, idx) => (
              <Line
                key={combo.id}
                type="monotone"
                dataKey={combo.name}
                stroke={colors[idx % colors.length]}
                strokeWidth={2}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}