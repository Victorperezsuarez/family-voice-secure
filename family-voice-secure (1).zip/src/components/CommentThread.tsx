import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase-client';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card } from '@/components/ui/card';
import { MessageSquare, Reply, Trash2 } from 'lucide-react';
import { RecordingNote } from '@/types/collaboration';
import { useToast } from '@/hooks/use-toast';
import { formatDistanceToNow } from 'date-fns';

interface Props {
  recordingId: string;
  timestampStart?: number;
  timestampEnd?: number;
}

export default function CommentThread({ recordingId, timestampStart, timestampEnd }: Props) {
  const [notes, setNotes] = useState<RecordingNote[]>([]);
  const [newComment, setNewComment] = useState('');
  const [replyTo, setReplyTo] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadNotes();
    const channel = supabase
      .channel(`notes:${recordingId}`)
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'recording_notes',
        filter: `recording_id=eq.${recordingId}`
      }, loadNotes)
      .subscribe();

    return () => { channel.unsubscribe(); };
  }, [recordingId]);

  const loadNotes = async () => {
    const { data } = await supabase
      .from('recording_notes')
      .select(`*, user:profiles(id, full_name, avatar_url)`)
      .eq('recording_id', recordingId)
      .is('parent_note_id', null)
      .order('created_at', { ascending: false });

    if (data) {
      const notesWithReplies = await Promise.all(
        data.map(async (note) => {
          const { data: replies } = await supabase
            .from('recording_notes')
            .select(`*, user:profiles(id, full_name, avatar_url)`)
            .eq('parent_note_id', note.id)
            .order('created_at', { ascending: true });
          return { ...note, replies: replies || [] };
        })
      );
      setNotes(notesWithReplies as any);
    }
  };

  const handleSubmit = async () => {
    if (!newComment.trim()) return;
    setLoading(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { error } = await supabase.from('recording_notes').insert({
      recording_id: recordingId,
      user_id: user.id,
      content: newComment,
      timestamp_start: timestampStart,
      timestamp_end: timestampEnd,
      parent_note_id: replyTo
    });

    if (error) {
      toast({ title: 'Error', description: 'Failed to post comment', variant: 'destructive' });
    } else {
      setNewComment('');
      setReplyTo(null);
      loadNotes();
    }
    setLoading(false);
  };

  const handleDelete = async (noteId: string) => {
    await supabase.from('recording_notes').delete().eq('id', noteId);
    loadNotes();
  };

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Textarea
          value={newComment}
          onChange={(e) => setNewComment(e.target.value)}
          placeholder={replyTo ? "Write a reply..." : "Add a comment..."}
          className="min-h-[100px]"
        />
        <div className="flex justify-between">
          {replyTo && (
            <Button variant="ghost" size="sm" onClick={() => setReplyTo(null)}>
              Cancel Reply
            </Button>
          )}
          <Button onClick={handleSubmit} disabled={loading} className="ml-auto">
            <MessageSquare className="h-4 w-4 mr-2" />
            {replyTo ? 'Reply' : 'Comment'}
          </Button>
        </div>
      </div>

      <div className="space-y-4">
        {notes.map((note) => (
          <Card key={note.id} className="p-4">
            <div className="flex gap-3">
              <Avatar className="h-8 w-8">
                <AvatarImage src={note.user?.avatar_url} />
                <AvatarFallback>{note.user?.full_name?.[0]}</AvatarFallback>
              </Avatar>
              <div className="flex-1 space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="font-medium">{note.user?.full_name}</span>
                    <span className="text-sm text-muted-foreground ml-2">
                      {formatDistanceToNow(new Date(note.created_at), { addSuffix: true })}
                    </span>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => handleDelete(note.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-sm">{note.content}</p>
                <Button variant="ghost" size="sm" onClick={() => setReplyTo(note.id)}>
                  <Reply className="h-4 w-4 mr-2" />
                  Reply
                </Button>
                {note.replies && note.replies.length > 0 && (
                  <div className="ml-6 mt-3 space-y-3 border-l-2 pl-4">
                    {note.replies.map((reply) => (
                      <div key={reply.id} className="flex gap-3">
                        <Avatar className="h-6 w-6">
                          <AvatarImage src={reply.user?.avatar_url} />
                          <AvatarFallback>{reply.user?.full_name?.[0]}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-sm">{reply.user?.full_name}</span>
                            <span className="text-xs text-muted-foreground">
                              {formatDistanceToNow(new Date(reply.created_at), { addSuffix: true })}
                            </span>
                          </div>
                          <p className="text-sm mt-1">{reply.content}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
