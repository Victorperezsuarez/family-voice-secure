import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Heart, Smile, Frown, Laugh, Sparkles } from 'lucide-react';

interface EmotionalPeak {
  emotion: string;
  timestamp: number;
  context: string;
}

interface EmotionalTone {
  primary: string[];
  arc: string;
  peaks: EmotionalPeak[];
}

interface EmotionalToneAnalysisProps {
  emotionalTone: EmotionalTone;
  onSeekTo?: (time: number) => void;
}

const emotionIcons: Record<string, any> = {
  joy: Smile,
  happiness: Smile,
  humor: Laugh,
  sadness: Frown,
  nostalgia: Heart,
  love: Heart,
  default: Sparkles
};

const emotionColors: Record<string, string> = {
  joy: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300',
  happiness: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300',
  humor: 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300',
  sadness: 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300',
  nostalgia: 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300',
  love: 'bg-pink-100 text-pink-800 dark:bg-pink-900/30 dark:text-pink-300',
  default: 'bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-300'
};

export function EmotionalToneAnalysis({ emotionalTone, onSeekTo }: EmotionalToneAnalysisProps) {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <Card className="p-4">
      <h3 className="text-lg font-semibold mb-4">Emotional Journey</h3>
      
      <div className="mb-4">
        <p className="text-sm text-muted-foreground mb-2">Primary Emotions</p>
        <div className="flex flex-wrap gap-2">
          {emotionalTone.primary.map((emotion, index) => {
            const Icon = emotionIcons[emotion.toLowerCase()] || emotionIcons.default;
            const colorClass = emotionColors[emotion.toLowerCase()] || emotionColors.default;
            return (
              <Badge key={index} className={colorClass}>
                <Icon className="h-3 w-3 mr-1" />
                {emotion}
              </Badge>
            );
          })}
        </div>
      </div>

      <div className="mb-4">
        <p className="text-sm text-muted-foreground mb-2">Emotional Arc</p>
        <p className="text-sm">{emotionalTone.arc}</p>
      </div>

      {emotionalTone.peaks.length > 0 && (
        <div>
          <p className="text-sm text-muted-foreground mb-2">Key Emotional Moments</p>
          <div className="space-y-2">
            {emotionalTone.peaks.map((peak, index) => (
              <div
                key={index}
                className="p-3 rounded-lg bg-muted/50 hover:bg-muted cursor-pointer transition-colors"
                onClick={() => onSeekTo?.(peak.timestamp)}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <Badge variant="outline" className="text-xs mb-1">
                      {peak.emotion}
                    </Badge>
                    <p className="text-sm">{peak.context}</p>
                  </div>
                  <span className="text-xs text-muted-foreground">
                    {formatTime(peak.timestamp)}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </Card>
  );
}