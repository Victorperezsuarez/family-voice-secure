import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { CheckCircle, XCircle, Clock } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { RecordingApproval } from '@/types/privacy';
import { useToast } from '@/hooks/use-toast';

export default function ApprovalWorkflowPanel() {
  const [approvals, setApprovals] = useState<RecordingApproval[]>([]);
  const [notes, setNotes] = useState<{ [key: string]: string }>({});
  const { toast } = useToast();

  useEffect(() => {
    loadApprovals();
  }, []);

  const loadApprovals = async () => {
    const { data, error } = await supabase
      .from('recording_approvals')
      .select('*')
      .eq('status', 'pending')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error loading approvals:', error);
      return;
    }
    setApprovals(data || []);
  };

  const handleApproval = async (approvalId: string, status: 'approved' | 'rejected') => {
    const { error } = await supabase
      .from('recording_approvals')
      .update({
        status,
        notes: notes[approvalId],
        reviewed_at: new Date().toISOString(),
        approver_id: (await supabase.auth.getUser()).data.user?.id,
      })
      .eq('id', approvalId);

    if (error) {
      toast({ title: 'Error', description: 'Failed to update approval', variant: 'destructive' });
      return;
    }

    toast({ title: 'Success', description: `Recording ${status}` });
    loadApprovals();
  };

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Pending Approvals</h2>
      {approvals.length === 0 ? (
        <Card>
          <CardContent className="pt-6 text-center text-muted-foreground">
            No pending approvals
          </CardContent>
        </Card>
      ) : (
        approvals.map((approval) => (
          <Card key={approval.id}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Approval Request</CardTitle>
                <Badge variant="outline">
                  <Clock className="w-3 h-3 mr-1" />
                  Pending
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-sm text-muted-foreground">
                Requested on {new Date(approval.created_at).toLocaleDateString()}
              </div>
              
              <div>
                <label className="text-sm font-medium">Notes (optional)</label>
                <Textarea
                  value={notes[approval.id] || ''}
                  onChange={(e) => setNotes({ ...notes, [approval.id]: e.target.value })}
                  placeholder="Add notes about your decision..."
                  className="mt-2"
                />
              </div>

              <div className="flex gap-2">
                <Button
                  onClick={() => handleApproval(approval.id, 'approved')}
                  className="flex-1"
                  variant="default"
                >
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Approve
                </Button>
                <Button
                  onClick={() => handleApproval(approval.id, 'rejected')}
                  className="flex-1"
                  variant="destructive"
                >
                  <XCircle className="w-4 h-4 mr-2" />
                  Reject
                </Button>
              </div>
            </CardContent>
          </Card>
        ))
      )}
    </div>
  );
}
