import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Lightbulb, X, Check, Clock, TrendingUp } from 'lucide-react';
import { VelaProactiveSuggestion } from '@/types/vela';
import { useVelaPersona } from '@/contexts/VelaPersonaContext';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';

export function VelaProactiveSuggestions() {
  const { activePersona } = useVelaPersona();

  const [suggestions, setSuggestions] = useState<VelaProactiveSuggestion[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (activePersona) {
      loadSuggestions();
    }
  }, [activePersona]);

  const loadSuggestions = async () => {
    if (!activePersona) return;

    const { data, error } = await supabase
      .from('vela_proactive_suggestions')
      .select('*')
      .eq('persona_id', activePersona.id)
      .eq('status', 'pending')
      .order('priority', { ascending: false })
      .order('created_at', { ascending: false })
      .limit(5);

    if (!error && data) {
      setSuggestions(data);
    }
  };

  const handleAccept = async (suggestion: VelaProactiveSuggestion) => {
    const { error } = await supabase
      .from('vela_proactive_suggestions')
      .update({ status: 'accepted', accepted_at: new Date().toISOString() })
      .eq('id', suggestion.id);

    if (!error) {
      updateAnalytics(suggestion, 'accepted');
      setSuggestions(prev => prev.filter(s => s.id !== suggestion.id));
      toast.success('Great! I\'ll remember this helped you.');
    }
  };

  const handleDismiss = async (suggestion: VelaProactiveSuggestion) => {
    const { error } = await supabase
      .from('vela_proactive_suggestions')
      .update({ status: 'dismissed', dismissed_at: new Date().toISOString() })
      .eq('id', suggestion.id);

    if (!error) {
      updateAnalytics(suggestion, 'dismissed');
      setSuggestions(prev => prev.filter(s => s.id !== suggestion.id));
    }
  };

  const updateAnalytics = async (suggestion: VelaProactiveSuggestion, action: 'accepted' | 'dismissed') => {
    const contextPattern = suggestion.context?.trigger_pattern || 'general';
    
    await supabase.rpc('upsert_suggestion_analytics', {
      p_persona_id: suggestion.persona_id,
      p_suggestion_type: suggestion.suggestion_type,
      p_context_pattern: contextPattern,
      p_action: action
    });
  };

  const getSuggestionIcon = (type: string) => {
    switch (type) {
      case 'tip': return <Lightbulb className="h-4 w-4" />;
      case 'reminder': return <Clock className="h-4 w-4" />;
      case 'recommendation': return <TrendingUp className="h-4 w-4" />;
      default: return <Lightbulb className="h-4 w-4" />;
    }
  };

  if (!activePersona || suggestions.length === 0) return null;

  return (
    <div className="space-y-3">
      {suggestions.map((suggestion) => (
        <Card key={suggestion.id} className="border-l-4 border-l-blue-500">
          <CardContent className="p-4">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-3 flex-1">
                <div className="mt-1">{getSuggestionIcon(suggestion.suggestion_type)}</div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge variant="secondary" className="text-xs">
                      {suggestion.suggestion_type}
                    </Badge>
                    {suggestion.priority >= 8 && (
                      <Badge variant="destructive" className="text-xs">High Priority</Badge>
                    )}
                  </div>
                  <p className="text-sm">{suggestion.suggestion_text}</p>
                  {suggestion.context?.time_of_day && (
                    <p className="text-xs text-muted-foreground mt-1">
                      Suggested for {suggestion.context.time_of_day}
                    </p>
                  )}
                </div>
              </div>
              <div className="flex gap-2">
                <Button size="sm" variant="ghost" onClick={() => handleAccept(suggestion)}>
                  <Check className="h-4 w-4" />
                </Button>
                <Button size="sm" variant="ghost" onClick={() => handleDismiss(suggestion)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}