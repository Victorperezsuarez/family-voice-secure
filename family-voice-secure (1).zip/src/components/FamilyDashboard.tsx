import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase-client';
import { useAuth } from '@/contexts/AuthContext';
import { Family } from '@/types/family';
import { FamilyDashboardCard } from './FamilyDashboardCard';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface FamilyWithStats extends Family {
  role: string;
  recordingCount: number;
  memberCount: number;
}

interface FamilyDashboardProps {
  onCreateFamily: () => void;
}

export function FamilyDashboard({ onCreateFamily }: FamilyDashboardProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [families, setFamilies] = useState<FamilyWithStats[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadFamilies();
    }
  }, [user]);

  const loadFamilies = async () => {
    if (!user) return;

    try {
      const { data: familyUsers } = await supabase
        .from('family_users')
        .select('family_id, role, families(*)')
        .eq('user_id', user.id);

      if (!familyUsers) {
        setFamilies([]);
        return;
      }

      const familiesWithStats = await Promise.all(
        familyUsers.map(async (fu) => {
          const family = fu.families as Family;
          
          const { count: recordingCount } = await supabase
            .from('recordings')
            .select('*', { count: 'exact', head: true })
            .eq('family_id', family.id);

          const { count: memberCount } = await supabase
            .from('family_users')
            .select('*', { count: 'exact', head: true })
            .eq('family_id', family.id);

          return {
            ...family,
            role: fu.role,
            recordingCount: recordingCount || 0,
            memberCount: memberCount || 0
          };
        })
      );

      setFamilies(familiesWithStats);
    } catch (error) {
      console.error('Error loading families:', error);
      toast({ title: 'Failed to load families', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const selectFamily = async (familyId: string) => {
    if (!user) return;

    try {
      await supabase
        .from('profiles')
        .update({ current_family_id: familyId })
        .eq('id', user.id);

      toast({ title: 'Family selected' });
      window.location.href = '/';
    } catch (error) {
      toast({ title: 'Failed to select family', variant: 'destructive' });
    }
  };

  if (loading) {
    return <div className="text-center py-8">Loading families...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">My Families</h1>
          <p className="text-muted-foreground mt-1">
            Manage and switch between your family accounts
          </p>
        </div>
        <Button onClick={onCreateFamily}>
          <Plus className="h-4 w-4 mr-2" />
          Create Family
        </Button>
      </div>

      {families.length === 0 ? (
        <div className="text-center py-12 border-2 border-dashed rounded-lg">
          <p className="text-muted-foreground mb-4">You haven't joined any families yet</p>
          <Button onClick={onCreateFamily}>
            <Plus className="h-4 w-4 mr-2" />
            Create Your First Family
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {families.map(family => (
            <FamilyDashboardCard
              key={family.id}
              family={family}
              recordingCount={family.recordingCount}
              memberCount={family.memberCount}
              role={family.role}
              onSelect={() => selectFamily(family.id)}
              onSettings={() => {}}
            />
          ))}
        </div>
      )}
    </div>
  );
}
