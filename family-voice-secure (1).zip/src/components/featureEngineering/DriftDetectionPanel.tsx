import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase-client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, RefreshCw } from 'lucide-react';
import { detectDistributionDrift } from '@/utils/realtimeFeatureEngine';
import type { DriftDetectionResult } from '@/types/realtimeFeatures';

export function DriftDetectionPanel() {
  const [driftResults, setDriftResults] = useState<DriftDetectionResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [features, setFeatures] = useState<string[]>([]);

  useEffect(() => {
    loadFeatures();
  }, []);

  async function loadFeatures() {
    const { data } = await supabase
      .from('feature_store')
      .select('name')
      .limit(10);
    
    if (data) {
      setFeatures(data.map(f => f.name));
    }
  }

  async function runDriftDetection() {
    setLoading(true);
    const results: DriftDetectionResult[] = [];
    
    for (const feature of features) {
      const result = await detectDistributionDrift(feature, 7);
      results.push(result);
    }
    
    setDriftResults(results);
    setLoading(false);
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5" />
            Distribution Drift Detection
          </span>
          <Button onClick={runDriftDetection} disabled={loading} size="sm">
            <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Run Detection
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {driftResults.map((result) => (
            <div key={result.feature_name} className="p-4 border rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <div className="font-medium">{result.feature_name}</div>
                {result.drift_detected ? (
                  <Badge variant="destructive">Drift Detected</Badge>
                ) : (
                  <Badge variant="default">Stable</Badge>
                )}
              </div>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <div className="text-muted-foreground">Drift Score</div>
                  <div className="font-medium">{result.drift_score.toFixed(2)}%</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Recommendation</div>
                  <div className="font-medium">{result.recommendation}</div>
                </div>
              </div>
              <div className="mt-3 grid grid-cols-2 gap-4 text-xs">
                <div className="p-2 bg-muted rounded">
                  <div className="font-medium mb-1">Baseline</div>
                  <div>Mean: {result.baseline_distribution.mean.toFixed(2)}</div>
                  <div>Std: {result.baseline_distribution.std_dev.toFixed(2)}</div>
                </div>
                <div className="p-2 bg-muted rounded">
                  <div className="font-medium mb-1">Current</div>
                  <div>Mean: {result.current_distribution.mean.toFixed(2)}</div>
                  <div>Std: {result.current_distribution.std_dev.toFixed(2)}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
