import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase-client';
import type { FamilyUser } from '@/types/family';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Trash2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Props {
  familyId: string;
  userRole: string;
}

export function FamilyMembersList({ familyId, userRole }: Props) {
  const [members, setMembers] = useState<FamilyUser[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    loadMembers();
  }, [familyId]);

  const loadMembers = async () => {
    const { data } = await supabase
      .from('family_users')
      .select('*')
      .eq('family_id', familyId);

    if (data) {
      const membersWithEmails = await Promise.all(
        data.map(async (member) => {
          const { data: userData } = await supabase.auth.admin.getUserById(member.user_id);
          return { ...member, user_email: userData?.user?.email || 'Unknown' };
        })
      );
      setMembers(membersWithEmails);
    }
  };

  const removeMember = async (memberId: string) => {
    if (userRole !== 'admin') return;

    const { error } = await supabase
      .from('family_users')
      .delete()
      .eq('id', memberId);

    if (!error) {
      toast({ title: 'Member removed' });
      loadMembers();
    }
  };

  return (
    <div className="space-y-2">
      {members.map((member) => (
        <div key={member.id} className="flex items-center justify-between p-3 border rounded-lg">
          <div>
            <p className="font-medium">{member.user_email}</p>
            <Badge variant="secondary" className="mt-1">{member.role}</Badge>
          </div>
          {userRole === 'admin' && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => removeMember(member.id)}
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          )}
        </div>
      ))}
    </div>
  );
}
