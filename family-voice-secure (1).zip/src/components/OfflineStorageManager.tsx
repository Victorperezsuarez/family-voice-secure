import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Database, HardDrive, Trash2, Upload } from 'lucide-react';
import { indexedDB } from '@/utils/indexedDB';
import { useOfflineSync } from '@/contexts/OfflineSyncContext';

export function OfflineStorageManager() {
  const [storageInfo, setStorageInfo] = useState({ used: 0, quota: 0 });
  const [recordings, setRecordings] = useState(0);
  const [photos, setPhotos] = useState(0);
  const { queueItems, retrySync } = useOfflineSync();

  useEffect(() => {
    loadStorageInfo();
  }, []);

  const loadStorageInfo = async () => {
    if ('storage' in navigator && 'estimate' in navigator.storage) {
      const estimate = await navigator.storage.estimate();
      setStorageInfo({
        used: estimate.usage || 0,
        quota: estimate.quota || 0
      });
    }
  };

  const usedPercent = (storageInfo.used / storageInfo.quota) * 100;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Database className="w-5 h-5" />
          Offline Storage
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <div className="flex justify-between text-sm mb-2">
            <span>Storage Used</span>
            <span>{(storageInfo.used / 1024 / 1024).toFixed(2)} MB / {(storageInfo.quota / 1024 / 1024).toFixed(0)} MB</span>
          </div>
          <Progress value={usedPercent} />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="text-center p-3 bg-blue-50 rounded-lg">
            <div className="text-2xl font-bold text-blue-600">{queueItems.length}</div>
            <div className="text-xs text-gray-600">Pending Sync</div>
          </div>
          <div className="text-center p-3 bg-green-50 rounded-lg">
            <div className="text-2xl font-bold text-green-600">{recordings + photos}</div>
            <div className="text-xs text-gray-600">Offline Items</div>
          </div>
        </div>

        <div className="flex gap-2">
          <Button onClick={retrySync} variant="outline" size="sm" className="flex-1">
            <Upload className="w-4 h-4 mr-2" />
            Sync Now
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
