import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase-client';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Users, Activity, UserPlus } from 'lucide-react';
import { InviteMemberModal } from './InviteMemberModal';
import { ActivityFeed } from './ActivityFeed';
import { FamilyMembersList } from './FamilyMembersList';
import type { Family, FamilyUser } from '@/types/family';

export function FamilyWorkspace() {
  const [activeFamily, setActiveFamily] = useState<Family | null>(null);
  const [familyUsers, setFamilyUsers] = useState<FamilyUser[]>([]);
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [activeTab, setActiveTab] = useState<'members' | 'activity'>('members');
  const [userRole, setUserRole] = useState<string>('view-only');

  useEffect(() => {
    loadFamily();
  }, []);

  const loadFamily = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data: familyUser } = await supabase
      .from('family_users')
      .select('family_id, role')
      .eq('user_id', user.id)
      .single();

    if (familyUser) {
      setUserRole(familyUser.role);
      const { data: family } = await supabase
        .from('families')
        .select('*')
        .eq('id', familyUser.family_id)
        .single();
      
      setActiveFamily(family);
      loadFamilyUsers(familyUser.family_id);
    }
  };

  const loadFamilyUsers = async (familyId: string) => {
    const { data } = await supabase
      .from('family_users')
      .select('*')
      .eq('family_id', familyId);
    
    if (data) setFamilyUsers(data);
  };

  if (!activeFamily) {
    return (
      <Card className="p-6">
        <p className="text-center text-muted-foreground">No family workspace found. Create or join a family to get started.</p>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <Card className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h2 className="text-2xl font-bold">{activeFamily.name}</h2>
            <p className="text-muted-foreground">{activeFamily.description}</p>
          </div>
          {(userRole === 'admin' || userRole === 'contributor') && (
            <Button onClick={() => setShowInviteModal(true)}>
              <UserPlus className="w-4 h-4 mr-2" />
              Invite Member
            </Button>
          )}
        </div>

        <div className="flex gap-2 mb-4">
          <Button
            variant={activeTab === 'members' ? 'default' : 'outline'}
            onClick={() => setActiveTab('members')}
          >
            <Users className="w-4 h-4 mr-2" />
            Members
          </Button>
          <Button
            variant={activeTab === 'activity' ? 'default' : 'outline'}
            onClick={() => setActiveTab('activity')}
          >
            <Activity className="w-4 h-4 mr-2" />
            Activity
          </Button>
        </div>

        {activeTab === 'members' && (
          <FamilyMembersList 
            familyId={activeFamily.id} 
            userRole={userRole}
          />
        )}
        {activeTab === 'activity' && (
          <ActivityFeed familyId={activeFamily.id} />
        )}
      </Card>

      {showInviteModal && (
        <InviteMemberModal
          familyId={activeFamily.id}
          familyName={activeFamily.name}
          onClose={() => setShowInviteModal(false)}
        />
      )}
    </div>
  );
}
