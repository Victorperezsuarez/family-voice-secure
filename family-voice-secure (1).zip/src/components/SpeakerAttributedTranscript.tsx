import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { Languages } from 'lucide-react';

interface SpeakerSegment {
  id: string;
  speaker_label: string;
  start_time: number;
  end_time: number;
  confidence_score: number;
  text_content?: string;
  identified_member_id?: string;
  identified_member_name?: string;
  identification_confidence?: number;
  identification_status?: string;
  emotion?: string;
  emotion_confidence?: number;
  emotion_intensity?: number;
  translations?: Record<string, { text: string; emotion?: string }>;
  original_language?: string;
}




interface Props {
  segments: SpeakerSegment[];
  onSeek?: (time: number) => void;
}

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

const emotionEmojis: Record<string, string> = {
  happy: '😊',
  sad: '😢',
  excited: '🤩',
  nostalgic: '🥺',
  angry: '😠',
  calm: '😌',
  anxious: '😰',
  surprised: '😲',
  neutral: '😐',
  frustrated: '😤',
  joyful: '😄',
  melancholic: '😔',
  enthusiastic: '🎉',
  worried: '😟',
  content: '😊'
};


export default function SpeakerAttributedTranscript({ segments, onSeek }: Props) {
  const getSpeakerColor = (label: string) => {
    const uniqueSpeakers = Array.from(new Set(segments.map(s => s.speaker_label)));
    const index = uniqueSpeakers.indexOf(label);
    return COLORS[index % COLORS.length];
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const sortedSegments = [...segments].sort((a, b) => a.start_time - b.start_time);

  return (
    <Card className="p-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold">Speaker-Attributed Transcript</h3>
        <Badge variant="outline">{segments.length} segments</Badge>
      </div>

      <ScrollArea className="h-96">
        <div className="space-y-4">
          {sortedSegments.map(segment => (
            <div key={segment.id} className="flex gap-3">
              <div className="flex-shrink-0 w-24 text-right">
                <button
                  onClick={() => onSeek?.(segment.start_time)}
                  className="text-sm text-gray-500 hover:text-blue-600 transition-colors"
                >
                  {formatTime(segment.start_time)}
                </button>
              </div>
              
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <div
                    className="w-2 h-2 rounded-full"
                    style={{ backgroundColor: getSpeakerColor(segment.speaker_label) }}
                  />
                  <span 
                    className="font-medium text-sm"
                    style={{ color: getSpeakerColor(segment.speaker_label) }}
                  >
                    {segment.identification_status === 'confirmed' && segment.identified_member_name 
                      ? segment.identified_member_name 
                      : segment.speaker_label}
                  </span>
                  <Badge variant="secondary" className="text-xs">
                    {Math.round(segment.confidence_score * 100)}%
                  </Badge>
                  {segment.identified_member_name && segment.identification_status === 'confirmed' && (
                    <Badge variant="default" className="text-xs bg-green-600">
                      Voice ID: {segment.identification_confidence}%
                    </Badge>
                  )}
                  {segment.emotion && (
                    <Badge variant="outline" className="text-xs">
                      <span className="mr-1">{emotionEmojis[segment.emotion]}</span>
                      <span className="capitalize">{segment.emotion}</span>
                    </Badge>
                  )}
                </div>

                {segment.text_content && (
                  <p className="text-sm leading-relaxed">{segment.text_content}</p>
                )}
              </div>
            </div>

          ))}
        </div>
      </ScrollArea>
    </Card>
  );
}
