import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase-client';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { History, GitCompare, RotateCcw, Clock } from 'lucide-react';
import { toast } from 'sonner';

interface Version {
  id: string;
  version_number: number;
  changelog: string;
  breaking_changes: boolean;
  migration_notes: string;
  permissions: Record<string, boolean>;
  created_at: string;
}

interface Props {
  templateId: string;
  currentVersion: number;
  subscriptionId?: string;
  onCompare: (v1: number, v2: number) => void;
}

export function TemplateVersionHistory({ templateId, currentVersion, subscriptionId, onCompare }: Props) {
  const [versions, setVersions] = useState<Version[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadVersions();
  }, [templateId]);

  const loadVersions = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('get-version-history', {
        body: { templateId }
      });

      if (error) throw error;
      setVersions(data.versions);
    } catch (error) {
      toast.error('Failed to load version history');
    } finally {
      setLoading(false);
    }
  };

  const handleRollback = async (version: number) => {
    if (!subscriptionId) {
      toast.error('No subscription found');
      return;
    }

    try {
      const { error } = await supabase.functions.invoke('rollback-template-version', {
        body: { subscriptionId, targetVersion: version }
      });

      if (error) throw error;
      toast.success(`Rolled back to version ${version}`);
    } catch (error) {
      toast.error('Failed to rollback version');
    }
  };

  if (loading) return <div>Loading versions...</div>;

  return (
    <Card className="p-6">
      <div className="flex items-center gap-2 mb-4">
        <History className="w-5 h-5" />
        <h3 className="text-lg font-semibold">Version History</h3>
      </div>

      <ScrollArea className="h-[400px]">
        <div className="space-y-4">
          {versions.map((version, idx) => (
            <div key={version.id} className="border rounded-lg p-4">
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Badge variant={version.version_number === currentVersion ? 'default' : 'outline'}>
                    v{version.version_number}
                  </Badge>
                  {version.breaking_changes && (
                    <Badge variant="destructive">Breaking</Badge>
                  )}
                  {version.version_number === currentVersion && (
                    <Badge variant="secondary">Current</Badge>
                  )}
                </div>
                <span className="text-sm text-muted-foreground flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {new Date(version.created_at).toLocaleDateString()}
                </span>
              </div>

              <p className="text-sm mb-3">{version.changelog}</p>

              {version.migration_notes && (
                <div className="bg-amber-50 border border-amber-200 rounded p-2 mb-3">
                  <p className="text-xs font-medium text-amber-900 mb-1">Migration Notes:</p>
                  <p className="text-xs text-amber-800">{version.migration_notes}</p>
                </div>
              )}

              <div className="flex gap-2">
                {idx < versions.length - 1 && (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => onCompare(version.version_number, versions[idx + 1].version_number)}
                  >
                    <GitCompare className="w-3 h-3 mr-1" />
                    Compare
                  </Button>
                )}
                {subscriptionId && version.version_number < currentVersion && (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleRollback(version.version_number)}
                  >
                    <RotateCcw className="w-3 h-3 mr-1" />
                    Rollback
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>
    </Card>
  );
}