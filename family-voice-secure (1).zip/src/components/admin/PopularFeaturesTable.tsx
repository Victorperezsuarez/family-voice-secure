import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';

interface Feature {
  name: string;
  usage: number;
  trend: 'up' | 'down' | 'stable';
}

interface PopularFeaturesTableProps {
  features: Feature[];
}

export function PopularFeaturesTable({ features }: PopularFeaturesTableProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Popular Features</CardTitle>
        <CardDescription>Most used features this month</CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Feature</TableHead>
              <TableHead className="text-right">Usage Count</TableHead>
              <TableHead className="text-right">Trend</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {features.map((feature) => (
              <TableRow key={feature.name}>
                <TableCell className="font-medium">{feature.name}</TableCell>
                <TableCell className="text-right">{feature.usage.toLocaleString()}</TableCell>
                <TableCell className="text-right">
                  <Badge variant={feature.trend === 'up' ? 'default' : feature.trend === 'down' ? 'destructive' : 'secondary'}>
                    {feature.trend}
                  </Badge>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
