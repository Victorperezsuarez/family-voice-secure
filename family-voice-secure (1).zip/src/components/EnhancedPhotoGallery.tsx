import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Edit, Tag, Album, Upload, Printer, Sparkles, Image, Camera, Video, QrCode, ImagePlus } from 'lucide-react';
import { PhotoEditor } from './PhotoEditor';
import { FaceTaggingPanel } from './FaceTaggingPanel';
import { SmartAlbumsManager } from './SmartAlbumsManager';
import { BulkPhotoUploader } from './BulkPhotoUploader';
import { PhotoSlideshowCreator } from './PhotoSlideshowCreator';
import { PhotoPrintingService } from './PhotoPrintingService';
import { CameraCapture } from './CameraCapture';
import { VideoRecorder } from './VideoRecorder';
import { QRCodeScanner } from './QRCodeScanner';
import { PhotoLibraryImporter } from './PhotoLibraryImporter';
import { supabase } from '@/lib/supabase-client';


interface Photo {
  id: string;
  photo_url: string;
  thumbnail_url?: string;
  title?: string;
}

export function EnhancedPhotoGallery({ familyId }: { familyId: string }) {
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [selectedPhoto, setSelectedPhoto] = useState<Photo | null>(null);
  const [mode, setMode] = useState<'view' | 'edit' | 'tag' | 'slideshow' | 'print' | 'camera' | 'video' | 'qr' | 'import'>('view');
  const [selectedPhotos, setSelectedPhotos] = useState<string[]>([]);
  const [showUpload, setShowUpload] = useState(false);


  useEffect(() => {
    loadPhotos();
  }, [familyId]);

  const loadPhotos = async () => {
    const { data } = await supabase
      .from('photos')
      .select('*')
      .eq('family_id', familyId)
      .order('created_at', { ascending: false });
    if (data) setPhotos(data);
  };

  const togglePhotoSelection = (photoId: string) => {
    setSelectedPhotos(prev =>
      prev.includes(photoId) ? prev.filter(id => id !== photoId) : [...prev, photoId]
    );
  };

  const handleCameraCapture = async (imageData: string) => {
    const blob = await fetch(imageData).then(r => r.blob());
    const file = new File([blob], `photo-${Date.now()}.jpg`, { type: 'image/jpeg' });
    await uploadPhoto(file);
    setMode('view');
  };

  const handleVideoSave = async (videoBlob: Blob) => {
    const file = new File([videoBlob], `video-${Date.now()}.webm`, { type: 'video/webm' });
    await uploadPhoto(file);
    setMode('view');
  };

  const handleQRScan = (data: string) => {
    console.log('QR Code scanned:', data);
    setMode('view');
  };

  const handleImportPhotos = async (files: File[]) => {
    for (const file of files) {
      await uploadPhoto(file);
    }
    await loadPhotos();
  };

  const uploadPhoto = async (file: File) => {
    const fileName = `${familyId}/${Date.now()}-${file.name}`;
    const { data, error } = await supabase.storage.from('photos').upload(fileName, file);
    if (error) {
      console.error('Upload error:', error);
      return;
    }
    const { data: urlData } = supabase.storage.from('photos').getPublicUrl(fileName);
    await supabase.from('photos').insert({ family_id: familyId, photo_url: urlData.publicUrl, title: file.name });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <Image className="h-6 w-6" />
          Galería de Fotos
        </h2>
        <div className="flex gap-2 flex-wrap">
          <Button onClick={() => setMode('camera')} size="sm" variant="outline">
            <Camera className="h-4 w-4 mr-2" />
            Cámara
          </Button>
          <Button onClick={() => setMode('video')} size="sm" variant="outline">
            <Video className="h-4 w-4 mr-2" />
            Video
          </Button>
          <Button onClick={() => setMode('import')} size="sm" variant="outline">
            <ImagePlus className="h-4 w-4 mr-2" />
            Importar
          </Button>
          <Button onClick={() => setMode('qr')} size="sm" variant="outline">
            <QrCode className="h-4 w-4 mr-2" />
            Escanear QR
          </Button>
          <Button onClick={() => setShowUpload(true)} size="sm">
            <Upload className="h-4 w-4 mr-2" />
            Subir
          </Button>
          {selectedPhotos.length > 0 && (
            <>
              <Button onClick={() => setMode('slideshow')} variant="outline" size="sm">
                <Sparkles className="h-4 w-4 mr-2" />
                Presentación
              </Button>
              <Button onClick={() => setMode('print')} variant="outline" size="sm">
                <Printer className="h-4 w-4 mr-2" />
                Imprimir
              </Button>
            </>
          )}
        </div>
      </div>


      <Tabs defaultValue="photos">
        <TabsList>
          <TabsTrigger value="photos">Photos</TabsTrigger>
          <TabsTrigger value="albums">Albums</TabsTrigger>
        </TabsList>

        <TabsContent value="photos" className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {photos.map((photo) => (
              <div
                key={photo.id}
                className={`relative aspect-square rounded-lg overflow-hidden cursor-pointer group ${
                  selectedPhotos.includes(photo.id) ? 'ring-4 ring-blue-500' : ''
                }`}
                onClick={() => togglePhotoSelection(photo.id)}
              >
                <img
                  src={photo.thumbnail_url || photo.photo_url}
                  alt={photo.title || 'Photo'}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-opacity flex items-center justify-center gap-2">
                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedPhoto(photo);
                      setMode('edit');
                    }}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedPhoto(photo);
                      setMode('tag');
                    }}
                  >
                    <Tag className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="albums">
          <SmartAlbumsManager familyId={familyId} />
        </TabsContent>
      </Tabs>

      <Dialog open={showUpload} onOpenChange={setShowUpload}>
        <DialogContent className="max-w-2xl">
          <BulkPhotoUploader familyId={familyId} onComplete={() => { setShowUpload(false); loadPhotos(); }} />
        </DialogContent>
      </Dialog>

      <Dialog open={mode === 'edit' && !!selectedPhoto} onOpenChange={() => setMode('view')}>
        <DialogContent className="max-w-6xl h-[80vh]">
          {selectedPhoto && (
            <PhotoEditor
              photoUrl={selectedPhoto.photo_url}
              onSave={() => setMode('view')}
              onCancel={() => setMode('view')}
            />
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={mode === 'tag' && !!selectedPhoto} onOpenChange={() => setMode('view')}>
        <DialogContent className="max-w-3xl">
          {selectedPhoto && (
            <FaceTaggingPanel
              photoId={selectedPhoto.id}
              photoUrl={selectedPhoto.photo_url}
              familyId={familyId}
            />
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={mode === 'slideshow'} onOpenChange={() => setMode('view')}>
        <DialogContent>
          <PhotoSlideshowCreator familyId={familyId} selectedPhotos={selectedPhotos} />
        </DialogContent>
      </Dialog>

      <Dialog open={mode === 'print'} onOpenChange={() => setMode('view')}>
        <DialogContent className="max-w-2xl">
          <PhotoPrintingService photoIds={selectedPhotos} familyId={familyId} />
        </DialogContent>
      </Dialog>

      {mode === 'camera' && (
        <CameraCapture onCapture={handleCameraCapture} onClose={() => setMode('view')} />
      )}

      {mode === 'video' && (
        <VideoRecorder onSave={handleVideoSave} onClose={() => setMode('view')} />
      )}

      {mode === 'qr' && (
        <QRCodeScanner onScan={handleQRScan} onClose={() => setMode('view')} />
      )}

      <PhotoLibraryImporter
        open={mode === 'import'}
        onClose={() => setMode('view')}
        onImport={handleImportPhotos}
        familyId={familyId}
      />
    </div>
  );
}

