import { useState, useEffect } from 'react';
import { Bell, BellOff, Check, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';

export function ReminderPushNotifications() {
  const [enabled, setEnabled] = useState(false);
  const [permission, setPermission] = useState<NotificationPermission>('default');

  useEffect(() => {
    if ('Notification' in window) {
      setPermission(Notification.permission);
      setEnabled(Notification.permission === 'granted');
    }
  }, []);

  const requestPermission = async () => {
    if (!('Notification' in window)) {
      toast.error('Notifications not supported');
      return;
    }

    const result = await Notification.requestPermission();
    setPermission(result);
    
    if (result === 'granted') {
      setEnabled(true);
      toast.success('Notifications enabled!');
      
      // Register service worker for push
      if ('serviceWorker' in navigator) {
        const registration = await navigator.serviceWorker.ready;
        console.log('Service Worker ready for push notifications');
      }
    } else {
      toast.error('Permission denied');
    }
  };

  const sendTestNotification = () => {
    if (permission === 'granted') {
      new Notification('Vela Reminder', {
        body: 'Time to record your family story!',
        icon: '/placeholder.svg',
        badge: '/placeholder.svg',
        tag: 'vela-reminder',
        requireInteraction: false
      });
      toast.success('Test notification sent');
    }
  };

  const toggleNotifications = async (checked: boolean) => {
    if (checked && permission !== 'granted') {
      await requestPermission();
    } else {
      setEnabled(checked);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bell className="h-5 w-5" />
          Push Notifications
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <p className="font-medium">Enable Reminders</p>
            <p className="text-sm text-muted-foreground">Get notified about recording prompts</p>
          </div>
          <Switch checked={enabled} onCheckedChange={toggleNotifications} />
        </div>

        {permission === 'granted' && (
          <div className="space-y-2">
            <Button variant="outline" className="w-full" onClick={sendTestNotification}>
              <Bell className="w-4 h-4 mr-2" />
              Send Test Notification
            </Button>
            <div className="text-xs text-muted-foreground flex items-center gap-1">
              <Check className="w-3 h-3 text-green-600" />
              Notifications are enabled
            </div>
          </div>
        )}

        {permission === 'denied' && (
          <div className="text-sm text-red-600 flex items-center gap-2">
            <BellOff className="w-4 h-4" />
            Notifications blocked. Enable in browser settings.
          </div>
        )}
      </CardContent>
    </Card>
  );
}
