import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';

interface CreateHealthAlertRuleDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  channelId: string;
  familyId: string;
  onSuccess: () => void;
}

export function CreateHealthAlertRuleDialog({ open, onOpenChange, channelId, familyId, onSuccess }: CreateHealthAlertRuleDialogProps) {
  const [ruleName, setRuleName] = useState('');
  const [ruleType, setRuleType] = useState('success_rate');
  const [severity, setSeverity] = useState('medium');
  const [threshold, setThreshold] = useState('');
  const [timeWindow, setTimeWindow] = useState('30');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const conditionConfig: any = { time_window_minutes: parseInt(timeWindow) };
      
      if (ruleType === 'success_rate' || ruleType === 'error_rate') {
        conditionConfig.threshold = parseFloat(threshold);
      } else if (ruleType === 'consecutive_failures') {
        conditionConfig.max_failures = parseInt(threshold);
      } else if (ruleType === 'latency_spike') {
        conditionConfig.threshold_ms = parseInt(threshold);
      }

      const { error } = await supabase.from('channel_health_alert_rules').insert({
        family_id: familyId,
        channel_id: channelId,
        rule_name: ruleName,
        rule_type: ruleType,
        condition_config: conditionConfig,
        severity,
        enabled: true
      });

      if (error) throw error;

      toast.success('Alert rule created successfully');
      onSuccess();
      onOpenChange(false);
      setRuleName('');
      setThreshold('');
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Create Health Alert Rule</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label>Rule Name</Label>
            <Input value={ruleName} onChange={(e) => setRuleName(e.target.value)} required />
          </div>

          <div>
            <Label>Rule Type</Label>
            <Select value={ruleType} onValueChange={setRuleType}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="success_rate">Success Rate</SelectItem>
                <SelectItem value="consecutive_failures">Consecutive Failures</SelectItem>
                <SelectItem value="latency_spike">Latency Spike</SelectItem>
                <SelectItem value="error_rate">Error Rate</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Threshold</Label>
            <Input 
              type="number" 
              value={threshold} 
              onChange={(e) => setThreshold(e.target.value)}
              placeholder={ruleType === 'latency_spike' ? 'Milliseconds' : ruleType === 'consecutive_failures' ? 'Count' : 'Percentage'}
              required 
            />
          </div>

          <div>
            <Label>Time Window (minutes)</Label>
            <Input type="number" value={timeWindow} onChange={(e) => setTimeWindow(e.target.value)} required />
          </div>

          <div>
            <Label>Severity</Label>
            <Select value={severity} onValueChange={setSeverity}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? 'Creating...' : 'Create Rule'}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
