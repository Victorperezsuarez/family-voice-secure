import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Plus, Trash2 } from 'lucide-react';

interface MaintenanceWindow {
  start: string;
  end: string;
  description?: string;
}

interface MaintenanceWindowEditorProps {
  windows: MaintenanceWindow[];
  onChange: (windows: MaintenanceWindow[]) => void;
}

export function MaintenanceWindowEditor({ windows, onChange }: MaintenanceWindowEditorProps) {
  const addWindow = () => {
    const now = new Date();
    const end = new Date(now.getTime() + 3600000);
    onChange([...windows, {
      start: now.toISOString().slice(0, 16),
      end: end.toISOString().slice(0, 16),
      description: ''
    }]);
  };

  const removeWindow = (index: number) => {
    onChange(windows.filter((_, i) => i !== index));
  };

  const updateWindow = (index: number, field: string, value: string) => {
    const newWindows = [...windows];
    newWindows[index] = { ...newWindows[index], [field]: value };
    onChange(newWindows);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Label>Maintenance Windows</Label>
        <Button type="button" size="sm" variant="outline" onClick={addWindow}>
          <Plus className="w-4 h-4 mr-2" />
          Add Window
        </Button>
      </div>

      {windows.length === 0 ? (
        <Card className="p-4 text-center text-muted-foreground">
          No maintenance windows configured
        </Card>
      ) : (
        <div className="space-y-3">
          {windows.map((window, index) => (
            <Card key={index} className="p-4">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-semibold">Window {index + 1}</h4>
                <Button type="button" size="sm" variant="ghost" onClick={() => removeWindow(index)}>
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Start Time</Label>
                  <Input
                    type="datetime-local"
                    value={window.start}
                    onChange={(e) => updateWindow(index, 'start', e.target.value)}
                  />
                </div>
                <div>
                  <Label>End Time</Label>
                  <Input
                    type="datetime-local"
                    value={window.end}
                    onChange={(e) => updateWindow(index, 'end', e.target.value)}
                  />
                </div>
              </div>

              <div className="mt-3">
                <Label>Description (optional)</Label>
                <Input
                  value={window.description || ''}
                  onChange={(e) => updateWindow(index, 'description', e.target.value)}
                  placeholder="e.g., Scheduled maintenance"
                />
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
