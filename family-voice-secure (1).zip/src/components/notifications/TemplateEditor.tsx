import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Plus, Save } from 'lucide-react';

interface Template {
  id: string;
  template_name: string;
  channel_type: string;
  subject?: string;
  body_template: string;
  variables: string[];
  is_default: boolean;
}

interface TemplateEditorProps {
  templates: Template[];
  onSave: (template: any) => void;
}

export function TemplateEditor({ templates, onSave }: TemplateEditorProps) {

  const [showForm, setShowForm] = useState(false);
  const [name, setName] = useState('');
  const [channelType, setChannelType] = useState<'email' | 'sms' | 'slack' | 'webhook'>('email');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');

  const handleSave = () => {
    const variables = (body.match(/\{\{(\w+)\}\}/g) || []).map(v => v.replace(/\{\{|\}\}/g, ''));
    onSave({
      template_name: name,
      channel_type: channelType,
      subject: channelType === 'email' ? subject : undefined,
      body_template: body,
      variables,
      is_default: false
    });
    setName('');
    setSubject('');
    setBody('');
    setShowForm(false);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Message Templates</h3>
        <Button size="sm" onClick={() => setShowForm(!showForm)}>
          <Plus className="h-4 w-4 mr-1" />
          New Template
        </Button>
      </div>

      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Create Template</CardTitle>
            <CardDescription>Use variables like {`{{alert_name}}, {{severity}}, {{value}}`}</CardDescription>

          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Template Name</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Critical Alert Template" />
            </div>
            <div>
              <Label>Channel Type</Label>
              <Select value={channelType} onValueChange={(v: any) => setChannelType(v)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="email">Email</SelectItem>
                  <SelectItem value="sms">SMS</SelectItem>
                  <SelectItem value="slack">Slack</SelectItem>
                  <SelectItem value="webhook">Webhook</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {channelType === 'email' && (
              <div>
                <Label>Subject</Label>
                <Input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="Alert: {{'{'}{'{'} alert_name {'}'}{'}'}" />
              </div>
            )}
            <div>
              <Label>Message Body</Label>
              <Textarea value={body} onChange={(e) => setBody(e.target.value)} placeholder="Alert {{'{'}{'{'} alert_name {'}'}{'}'}has been triggered with severity {{'{'}{'{'} severity {'}'}{'}'}." rows={6} />
            </div>
            <Button onClick={handleSave} className="w-full">
              <Save className="h-4 w-4 mr-2" />
              Save Template
            </Button>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4">
        {templates.map((template) => (
          <Card key={template.id}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-base">{template.template_name}</CardTitle>
                  <CardDescription className="capitalize">{template.channel_type}</CardDescription>
                </div>
                {template.is_default && <Badge>Default</Badge>}
              </div>
            </CardHeader>
            <CardContent>
              {template.subject && (
                <div className="mb-2">
                  <span className="text-sm font-medium">Subject: </span>
                  <span className="text-sm text-muted-foreground">{template.subject}</span>
                </div>
              )}
              <p className="text-sm text-muted-foreground line-clamp-2">{template.body_template}</p>
              {template.variables.length > 0 && (
                <div className="flex gap-1 mt-2 flex-wrap">
                  {template.variables.map(v => (
                    <Badge key={v} variant="secondary" className="text-xs">{v}</Badge>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}