import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, TrendingUp, Clock } from 'lucide-react';

interface FailureAnalysisPanelProps {
  failures: Array<{
    channel_name: string;
    error_message: string;
    count: number;
    last_occurred: string;
  }>;
}

export function FailureAnalysisPanel({ failures }: FailureAnalysisPanelProps) {
  const topFailures = failures.slice(0, 5);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <AlertTriangle className="h-5 w-5 text-orange-500" />
          Failure Analysis
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {topFailures.map((failure, idx) => (
            <div key={idx} className="border-b pb-3 last:border-0">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <p className="font-semibold">{failure.channel_name}</p>
                  <p className="text-sm text-muted-foreground">{failure.error_message}</p>
                </div>
                <Badge variant="destructive">{failure.count}x</Badge>
              </div>
              <div className="flex items-center gap-4 text-xs text-muted-foreground">
                <span className="flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  {new Date(failure.last_occurred).toLocaleString()}
                </span>
              </div>
            </div>
          ))}
          {failures.length === 0 && (
            <p className="text-center text-muted-foreground py-4">
              No failures detected
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
