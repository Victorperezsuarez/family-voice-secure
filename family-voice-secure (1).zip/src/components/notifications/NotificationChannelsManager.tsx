import { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ChannelConfigCard } from './ChannelConfigCard';
import { CreateChannelDialog } from './CreateChannelDialog';
import { SLAMonitoringDashboard } from './SLAMonitoringDashboard';
import { AlertFatigueDashboard } from './AlertFatigueDashboard';
import { AlertRoutingDashboard } from '@/components/routing/AlertRoutingDashboard';
import { supabase } from '@/lib/supabase-client';
import { Bell, MessageSquare, Clock, Brain, Users } from 'lucide-react';
import { toast } from 'sonner';

export default function NotificationChannelsManager({ familyId }: { familyId: string }) {
  const [channels, setChannels] = useState<any[]>([]);
  const [rules, setRules] = useState<any[]>([]);
  const [templates, setTemplates] = useState<any[]>([]);
  const [alertRules, setAlertRules] = useState<any[]>([]);
  const [selectedChannel, setSelectedChannel] = useState<string | null>(null);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showCreateAlertDialog, setShowCreateAlertDialog] = useState(false);
  const [loading, setLoading] = useState(true);



  useEffect(() => {
    loadData();
  }, [familyId]);

  const loadData = async () => {
    setLoading(true);
    const [channelsRes, templatesRes, alertRulesRes] = await Promise.all([
      supabase.from('notification_channels').select('*').eq('family_id', familyId),
      supabase.from('notification_templates').select('*').eq('family_id', familyId),
      supabase.from('channel_health_alert_rules').select('*').eq('family_id', familyId)
    ]);
    if (channelsRes.data) setChannels(channelsRes.data);
    if (templatesRes.data) setTemplates(templatesRes.data);
    if (alertRulesRes.data) setAlertRules(alertRulesRes.data);
    if (channelsRes.data?.[0]) {
      setSelectedChannel(channelsRes.data[0].id);
      loadRules(channelsRes.data[0].id);
    }
    setLoading(false);
  };


  const loadRules = async (channelId: string) => {
    const { data } = await supabase.from('channel_delivery_rules').select('*').eq('channel_id', channelId);
    if (data) setRules(data);
  };

  const handleCreateChannel = async (channel: any) => {
    const { error } = await supabase.from('notification_channels').insert({ ...channel, family_id: familyId });
    if (error) {
      toast.error('Failed to create channel');
    } else {
      toast.success('Channel created');
      loadData();
      setShowCreateDialog(false);
    }
  };

  const handleToggleChannel = async (id: string, active: boolean) => {
    await supabase.from('notification_channels').update({ is_active: active }).eq('id', id);
    loadData();
  };

  const handleDeleteChannel = async (id: string) => {
    await supabase.from('notification_channels').delete().eq('id', id);
    toast.success('Channel deleted');
    loadData();
  };

  const handleTestChannel = async (id: string) => {
    const { error } = await supabase.functions.invoke('send-channel-notification', {
      body: { channelId: id, message: { subject: 'Test', body: 'Test notification' }, recipient: 'test@example.com' }
    });
    if (error) toast.error('Test failed');
    else toast.success('Test sent');
  };

  const handleSaveRule = async (rule: any) => {
    await supabase.from('channel_delivery_rules').insert(rule);
    if (selectedChannel) loadRules(selectedChannel);
    toast.success('Rule saved');
  };

  const handleSaveTemplate = async (template: any) => {
    await supabase.from('notification_templates').insert({ ...template, family_id: familyId });
    loadData();
    toast.success('Template saved');
  };

  const handleToggleAlertRule = async (id: string, enabled: boolean) => {
    await supabase.from('channel_health_alert_rules').update({ enabled }).eq('id', id);
    loadData();
  };

  const handleDeleteAlertRule = async (id: string) => {
    await supabase.from('channel_health_alert_rules').delete().eq('id', id);
    toast.success('Alert rule deleted');
    loadData();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Notification Channels</h2>
        <Button onClick={() => setShowCreateDialog(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Add Channel
        </Button>
      </div>

      <Tabs defaultValue="channels" className="w-full">
        <TabsList>
          <TabsTrigger value="channels">Channels</TabsTrigger>
          <TabsTrigger value="rules">Delivery Rules</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="health-alerts">Health Alerts</TabsTrigger>
          <TabsTrigger value="triggered">Triggered Alerts</TabsTrigger>
          <TabsTrigger value="patterns">Alert Patterns</TabsTrigger>
          <TabsTrigger value="sla">SLA Monitoring</TabsTrigger>
          <TabsTrigger value="fatigue">Alert Fatigue</TabsTrigger>
        </TabsList>





        <TabsContent value="channels" className="space-y-4">
          {channels.map(channel => (
            <ChannelConfigCard key={channel.id} channel={channel} onToggle={handleToggleChannel} onEdit={(c) => setSelectedChannel(c.id)} onDelete={handleDeleteChannel} onTest={handleTestChannel} />
          ))}
        </TabsContent>

        <TabsContent value="rules">
          {selectedChannel && <DeliveryRulesBuilder channelId={selectedChannel} rules={rules} onSave={handleSaveRule} onDelete={async (id) => { await supabase.from('channel_delivery_rules').delete().eq('id', id); loadRules(selectedChannel); }} onToggle={async (id, active) => { await supabase.from('channel_delivery_rules').update({ is_active: active }).eq('id', id); loadRules(selectedChannel); }} />}
        </TabsContent>

        <TabsContent value="templates">
          <TemplateEditor templates={templates} onSave={handleSaveTemplate} />
        </TabsContent>

        <TabsContent value="performance">
          <ChannelPerformanceDashboard />
        </TabsContent>

        <TabsContent value="health-alerts" className="space-y-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Health Alert Rules</h3>
            <Button onClick={() => setShowCreateAlertDialog(true)} size="sm">
              <Plus className="w-4 h-4 mr-2" />
              Create Rule
            </Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {alertRules.map(rule => (
              <HealthAlertRuleCard 
                key={rule.id} 
                rule={rule} 
                onToggle={handleToggleAlertRule}
                onEdit={() => {}}
                onDelete={handleDeleteAlertRule}
              />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="triggered">
          <TriggeredAlertsPanel familyId={familyId} />
        </TabsContent>

        <TabsContent value="patterns">
          <AlertGroupingPanel />
        </TabsContent>

        <TabsContent value="sla" className="space-y-6">
          <SLAMonitoringDashboard familyId={familyId} />
          <SLAComplianceTrends familyId={familyId} />
        </TabsContent>

        <TabsContent value="fatigue">
          <AlertFatigueDashboard />
        </TabsContent>

      </Tabs>


      <CreateChannelDialog open={showCreateDialog} onOpenChange={setShowCreateDialog} onSave={handleCreateChannel} />
      {selectedChannel && (
        <CreateHealthAlertRuleDialog 
          open={showCreateAlertDialog}
          onOpenChange={setShowCreateAlertDialog}
          channelId={selectedChannel}
          familyId={familyId}
          onSuccess={loadData}
        />
      )}
    </div>
  );
}
