import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Mail, MessageSquare, Webhook, Phone, Settings, Trash2, CheckCircle, XCircle } from 'lucide-react';

interface Channel {
  id: string;
  name: string;
  type: 'email' | 'sms' | 'slack' | 'webhook';
  is_active: boolean;
  is_verified: boolean;
  config: any;
  last_used_at?: string;
}

interface ChannelConfigCardProps {
  channel: Channel;
  onToggle: (id: string, active: boolean) => void;
  onEdit: (channel: Channel) => void;
  onDelete: (id: string) => void;
  onTest: (id: string) => void;
}

const channelIcons = {
  email: Mail,
  sms: Phone,
  slack: MessageSquare,
  webhook: Webhook
};

export function ChannelConfigCard({ channel, onToggle, onEdit, onDelete, onTest }: ChannelConfigCardProps) {

  const Icon = channelIcons[channel.type];

  return (
    <Card>
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-primary/10 rounded-lg">
              <Icon className="h-5 w-5 text-primary" />
            </div>
            <div>
              <CardTitle className="text-lg">{channel.name}</CardTitle>
              <CardDescription className="capitalize">{channel.type} Channel</CardDescription>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {channel.is_verified ? (
              <Badge variant="outline" className="gap-1">
                <CheckCircle className="h-3 w-3" />
                Verified
              </Badge>
            ) : (
              <Badge variant="secondary" className="gap-1">
                <XCircle className="h-3 w-3" />
                Unverified
              </Badge>
            )}
            <Switch checked={channel.is_active} onCheckedChange={(checked) => onToggle(channel.id, checked)} />
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="text-sm text-muted-foreground">
            {channel.type === 'email' && `To: ${channel.config.to_email || 'Not configured'}`}
            {channel.type === 'sms' && `To: ${channel.config.to_number || 'Not configured'}`}
            {channel.type === 'slack' && `Webhook configured`}
            {channel.type === 'webhook' && `URL: ${channel.config.url || 'Not configured'}`}
          </div>
          {channel.last_used_at && (
            <div className="text-xs text-muted-foreground">
              Last used: {new Date(channel.last_used_at).toLocaleString()}
            </div>
          )}
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => onEdit(channel)}>
              <Settings className="h-4 w-4 mr-1" />
              Configure
            </Button>
            <Button variant="outline" size="sm" onClick={() => onTest(channel.id)}>
              Test
            </Button>
            <Button variant="outline" size="sm" onClick={() => onDelete(channel.id)} className="text-destructive">
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}