import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Plus, Trash2 } from 'lucide-react';

interface EscalationLevel {
  delay_minutes: number;
  notify: { channel_id: string; name: string }[];
}

interface EscalationPolicyEditorProps {
  policy: { levels: EscalationLevel[] } | null;
  onChange: (policy: { levels: EscalationLevel[] }) => void;
  availableChannels: { id: string; name: string }[];
}

export function EscalationPolicyEditor({ policy, onChange, availableChannels }: EscalationPolicyEditorProps) {
  const [levels, setLevels] = useState<EscalationLevel[]>(policy?.levels || []);

  const addLevel = () => {
    const newLevels = [...levels, { delay_minutes: 30, notify: [] }];
    setLevels(newLevels);
    onChange({ levels: newLevels });
  };

  const removeLevel = (index: number) => {
    const newLevels = levels.filter((_, i) => i !== index);
    setLevels(newLevels);
    onChange({ levels: newLevels });
  };

  const updateLevel = (index: number, field: string, value: any) => {
    const newLevels = [...levels];
    newLevels[index] = { ...newLevels[index], [field]: value };
    setLevels(newLevels);
    onChange({ levels: newLevels });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Label>Escalation Policy</Label>
        <Button type="button" size="sm" variant="outline" onClick={addLevel}>
          <Plus className="w-4 h-4 mr-2" />
          Add Level
        </Button>
      </div>

      {levels.length === 0 ? (
        <Card className="p-4 text-center text-muted-foreground">
          No escalation levels configured
        </Card>
      ) : (
        <div className="space-y-3">
          {levels.map((level, index) => (
            <Card key={index} className="p-4">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-semibold">Level {index + 1}</h4>
                <Button type="button" size="sm" variant="ghost" onClick={() => removeLevel(index)}>
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>

              <div className="space-y-3">
                <div>
                  <Label>Delay (minutes)</Label>
                  <Input
                    type="number"
                    value={level.delay_minutes}
                    onChange={(e) => updateLevel(index, 'delay_minutes', parseInt(e.target.value))}
                  />
                </div>

                <div>
                  <Label>Notify Channels</Label>
                  <div className="text-sm text-muted-foreground">
                    {level.notify.length} channel(s) selected
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
