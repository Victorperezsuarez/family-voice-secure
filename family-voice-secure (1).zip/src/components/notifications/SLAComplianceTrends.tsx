import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { supabase } from '@/lib/supabase-client';

interface TrendData {
  date: string;
  compliance: number;
  avgAckTime: number;
  breaches: number;
}

export function SLAComplianceTrends({ familyId }: { familyId: string }) {
  const [trends, setTrends] = useState<TrendData[]>([]);

  useEffect(() => {
    loadTrends();
  }, [familyId]);

  const loadTrends = async () => {
    try {
      const { data } = await supabase
        .from('alert_sla_metrics')
        .select('*')
        .eq('family_id', familyId)
        .order('metric_date', { ascending: true })
        .limit(30);

      if (data) {
        const aggregated = data.reduce((acc: any, curr) => {
          const existing = acc.find((d: any) => d.date === curr.metric_date);
          if (existing) {
            existing.compliance = (existing.compliance + curr.compliance_percentage) / 2;
            existing.avgAckTime = (existing.avgAckTime + curr.avg_acknowledgment_time_minutes) / 2;
            existing.breaches += curr.acknowledged_late;
          } else {
            acc.push({
              date: curr.metric_date,
              compliance: curr.compliance_percentage,
              avgAckTime: curr.avg_acknowledgment_time_minutes,
              breaches: curr.acknowledged_late
            });
          }
          return acc;
        }, []);

        setTrends(aggregated);
      }
    } catch (error) {
      console.error('Failed to load trends:', error);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>SLA Compliance Trends (Last 30 Days)</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={trends}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis yAxisId="left" />
            <YAxis yAxisId="right" orientation="right" />
            <Tooltip />
            <Legend />
            <Line 
              yAxisId="left"
              type="monotone" 
              dataKey="compliance" 
              stroke="#10b981" 
              name="Compliance %" 
            />
            <Line 
              yAxisId="right"
              type="monotone" 
              dataKey="avgAckTime" 
              stroke="#3b82f6" 
              name="Avg Ack Time (min)" 
            />
            <Line 
              yAxisId="right"
              type="monotone" 
              dataKey="breaches" 
              stroke="#ef4444" 
              name="Breaches" 
            />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}