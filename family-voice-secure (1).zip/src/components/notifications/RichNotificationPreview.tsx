import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Bell } from 'lucide-react';
import { RichNotificationOptions } from '@/types/notificationTemplates';

interface RichNotificationPreviewProps {
  options: RichNotificationOptions;
}

export function RichNotificationPreview({ options }: RichNotificationPreviewProps) {
  return (
    <Card className="max-w-md">
      <CardContent className="p-4">
        <div className="flex gap-3">
          {/* Icon/Badge */}
          <div className="flex-shrink-0">
            {options.badge ? (
              <img src={options.badge} alt="Badge" className="w-6 h-6" />
            ) : options.icon ? (
              <img src={options.icon} alt="Icon" className="w-12 h-12 rounded" />
            ) : (
              <div className="w-12 h-12 bg-primary/10 rounded flex items-center justify-center">
                <Bell className="h-6 w-6 text-primary" />
              </div>
            )}
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2 mb-1">
              <h4 className="font-semibold text-sm">{options.title}</h4>
              <Badge variant="secondary" className="text-xs">Now</Badge>
            </div>
            
            <p className="text-sm text-muted-foreground mb-2">{options.body}</p>

            {/* Image */}
            {options.image && (
              <img 
                src={options.image} 
                alt="Notification" 
                className="w-full h-32 object-cover rounded mb-2"
              />
            )}

            {/* Progress Bar */}
            {options.progress !== undefined && (
              <div className="mb-2">
                <div className="flex justify-between text-xs text-muted-foreground mb-1">
                  <span>{options.progressLabel || 'Progress'}</span>
                  <span>{options.progress}/{options.progressMax || 100}</span>
                </div>
                <Progress 
                  value={(options.progress / (options.progressMax || 100)) * 100} 
                  className="h-2"
                />
              </div>
            )}

            {/* Action Buttons */}
            {options.actions && options.actions.length > 0 && (
              <div className="flex gap-2 mt-2">
                {options.actions.map((action, index) => (
                  <Button 
                    key={index} 
                    variant="outline" 
                    size="sm"
                    className="flex-1"
                  >
                    {action.title}
                  </Button>
                ))}
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
