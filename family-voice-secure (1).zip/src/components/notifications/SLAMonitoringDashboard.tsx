import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Clock, AlertTriangle, CheckCircle, XCircle, TrendingUp } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';


interface SLAAlert {
  id: string;
  alert_id: string;
  sla_deadline: string;
  warning_deadline: string;
  minutesRemaining: number;
  alert: {
    rule_name: string;
    severity: string;
    channel_name: string;
  };
}

interface SLAMetrics {
  total: number;
  onTime: number;
  breached: number;
  atRisk: number;
  avgAckTime: number;
}

export function SLAMonitoringDashboard({ familyId }: { familyId: string }) {
  const [atRisk, setAtRisk] = useState<SLAAlert[]>([]);
  const [metrics, setMetrics] = useState<SLAMetrics | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadSLAData();
    const interval = setInterval(loadSLAData, 30000);
    return () => clearInterval(interval);
  }, [familyId]);

  const loadSLAData = async () => {
    try {
      const { data } = await supabase.functions.invoke('monitor-sla-compliance', {
        body: { familyId }
      });
      if (data) {
        setAtRisk(data.atRisk || []);
        setMetrics(data.metrics);
      }
    } catch (error) {
      console.error('Failed to load SLA data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getSLAStatus = (minutes: number) => {
    if (minutes < 5) return { color: 'destructive', label: 'Critical' };
    if (minutes < 15) return { color: 'warning', label: 'Warning' };
    return { color: 'default', label: 'Normal' };
  };

  const complianceRate = metrics ? ((metrics.onTime / metrics.total) * 100) : 0;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Compliance Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{complianceRate.toFixed(1)}%</div>
            <Progress value={complianceRate} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">At Risk</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-yellow-500" />
              <span className="text-2xl font-bold">{metrics?.atRisk || 0}</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Breached</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <XCircle className="h-5 w-5 text-red-500" />
              <span className="text-2xl font-bold">{metrics?.breached || 0}</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Avg Ack Time</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-blue-500" />
              <span className="text-2xl font-bold">{metrics?.avgAckTime.toFixed(0) || 0}m</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Alerts Approaching SLA Deadline</CardTitle>
        </CardHeader>
        <CardContent>
          {atRisk.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <CheckCircle className="h-12 w-12 mx-auto mb-2 text-green-500" />
              <p>All alerts within SLA targets</p>
            </div>
          ) : (
            <div className="space-y-3">
              {atRisk.map((alert) => {
                const status = getSLAStatus(alert.minutesRemaining);
                return (
                  <div key={alert.id} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Badge variant={status.color as any}>{status.label}</Badge>
                        <span className="font-medium">{alert.alert.rule_name}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <Clock className="h-4 w-4" />
                        <span className="font-mono">{Math.floor(alert.minutesRemaining)}m remaining</span>
                      </div>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      Channel: {alert.alert.channel_name} • Severity: {alert.alert.severity}
                    </div>
                    <Progress 
                      value={(alert.minutesRemaining / 30) * 100} 
                      className="mt-2"
                    />
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}