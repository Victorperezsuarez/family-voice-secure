import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Target, TrendingUp, TrendingDown } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';

export function QualityScorePanel() {
  const [scores, setScores] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadScores();
  }, []);

  const loadScores = async () => {
    const { data } = await supabase
      .from('alert_quality_scores')
      .select('*, alert_rules(name)')
      .order('calculated_at', { ascending: false })
      .limit(20);
    
    setScores(data || []);
  };

  const recalculateScore = async (ruleId: string) => {
    setLoading(true);
    try {
      await supabase.functions.invoke('calculate-alert-quality', {
        body: { alertRuleId: ruleId }
      });
      await loadScores();
    } catch (error) {
      console.error('Error recalculating score:', error);
    }
    setLoading(false);
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-blue-600';
    if (score >= 40) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreBadge = (score: number) => {
    if (score >= 80) return { variant: 'default' as const, label: 'Excellent' };
    if (score >= 60) return { variant: 'secondary' as const, label: 'Good' };
    if (score >= 40) return { variant: 'outline' as const, label: 'Fair' };
    return { variant: 'destructive' as const, label: 'Poor' };
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            Alert Quality Scores
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {scores.map((score) => {
              const badge = getScoreBadge(score.quality_score);
              return (
                <Card key={score.id}>
                  <CardContent className="pt-6">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h4 className="font-semibold mb-1">{score.alert_rules?.name || 'Unknown Rule'}</h4>
                        <Badge variant={badge.variant}>{badge.label}</Badge>
                      </div>
                      <div className="text-right">
                        <div className={`text-3xl font-bold ${getScoreColor(score.quality_score)}`}>
                          {score.quality_score}
                        </div>
                        <p className="text-xs text-muted-foreground">Quality Score</p>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Actionability</span>
                          <span className="font-medium">{score.actionability_score}%</span>
                        </div>
                        <Progress value={score.actionability_score} className="h-2" />
                      </div>

                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Noise Level</span>
                          <span className="font-medium">{score.noise_level}%</span>
                        </div>
                        <Progress value={score.noise_level} className="h-2" />
                      </div>

                      <div className="grid grid-cols-3 gap-4 pt-2 text-sm">
                        <div>
                          <p className="text-muted-foreground">Ack Rate</p>
                          <p className="font-semibold">{score.acknowledgment_rate?.toFixed(1)}%</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">False Positive</p>
                          <p className="font-semibold">{score.false_positive_probability?.toFixed(1)}%</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Avg Resolution</p>
                          <p className="font-semibold">{Math.round(score.resolution_time_avg / 60)}m</p>
                        </div>
                      </div>
                    </div>

                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full mt-4"
                      onClick={() => recalculateScore(score.alert_rule_id)}
                      disabled={loading}
                    >
                      Recalculate Score
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}