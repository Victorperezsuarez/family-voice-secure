import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Plus, Trash2 } from 'lucide-react';

interface DeliveryRule {
  id: string;
  rule_name: string;
  priority: number;
  conditions: any;
  schedule?: any;
  is_active: boolean;
}

interface DeliveryRulesBuilderProps {
  channelId: string;
  rules: DeliveryRule[];
  onSave: (rule: any) => void;
  onDelete: (id: string) => void;
  onToggle: (id: string, active: boolean) => void;
}

export function DeliveryRulesBuilder({ channelId, rules, onSave, onDelete, onToggle }: DeliveryRulesBuilderProps) {

  const [showForm, setShowForm] = useState(false);
  const [ruleName, setRuleName] = useState('');
  const [severity, setSeverity] = useState('');
  const [timeStart, setTimeStart] = useState('');
  const [timeEnd, setTimeEnd] = useState('');

  const handleSave = () => {
    onSave({
      channel_id: channelId,
      rule_name: ruleName,
      priority: rules.length,
      conditions: { severity: severity || undefined },
      schedule: timeStart && timeEnd ? { time_start: timeStart, time_end: timeEnd } : null,
      is_active: true
    });
    setRuleName('');
    setSeverity('');
    setTimeStart('');
    setTimeEnd('');
    setShowForm(false);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Delivery Rules</h3>
        <Button size="sm" onClick={() => setShowForm(!showForm)}>
          <Plus className="h-4 w-4 mr-1" />
          Add Rule
        </Button>
      </div>

      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">New Delivery Rule</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Rule Name</Label>
              <Input value={ruleName} onChange={(e) => setRuleName(e.target.value)} placeholder="Critical alerts only" />
            </div>
            <div>
              <Label>Severity Filter</Label>
              <Select value={severity} onValueChange={setSeverity}>
                <SelectTrigger>
                  <SelectValue placeholder="All severities" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Active From</Label>
                <Input type="time" value={timeStart} onChange={(e) => setTimeStart(e.target.value)} />
              </div>
              <div>
                <Label>Active Until</Label>
                <Input type="time" value={timeEnd} onChange={(e) => setTimeEnd(e.target.value)} />
              </div>
            </div>
            <Button onClick={handleSave} className="w-full">Save Rule</Button>
          </CardContent>
        </Card>
      )}

      <div className="space-y-2">
        {rules.map((rule) => (
          <Card key={rule.id}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-medium">{rule.rule_name}</span>
                    {rule.conditions?.severity && (
                      <Badge variant="outline" className="capitalize">{rule.conditions.severity}</Badge>
                    )}
                  </div>
                  {rule.schedule && (
                    <p className="text-sm text-muted-foreground">
                      Active: {rule.schedule.time_start} - {rule.schedule.time_end}
                    </p>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <Switch checked={rule.is_active} onCheckedChange={(checked) => onToggle(rule.id, checked)} />
                  <Button variant="ghost" size="sm" onClick={() => onDelete(rule.id)}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}