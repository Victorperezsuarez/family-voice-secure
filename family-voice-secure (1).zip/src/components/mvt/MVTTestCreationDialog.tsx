import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Trash2, Sparkles } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';

interface Element {
  name: string;
  type: string;
  variants: { id: string; value: string; label: string }[];
}

export function MVTTestCreationDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [elements, setElements] = useState<Element[]>([]);
  const [successMetric, setSuccessMetric] = useState('click_rate');
  const [creating, setCreating] = useState(false);

  const addElement = () => {
    setElements([...elements, { name: '', type: 'title', variants: [{ id: '1', value: '', label: 'Variant 1' }] }]);
  };

  const addVariant = (elementIndex: number) => {
    const newElements = [...elements];
    const variantCount = newElements[elementIndex].variants.length;
    newElements[elementIndex].variants.push({
      id: String(variantCount + 1),
      value: '',
      label: `Variant ${variantCount + 1}`
    });
    setElements(newElements);
  };

  const calculateCombinations = () => {
    return elements.reduce((acc, el) => acc * el.variants.length, 1);
  };

  const createTest = async () => {
    if (!name || elements.length < 2) {
      toast.error('Please provide a name and at least 2 elements');
      return;
    }

    setCreating(true);
    try {
      const { data, error } = await supabase.functions.invoke('create-mvt-test', {
        body: { name, description, elements, successMetric, factorialDesign: 'full' }
      });

      if (error) throw error;
      toast.success(`MVT test created with ${data.combinationsCount} combinations`);
      onOpenChange(false);
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setCreating(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5" />
            Create Multi-Variate Test
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          <div>
            <Label>Test Name</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Holiday Campaign MVT" />
          </div>

          <div>
            <Label>Description</Label>
            <Input value={description} onChange={(e) => setDescription(e.target.value)} />
          </div>

          <div>
            <Label>Success Metric</Label>
            <Select value={successMetric} onValueChange={setSuccessMetric}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="click_rate">Click Rate</SelectItem>
                <SelectItem value="action_rate">Action Rate</SelectItem>
                <SelectItem value="conversion_rate">Conversion Rate</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label>Test Elements</Label>
              <Button onClick={addElement} size="sm" variant="outline">
                <Plus className="w-4 h-4 mr-2" />
                Add Element
              </Button>
            </div>

            {elements.map((element, idx) => (
              <div key={idx} className="border rounded-lg p-4 space-y-3">
                <div className="flex gap-3">
                  <div className="flex-1">
                    <Input
                      placeholder="Element name (e.g., Headline)"
                      value={element.name}
                      onChange={(e) => {
                        const newElements = [...elements];
                        newElements[idx].name = e.target.value;
                        setElements(newElements);
                      }}
                    />
                  </div>
                  <Select
                    value={element.type}
                    onValueChange={(value) => {
                      const newElements = [...elements];
                      newElements[idx].type = value;
                      setElements(newElements);
                    }}
                  >
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="title">Title</SelectItem>
                      <SelectItem value="body">Body</SelectItem>
                      <SelectItem value="cta">CTA</SelectItem>
                      <SelectItem value="image">Image</SelectItem>
                      <SelectItem value="icon">Icon</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setElements(elements.filter((_, i) => i !== idx))}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>

                <div className="space-y-2">
                  {element.variants.map((variant, vIdx) => (
                    <Input
                      key={variant.id}
                      placeholder={`Variant ${vIdx + 1} value`}
                      value={variant.value}
                      onChange={(e) => {
                        const newElements = [...elements];
                        newElements[idx].variants[vIdx].value = e.target.value;
                        setElements(newElements);
                      }}
                    />
                  ))}
                  <Button onClick={() => addVariant(idx)} size="sm" variant="outline" className="w-full">
                    Add Variant
                  </Button>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-blue-50 p-4 rounded-lg">
            <p className="text-sm font-medium">Total Combinations: {calculateCombinations()}</p>
            <p className="text-xs text-gray-600 mt-1">
              Each combination will receive equal traffic allocation
            </p>
          </div>

          <div className="flex gap-3">
            <Button onClick={createTest} disabled={creating} className="flex-1">
              {creating ? 'Creating...' : 'Create MVT Test'}
            </Button>
            <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
