import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/lib/supabase-client';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ScatterChart, Scatter, Cell } from 'recharts';
import { RefreshCw, TrendingUp, Zap, Activity, Target } from 'lucide-react';
import type { MVTCombination, MVTInteraction, MainEffect } from '@/types/mvt';
import { BayesianOptimizationPanel } from '@/components/bayesian/BayesianOptimizationPanel';
import { TrafficAllocationChart } from '@/components/bayesian/TrafficAllocationChart';
import { EarlyStoppingPanel } from '@/components/bayesian/EarlyStoppingPanel';
import { UserSegmentationDashboard } from '@/components/contextual/UserSegmentationDashboard';
import { ContextualPerformanceChart } from '@/components/contextual/ContextualPerformanceChart';
import { PersonalizedDeliveryManager } from '@/components/contextual/PersonalizedDeliveryManager';



export function MVTAnalyticsDashboard({ testId }: { testId: string }) {
  const [combinations, setCombinations] = useState<MVTCombination[]>([]);
  const [interactions, setInteractions] = useState<MVTInteraction[]>([]);
  const [mainEffects, setMainEffects] = useState<MainEffect[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, [testId]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [combosRes, interactionsRes] = await Promise.all([
        supabase.from('notification_mvt_combinations').select('*').eq('test_id', testId),
        supabase.from('notification_mvt_interactions').select('*').eq('test_id', testId)
      ]);

      setCombinations(combosRes.data || []);
      setInteractions(interactionsRes.data || []);
      
      // Calculate main effects client-side
      calculateMainEffects(combosRes.data || []);
    } catch (error) {
      console.error('Error loading MVT data:', error);
    } finally {
      setLoading(false);
    }
  };

  const calculateMainEffects = (combos: MVTCombination[]) => {
    if (combos.length === 0) return;

    const elements = new Set<string>();
    combos.forEach(c => Object.keys(c.element_values).forEach(k => elements.add(k)));

    const effects: MainEffect[] = Array.from(elements).map(element => {
      const groups: Record<string, number[]> = {};
      
      combos.forEach(combo => {
        const value = combo.element_values[element]?.value || combo.element_values[element];
        if (!groups[value]) groups[value] = [];
        const rate = combo.deliveries > 0 ? (combo.clicks / combo.deliveries) * 100 : 0;
        groups[value].push(rate);
      });

      const means = Object.entries(groups).map(([variant, values]) => ({
        variant,
        mean: values.reduce((a, b) => a + b, 0) / values.length,
        count: values.length
      }));

      return { element, means };
    });

    setMainEffects(effects);
  };

  const bestCombination = [...combinations].sort((a, b) => {
    const aRate = a.deliveries > 0 ? a.clicks / a.deliveries : 0;
    const bRate = b.deliveries > 0 ? b.clicks / b.deliveries : 0;
    return bRate - aRate;
  })[0];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Multi-Variate Test Analysis</h2>
        <Button onClick={loadData} disabled={loading} size="sm" variant="outline">
          <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>

      <Tabs defaultValue="performance" className="w-full">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="optimization">
            <Activity className="w-4 h-4 mr-2" />
            Optimization
          </TabsTrigger>
          <TabsTrigger value="allocation">
            <TrendingUp className="w-4 h-4 mr-2" />
            Traffic
          </TabsTrigger>
          <TabsTrigger value="early-stopping">
            <Target className="w-4 h-4 mr-2" />
            Early Stop
          </TabsTrigger>
          <TabsTrigger value="segments">Segments</TabsTrigger>
          <TabsTrigger value="interactions">Interactions</TabsTrigger>
        </TabsList>


        <TabsContent value="performance" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium">Total Combinations</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{combinations.length}</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium">Significant Interactions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-green-600">
                  {interactions.filter(i => i.is_significant).length}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium">Best Combination</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-lg font-bold">{bestCombination?.combination_id || 'N/A'}</div>
                <div className="text-sm text-gray-600">
                  {bestCombination && bestCombination.deliveries > 0
                    ? `${((bestCombination.clicks / bestCombination.deliveries) * 100).toFixed(2)}% CTR`
                    : 'No data'}
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5" />
                Main Effects by Element
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {mainEffects.map(effect => (
                  <div key={effect.element}>
                    <h4 className="font-medium mb-3 capitalize">{effect.element}</h4>
                    <ResponsiveContainer width="100%" height={200}>
                      <BarChart data={effect.means}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="variant" />
                        <YAxis label={{ value: 'Click Rate %', angle: -90, position: 'insideLeft' }} />
                        <Tooltip />
                        <Bar dataKey="mean" fill="#3b82f6" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="optimization">
          <BayesianOptimizationPanel testId={testId} />
        </TabsContent>

        <TabsContent value="allocation">
          <TrafficAllocationChart testId={testId} />
        </TabsContent>

        <TabsContent value="early-stopping">
          <EarlyStoppingPanel testId={testId} />
        </TabsContent>

        <TabsContent value="segments" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <PersonalizedDeliveryManager testId={testId} />
            <ContextualPerformanceChart testId={testId} />
          </div>
          <UserSegmentationDashboard testId={testId} />
        </TabsContent>

        <TabsContent value="interactions">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5" />
                Interaction Effects
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {interactions.map(interaction => (
                  <div
                    key={interaction.id}
                    className={`p-4 rounded-lg border ${
                      interaction.is_significant ? 'bg-green-50 border-green-200' : 'bg-gray-50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">
                          {interaction.element_a} × {interaction.element_b}
                        </div>
                        <div className="text-sm text-gray-600">
                          Effect: {interaction.interaction_effect.toFixed(4)} | p-value: {interaction.p_value.toFixed(4)}
                        </div>
                      </div>
                      <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                        interaction.effect_direction === 'positive' ? 'bg-green-100 text-green-700' :
                        interaction.effect_direction === 'negative' ? 'bg-red-100 text-red-700' :
                        'bg-gray-100 text-gray-700'
                      }`}>
                        {interaction.effect_direction}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

