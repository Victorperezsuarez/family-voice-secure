import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Clock, Play } from 'lucide-react';

interface Chapter {
  title: string;
  startTime: number;
  summary: string;
}

interface StoryChaptersViewProps {
  chapters: Chapter[];
  onSeekTo: (time: number) => void;
  currentTime: number;
}

export function StoryChaptersView({ chapters, onSeekTo, currentTime }: StoryChaptersViewProps) {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getCurrentChapter = () => {
    for (let i = chapters.length - 1; i >= 0; i--) {
      if (currentTime >= chapters[i].startTime) {
        return i;
      }
    }
    return 0;
  };

  const currentChapterIndex = getCurrentChapter();

  return (
    <Card className="p-4">
      <h3 className="text-lg font-semibold mb-4">Story Chapters</h3>
      <div className="space-y-3">
        {chapters.map((chapter, index) => (
          <div
            key={index}
            className={`p-3 rounded-lg border transition-colors ${
              index === currentChapterIndex
                ? 'bg-primary/10 border-primary'
                : 'bg-muted/50 border-border hover:bg-muted'
            }`}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <Badge variant="outline" className="text-xs">
                    Chapter {index + 1}
                  </Badge>
                  <span className="text-xs text-muted-foreground flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {formatTime(chapter.startTime)}
                  </span>
                </div>
                <h4 className="font-medium mb-1">{chapter.title}</h4>
                <p className="text-sm text-muted-foreground line-clamp-2">
                  {chapter.summary}
                </p>
              </div>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => onSeekTo(chapter.startTime)}
                className="shrink-0"
              >
                <Play className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}