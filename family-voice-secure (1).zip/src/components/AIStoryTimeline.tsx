import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Loader2, Calendar, Link2, Sparkles } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';

interface Recording {
  id: string;
  title: string;
  created_at: string;
  transcription: string;
}

interface TimelineEvent {
  id: string;
  title: string;
  date: string;
  connections: string[];
  themes: string[];
}

export function AIStoryTimeline({ familyId }: { familyId: string }) {
  const [timeline, setTimeline] = useState<TimelineEvent[]>([]);
  const [loading, setLoading] = useState(false);

  const generateTimeline = async () => {
    setLoading(true);
    try {
      const { data: recordings, error } = await supabase
        .from('recordings')
        .select('*')
        .eq('family_id', familyId)
        .order('created_at', { ascending: true });

      if (error) throw error;

      const events: TimelineEvent[] = recordings.map((r: Recording) => ({
        id: r.id,
        title: r.title,
        date: new Date(r.created_at).toLocaleDateString(),
        connections: [],
        themes: []
      }));

      setTimeline(events);
      toast.success('Timeline generated!');
    } catch (error: any) {
      toast.error(error.message || 'Failed to generate timeline');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <Button onClick={generateTimeline} disabled={loading}>
        {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Sparkles className="w-4 h-4 mr-2" />}
        Generate AI Timeline
      </Button>

      {timeline.length > 0 && (
        <div className="relative">
          <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-border" />
          <div className="space-y-6">
            {timeline.map((event, i) => (
              <Card key={event.id} className="p-4 ml-10 relative">
                <div className="absolute -left-6 top-4 w-4 h-4 rounded-full bg-primary border-4 border-background" />
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <Calendar className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground">{event.date}</span>
                    </div>
                    <h3 className="font-semibold">{event.title}</h3>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}