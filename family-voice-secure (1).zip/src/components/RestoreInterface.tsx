import { useState, useEffect } from 'react';
import { BackupHistory, BackupContent, ConflictResolution } from '@/types/backup';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { BackupContentPreview } from './BackupContentPreview';
import { supabase } from '@/lib/supabase-client';
import { useAuth } from '@/contexts/AuthContext';
import { AlertCircle, Download, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';

interface RestoreInterfaceProps {
  backup: BackupHistory;
  onRestoreComplete: () => void;
}

export function RestoreInterface({ backup, onRestoreComplete }: RestoreInterfaceProps) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [previewLoading, setPreviewLoading] = useState(true);
  const [content, setContent] = useState<BackupContent | null>(null);
  const [conflictResolution, setConflictResolution] = useState<ConflictResolution>('skip');
  const [selectedItems, setSelectedItems] = useState({ recordings: [] as string[], transcriptions: [] as string[], photos: [] as string[] });

  useEffect(() => {
    loadBackupPreview();
  }, [backup.id]);

  const loadBackupPreview = async () => {
    setPreviewLoading(true);
    // Mock preview data - in production, fetch from cloud storage
    const mockContent: BackupContent = {
      recordings: [
        { id: '1', title: 'Historia familiar', duration: 180, created_at: new Date().toISOString(), file_path: '/path' }
      ],
      transcriptions: [],
      photos: [],
      metadata: { backup_date: backup.created_at, total_size: backup.file_size_bytes, version: '1.0' }
    };
    setContent(mockContent);
    setPreviewLoading(false);
  };

  const handleSelectionChange = (type: 'recordings' | 'transcriptions' | 'photos', id: string) => {
    setSelectedItems(prev => ({
      ...prev,
      [type]: prev[type].includes(id) ? prev[type].filter((i: string) => i !== id) : [...prev[type], id]
    }));
  };

  const handleRestore = async () => {
    if (!user) return;
    setLoading(true);
    const { data, error } = await supabase.functions.invoke('restore-from-backup', {
      body: { 
        backupId: backup.id, 
        provider: backup.provider, 
        backupPath: backup.backup_path,
        selectedItems, 
        conflictResolution,
        familyId: backup.family_id,
        userId: user.id
      }
    });
    setLoading(false);
    if (error) {
      toast.error('Error al restaurar');
    } else if (data?.success) {
      toast.success(`Restaurados ${data.recordingsRestored} grabaciones`);
      onRestoreComplete();
    }
  };

  if (previewLoading) return <div className="text-center py-8">Cargando vista previa...</div>;

  return (
    <div className="space-y-4">
      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>Revisa el contenido antes de restaurar</AlertDescription>
      </Alert>
      
      {content && (
        <BackupContentPreview 
          content={content} 
          selectedItems={selectedItems}
          onSelectionChange={handleSelectionChange}
        />
      )}

      <div className="space-y-3">
        <label className="text-sm font-medium">Resolución de conflictos</label>
        <Select value={conflictResolution} onValueChange={(v) => setConflictResolution(v as ConflictResolution)}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="skip">Omitir archivos existentes</SelectItem>
            <SelectItem value="overwrite">Sobrescribir existentes</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Button onClick={handleRestore} disabled={loading || selectedItems.recordings.length === 0} className="w-full">
        {loading ? 'Restaurando...' : (
          <>
            <Download className="h-4 w-4 mr-2" />
            Restaurar {selectedItems.recordings.length} elementos
          </>
        )}
      </Button>
    </div>
  );
}
