import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase-client';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, Play, Download, Trash2, Upload, Filter } from 'lucide-react';
import { toast } from 'sonner';

interface Video {
  id: string;
  title: string;
  description?: string;
  storage_path: string;
  thumbnail_path?: string;
  duration: number;
  quality: string;
  orientation: string;
  file_size: number;
  upload_status: string;
  upload_progress: number;
  created_at: string;
}

export function VideoLibrary() {
  const [videos, setVideos] = useState<Video[]>([]);
  const [filteredVideos, setFilteredVideos] = useState<Video[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [qualityFilter, setQualityFilter] = useState('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadVideos();
  }, []);

  useEffect(() => {
    filterVideos();
  }, [videos, searchQuery, qualityFilter]);

  const loadVideos = async () => {
    try {
      const { data, error } = await supabase
        .from('videos')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setVideos(data || []);
    } catch (error) {
      console.error('Error loading videos:', error);
      toast.error('Failed to load videos');
    } finally {
      setLoading(false);
    }
  };

  const filterVideos = () => {
    let filtered = videos;

    if (searchQuery) {
      filtered = filtered.filter(v =>
        v.title.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    if (qualityFilter !== 'all') {
      filtered = filtered.filter(v => v.quality === qualityFilter);
    }

    setFilteredVideos(filtered);
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const formatFileSize = (bytes: number) => {
    const mb = bytes / (1024 * 1024);
    return `${mb.toFixed(1)} MB`;
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search videos..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={qualityFilter} onValueChange={setQualityFilter}>
          <SelectTrigger className="w-32">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Quality</SelectItem>
            <SelectItem value="720p">720p</SelectItem>
            <SelectItem value="1080p">1080p</SelectItem>
            <SelectItem value="4K">4K</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {filteredVideos.map((video) => (
          <Card key={video.id} className="overflow-hidden">
            <div className="aspect-video bg-muted relative">
              {video.thumbnail_path ? (
                <img src={video.thumbnail_path} alt={video.title} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Play className="h-8 w-8 text-muted-foreground" />
                </div>
              )}
              {video.upload_status === 'uploading' && (
                <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                  <div className="text-white text-sm">{video.upload_progress}%</div>
                </div>
              )}
            </div>
            <div className="p-2 space-y-1">
              <h3 className="font-medium text-sm truncate">{video.title}</h3>
              <div className="flex gap-1 flex-wrap">
                <Badge variant="secondary" className="text-xs">{video.quality}</Badge>
                <Badge variant="outline" className="text-xs">{formatDuration(video.duration)}</Badge>
              </div>
              <p className="text-xs text-muted-foreground">{formatFileSize(video.file_size)}</p>
            </div>
          </Card>
        ))}
      </div>

      {filteredVideos.length === 0 && !loading && (
        <div className="text-center py-12 text-muted-foreground">
          <p>No videos found</p>
        </div>
      )}
    </div>
  );
}
