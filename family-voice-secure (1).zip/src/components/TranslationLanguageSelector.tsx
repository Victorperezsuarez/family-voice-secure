import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Languages, Loader2, Volume2 } from 'lucide-react';

const SUPPORTED_LANGUAGES = [
  { code: 'en', name: 'English', flag: '🇺🇸' },
  { code: 'es', name: 'Spanish', flag: '🇪🇸' },
  { code: 'fr', name: 'French', flag: '🇫🇷' },
  { code: 'de', name: 'German', flag: '🇩🇪' },
  { code: 'zh', name: 'Chinese', flag: '🇨🇳' },
  { code: 'ja', name: 'Japanese', flag: '🇯🇵' },
  { code: 'ko', name: 'Korean', flag: '🇰🇷' },
  { code: 'it', name: 'Italian', flag: '🇮🇹' },
  { code: 'pt', name: 'Portuguese', flag: '🇵🇹' },
  { code: 'ru', name: 'Russian', flag: '🇷🇺' },
  { code: 'ar', name: 'Arabic', flag: '🇸🇦' },
  { code: 'hi', name: 'Hindi', flag: '🇮🇳' },
];

interface TranslationLanguageSelectorProps {
  currentLanguage: string;
  onLanguageChange: (language: string) => void;
  onTranslate: (targetLanguage: string, withVoiceCloning?: boolean) => Promise<void>;
  isTranslating?: boolean;
  availableTranslations?: string[];
  showBilingualToggle?: boolean;
  bilingualMode?: boolean;
  onBilingualToggle?: (enabled: boolean) => void;
}

export function TranslationLanguageSelector({
  currentLanguage,
  onLanguageChange,
  onTranslate,
  isTranslating = false,
  availableTranslations = [],
  showBilingualToggle = false,
  bilingualMode = false,
  onBilingualToggle
}: TranslationLanguageSelectorProps) {
  const [selectedTarget, setSelectedTarget] = useState<string>('');
  const [enableVoiceCloning, setEnableVoiceCloning] = useState(true);

  const handleTranslate = async () => {
    if (selectedTarget && selectedTarget !== currentLanguage) {
      await onTranslate(selectedTarget, enableVoiceCloning);
    }
  };

  return (
    <div className="flex items-center gap-3 flex-wrap">
      <div className="flex items-center gap-2">
        <Languages className="h-4 w-4 text-muted-foreground" />
        <span className="text-sm font-medium">Translate:</span>
      </div>

      <Select value={selectedTarget} onValueChange={setSelectedTarget}>
        <SelectTrigger className="w-[180px]">
          <SelectValue placeholder="Select language" />
        </SelectTrigger>
        <SelectContent>
          {SUPPORTED_LANGUAGES.filter(lang => lang.code !== currentLanguage).map(lang => (
            <SelectItem key={lang.code} value={lang.code}>
              <span className="flex items-center gap-2">
                <span>{lang.flag}</span>
                <span>{lang.name}</span>
              </span>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <div className="flex items-center gap-2">
        <Switch
          id="voice-cloning"
          checked={enableVoiceCloning}
          onCheckedChange={setEnableVoiceCloning}
        />
        <Label htmlFor="voice-cloning" className="text-sm flex items-center gap-1 cursor-pointer">
          <Volume2 className="h-3 w-3" />
          Voice Clone
        </Label>
      </div>

      <Button
        onClick={handleTranslate}
        disabled={!selectedTarget || isTranslating || selectedTarget === currentLanguage}
        size="sm"
      >
        {isTranslating ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Translating...
          </>
        ) : (
          'Translate'
        )}
      </Button>

      {availableTranslations.length > 0 && (
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">Available:</span>
          {availableTranslations.map(lang => {
            const langInfo = SUPPORTED_LANGUAGES.find(l => l.code === lang);
            return langInfo ? (
              <Badge
                key={lang}
                variant="secondary"
                className="cursor-pointer"
                onClick={() => onLanguageChange(lang)}
              >
                {langInfo.flag} {langInfo.name}
              </Badge>
            ) : null;
          })}
        </div>
      )}

      {showBilingualToggle && onBilingualToggle && (
        <Button
          variant={bilingualMode ? "default" : "outline"}
          size="sm"
          onClick={() => onBilingualToggle(!bilingualMode)}
        >
          Bilingual View
        </Button>
      )}
    </div>
  );
}