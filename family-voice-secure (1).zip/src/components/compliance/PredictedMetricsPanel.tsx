import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Mail, MousePointer, TrendingUp, AlertCircle } from 'lucide-react';

interface PredictedMetricsPanelProps {
  predictedOpenRate: number;
  predictedClickRate: number;
  predictedConversionRate: number;
  predictedBounceRate: number;
  industryAvgOpenRate?: number;
  industryAvgClickRate?: number;
}

export function PredictedMetricsPanel({
  predictedOpenRate,
  predictedClickRate,
  predictedConversionRate,
  predictedBounceRate,
  industryAvgOpenRate = 21.5,
  industryAvgClickRate = 2.6
}: PredictedMetricsPanelProps) {
  const metrics = [
    {
      label: 'Open Rate',
      value: predictedOpenRate,
      benchmark: industryAvgOpenRate,
      icon: Mail,
      color: 'text-blue-600'
    },
    {
      label: 'Click Rate',
      value: predictedClickRate,
      benchmark: industryAvgClickRate,
      icon: MousePointer,
      color: 'text-green-600'
    },
    {
      label: 'Conversion Rate',
      value: predictedConversionRate,
      benchmark: 1.5,
      icon: TrendingUp,
      color: 'text-purple-600'
    },
    {
      label: 'Bounce Rate',
      value: predictedBounceRate,
      benchmark: 5.0,
      icon: AlertCircle,
      color: 'text-red-600',
      inverse: true
    }
  ];

  const getComparison = (value: number, benchmark: number, inverse = false) => {
    const diff = inverse ? benchmark - value : value - benchmark;
    if (Math.abs(diff) < 0.5) return { text: 'On Par', color: 'bg-gray-500' };
    if (diff > 0) return { text: 'Above Avg', color: 'bg-green-600' };
    return { text: 'Below Avg', color: 'bg-red-600' };
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Predicted Performance</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4">
          {metrics.map((metric) => {
            const Icon = metric.icon;
            const comparison = getComparison(metric.value, metric.benchmark, metric.inverse);
            
            return (
              <div key={metric.label} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <Icon className={`h-5 w-5 ${metric.color}`} />
                  <Badge className={comparison.color}>{comparison.text}</Badge>
                </div>
                <div className={`text-2xl font-bold ${metric.color}`}>
                  {metric.value.toFixed(1)}%
                </div>
                <div className="text-sm text-muted-foreground">{metric.label}</div>
                <div className="text-xs text-muted-foreground mt-1">
                  Industry avg: {metric.benchmark.toFixed(1)}%
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
