import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { supabase } from '@/lib/supabase-client';
import { DomainAuthenticationCard } from './DomainAuthenticationCard';
import { BlacklistMonitoringPanel } from './BlacklistMonitoringPanel';
import { SenderReputationCard } from './SenderReputationCard';
import { ISPDeliveryRatesChart } from './ISPDeliveryRatesChart';
import { DeliverabilityAlertsPanel } from './DeliverabilityAlertsPanel';
import { HealthTrendsChart } from './HealthTrendsChart';
import { AlertTriangle, TrendingUp } from 'lucide-react';

export function DeliverabilityHealthDashboard() {
  const [domain] = useState('example.com');
  const [authentication, setAuthentication] = useState<any>(null);
  const [blacklists, setBlacklists] = useState<any[]>([]);
  const [reputation, setReputation] = useState<any>(null);
  const [alerts, setAlerts] = useState<any[]>([]);
  const [healthScore, setHealthScore] = useState(0);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadDeliverabilityData();
  }, []);

  const loadDeliverabilityData = async () => {
    setLoading(true);
    try {
      await Promise.all([
        loadAuthentication(),
        loadBlacklists(),
        loadReputation(),
        loadAlerts()
      ]);
      calculateHealthScore();
    } finally {
      setLoading(false);
    }
  };

  const loadAuthentication = async () => {
    const { data } = await supabase.functions.invoke('check-domain-authentication', {
      body: { domain }
    });
    if (data) setAuthentication(data);
  };

  const loadBlacklists = async () => {
    const { data } = await supabase.functions.invoke('monitor-email-blacklists', {
      body: { domain, ipAddress: '1.2.3.4' }
    });
    if (data) setBlacklists(data.results || []);
  };

  const loadReputation = async () => {
    const { data } = await supabase
      .from('email_sender_reputation')
      .select('*')
      .eq('domain', domain)
      .order('created_at', { ascending: false })
      .limit(1)
      .single();
    if (data) setReputation(data);
  };

  const loadAlerts = async () => {
    const { data } = await supabase
      .from('email_deliverability_alerts')
      .select('*')
      .eq('domain', domain)
      .eq('is_resolved', false)
      .order('created_at', { ascending: false });
    if (data) setAlerts(data);
  };

  const calculateHealthScore = () => {
    let score = 100;
    if (authentication?.authenticationScore) score = authentication.authenticationScore;
    setHealthScore(score);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold">Email Deliverability</h2>
          <p className="text-muted-foreground">Monitor sender reputation and delivery health</p>
        </div>
        <Card className="w-32">
          <CardContent className="pt-6 text-center">
            <p className="text-3xl font-bold text-green-500">{healthScore}</p>
            <p className="text-xs text-muted-foreground">Health Score</p>
          </CardContent>
        </Card>
      </div>

      {alerts.length > 0 && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            You have {alerts.length} active deliverability alert{alerts.length > 1 ? 's' : ''}
          </AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="authentication">Authentication</TabsTrigger>
          <TabsTrigger value="reputation">Reputation</TabsTrigger>
          <TabsTrigger value="alerts">Alerts</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <SenderReputationCard reputation={reputation} />
            <DomainAuthenticationCard 
              authentication={authentication} 
              onRefresh={loadAuthentication}
              loading={loading}
            />
          </div>
          <BlacklistMonitoringPanel 
            blacklists={blacklists} 
            blacklistScore={authentication?.authenticationScore || 0}
          />
        </TabsContent>

        <TabsContent value="authentication">
          <DomainAuthenticationCard 
            authentication={authentication} 
            onRefresh={loadAuthentication}
            loading={loading}
          />
        </TabsContent>

        <TabsContent value="reputation">
          <SenderReputationCard reputation={reputation} />
        </TabsContent>

        <TabsContent value="alerts">
          <DeliverabilityAlertsPanel alerts={alerts} onResolve={loadAlerts} />
        </TabsContent>
      </Tabs>
    </div>
  );
}
