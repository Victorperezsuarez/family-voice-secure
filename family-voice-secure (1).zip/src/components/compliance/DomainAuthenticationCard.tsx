import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Shield, CheckCircle, XCircle, AlertTriangle, RefreshCw } from 'lucide-react';
import { EmailDomainAuthentication } from '@/types/emailDeliverability';

interface DomainAuthenticationCardProps {
  authentication: EmailDomainAuthentication | null;
  onRefresh: () => void;
  loading?: boolean;
}

export function DomainAuthenticationCard({ authentication, onRefresh, loading }: DomainAuthenticationCardProps) {
  const getStatusIcon = (status: string) => {
    if (status === 'pass') return <CheckCircle className="h-5 w-5 text-green-500" />;
    if (status === 'fail' || status === 'permerror') return <XCircle className="h-5 w-5 text-red-500" />;
    if (status === 'none') return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
    return <AlertTriangle className="h-5 w-5 text-gray-400" />;
  };

  const getStatusBadge = (status: string) => {
    const variant = status === 'pass' ? 'default' : status === 'fail' ? 'destructive' : 'secondary';
    return <Badge variant={variant}>{status.toUpperCase()}</Badge>;
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div className="flex items-center gap-2">
          <Shield className="h-5 w-5" />
          <CardTitle>Domain Authentication</CardTitle>
        </div>
        <Button variant="outline" size="sm" onClick={onRefresh} disabled={loading}>
          <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </CardHeader>
      <CardContent className="space-y-4">
        {authentication ? (
          <>
            <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
              <div className="flex items-center gap-3">
                {getStatusIcon(authentication.spfStatus)}
                <div>
                  <p className="font-medium">SPF Record</p>
                  <p className="text-sm text-muted-foreground">Sender Policy Framework</p>
                </div>
              </div>
              {getStatusBadge(authentication.spfStatus)}
            </div>

            <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
              <div className="flex items-center gap-3">
                {getStatusIcon(authentication.dkimStatus)}
                <div>
                  <p className="font-medium">DKIM Record</p>
                  <p className="text-sm text-muted-foreground">DomainKeys Identified Mail</p>
                </div>
              </div>
              {getStatusBadge(authentication.dkimStatus)}
            </div>

            <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
              <div className="flex items-center gap-3">
                {getStatusIcon(authentication.dmarcStatus)}
                <div>
                  <p className="font-medium">DMARC Policy</p>
                  <p className="text-sm text-muted-foreground">
                    {authentication.dmarcPolicy ? `Policy: ${authentication.dmarcPolicy}` : 'Not configured'}
                  </p>
                </div>
              </div>
              {getStatusBadge(authentication.dmarcStatus)}
            </div>
          </>
        ) : (
          <p className="text-center text-muted-foreground py-4">No authentication data available</p>
        )}
      </CardContent>
    </Card>
  );
}
