import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';
import { History, Check, Eye } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

interface TemplateVersion {
  id: string;
  version_number: number;
  name: string;
  subject: string;
  html_content: string;
  created_at: string;
  is_active: boolean;
  change_notes: string;
}

interface TemplateVersionHistoryProps {
  templateId: string;
}

export function TemplateVersionHistory({ templateId }: TemplateVersionHistoryProps) {
  const [versions, setVersions] = useState<TemplateVersion[]>([]);
  const [selectedVersion, setSelectedVersion] = useState<TemplateVersion | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadVersions();
  }, [templateId]);

  const loadVersions = async () => {
    const { data, error } = await supabase
      .from('email_template_versions')
      .select('*')
      .eq('template_id', templateId)
      .order('version_number', { ascending: false });

    if (error) {
      toast.error('Failed to load version history');
      return;
    }

    setVersions(data || []);
  };

  const activateVersion = async (versionId: string) => {
    setLoading(true);
    try {
      // Deactivate all versions
      await supabase
        .from('email_template_versions')
        .update({ is_active: false })
        .eq('template_id', templateId);

      // Activate selected version
      const { error } = await supabase
        .from('email_template_versions')
        .update({ is_active: true })
        .eq('id', versionId);

      if (error) throw error;

      toast.success('Version activated successfully');
      loadVersions();
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <div className="space-y-4">
        <div className="flex items-center gap-2 mb-4">
          <History className="w-5 h-5" />
          <h3 className="text-lg font-semibold">Version History</h3>
        </div>

        {versions.map((version) => (
          <Card key={version.id} className="p-4">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span className="font-semibold">Version {version.version_number}</span>
                  {version.is_active && (
                    <Badge variant="default">
                      <Check className="w-3 h-3 mr-1" />
                      Active
                    </Badge>
                  )}
                </div>
                <p className="text-sm text-muted-foreground mb-2">{version.name}</p>
                {version.change_notes && (
                  <p className="text-sm text-muted-foreground italic">{version.change_notes}</p>
                )}
                <p className="text-xs text-muted-foreground mt-2">
                  {new Date(version.created_at).toLocaleString()}
                </p>
              </div>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setSelectedVersion(version)}
                >
                  <Eye className="w-4 h-4" />
                </Button>
                {!version.is_active && (
                  <Button
                    size="sm"
                    onClick={() => activateVersion(version.id)}
                    disabled={loading}
                  >
                    Activate
                  </Button>
                )}
              </div>
            </div>
          </Card>
        ))}
      </div>

      <Dialog open={!!selectedVersion} onOpenChange={() => setSelectedVersion(null)}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Version {selectedVersion?.version_number} Preview</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <p className="text-sm font-semibold mb-1">Subject:</p>
              <p className="text-sm">{selectedVersion?.subject}</p>
            </div>
            <div>
              <p className="text-sm font-semibold mb-2">Content:</p>
              <Card className="p-4">
                <div dangerouslySetInnerHTML={{ __html: selectedVersion?.html_content || '' }} />
              </Card>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
