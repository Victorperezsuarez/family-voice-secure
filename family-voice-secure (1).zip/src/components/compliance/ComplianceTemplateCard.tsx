import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ComplianceReportTemplate } from '@/types/compliance';
import { FileText, Edit, Trash2, Play } from 'lucide-react';

interface Props {
  template: ComplianceReportTemplate;
  onEdit: (template: ComplianceReportTemplate) => void;
  onDelete: (id: string) => void;
  onGenerate: (template: ComplianceReportTemplate) => void;
}

export default function ComplianceTemplateCard({ template, onEdit, onDelete, onGenerate }: Props) {
  const standardColors: Record<string, string> = {
    GDPR: 'bg-blue-500',
    HIPAA: 'bg-green-500',
    SOC2: 'bg-purple-500',
    ISO27001: 'bg-orange-500',
    CUSTOM: 'bg-gray-500'
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-muted-foreground" />
            <div>
              <CardTitle className="text-lg">{template.name}</CardTitle>
              <CardDescription>{template.description}</CardDescription>
            </div>
          </div>
          <Badge className={standardColors[template.standard]}>{template.standard}</Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="text-sm text-muted-foreground">
            <span className="font-medium">{template.sections.length}</span> sections • 
            <span className="font-medium ml-1">{template.metrics.length}</span> metrics
          </div>
          <div className="flex gap-2">
            <Button size="sm" onClick={() => onGenerate(template)}>
              <Play className="h-4 w-4 mr-1" />
              Generate Report
            </Button>
            <Button size="sm" variant="outline" onClick={() => onEdit(template)}>
              <Edit className="h-4 w-4 mr-1" />
              Edit
            </Button>
            <Button size="sm" variant="outline" onClick={() => onDelete(template.id)}>
              <Trash2 className="h-4 w-4 mr-1" />
              Delete
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
