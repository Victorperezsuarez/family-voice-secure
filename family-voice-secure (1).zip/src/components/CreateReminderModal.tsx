import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { FamilyMember } from '@/types/family';

interface CreateReminderModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: any) => void;
  familyMembers: FamilyMember[];
}

const OCCASION_TEMPLATES = {
  birthday: ['Share your favorite birthday memory', 'What gift meant the most to you?', 'Describe your best birthday celebration'],
  anniversary: ['How did you meet?', 'What makes your relationship special?', 'Share a favorite memory together'],
  holiday: ['What traditions do you remember?', 'Share a holiday story', 'What did this holiday mean to you?'],
  custom: []
};

export function CreateReminderModal({ isOpen, onClose, onSubmit, familyMembers }: CreateReminderModalProps) {
  const [formData, setFormData] = useState({
    occasion: '',
    occasion_type: 'custom',
    occasion_date: '',
    recurrence: 'yearly',
    family_member_id: '',
    reminder_days_before: 7,
    send_email: true,
    send_sms: false,
    suggested_topics: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const topics = formData.suggested_topics.split('\n').filter(t => t.trim());
    onSubmit({ ...formData, suggested_topics: topics });
    onClose();
  };

  const handleTypeChange = (type: string) => {
    setFormData(prev => ({
      ...prev,
      occasion_type: type,
      suggested_topics: OCCASION_TEMPLATES[type as keyof typeof OCCASION_TEMPLATES]?.join('\n') || ''
    }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create Reminder</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label>Occasion Name</Label>
            <Input value={formData.occasion} onChange={e => setFormData(prev => ({ ...prev, occasion: e.target.value }))} required />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Occasion Type</Label>
              <Select value={formData.occasion_type} onValueChange={handleTypeChange}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="birthday">Birthday</SelectItem>
                  <SelectItem value="anniversary">Anniversary</SelectItem>
                  <SelectItem value="holiday">Holiday</SelectItem>
                  <SelectItem value="custom">Custom</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Date</Label>
              <Input type="date" value={formData.occasion_date} onChange={e => setFormData(prev => ({ ...prev, occasion_date: e.target.value }))} required />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Recurrence</Label>
              <Select value={formData.recurrence} onValueChange={v => setFormData(prev => ({ ...prev, recurrence: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="once">Once</SelectItem>
                  <SelectItem value="yearly">Yearly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Days Before</Label>
              <Input type="number" value={formData.reminder_days_before} onChange={e => setFormData(prev => ({ ...prev, reminder_days_before: parseInt(e.target.value) }))} />
            </div>
          </div>
          <div>
            <Label>Family Member (Optional)</Label>
            <Select value={formData.family_member_id} onValueChange={v => setFormData(prev => ({ ...prev, family_member_id: v }))}>
              <SelectTrigger><SelectValue placeholder="All members" /></SelectTrigger>
              <SelectContent>
                {familyMembers.map(m => <SelectItem key={m.id} value={m.id}>{m.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Suggested Topics (one per line)</Label>
            <Textarea rows={4} value={formData.suggested_topics} onChange={e => setFormData(prev => ({ ...prev, suggested_topics: e.target.value }))} />
          </div>
          <div className="flex gap-4">
            <div className="flex items-center gap-2">
              <Switch checked={formData.send_email} onCheckedChange={v => setFormData(prev => ({ ...prev, send_email: v }))} />
              <Label>Email</Label>
            </div>
            <div className="flex items-center gap-2">
              <Switch checked={formData.send_sms} onCheckedChange={v => setFormData(prev => ({ ...prev, send_sms: v }))} />
              <Label>SMS</Label>
            </div>
          </div>
          <div className="flex gap-2 justify-end">
            <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
            <Button type="submit">Create Reminder</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
