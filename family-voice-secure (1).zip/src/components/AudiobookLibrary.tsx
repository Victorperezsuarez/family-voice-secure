import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { BookOpen, Play, Download, Trash2 } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { Audiobook } from '@/types/audiobook';
import { toast } from 'sonner';
import { Badge } from '@/components/ui/badge';

export function AudiobookLibrary() {
  const [audiobooks, setAudiobooks] = useState<Audiobook[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAudiobooks();
  }, []);

  const loadAudiobooks = async () => {
    try {
      const { data, error } = await supabase
        .from('audiobooks')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setAudiobooks(data || []);
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const deleteAudiobook = async (id: string) => {
    try {
      const { error } = await supabase.from('audiobooks').delete().eq('id', id);
      if (error) throw error;
      toast.success('Audiobook deleted');
      loadAudiobooks();
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  if (loading) return <div>Loading...</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">My Audiobooks</h2>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {audiobooks.map((book) => (
          <Card key={book.id} className="p-6">
            <div className="space-y-4">
              <div className="flex items-start justify-between">
                <BookOpen className="w-8 h-8 text-primary" />
                <Badge>{book.status}</Badge>
              </div>
              <div>
                <h3 className="font-semibold text-lg">{book.title}</h3>
                <p className="text-sm text-muted-foreground line-clamp-2">{book.description}</p>
              </div>
              <div className="flex items-center gap-2">
                <Button size="sm" className="flex-1">
                  <Play className="w-4 h-4 mr-2" />
                  Play
                </Button>
                {book.audio_url && (
                  <Button variant="outline" size="sm">
                    <Download className="w-4 h-4" />
                  </Button>
                )}
                <Button variant="ghost" size="sm" onClick={() => deleteAudiobook(book.id)}>
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
