import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Mic, UserCheck, AlertCircle, Trash2 } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { VoiceEnrollmentDialog } from './VoiceEnrollmentDialog';
import { toast } from 'sonner';

interface VoiceProfile {
  id: string;
  family_member_id: string;
  enrollment_status: string;
  confidence_score: number;
  sample_recording_ids: string[];
  last_updated: string;
  family_members: {
    name: string;
    photo_url?: string;
  };
}

export function VoiceProfilesManager({ familyId }: { familyId: string }) {
  const [profiles, setProfiles] = useState<VoiceProfile[]>([]);
  const [familyMembers, setFamilyMembers] = useState<any[]>([]);
  const [selectedMember, setSelectedMember] = useState<{ id: string; name: string } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, [familyId]);

  const loadData = async () => {
    try {
      const [profilesRes, membersRes] = await Promise.all([
        supabase
          .from('voice_profiles')
          .select('*, family_members!inner(name, photo_url, family_id)')
          .eq('family_members.family_id', familyId),
        supabase
          .from('family_members')
          .select('*')
          .eq('family_id', familyId)
      ]);

      if (profilesRes.data) setProfiles(profilesRes.data);
      if (membersRes.data) setFamilyMembers(membersRes.data);
    } catch (error) {
      toast.error('Failed to load voice profiles');
    } finally {
      setLoading(false);
    }
  };

  const deleteProfile = async (profileId: string) => {
    try {
      await supabase.from('voice_profiles').delete().eq('id', profileId);
      toast.success('Voice profile deleted');
      loadData();
    } catch (error) {
      toast.error('Failed to delete profile');
    }
  };

  const unenrolledMembers = familyMembers.filter(
    member => !profiles.find(p => p.family_member_id === member.id)
  );

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <UserCheck className="h-5 w-5" />
            Voice Biometric Profiles
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {profiles.map(profile => (
            <div key={profile.id} className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarImage src={profile.family_members.photo_url} />
                  <AvatarFallback>{profile.family_members.name[0]}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium">{profile.family_members.name}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant={profile.enrollment_status === 'enrolled' ? 'default' : 'secondary'}>
                      {profile.enrollment_status}
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      {Math.round(profile.confidence_score * 100)}% confidence
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setSelectedMember({ id: profile.family_member_id, name: profile.family_members.name })}
                >
                  <Mic className="h-4 w-4 mr-1" />
                  Add Samples
                </Button>
                <Button variant="ghost" size="sm" onClick={() => deleteProfile(profile.id)}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}

          {unenrolledMembers.length > 0 && (
            <div className="space-y-2">
              <p className="text-sm font-medium text-muted-foreground">Unenrolled Members</p>
              {unenrolledMembers.map(member => (
                <div key={member.id} className="flex items-center justify-between p-3 border rounded-lg bg-muted/50">
                  <div className="flex items-center gap-3">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={member.photo_url} />
                      <AvatarFallback>{member.name[0]}</AvatarFallback>
                    </Avatar>
                    <span className="text-sm">{member.name}</span>
                  </div>
                  <Button
                    size="sm"
                    onClick={() => setSelectedMember({ id: member.id, name: member.name })}
                  >
                    <Mic className="h-4 w-4 mr-1" />
                    Enroll Voice
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {selectedMember && (
        <VoiceEnrollmentDialog
          open={!!selectedMember}
          onOpenChange={(open) => !open && setSelectedMember(null)}
          familyMemberId={selectedMember.id}
          memberName={selectedMember.name}
        />
      )}
    </div>
  );
}
