import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Calendar, User, MapPin, Sparkles } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase-client';

interface Album {
  id: string;
  name: string;
  album_type: string;
  photo_count: number;
  cover_photo_id?: string;
}

export function SmartAlbumsManager({ familyId }: { familyId: string }) {
  const [albums, setAlbums] = useState<Album[]>([]);
  const [showCreate, setShowCreate] = useState(false);
  const [albumName, setAlbumName] = useState('');
  const [albumType, setAlbumType] = useState<string>('manual');
  const { toast } = useToast();

  const createAlbum = async () => {
    try {
      const { data, error } = await supabase
        .from('photo_albums')
        .insert({ family_id: familyId, name: albumName, album_type: albumType })
        .select()
        .single();
      
      if (error) throw error;
      setAlbums([...albums, { ...data, photo_count: 0 }]);
      setShowCreate(false);
      setAlbumName('');
      toast({ title: 'Success', description: 'Album created' });
    } catch (error: any) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    }
  };

  const albumTypes = [
    { value: 'manual', label: 'Manual Album', icon: Plus },
    { value: 'smart', label: 'Smart Album', icon: Sparkles },
    { value: 'date', label: 'By Date', icon: Calendar },
    { value: 'person', label: 'By Person', icon: User },
    { value: 'event', label: 'By Event', icon: MapPin }
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Albums</h3>
        <Button onClick={() => setShowCreate(true)} size="sm">
          <Plus className="h-4 w-4 mr-2" />
          New Album
        </Button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {albums.map((album) => (
          <Card key={album.id} className="p-4 cursor-pointer hover:shadow-lg transition-shadow">
            <div className="aspect-square bg-gray-100 rounded-lg mb-2" />
            <h4 className="font-medium">{album.name}</h4>
            <p className="text-sm text-gray-500">{album.photo_count} photos</p>
          </Card>
        ))}
      </div>

      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create Album</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Input
              placeholder="Album name"
              value={albumName}
              onChange={(e) => setAlbumName(e.target.value)}
            />
            <Select value={albumType} onValueChange={setAlbumType}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {albumTypes.map((type) => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button onClick={createAlbum} className="w-full">Create</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
