import { useState, useEffect } from 'react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CloudOff, Wifi } from 'lucide-react';

export function OfflineIndicator() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [showNotification, setShowNotification] = useState(false);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      setShowNotification(true);
      setTimeout(() => setShowNotification(false), 3000);
    };

    const handleOffline = () => {
      setIsOnline(false);
      setShowNotification(true);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  if (!showNotification && isOnline) return null;

  return (
    <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 w-full max-w-md px-4">
      <Alert variant={isOnline ? 'default' : 'destructive'} className="shadow-lg">
        {isOnline ? (
          <Wifi className="h-4 w-4" />
        ) : (
          <CloudOff className="h-4 w-4" />
        )}
        <AlertDescription>
          {isOnline 
            ? 'Back online! Syncing your data...' 
            : 'You are offline. Changes will be saved locally and synced when online.'}
        </AlertDescription>
      </Alert>
    </div>
  );
}
