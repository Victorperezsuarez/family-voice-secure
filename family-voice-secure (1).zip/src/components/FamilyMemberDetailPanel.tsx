import { FamilyMember } from '@/types/familyTree';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Mic, Calendar, Users, Plus } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';

interface FamilyMemberDetailPanelProps {
  member: FamilyMember;
  recordings: any[];
  onAddRelationship: () => void;
  onPlayRecording: (recordingId: string) => void;
}

export function FamilyMemberDetailPanel({
  member,
  recordings,
  onAddRelationship,
  onPlayRecording
}: FamilyMemberDetailPanelProps) {
  return (
    <Card className="h-full">
      <CardHeader>
        <div className="flex items-center gap-4">
          <Avatar className="h-20 w-20">
            <AvatarImage src={member.photoUrl} alt={member.name} />
            <AvatarFallback>{member.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <CardTitle>{member.name}</CardTitle>
            {member.birthDate && (
              <p className="text-sm text-muted-foreground flex items-center gap-1 mt-1">
                <Calendar className="h-3 w-3" />
                {new Date(member.birthDate).toLocaleDateString()}
                {member.deathDate && ` - ${new Date(member.deathDate).toLocaleDateString()}`}
              </p>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {member.bio && (
          <div>
            <h4 className="text-sm font-medium mb-2">Biography</h4>
            <p className="text-sm text-muted-foreground">{member.bio}</p>
          </div>
        )}
        
        <div>
          <div className="flex items-center justify-between mb-2">
            <h4 className="text-sm font-medium flex items-center gap-2">
              <Users className="h-4 w-4" />
              Relationships ({member.relationships.length})
            </h4>
            <Button size="sm" variant="outline" onClick={onAddRelationship}>
              <Plus className="h-3 w-3 mr-1" />
              Add
            </Button>
          </div>
          <div className="flex flex-wrap gap-2">
            {member.relationships.map(rel => (
              <Badge key={rel.id} variant="secondary">{rel.type}</Badge>
            ))}
          </div>
        </div>

        <div>
          <h4 className="text-sm font-medium flex items-center gap-2 mb-2">
            <Mic className="h-4 w-4" />
            Recordings ({recordings.length})
          </h4>
          <ScrollArea className="h-64">
            <div className="space-y-2">
              {recordings.map(recording => (
                <Card key={recording.id} className="p-3 cursor-pointer hover:bg-accent"
                  onClick={() => onPlayRecording(recording.id)}>
                  <p className="text-sm font-medium">{recording.title}</p>
                  <p className="text-xs text-muted-foreground">{recording.date}</p>
                </Card>
              ))}
            </div>
          </ScrollArea>
        </div>
      </CardContent>
    </Card>
  );
}
