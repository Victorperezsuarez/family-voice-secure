import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Pencil, Merge, Split, Check, X } from 'lucide-react';

interface SpeakerSegment {
  id: string;
  speaker_label: string;
  speaker_id?: string;
  start_time: number;
  end_time: number;
  confidence_score: number;
  text_content?: string;
  identified_member_id?: string;
  identified_member_name?: string;
  identification_confidence?: number;
  identification_status?: string;
  emotion?: string;
  emotion_confidence?: number;
  emotion_intensity?: number;
}



interface Props {
  segments: SpeakerSegment[];
  duration: number;
  onUpdateSegment: (id: string, updates: Partial<SpeakerSegment>) => void;
  onMergeSegments: (ids: string[]) => void;
  onSplitSegment: (id: string, splitTime: number) => void;
}

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

export default function SpeakerDiarizationTimeline({ segments, duration, onUpdateSegment, onMergeSegments, onSplitSegment }: Props) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editLabel, setEditLabel] = useState('');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  const getSpeakerColor = (label: string) => {
    const index = segments.findIndex(s => s.speaker_label === label);
    return COLORS[index % COLORS.length];
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleEdit = (segment: SpeakerSegment) => {
    setEditingId(segment.id);
    setEditLabel(segment.speaker_label);
  };

  const handleSave = (id: string) => {
    onUpdateSegment(id, { speaker_label: editLabel });
    setEditingId(null);
  };

  const toggleSelect = (id: string) => {
    setSelectedIds(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Speaker Timeline</h3>
        {selectedIds.length > 1 && (
          <Button size="sm" onClick={() => { onMergeSegments(selectedIds); setSelectedIds([]); }}>
            <Merge className="w-4 h-4 mr-2" />
            Merge {selectedIds.length} Segments
          </Button>
        )}
      </div>

      <div className="relative h-16 bg-gray-100 rounded-lg overflow-hidden">
        {segments.map(segment => {
          const left = (segment.start_time / duration) * 100;
          const width = ((segment.end_time - segment.start_time) / duration) * 100;
          return (
            <div
              key={segment.id}
              className={`absolute h-full cursor-pointer transition-opacity ${
                selectedIds.includes(segment.id) ? 'ring-2 ring-black' : ''
              }`}
              style={{
                left: `${left}%`,
                width: `${width}%`,
                backgroundColor: getSpeakerColor(segment.speaker_label),
                opacity: 0.8
              }}
              onClick={() => toggleSelect(segment.id)}
              title={`${segment.speaker_label}: ${formatTime(segment.start_time)} - ${formatTime(segment.end_time)}`}
            />
          );
        })}
      </div>

      <div className="space-y-2">
        {segments.map(segment => (
          <Card key={segment.id} className="p-3">
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: getSpeakerColor(segment.speaker_label) }}
                  />
                  {editingId === segment.id ? (
                    <div className="flex items-center gap-2">
                      <Input
                        value={editLabel}
                        onChange={(e) => setEditLabel(e.target.value)}
                        className="h-7 w-32"
                      />
                      <Button size="sm" variant="ghost" onClick={() => handleSave(segment.id)}>
                        <Check className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => setEditingId(null)}>
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  ) : (
                    <>
                      <span className="font-medium">
                        {segment.identification_status === 'confirmed' && segment.identified_member_name 
                          ? segment.identified_member_name 
                          : segment.speaker_label}
                      </span>
                      <Button size="sm" variant="ghost" onClick={() => handleEdit(segment)}>
                        <Pencil className="w-3 h-3" />
                      </Button>
                    </>
                  )}
                  <Badge variant="secondary" className="text-xs">
                    {Math.round(segment.confidence_score * 100)}% confident
                  </Badge>
                  {segment.identified_member_name && segment.identification_status === 'confirmed' && (
                    <Badge variant="default" className="text-xs bg-green-600">
                      Voice ID: {segment.identification_confidence}%
                    </Badge>
                  )}
                  {segment.emotion && (
                    <Badge variant="outline" className="text-xs capitalize">
                      {segment.emotion} ({Math.round((segment.emotion_confidence || 0) * 100)}%)
                    </Badge>
                  )}

                </div>
                <div className="text-sm text-gray-600 mb-1">
                  {formatTime(segment.start_time)} - {formatTime(segment.end_time)}
                </div>
                {segment.text_content && (
                  <p className="text-sm">{segment.text_content}</p>
                )}
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
