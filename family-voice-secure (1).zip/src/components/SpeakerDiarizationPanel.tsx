import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Users, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';
import SpeakerDiarizationTimeline from './SpeakerDiarizationTimeline';
import SpeakerAttributedTranscript from './SpeakerAttributedTranscript';
import { AutoIdentificationReviewPanel } from './AutoIdentificationReviewPanel';
import { EmotionalJourneyVisualization } from './EmotionalJourneyVisualization';
import { TranslationLanguageSelector } from './TranslationLanguageSelector';
import { BilingualTranscriptView } from './BilingualTranscriptView';


interface SpeakerSegment {
  id: string;
  speaker_label: string;
  speaker_id?: string;
  start_time: number;
  end_time: number;
  confidence_score: number;
  text_content?: string;
  voice_characteristics?: any;
  identified_member_id?: string;
  identified_member_name?: string;
  identification_confidence?: number;
  identification_status?: string;
  emotion?: string;
  emotion_confidence?: number;
  emotion_intensity?: number;
  translations?: Record<string, { text: string; emotion?: string }>;
  original_language?: string;
}




interface Props {
  recordingId: string;
  audioUrl: string;
  transcription?: string;
  duration: number;
  onSeek?: (time: number) => void;
}

export default function SpeakerDiarizationPanel({ recordingId, audioUrl, transcription, duration, onSeek }: Props) {
  const [segments, setSegments] = useState<SpeakerSegment[]>([]);
  const [loading, setLoading] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [currentLanguage, setCurrentLanguage] = useState('en');
  const [isTranslating, setIsTranslating] = useState(false);
  const [bilingualMode, setBilingualMode] = useState(false);
  const [targetLanguage, setTargetLanguage] = useState<string>('');
  const [memberNames, setMemberNames] = useState<Record<string, string>>({});


  useEffect(() => {
    loadSegments();
  }, [recordingId]);

  const loadSegments = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('speaker_segments')
        .select('*')
        .eq('recording_id', recordingId)
        .order('start_time');

      if (error) throw error;
      setSegments(data || []);
    } catch (error: any) {
      console.error('Error loading segments:', error);
    } finally {
      setLoading(false);
    }
  };

  const analyzeSpeakers = async () => {
    setAnalyzing(true);
    try {
      // Get current family ID
      const { data: userData } = await supabase.auth.getUser();
      const { data: profileData } = await supabase
        .from('profiles')
        .select('current_family_id')
        .eq('id', userData?.user?.id)
        .single();

      const { data, error } = await supabase.functions.invoke('diarize-speakers', {
        body: { 
          recordingId, 
          audioUrl, 
          transcription,
          familyId: profileData?.current_family_id 
        }
      });

      if (error) throw error;

      if (data.success && data.segments) {
        // Save segments to database with voice identification data
        const segmentsToInsert = data.segments.map((seg: any) => ({
          recording_id: recordingId,
          speaker_label: seg.speaker_label,
          start_time: seg.start_time,
          end_time: seg.end_time,
          confidence_score: seg.confidence_score,
          text_content: seg.text_content,
          voice_characteristics: seg.voice_characteristics,
          identified_member_id: seg.identified_member_id || null,
          identification_confidence: seg.identification_confidence || null,
          identification_status: seg.identified_member_id ? 'pending' : null,
          emotion: seg.emotion || null,
          emotion_confidence: seg.emotion_confidence || null,
          emotion_intensity: seg.emotion_intensity || null,
          emotions_detected: seg.emotions_detected || null
        }));


        const { error: insertError } = await supabase
          .from('speaker_segments')
          .insert(segmentsToInsert);

        if (insertError) throw insertError;

        const identifiedCount = segmentsToInsert.filter(s => s.identified_member_id).length;
        if (identifiedCount > 0) {
          toast.success(`Speaker diarization complete! ${identifiedCount} speaker(s) automatically identified.`);
        } else {
          toast.success('Speaker diarization complete!');
        }
        
        loadSegments();
      }
    } catch (error: any) {
      console.error('Error analyzing speakers:', error);
      toast.error('Failed to analyze speakers');
    } finally {
      setAnalyzing(false);
    }
  };


  const handleUpdateSegment = async (id: string, updates: Partial<SpeakerSegment>) => {
    try {
      const { error } = await supabase
        .from('speaker_segments')
        .update(updates)
        .eq('id', id);

      if (error) throw error;

      setSegments(prev => prev.map(s => s.id === id ? { ...s, ...updates } : s));
      toast.success('Segment updated');
    } catch (error: any) {
      toast.error('Failed to update segment');
    }
  };

  const handleMergeSegments = async (ids: string[]) => {
    try {
      const toMerge = segments.filter(s => ids.includes(s.id)).sort((a, b) => a.start_time - b.start_time);
      const merged = {
        recording_id: recordingId,
        speaker_label: toMerge[0].speaker_label,
        start_time: toMerge[0].start_time,
        end_time: toMerge[toMerge.length - 1].end_time,
        confidence_score: toMerge.reduce((sum, s) => sum + s.confidence_score, 0) / toMerge.length,
        text_content: toMerge.map(s => s.text_content).join(' ')
      };

      const { error: deleteError } = await supabase.from('speaker_segments').delete().in('id', ids);
      if (deleteError) throw deleteError;

      const { error: insertError } = await supabase.from('speaker_segments').insert(merged);
      if (insertError) throw insertError;

      toast.success('Segments merged');
      loadSegments();
    } catch (error: any) {
      toast.error('Failed to merge segments');
    }
  };

  const handleSplitSegment = async (id: string, splitTime: number) => {
    toast.info('Split functionality coming soon');
  };

  const handleTranslate = async (targetLang: string, withVoiceCloning: boolean = true) => {
    setIsTranslating(true);
    setTargetLanguage(targetLang);
    try {
      let translatedCount = 0;
      for (const segment of segments) {
        if (segment.text_content && !segment.translations?.[targetLang]) {
          const { data, error } = await supabase.functions.invoke('translate-segment', {
            body: {
              segmentId: segment.id,
              text: segment.text_content,
              targetLanguage: targetLang,
              sourceLanguage: currentLanguage,
              emotion: segment.emotion,
              preserveEmotion: true
            }
          });

          if (!error && data) {
            translatedCount++;
            
            // Generate voice-cloned audio if enabled
            if (withVoiceCloning) {
              await supabase.functions.invoke('clone-voice-translation', {
                body: {
                  segmentId: segment.id,
                  translatedText: data.translatedText,
                  targetLanguage: targetLang,
                  voiceCharacteristics: segment.voice_characteristics || {},
                  originalAudioUrl: audioUrl
                }
              });
            }
          }
        }
      }
      
      toast.success(`Translated ${translatedCount} segments to ${targetLang}${withVoiceCloning ? ' with voice cloning' : ''}`);
      loadSegments();
    } catch (error: any) {
      console.error('Translation error:', error);
      toast.error('Failed to translate segments');
    } finally {
      setIsTranslating(false);
    }
  };


  const getAvailableTranslations = () => {
    const translations = new Set<string>();
    segments.forEach(seg => {
      if (seg.translations) {
        Object.keys(seg.translations).forEach(lang => translations.add(lang));
      }
    });
    return Array.from(translations);
  };


  if (loading) {
    return <div className="flex items-center justify-center p-8"><Loader2 className="w-6 h-6 animate-spin" /></div>;
  }

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Users className="w-5 h-5" />
          <h2 className="text-xl font-semibold">Speaker Diarization</h2>
        </div>
        {segments.length === 0 && (
          <Button onClick={analyzeSpeakers} disabled={analyzing}>
            {analyzing ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
            Analyze Speakers
          </Button>
        )}
      </div>

      {segments.length > 0 ? (
        <div className="space-y-4">
          <AutoIdentificationReviewPanel 
            segments={segments} 
            onReviewComplete={loadSegments} 
          />

          <Card className="p-4 bg-muted/50">
            <TranslationLanguageSelector
              currentLanguage={currentLanguage}
              onLanguageChange={setCurrentLanguage}
              onTranslate={handleTranslate}
              isTranslating={isTranslating}
              availableTranslations={getAvailableTranslations()}
              showBilingualToggle={targetLanguage !== ''}
              bilingualMode={bilingualMode}
              onBilingualToggle={setBilingualMode}
            />
          </Card>
          
          <Tabs defaultValue="timeline">
            <TabsList>
              <TabsTrigger value="timeline">Timeline</TabsTrigger>
              <TabsTrigger value="transcript">Transcript</TabsTrigger>
              <TabsTrigger value="emotions">Emotional Journey</TabsTrigger>
              {bilingualMode && targetLanguage && (
                <TabsTrigger value="bilingual">Bilingual View</TabsTrigger>
              )}
            </TabsList>
            <TabsContent value="timeline" className="mt-4">
              <SpeakerDiarizationTimeline
                segments={segments}
                duration={duration}
                onUpdateSegment={handleUpdateSegment}
                onMergeSegments={handleMergeSegments}
                onSplitSegment={handleSplitSegment}
              />
            </TabsContent>
            <TabsContent value="transcript" className="mt-4">
              <SpeakerAttributedTranscript segments={segments} onSeek={onSeek} />
            </TabsContent>
            <TabsContent value="emotions" className="mt-4">
              <EmotionalJourneyVisualization segments={segments} />
            </TabsContent>
            {bilingualMode && targetLanguage && (
              <TabsContent value="bilingual" className="mt-4">
                <BilingualTranscriptView
                  segments={segments}
                  originalLanguage={currentLanguage}
                  targetLanguage={targetLanguage}
                  memberNames={memberNames}
                  recordingUrl={audioUrl}
                />
              </TabsContent>
            )}

          </Tabs>
        </div>


      ) : (
        <div className="text-center py-8 text-gray-500">
          Click "Analyze Speakers" to detect and separate speakers in this recording
        </div>
      )}
    </Card>
  );
}
