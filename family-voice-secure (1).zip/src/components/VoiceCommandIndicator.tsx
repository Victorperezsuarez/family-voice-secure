import { Mic } from 'lucide-react';

interface VoiceCommandIndicatorProps {
  isListening: boolean;
  lastCommand?: string;
}

export function VoiceCommandIndicator({ isListening, lastCommand }: VoiceCommandIndicatorProps) {
  if (!isListening && !lastCommand) return null;

  return (
    <div className="fixed top-4 right-4 z-50 bg-amber-600 text-white px-6 py-3 rounded-full shadow-lg flex items-center gap-3 animate-in fade-in slide-in-from-top">
      <Mic className={`w-5 h-5 ${isListening ? 'animate-pulse' : ''}`} />
      <span className="font-medium">
        {isListening ? 'Escuchando comando...' : lastCommand ? `Comando: ${lastCommand}` : ''}
      </span>
    </div>
  );
}
