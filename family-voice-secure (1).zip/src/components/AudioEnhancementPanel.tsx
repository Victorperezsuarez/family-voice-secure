import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Play, Pause, Wand2, Download, RotateCcw, Sparkles } from 'lucide-react';
import AudioEnhancementSettings from './AudioEnhancementSettings';
import QualityMetricsDisplay from './QualityMetricsDisplay';
import { EnhancementRecommendationCard } from './EnhancementRecommendationCard';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';

interface AudioEnhancementPanelProps {
  recordingId: string;
  audioUrl: string;
  onEnhanced?: (enhancedUrl: string) => void;
}

export default function AudioEnhancementPanel({ 
  recordingId, 
  audioUrl,
  onEnhanced 
}: AudioEnhancementPanelProps) {
  const [settings, setSettings] = useState({
    intensity: 'medium' as 'light' | 'medium' | 'aggressive',
    noise_reduction: true,
    volume_normalization: true,
    echo_reduction: true,
    clarity_enhancement: true,
    voice_separation: true
  });
  
  const [enhancing, setEnhancing] = useState(false);
  const [enhanced, setEnhanced] = useState(false);
  const [enhancedUrl, setEnhancedUrl] = useState<string | null>(null);
  const [metrics, setMetrics] = useState<any>(null);
  const [playingOriginal, setPlayingOriginal] = useState(false);
  const [playingEnhanced, setPlayingEnhanced] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [recommendation, setRecommendation] = useState<any>(null);
  const [analysis, setAnalysis] = useState<any>(null);
  const [showRecommendation, setShowRecommendation] = useState(true);

  useEffect(() => {
    analyzeRecording();
  }, [recordingId]);

  const analyzeRecording = async () => {
    setAnalyzing(true);
    try {
      const { data: user } = await supabase.auth.getUser();
      const { data, error } = await supabase.functions.invoke('analyze-recording-conditions', {
        body: { recordingId, audioUrl, userId: user.user?.id }
      });

      if (error) throw error;

      setAnalysis(data.analysis);
      setRecommendation(data.recommendation);
    } catch (error: any) {
      console.error('Analysis failed:', error);
    } finally {
      setAnalyzing(false);
    }
  };

  const handleAcceptRecommendation = async () => {
    const recommendedSettings = {
      intensity: recommendation.intensity,
      noise_reduction: recommendation.features.noise_reduction?.enabled || false,
      volume_normalization: recommendation.features.volume_normalization?.enabled || false,
      echo_reduction: recommendation.features.echo_reduction?.enabled || false,
      clarity_enhancement: recommendation.features.clarity_enhancement?.enabled || false,
      voice_separation: recommendation.features.voice_separation?.enabled || false
    };
    
    setSettings(recommendedSettings);
    setShowRecommendation(false);
    
    await supabase.from('recordings').update({
      enhancement_recommendation: recommendation,
      recommendation_accepted: true,
      ai_analysis: analysis
    }).eq('id', recordingId);

    await saveUserPreference(analysis, recommendedSettings);
    toast.success('Recommendation applied!');
  };

  const handleModifyRecommendation = () => {
    const recommendedSettings = {
      intensity: recommendation.intensity,
      noise_reduction: recommendation.features.noise_reduction?.enabled || false,
      volume_normalization: recommendation.features.volume_normalization?.enabled || false,
      echo_reduction: recommendation.features.echo_reduction?.enabled || false,
      clarity_enhancement: recommendation.features.clarity_enhancement?.enabled || false,
      voice_separation: recommendation.features.voice_separation?.enabled || false
    };
    
    setSettings(recommendedSettings);
    setShowRecommendation(false);
  };

  const handleRejectRecommendation = async () => {
    setShowRecommendation(false);
    await supabase.from('recordings').update({
      recommendation_accepted: false
    }).eq('id', recordingId);
    toast.info('Using manual settings');
  };

  const saveUserPreference = async (conditions: any, preferredSettings: any) => {
    try {
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) return;

      const { data: existing } = await supabase
        .from('user_enhancement_preferences')
        .select('*')
        .eq('user_id', user.user.id)
        .eq('recording_conditions->>environment', conditions.environment)
        .eq('recording_conditions->>noise_level', conditions.noise_level)
        .single();

      if (existing) {
        await supabase
          .from('user_enhancement_preferences')
          .update({
            preferred_settings: preferredSettings,
            times_applied: existing.times_applied + 1,
            last_used_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          })
          .eq('id', existing.id);
      } else {
        await supabase.from('user_enhancement_preferences').insert({
          user_id: user.user.id,
          recording_conditions: conditions,
          preferred_settings: preferredSettings
        });
      }
    } catch (error) {
      console.error('Failed to save preference:', error);
    }
  };


  const handleEnhance = async () => {
    setEnhancing(true);
    try {
      // Save user-modified settings if they differ from recommendation
      if (recommendation && !showRecommendation) {
        const isModified = JSON.stringify(settings) !== JSON.stringify({
          intensity: recommendation.intensity,
          noise_reduction: recommendation.features.noise_reduction?.enabled || false,
          volume_normalization: recommendation.features.volume_normalization?.enabled || false,
          echo_reduction: recommendation.features.echo_reduction?.enabled || false,
          clarity_enhancement: recommendation.features.clarity_enhancement?.enabled || false,
          voice_separation: recommendation.features.voice_separation?.enabled || false
        });

        if (isModified) {
          await supabase.from('recordings').update({
            user_modified_settings: settings
          }).eq('id', recordingId);
          await saveUserPreference(analysis, settings);
        }
      }

      const { data, error } = await supabase.functions.invoke('enhance-audio', {
        body: { audioUrl, settings, recordingId }
      });

      if (error) throw error;

      setEnhancedUrl(data.enhanced_audio_url);
      setMetrics(data.quality_metrics);
      setEnhanced(true);
      
      await supabase.from('recordings').update({
        enhanced_audio_url: data.enhanced_audio_url,
        enhancement_applied: true,
        enhancement_settings: settings,
        quality_metrics: data.quality_metrics,
        enhancement_date: new Date().toISOString()
      }).eq('id', recordingId);

      toast.success('Audio enhanced successfully!');
      onEnhanced?.(data.enhanced_audio_url);
    } catch (error: any) {
      toast.error('Enhancement failed: ' + error.message);
    } finally {
      setEnhancing(false);
    }
  };


  const handleRevert = async () => {
    try {
      await supabase.from('recordings').update({
        enhanced_audio_url: null,
        enhancement_applied: false
      }).eq('id', recordingId);
      
      setEnhanced(false);
      setEnhancedUrl(null);
      setMetrics(null);
      toast.success('Reverted to original audio');
    } catch (error: any) {
      toast.error('Revert failed: ' + error.message);
    }
  };

  return (
    <div className="space-y-4">
      {analyzing && (
        <Card className="p-6 text-center">
          <Sparkles className="h-8 w-8 mx-auto mb-2 animate-pulse text-primary" />
          <p className="text-sm text-muted-foreground">Analyzing recording conditions...</p>
        </Card>
      )}

      {!analyzing && recommendation && analysis && showRecommendation && (
        <EnhancementRecommendationCard
          analysis={analysis}
          recommendation={recommendation}
          onAccept={handleAcceptRecommendation}
          onModify={handleModifyRecommendation}
          onReject={handleRejectRecommendation}
          isLoading={enhancing}
        />
      )}

      <Card className="p-6">
        <h2 className="text-xl font-semibold mb-4">Audio Enhancement</h2>

        
        <Tabs defaultValue="settings" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="settings">Settings</TabsTrigger>
            <TabsTrigger value="preview">Preview</TabsTrigger>
            <TabsTrigger value="metrics" disabled={!metrics}>Metrics</TabsTrigger>
          </TabsList>

          <TabsContent value="settings" className="space-y-4">
            <AudioEnhancementSettings settings={settings} onChange={setSettings} />
            
            <div className="flex gap-2">
              <Button onClick={handleEnhance} disabled={enhancing} className="flex-1">
                <Wand2 className="w-4 h-4 mr-2" />
                {enhancing ? 'Enhancing...' : 'Enhance Audio'}
              </Button>
              {enhanced && (
                <Button onClick={handleRevert} variant="outline">
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Revert
                </Button>
              )}
            </div>
          </TabsContent>

          <TabsContent value="preview" className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <Card className="p-4">
                <h3 className="font-medium mb-3">Original Audio</h3>
                <audio src={audioUrl} controls className="w-full mb-2" />
                <Button variant="outline" size="sm" className="w-full">
                  <Download className="w-4 h-4 mr-2" />
                  Download Original
                </Button>
              </Card>

              <Card className="p-4">
                <h3 className="font-medium mb-3">Enhanced Audio</h3>
                {enhancedUrl ? (
                  <>
                    <audio src={enhancedUrl} controls className="w-full mb-2" />
                    <Button variant="outline" size="sm" className="w-full">
                      <Download className="w-4 h-4 mr-2" />
                      Download Enhanced
                    </Button>
                  </>
                ) : (
                  <p className="text-sm text-muted-foreground">
                    No enhanced audio yet. Apply enhancement first.
                  </p>
                )}
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="metrics">
            {metrics && <QualityMetricsDisplay metrics={metrics} />}
          </TabsContent>
        </Tabs>
      </Card>
    </div>
  );
}
