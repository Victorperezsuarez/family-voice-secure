import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Check } from 'lucide-react';
import type { TemplatePricing } from '@/types/monetization';

interface PricingCardProps {
  pricing: TemplatePricing;
  onPurchase: (pricingId: string) => void;
  isPurchased?: boolean;
}

export function PricingCard({ pricing, onPurchase, isPurchased }: PricingCardProps) {
  const features = {
    personal: ['Personal projects', 'Single user', 'No commercial use'],
    commercial: ['Commercial projects', 'Up to 5 users', 'Client work allowed'],
    enterprise: ['Unlimited projects', 'Unlimited users', 'Priority support', 'Custom modifications']
  };

  return (
    <Card className={isPurchased ? 'border-green-500' : ''}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="capitalize">{pricing.license_type}</CardTitle>
          {isPurchased && <Badge variant="success">Owned</Badge>}
        </div>
        <CardDescription>
          {pricing.pricing_type === 'free' ? 'Free' : `$${pricing.price}`}
          {pricing.pricing_type === 'subscription' && '/month'}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ul className="space-y-2">
          {features[pricing.license_type]?.map((feature, idx) => (
            <li key={idx} className="flex items-center gap-2">
              <Check className="h-4 w-4 text-green-500" />
              <span className="text-sm">{feature}</span>
            </li>
          ))}
        </ul>
      </CardContent>
      <CardFooter>
        <Button 
          onClick={() => onPurchase(pricing.id)}
          disabled={isPurchased || pricing.pricing_type === 'free'}
          className="w-full"
        >
          {isPurchased ? 'Purchased' : pricing.pricing_type === 'free' ? 'Use Free' : 'Purchase'}
        </Button>
      </CardFooter>
    </Card>
  );
}
