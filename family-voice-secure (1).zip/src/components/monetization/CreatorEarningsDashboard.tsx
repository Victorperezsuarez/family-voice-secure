import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/supabase-client';
import { DollarSign, TrendingUp, Download, Calendar } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import type { CreatorEarnings, CreatorPayout } from '@/types/monetization';

export function CreatorEarningsDashboard() {
  const { user } = useAuth();
  const [earnings, setEarnings] = useState<CreatorEarnings[]>([]);
  const [payouts, setPayouts] = useState<CreatorPayout[]>([]);
  const [stats, setStats] = useState({ total: 0, available: 0, paid: 0 });

  useEffect(() => {
    if (user) {
      loadEarnings();
      loadPayouts();
    }
  }, [user]);

  const loadEarnings = async () => {
    const { data } = await supabase
      .from('creator_earnings')
      .select('*')
      .eq('creator_user_id', user?.id)
      .order('earned_at', { ascending: false });

    if (data) {
      setEarnings(data);
      const total = data.reduce((sum, e) => sum + e.net_amount, 0);
      const available = data.filter(e => e.status === 'available').reduce((sum, e) => sum + e.net_amount, 0);
      const paid = data.filter(e => e.status === 'paid').reduce((sum, e) => sum + e.net_amount, 0);
      setStats({ total, available, paid });
    }
  };

  const loadPayouts = async () => {
    const { data } = await supabase
      .from('creator_payouts')
      .select('*')
      .eq('creator_user_id', user?.id)
      .order('created_at', { ascending: false });

    if (data) setPayouts(data);
  };

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Earnings</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${stats.total.toFixed(2)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Available</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${stats.available.toFixed(2)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Paid Out</CardTitle>
            <Download className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${stats.paid.toFixed(2)}</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="earnings">
        <TabsList>
          <TabsTrigger value="earnings">Earnings</TabsTrigger>
          <TabsTrigger value="payouts">Payouts</TabsTrigger>
        </TabsList>
        <TabsContent value="earnings" className="space-y-4">
          {earnings.map(earning => (
            <Card key={earning.id}>
              <CardContent className="pt-6">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="font-medium">${earning.net_amount.toFixed(2)}</p>
                    <p className="text-sm text-muted-foreground">
                      {new Date(earning.earned_at).toLocaleDateString()}
                    </p>
                  </div>
                  <span className={`px-2 py-1 rounded text-xs ${
                    earning.status === 'paid' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                  }`}>
                    {earning.status}
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
        <TabsContent value="payouts">
          {payouts.map(payout => (
            <Card key={payout.id}>
              <CardContent className="pt-6">
                <div className="flex justify-between">
                  <div>
                    <p className="font-medium">${payout.amount.toFixed(2)}</p>
                    <p className="text-sm text-muted-foreground">{payout.earnings_count} earnings</p>
                  </div>
                  <span className={`px-2 py-1 rounded text-xs ${
                    payout.status === 'paid' ? 'bg-green-100' : 'bg-gray-100'
                  }`}>
                    {payout.status}
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  );
}
