import { useState, useRef, useEffect } from 'react';
import { Mic, Video, Camera, StopCircle, Play, Pause, Check, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { saveOfflineRecording, isOnline } from '@/utils/pwaUtils';

// Haptic feedback simulation
const hapticFeedback = (type: 'light' | 'medium' | 'heavy' = 'medium') => {
  if ('vibrate' in navigator) {
    const patterns = { light: 10, medium: 20, heavy: 30 };
    navigator.vibrate(patterns[type]);
  }
};

export function MobileRecordingInterface() {
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [mode, setMode] = useState<'audio' | 'video'>('audio');
  const [mediaUrl, setMediaUrl] = useState<string | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  const startRecording = async () => {
    hapticFeedback('heavy');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: true,
        video: mode === 'video' ? { facingMode: 'user' } : false
      });

      if (videoRef.current && mode === 'video') {
        videoRef.current.srcObject = stream;
      }

      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { 
          type: mode === 'audio' ? 'audio/webm' : 'video/webm' 
        });
        const url = URL.createObjectURL(blob);
        setMediaUrl(url);
        stream.getTracks().forEach(track => track.stop());
        hapticFeedback('medium');
      };

      mediaRecorder.start();
      setIsRecording(true);
      timerRef.current = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
    } catch (error) {
      console.error('Failed to start recording:', error);
      hapticFeedback('heavy');
    }
  };

  const stopRecording = () => {
    hapticFeedback('medium');
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      setIsPaused(false);
      if (timerRef.current) clearInterval(timerRef.current);
    }
  };

  const saveRecording = () => {
    hapticFeedback('light');
    if (mediaUrl) {
      const recording = {
        url: mediaUrl,
        type: mode,
        duration: recordingTime,
        createdAt: new Date().toISOString()
      };
      
      if (isOnline()) {
        // Save to server
      } else {
        saveOfflineRecording(recording);
      }
      
      resetRecording();
    }
  };

  const resetRecording = () => {
    setMediaUrl(null);
    setRecordingTime(0);
    setIsRecording(false);
    setIsPaused(false);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };


  return (
    <Card className="p-6 max-w-md mx-auto">
      <div className="space-y-6">
        <div className="flex gap-2 justify-center">
          <Button
            variant={mode === 'audio' ? 'default' : 'outline'}
            onClick={() => setMode('audio')}
            disabled={isRecording}
          >
            <Mic className="w-4 h-4 mr-2" />
            Audio
          </Button>
          <Button
            variant={mode === 'video' ? 'default' : 'outline'}
            onClick={() => setMode('video')}
            disabled={isRecording}
          >
            <Video className="w-4 h-4 mr-2" />
            Video
          </Button>
        </div>

        {mode === 'video' && (
          <video
            ref={videoRef}
            autoPlay
            muted
            playsInline
            className="w-full rounded-lg bg-black"
          />
        )}

        <div className="text-center">
          <div className="text-4xl font-mono font-bold mb-4">
            {formatTime(recordingTime)}
          </div>
          
          {!isRecording && !mediaUrl && (
            <Button
              size="lg"
              className="w-32 h-32 rounded-full"
              onClick={startRecording}
            >
              <Mic className="w-12 h-12" />
            </Button>
          )}

          {isRecording && (
            <Button
              size="lg"
              variant="destructive"
              className="w-32 h-32 rounded-full"
              onClick={stopRecording}
            >
              <StopCircle className="w-12 h-12" />
            </Button>
          )}

          {mediaUrl && (
            <div className="flex gap-4 justify-center">
              <Button size="lg" variant="outline" onClick={resetRecording}>
                <X className="w-6 h-6" />
              </Button>
              <Button size="lg" onClick={saveRecording}>
                <Check className="w-6 h-6" />
              </Button>
            </div>
          )}
        </div>
      </div>
    </Card>
  );
}
