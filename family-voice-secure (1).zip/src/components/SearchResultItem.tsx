import { Play, Clock, User } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { SearchResult } from '@/types/search';

interface SearchResultItemProps {
  result: SearchResult;
  onPlayFromTimestamp: (recordingId: string, timestamp: number) => void;
  onViewTranscription: (transcriptionId: string, timestamp: number) => void;
}

export const SearchResultItem = ({
  result,
  onPlayFromTimestamp,
  onViewTranscription,
}: SearchResultItemProps) => {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const highlightMatches = (text: string) => {
    return { __html: text };
  };

  return (
    <Card className="p-4 hover:shadow-md transition-shadow">
      <div className="space-y-3">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1">
            <h3 className="font-semibold text-lg mb-1">{result.title}</h3>
            <div className="flex items-center gap-3 text-sm text-muted-foreground mb-2">
              <div className="flex items-center gap-1">
                <Clock className="h-3 w-3" />
                {formatTime(result.startTime)}
              </div>
              {result.speaker && (
                <div className="flex items-center gap-1">
                  <User className="h-3 w-3" />
                  {result.speaker}
                </div>
              )}
              <Badge variant="outline">
                Match: {Math.round(result.matchScore * 100)}%
              </Badge>
            </div>
          </div>
          <Button
            size="sm"
            onClick={() => onPlayFromTimestamp(result.recordingId, result.startTime)}
          >
            <Play className="h-4 w-4 mr-1" />
            Play
          </Button>
        </div>

        <div
          className="text-sm leading-relaxed bg-muted/50 p-3 rounded-md"
          dangerouslySetInnerHTML={highlightMatches(result.highlightedContent)}
        />

        <Button
          variant="ghost"
          size="sm"
          onClick={() => onViewTranscription(result.transcriptionId, result.startTime)}
          className="w-full"
        >
          View Full Transcription
        </Button>
      </div>
    </Card>
  );
};
