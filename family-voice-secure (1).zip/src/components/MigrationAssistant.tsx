import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, Sparkles, AlertTriangle, CheckCircle2, Clock, Code, ArrowRight } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';

interface MigrationStep {
  step: number;
  title: string;
  description: string;
  code?: string;
}

interface MigrationGuide {
  summary: string;
  breakingChanges: string[];
  steps: MigrationStep[];
  potentialIssues: string[];
  rollbackInstructions: string;
  estimatedTime: string;
}

interface MigrationAssistantProps {
  fromVersion: string;
  toVersion: string;
  templateName: string;
  permissionChanges: any;
}

export function MigrationAssistant({ fromVersion, toVersion, templateName, permissionChanges }: MigrationAssistantProps) {
  const [loading, setLoading] = useState(false);
  const [migrationGuide, setMigrationGuide] = useState<MigrationGuide | null>(null);
  const [error, setError] = useState<string | null>(null);

  const generateMigrationScript = async () => {
    setLoading(true);
    setError(null);

    try {
      const { data, error: invokeError } = await supabase.functions.invoke('generate-migration-script', {
        body: { fromVersion, toVersion, templateName, permissionChanges }
      });

      if (invokeError) throw invokeError;
      if (!data.success) throw new Error(data.error);

      setMigrationGuide(data.migrationGuide);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="border-purple-200 bg-gradient-to-br from-purple-50 to-pink-50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-purple-600" />
          AI Migration Assistant
        </CardTitle>
        <CardDescription>
          Automatically generate migration instructions for upgrading from v{fromVersion} to v{toVersion}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {!migrationGuide && !loading && (
          <Button onClick={generateMigrationScript} className="w-full">
            <Sparkles className="mr-2 h-4 w-4" />
            Generate Migration Guide
          </Button>
        )}

        {loading && (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-purple-600" />
            <span className="ml-3 text-sm text-muted-foreground">AI analyzing changes...</span>
          </div>
        )}

        {error && (
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {migrationGuide && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Badge variant="outline" className="gap-1">
                <Clock className="h-3 w-3" />
                {migrationGuide.estimatedTime}
              </Badge>
              <Button variant="ghost" size="sm" onClick={generateMigrationScript}>
                Regenerate
              </Button>
            </div>

            <Alert>
              <CheckCircle2 className="h-4 w-4" />
              <AlertDescription>{migrationGuide.summary}</AlertDescription>
            </Alert>

            {migrationGuide.breakingChanges.length > 0 && (
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  <strong>Breaking Changes:</strong>
                  <ul className="mt-2 list-disc pl-5 space-y-1">
                    {migrationGuide.breakingChanges.map((change, idx) => (
                      <li key={idx}>{change}</li>
                    ))}
                  </ul>
                </AlertDescription>
              </Alert>
            )}

            <div className="space-y-3">
              <h4 className="font-semibold flex items-center gap-2">
                <ArrowRight className="h-4 w-4" />
                Migration Steps
              </h4>
              {migrationGuide.steps.map((step) => (
                <Card key={step.step}>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Badge variant="secondary">{step.step}</Badge>
                      {step.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <p className="text-sm text-muted-foreground">{step.description}</p>
                    {step.code && (
                      <div className="bg-slate-900 text-slate-50 p-3 rounded-md text-xs font-mono overflow-x-auto">
                        <div className="flex items-center gap-2 mb-2 text-slate-400">
                          <Code className="h-3 w-3" />
                          Code
                        </div>
                        <pre>{step.code}</pre>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>

            {migrationGuide.potentialIssues.length > 0 && (
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  <strong>Potential Issues:</strong>
                  <ul className="mt-2 list-disc pl-5 space-y-1">
                    {migrationGuide.potentialIssues.map((issue, idx) => (
                      <li key={idx}>{issue}</li>
                    ))}
                  </ul>
                </AlertDescription>
              </Alert>
            )}

            <Card className="bg-slate-50">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Rollback Instructions</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">{migrationGuide.rollbackInstructions}</p>
              </CardContent>
            </Card>
          </div>
        )}
      </CardContent>
    </Card>
  );
}