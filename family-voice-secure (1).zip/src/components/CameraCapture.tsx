import { useState, useRef, useEffect } from 'react';
import { Button } from './ui/button';
import { Camera, SwitchCamera, Zap, ZapOff, ZoomIn, ZoomOut, X, Circle, Repeat } from 'lucide-react';
import { Slider } from './ui/slider';

interface CameraCaptureProps {
  onCapture: (imageData: string) => void;
  onClose: () => void;
}

export function CameraCapture({ onCapture, onClose }: CameraCaptureProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [flashEnabled, setFlashEnabled] = useState(false);
  const [zoom, setZoom] = useState(1);
  const [filter, setFilter] = useState('none');
  const [burstMode, setBurstMode] = useState(false);

  useEffect(() => {
    startCamera();
    return () => {
      if (stream) stream.getTracks().forEach(track => track.stop());
    };
  }, [facingMode]);

  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode, width: 1920, height: 1080 },
        audio: false
      });
      setStream(mediaStream);
      if (videoRef.current) videoRef.current.srcObject = mediaStream;
    } catch (err) {
      console.error('Camera access error:', err);
    }
  };

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.filter = getFilterStyle();
        ctx.drawImage(video, 0, 0);
        const imageData = canvas.toDataURL('image/jpeg', 0.9);
        if (burstMode) {
          // Capture 5 photos in burst mode
          for (let i = 0; i < 5; i++) {
            setTimeout(() => {
              ctx.drawImage(video, 0, 0);
              onCapture(canvas.toDataURL('image/jpeg', 0.9));
            }, i * 200);
          }
        } else {
          onCapture(imageData);
        }
      }
    }
  };

  const getFilterStyle = () => {
    switch (filter) {
      case 'grayscale': return 'grayscale(100%)';
      case 'sepia': return 'sepia(100%)';
      case 'vintage': return 'sepia(50%) contrast(120%)';
      case 'bright': return 'brightness(120%)';
      default: return 'none';
    }
  };

  return (
    <div className="fixed inset-0 bg-black z-50 flex flex-col">
      <video ref={videoRef} autoPlay playsInline className="flex-1 object-cover" style={{ filter: getFilterStyle(), transform: `scale(${zoom})` }} />
      <canvas ref={canvasRef} className="hidden" />
      
      <div className="absolute top-4 left-4 right-4 flex justify-between items-start">
        <Button variant="ghost" size="icon" onClick={onClose} className="bg-black/50 text-white hover:bg-black/70">
          <X className="h-6 w-6" />
        </Button>
        <div className="flex gap-2">
          <Button variant="ghost" size="icon" onClick={() => setBurstMode(!burstMode)} className={`${burstMode ? 'bg-amber-500' : 'bg-black/50'} text-white hover:bg-black/70`}>
            <Repeat className="h-6 w-6" />
          </Button>
          <Button variant="ghost" size="icon" onClick={() => setFlashEnabled(!flashEnabled)} className="bg-black/50 text-white hover:bg-black/70">
            {flashEnabled ? <Zap className="h-6 w-6" /> : <ZapOff className="h-6 w-6" />}
          </Button>
          <Button variant="ghost" size="icon" onClick={() => setFacingMode(facingMode === 'user' ? 'environment' : 'user')} className="bg-black/50 text-white hover:bg-black/70">
            <SwitchCamera className="h-6 w-6" />
          </Button>
        </div>
      </div>

      <div className="absolute bottom-32 left-4 right-4 flex flex-col gap-4">
        <div className="flex items-center gap-2 bg-black/50 rounded-full px-4 py-2">
          <ZoomOut className="h-4 w-4 text-white" />
          <Slider value={[zoom]} onValueChange={(v) => setZoom(v[0])} min={1} max={3} step={0.1} className="flex-1" />
          <ZoomIn className="h-4 w-4 text-white" />
        </div>
        <div className="flex gap-2 overflow-x-auto pb-2">
          {['none', 'grayscale', 'sepia', 'vintage', 'bright'].map(f => (
            <button key={f} onClick={() => setFilter(f)} className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap ${filter === f ? 'bg-amber-500 text-white' : 'bg-black/50 text-white'}`}>
              {f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2">
        {burstMode && <p className="text-white text-sm bg-black/50 px-3 py-1 rounded-full">Modo Ráfaga (5 fotos)</p>}
        <Button size="icon" onClick={capturePhoto} className="w-20 h-20 rounded-full bg-white hover:bg-gray-200">
          <Circle className="h-16 w-16 text-amber-600" />
        </Button>
      </div>
    </div>
  );
}
