import { useState, useRef } from 'react';
import { Camera, Image, Upload, X, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { toast } from 'sonner';

export function MobilePhotoIntegration() {
  const [selectedImages, setSelectedImages] = useState<string[]>([]);
  const [showCamera, setShowCamera] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const openCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      streamRef.current = stream;
      if (videoRef.current) videoRef.current.srcObject = stream;
      setShowCamera(true);
    } catch (err) {
      toast.error('Camera access denied');
    }
  };

  const capturePhoto = () => {
    if (videoRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      canvas.getContext('2d')?.drawImage(videoRef.current, 0, 0);
      setSelectedImages(prev => [...prev, canvas.toDataURL('image/jpeg')]);
      closeCamera();
      toast.success('Photo captured!');
    }
  };

  const closeCamera = () => {
    streamRef.current?.getTracks().forEach(t => t.stop());
    setShowCamera(false);
  };

  const selectFromGallery = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    files.forEach(file => {
      const reader = new FileReader();
      reader.onload = (ev) => setSelectedImages(prev => [...prev, ev.target?.result as string]);
      reader.readAsDataURL(file);
    });
  };

  const removeImage = (idx: number) => setSelectedImages(prev => prev.filter((_, i) => i !== idx));

  return (
    <Card className="p-4">
      <div className="space-y-4">
        <div className="flex gap-2">
          <Button onClick={openCamera} className="flex-1">
            <Camera className="w-4 h-4 mr-2" />Camera
          </Button>
          <Button onClick={() => fileInputRef.current?.click()} variant="outline" className="flex-1">
            <Image className="w-4 h-4 mr-2" />Gallery
          </Button>
        </div>

        <input ref={fileInputRef} type="file" accept="image/*" multiple className="hidden" onChange={selectFromGallery} />

        {showCamera && (
          <div className="relative">
            <video ref={videoRef} autoPlay playsInline className="w-full rounded-lg" />
            <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-4">
              <Button variant="destructive" onClick={closeCamera}><X /></Button>
              <Button onClick={capturePhoto}><Check /></Button>
            </div>
          </div>
        )}

        <div className="grid grid-cols-3 gap-2">
          {selectedImages.map((img, i) => (
            <div key={i} className="relative">
              <img src={img} className="w-full h-24 object-cover rounded-lg" />
              <Button size="sm" variant="destructive" className="absolute top-1 right-1 h-6 w-6 p-0" onClick={() => removeImage(i)}>
                <X className="w-3 h-3" />
              </Button>
            </div>
          ))}
        </div>
      </div>
    </Card>
  );
}
