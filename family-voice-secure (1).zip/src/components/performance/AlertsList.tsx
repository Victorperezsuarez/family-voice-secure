import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { AlertTriangle, CheckCircle, Clock } from 'lucide-react';
import { PerformanceAlert } from '@/types/performance';

interface AlertsListProps {
  alerts: PerformanceAlert[];
  onResolve: (alertId: string) => void;
}

export function AlertsList({ alerts, onResolve }: AlertsListProps) {
  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'destructive';
      case 'high': return 'destructive';
      case 'medium': return 'default';
      case 'low': return 'secondary';
      default: return 'secondary';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <AlertTriangle className="h-5 w-5" />
          Performance Alerts
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {alerts.length === 0 ? (
            <p className="text-sm text-muted-foreground">No active alerts</p>
          ) : (
            alerts.map(alert => (
              <div key={alert.id} className="flex items-start justify-between p-3 border rounded-lg">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge variant={getSeverityColor(alert.severity)}>
                      {alert.severity}
                    </Badge>
                    <span className="text-sm font-medium">{alert.metric_type}</span>
                  </div>
                  <p className="text-sm text-muted-foreground">{alert.message}</p>
                  {alert.deviation_percent && (
                    <p className="text-xs text-muted-foreground mt-1">
                      Deviation: {alert.deviation_percent.toFixed(1)}%
                    </p>
                  )}
                </div>
                {alert.status === 'active' && (
                  <Button size="sm" variant="outline" onClick={() => onResolve(alert.id)}>
                    <CheckCircle className="h-4 w-4 mr-1" />
                    Resolve
                  </Button>
                )}
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
