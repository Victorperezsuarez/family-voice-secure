import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Mic, Image, Users, Trash2, Upload } from 'lucide-react';
import { useOfflineStorage } from '@/hooks/useOfflineStorage';
import { useOfflineSync } from '@/contexts/OfflineSyncContext';

export function OfflineDataViewer({ familyId }: { familyId: string }) {
  const { recordings, photos, loading, deleteRecording } = useOfflineStorage(familyId);
  const { isOnline, addToQueue } = useOfflineSync();

  const handleSyncItem = (type: string, item: any) => {
    addToQueue(type, item);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Offline Data</CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="recordings">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="recordings">
              <Mic className="w-4 h-4 mr-2" />
              Recordings ({recordings.length})
            </TabsTrigger>
            <TabsTrigger value="photos">
              <Image className="w-4 h-4 mr-2" />
              Photos ({photos.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="recordings">
            <ScrollArea className="h-[400px]">
              {recordings.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No offline recordings
                </div>
              ) : (
                <div className="space-y-2">
                  {recordings.map((recording) => (
                    <div key={recording.id} className="p-3 border rounded-lg">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="font-medium">{recording.title}</div>
                          <div className="text-xs text-gray-500">
                            {new Date(recording.created_at).toLocaleString()}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant={recording.synced ? 'default' : 'secondary'}>
                            {recording.synced ? 'Synced' : 'Offline'}
                          </Badge>
                          {!recording.synced && isOnline && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleSyncItem('create_recording', recording)}
                            >
                              <Upload className="w-3 h-3" />
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </ScrollArea>
          </TabsContent>

          <TabsContent value="photos">
            <ScrollArea className="h-[400px]">
              {photos.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No offline photos
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-2">
                  {photos.map((photo) => (
                    <div key={photo.id} className="relative">
                      <img
                        src={photo.photo_url}
                        alt={photo.caption}
                        className="w-full h-32 object-cover rounded-lg"
                      />
                      <Badge
                        className="absolute top-2 right-2"
                        variant={photo.synced ? 'default' : 'secondary'}
                      >
                        {photo.synced ? 'Synced' : 'Offline'}
                      </Badge>
                    </div>
                  ))}
                </div>
              )}
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
