import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/lib/supabase-client';
import { ContextualStats } from '@/types/contextualBandits';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface Props {
  testId: string;
}

export function ContextualPerformanceChart({ testId }: Props) {
  const [stats, setStats] = useState<ContextualStats[]>([]);
  const [selectedSegment, setSelectedSegment] = useState<string>('device_type');

  useEffect(() => {
    loadStats();
  }, [testId]);

  const loadStats = async () => {
    const { data } = await supabase
      .from('notification_contextual_stats')
      .select('*')
      .eq('test_id', testId);
    
    if (data) setStats(data);
  };

  const getChartData = (segmentKey: string) => {
    const filtered = stats.filter(s => s.segmentKey === segmentKey);
    const grouped = filtered.reduce((acc, stat) => {
      if (!acc[stat.segmentValue]) {
        acc[stat.segmentValue] = {
          segment: stat.segmentValue,
          impressions: 0,
          clicks: 0,
          conversions: 0,
          ctr: 0,
          cvr: 0
        };
      }
      acc[stat.segmentValue].impressions += stat.impressions;
      acc[stat.segmentValue].clicks += stat.clicks;
      acc[stat.segmentValue].conversions += stat.conversions;
      return acc;
    }, {} as Record<string, any>);

    return Object.values(grouped).map((item: any) => ({
      ...item,
      ctr: item.impressions > 0 ? (item.clicks / item.impressions) * 100 : 0,
      cvr: item.clicks > 0 ? (item.conversions / item.clicks) * 100 : 0
    }));
  };

  const segments = ['device_type', 'location_country', 'time_of_day', 'day_of_week', 'device_os'];

  return (
    <Card>
      <CardHeader>
        <CardTitle>Contextual Performance</CardTitle>
        <CardDescription>Performance metrics by user context</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs value={selectedSegment} onValueChange={setSelectedSegment}>
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="device_type">Device</TabsTrigger>
            <TabsTrigger value="location_country">Location</TabsTrigger>
            <TabsTrigger value="time_of_day">Time</TabsTrigger>
            <TabsTrigger value="day_of_week">Day</TabsTrigger>
            <TabsTrigger value="device_os">OS</TabsTrigger>
          </TabsList>

          {segments.map((segment) => (
            <TabsContent key={segment} value={segment} className="space-y-4">
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={getChartData(segment)}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="segment" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="ctr" fill="#3b82f6" name="CTR %" />
                  <Bar dataKey="cvr" fill="#10b981" name="CVR %" />
                </BarChart>
              </ResponsiveContainer>
            </TabsContent>
          ))}
        </Tabs>
      </CardContent>
    </Card>
  );
}
