import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/lib/supabase-client';
import { SegmentPerformance } from '@/types/contextualBandits';
import { UserBehaviorFeatures } from '@/types/segmentPrediction';
import { predictUserSegment } from '@/utils/segmentPredictor';
import { SegmentPredictionPanel } from '@/components/segmentation/SegmentPredictionPanel';
import { FeatureImportanceChart } from '@/components/segmentation/FeatureImportanceChart';
import { ModelPerformanceMetrics } from '@/components/segmentation/ModelPerformanceMetrics';
import { ExplainableAIDashboard } from '@/components/explainable/ExplainableAIDashboard';
import FeatureStoreManager from '@/components/featureEngineering/FeatureStoreManager';
import CorrelationHeatmap from '@/components/featureEngineering/CorrelationHeatmap';
import FeatureSelectionPanel from '@/components/featureEngineering/FeatureSelectionPanel';
import { FeatureFreshnessMonitor } from '@/components/featureEngineering/FeatureFreshnessMonitor';
import { StreamingUpdatesPanel } from '@/components/featureEngineering/StreamingUpdatesPanel';
import { DriftDetectionPanel } from '@/components/featureEngineering/DriftDetectionPanel';
import { ModelRetrainingManager } from '@/components/featureEngineering/ModelRetrainingManager';
import { ExperimentCreationDialog } from '@/components/experimentation/ExperimentCreationDialog';
import { ExperimentPerformanceComparison } from '@/components/experimentation/ExperimentPerformanceComparison';
import { ShadowModeMonitor } from '@/components/experimentation/ShadowModeMonitor';
import { calculateCorrelationMatrix } from '@/utils/featureEngineering';
import { Users, TrendingUp, Target, Award, Brain, FlaskConical } from 'lucide-react';





interface Props {
  testId: string;
}


export function UserSegmentationDashboard({ testId }: Props) {
  const [segments, setSegments] = useState<SegmentPerformance[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTab, setSelectedTab] = useState('performance');
  const [showExperimentDialog, setShowExperimentDialog] = useState(false);
  const [demoFeatures] = useState<Partial<UserBehaviorFeatures>>({
    daysSinceSignup: 45,
    totalSessions: 28,
    avgSessionDuration: 420,
    totalRecordings: 12,
    totalPhotos: 45,
    totalCollections: 3,
    daysActive: 18,
    lastActiveDaysAgo: 1,
    notificationOpenRate: 0.65,
    notificationClickRate: 0.42,
    emailOpenRate: 0.58,
    featureAdoptionScore: 0.72,
    deviceType: 'mobile',
    osType: 'iOS',
    engagementScore: 0,
    retentionScore: 0,
    activityFrequency: 'weekly'
  });

  // Mock experiment results
  const mockExperimentResults = [
    { id: '1', experiment_id: 'exp-1', config_id: 'control', metric_name: 'accuracy', metric_value: 0.82, sample_size: 1500, statistical_significance: true, p_value: 0.03, recorded_at: new Date().toISOString(), confidence_interval: { lower: 0.80, upper: 0.84 } },
    { id: '2', experiment_id: 'exp-1', config_id: 'treatment_A', metric_name: 'accuracy', metric_value: 0.87, sample_size: 1500, statistical_significance: true, p_value: 0.01, recorded_at: new Date().toISOString(), confidence_interval: { lower: 0.85, upper: 0.89 } },
    { id: '3', experiment_id: 'exp-1', config_id: 'treatment_B', metric_name: 'accuracy', metric_value: 0.85, sample_size: 1500, statistical_significance: true, p_value: 0.02, recorded_at: new Date().toISOString(), confidence_interval: { lower: 0.83, upper: 0.87 } },
  ];


  useEffect(() => {
    loadSegments();
  }, [testId]);

  const loadSegments = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('notification_segment_performance')
      .select('*')
      .eq('test_id', testId)
      .order('avg_engagement_rate', { ascending: false });
    
    if (data) setSegments(data);
    setLoading(false);
  };

  const topSegment = segments[0];
  const avgEngagement = segments.reduce((sum, s) => sum + s.avgEngagementRate, 0) / segments.length;
  const demoPrediction = predictUserSegment('demo-user', demoFeatures);

  // Generate demo correlation matrix
  const demoCorrelationData = [
    { engagement_score: 0.85, retention_score: 0.72, activity_frequency: 0.68, session_duration: 0.55 },
    { engagement_score: 0.65, retention_score: 0.58, activity_frequency: 0.45, session_duration: 0.38 },
    { engagement_score: 0.92, retention_score: 0.88, activity_frequency: 0.82, session_duration: 0.75 },
    { engagement_score: 0.45, retention_score: 0.42, activity_frequency: 0.35, session_duration: 0.28 },
  ];
  const correlationMatrix = calculateCorrelationMatrix(demoCorrelationData);

  return (
    <>
    <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-6">
      <TabsList className="grid w-full grid-cols-12">
        <TabsTrigger value="performance">Performance</TabsTrigger>
        <TabsTrigger value="prediction">ML Prediction</TabsTrigger>
        <TabsTrigger value="explainable">Explainable AI</TabsTrigger>
        <TabsTrigger value="features">Importance</TabsTrigger>
        <TabsTrigger value="model">Metrics</TabsTrigger>
        <TabsTrigger value="store">Feature Store</TabsTrigger>
        <TabsTrigger value="correlation">Correlation</TabsTrigger>
        <TabsTrigger value="selection">Selection</TabsTrigger>
        <TabsTrigger value="freshness">Freshness</TabsTrigger>
        <TabsTrigger value="streaming">Streaming</TabsTrigger>
        <TabsTrigger value="drift">Drift</TabsTrigger>
        <TabsTrigger value="retraining">Retraining</TabsTrigger>
      </TabsList>

      <div className="flex justify-end mb-4">
        <Button onClick={() => setShowExperimentDialog(true)}>
          <FlaskConical className="h-4 w-4 mr-2" />
          Create Feature Experiment
        </Button>
      </div>





      <TabsContent value="performance" className="space-y-6">
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Segments</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{segments.length}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Avg Engagement</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{(avgEngagement * 100).toFixed(2)}%</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Significant Segments</CardTitle>
              <Target className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {segments.filter(s => s.statisticalSignificance).length}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Top Segment</CardTitle>
              <Award className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-sm font-bold">{topSegment?.segmentName || 'N/A'}</div>
              <p className="text-xs text-muted-foreground">
                {topSegment ? `${(topSegment.avgEngagementRate * 100).toFixed(1)}%` : ''}
              </p>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Segment Performance</CardTitle>
            <CardDescription>Performance metrics by user segment</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {segments.map((segment) => (
                <div key={segment.id} className="flex items-center justify-between border-b pb-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <p className="font-medium">{segment.segmentName}</p>
                      {segment.statisticalSignificance && (
                        <Badge variant="default">Significant</Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {segment.totalUsers} users • {segment.totalImpressions} impressions
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold">
                      {(segment.avgEngagementRate * 100).toFixed(2)}%
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Confidence: {(segment.confidenceScore * 100).toFixed(0)}%
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="prediction" className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="h-5 w-5" />
              ML-Powered Segment Prediction
            </CardTitle>
            <CardDescription>
              Predict user segments for new users before they have enough behavioral data
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              Using machine learning to classify users based on signup source, initial engagement, 
              and demographic data with confidence scores and probability distributions.
            </p>
          </CardContent>
        </Card>
        <SegmentPredictionPanel prediction={demoPrediction} />
      </TabsContent>
      <TabsContent value="explainable" className="space-y-6">
        <ExplainableAIDashboard />
      </TabsContent>

      <TabsContent value="features" className="space-y-6">
        <FeatureImportanceChart />
      </TabsContent>

      <TabsContent value="model" className="space-y-6">
        <ModelPerformanceMetrics />
      </TabsContent>

      <TabsContent value="store" className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Automated Feature Engineering</CardTitle>
            <CardDescription>
              Discover and manage engineered features from raw user behavior data
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              The feature store automatically generates derived features, time-series aggregations, 
              and tracks feature importance across all ML models.
            </p>
          </CardContent>
        </Card>
        <FeatureStoreManager />
      </TabsContent>

      <TabsContent value="correlation" className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Feature Correlation Analysis</CardTitle>
            <CardDescription>
              Identify highly correlated features to reduce redundancy and improve model performance
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Features with high correlation (&gt;0.8) may be redundant. Consider removing one to reduce 
              multicollinearity and improve model interpretability.
            </p>

          </CardContent>
        </Card>
        <CorrelationHeatmap features={correlationMatrix.features} matrix={correlationMatrix.matrix} />
      </TabsContent>

      <TabsContent value="selection" className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Automated Feature Selection</CardTitle>
            <CardDescription>
              Use statistical methods to identify the most predictive features for your models
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Feature selection reduces overfitting, improves model performance, and decreases training time 
              by focusing on the most informative features.
            </p>
          </CardContent>
        </Card>
        <FeatureSelectionPanel />
      </TabsContent>

      <TabsContent value="freshness" className="space-y-6">
        <FeatureFreshnessMonitor />
      </TabsContent>

      <TabsContent value="streaming" className="space-y-6">
        <StreamingUpdatesPanel />
      </TabsContent>

      <TabsContent value="drift" className="space-y-6">
        <DriftDetectionPanel />
      </TabsContent>

      <TabsContent value="retraining" className="space-y-6">
        <ModelRetrainingManager />
      </TabsContent>

      <TabsContent value="experiments" className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FlaskConical className="h-5 w-5" />
              Feature Engineering Experiments
            </CardTitle>
            <CardDescription>
              A/B test different feature sets and automatically promote winning configurations
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              Compare model performance with different feature engineering approaches. 
              Shadow mode allows testing new features without affecting production predictions.
            </p>
          </CardContent>
        </Card>
        
        <ExperimentPerformanceComparison 
          experimentId="exp-1" 
          results={mockExperimentResults}
          onPromoteConfig={(configId) => console.log('Promoting config:', configId)}
        />
        
        <Card>
          <CardHeader>
            <CardTitle>Shadow Mode Testing</CardTitle>
            <CardDescription>
              New features are computed in parallel but not used in production until validated
            </CardDescription>
          </CardHeader>
        </Card>
        
        <ShadowModeMonitor configId="treatment_A" />
      </TabsContent>

    </Tabs>
    
    <ExperimentCreationDialog 
      open={showExperimentDialog}
      onOpenChange={setShowExperimentDialog}
      onExperimentCreated={() => {
        console.log('Experiment created');
        loadSegments();
      }}
    />
    </>
  );
}

