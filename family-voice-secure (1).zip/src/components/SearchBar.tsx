import { useState } from 'react';
import { Search, Filter, X } from 'lucide-react';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Calendar } from './ui/calendar';
import { FamilyMember } from '@/types/family';

interface SearchBarProps {
  onSearch: (filters: SearchFilters) => void;
  familyMembers: FamilyMember[];
}

export interface SearchFilters {
  query: string;
  memberId?: string;
  language?: string;
  dateFrom?: Date;
  dateTo?: Date;
}

export function SearchBar({ onSearch, familyMembers }: SearchBarProps) {
  const [query, setQuery] = useState('');
  const [memberId, setMemberId] = useState<string>();
  const [language, setLanguage] = useState<string>();
  const [dateFrom, setDateFrom] = useState<Date>();
  const [dateTo, setDateTo] = useState<Date>();
  const [showFilters, setShowFilters] = useState(false);

  const handleSearch = () => {
    onSearch({ query, memberId, language, dateFrom, dateTo });
  };

  const clearFilters = () => {
    setMemberId(undefined);
    setLanguage(undefined);
    setDateFrom(undefined);
    setDateTo(undefined);
    onSearch({ query });
  };

  const hasFilters = memberId || language || dateFrom || dateTo;

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
            placeholder="Buscar por título, transcripción o etiquetas..."
            className="pl-10 pr-4 h-12 text-base"
          />
        </div>
        <Button onClick={handleSearch} size="lg" className="bg-amber-600 hover:bg-amber-700">
          Buscar
        </Button>
        <Button
          onClick={() => setShowFilters(!showFilters)}
          variant={hasFilters ? "default" : "outline"}
          size="lg"
          className={hasFilters ? "bg-amber-600 hover:bg-amber-700" : ""}
        >
          <Filter className="w-5 h-5" />
        </Button>
      </div>

      {showFilters && (
        <div className="bg-white/80 backdrop-blur-sm rounded-xl p-4 border border-amber-200 space-y-3">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <Select value={memberId} onValueChange={setMemberId}>
              <SelectTrigger>
                <SelectValue placeholder="Miembro familiar" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                {familyMembers.map(m => (
                  <SelectItem key={m.id} value={m.id}>{m.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={language} onValueChange={setLanguage}>
              <SelectTrigger>
                <SelectValue placeholder="Idioma" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="es-MX">Español</SelectItem>
                <SelectItem value="en-US">English</SelectItem>
              </SelectContent>
            </Select>

            <div className="flex gap-2">
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="flex-1">
                    {dateFrom ? dateFrom.toLocaleDateString() : 'Desde'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar mode="single" selected={dateFrom} onSelect={setDateFrom} />
                </PopoverContent>
              </Popover>

              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="flex-1">
                    {dateTo ? dateTo.toLocaleDateString() : 'Hasta'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar mode="single" selected={dateTo} onSelect={setDateTo} />
                </PopoverContent>
              </Popover>
            </div>
          </div>

          {hasFilters && (
            <Button onClick={clearFilters} variant="ghost" size="sm" className="w-full">
              <X className="w-4 h-4 mr-2" />
              Limpiar filtros
            </Button>
          )}
        </div>
      )}
    </div>
  );
}
