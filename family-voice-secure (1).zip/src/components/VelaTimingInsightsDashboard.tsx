import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/lib/supabase-client';
import { Clock, TrendingUp, Target, Calendar } from 'lucide-react';
import type { VelaOptimalTimingPattern } from '@/types/velaSuggestionScheduling';

export function VelaTimingInsightsDashboard({ userId }: { userId: string }) {
  const [patterns, setPatterns] = useState<VelaOptimalTimingPattern[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPatterns();
  }, [userId]);

  const loadPatterns = async () => {
    try {
      const { data, error } = await supabase
        .from('vela_optimal_timing_patterns')
        .select('*')
        .eq('user_id', userId)
        .gte('total_delivered', 3)
        .order('acceptance_rate', { ascending: false });

      if (error) throw error;
      setPatterns(data || []);
    } catch (error) {
      console.error('Error loading patterns:', error);
    } finally {
      setLoading(false);
    }
  };

  const getDayName = (day: number) => {
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    return days[day];
  };

  const formatTime = (hour: number) => {
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 || 12;
    return `${displayHour}:00 ${ampm}`;
  };

  const getBestTimes = () => {
    return patterns.slice(0, 5);
  };

  const getWorstTimes = () => {
    return [...patterns].reverse().slice(0, 5);
  };

  if (loading) return <div>Loading insights...</div>;

  const bestTimes = getBestTimes();
  const worstTimes = getWorstTimes();

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Best Times for Suggestions
          </CardTitle>
          <CardDescription>When you're most receptive to Vela's suggestions</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {bestTimes.length === 0 ? (
              <p className="text-center text-muted-foreground py-4">
                Not enough data yet. Keep interacting with suggestions!
              </p>
            ) : (
              bestTimes.map((pattern) => (
                <div key={pattern.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <p className="font-medium">
                        {getDayName(pattern.day_of_week)} at {formatTime(pattern.hour_of_day)}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {pattern.total_delivered} delivered, {pattern.total_accepted} accepted
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-green-600">
                      {pattern.acceptance_rate.toFixed(0)}%
                    </p>
                    <p className="text-xs text-muted-foreground">acceptance</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            Times to Avoid
          </CardTitle>
          <CardDescription>When you're less likely to engage with suggestions</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {worstTimes.length === 0 ? (
              <p className="text-center text-muted-foreground py-4">No data available</p>
            ) : (
              worstTimes.map((pattern) => (
                <div key={pattern.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <p className="font-medium">
                        {getDayName(pattern.day_of_week)} at {formatTime(pattern.hour_of_day)}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {pattern.total_delivered} delivered, {pattern.total_dismissed} dismissed
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-red-600">
                      {pattern.acceptance_rate.toFixed(0)}%
                    </p>
                    <p className="text-xs text-muted-foreground">acceptance</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
