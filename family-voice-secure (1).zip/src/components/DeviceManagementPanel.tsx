import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase-client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Smartphone, Monitor, Tablet, Trash2 } from 'lucide-react';
import { UserDevice } from '@/types/deviceSync';
import { toast } from 'sonner';

export function DeviceManagementPanel() {
  const [devices, setDevices] = useState<UserDevice[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDevices();
  }, []);

  const loadDevices = async () => {
    try {
      const { data, error } = await supabase
        .from('user_devices')
        .select('*')
        .order('last_active_at', { ascending: false });

      if (error) throw error;
      setDevices(data || []);
    } catch (error: any) {
      toast.error('Failed to load devices');
    } finally {
      setLoading(false);
    }
  };

  const toggleDevice = async (deviceId: string, isActive: boolean) => {
    try {
      const { error } = await supabase
        .from('user_devices')
        .update({ is_active: isActive })
        .eq('id', deviceId);

      if (error) throw error;
      
      setDevices(devices.map(d => 
        d.id === deviceId ? { ...d, is_active: isActive } : d
      ));
      
      toast.success(isActive ? 'Device enabled' : 'Device disabled');
    } catch (error: any) {
      toast.error('Failed to update device');
    }
  };

  const removeDevice = async (deviceId: string) => {
    try {
      const { error } = await supabase
        .from('user_devices')
        .delete()
        .eq('id', deviceId);

      if (error) throw error;
      
      setDevices(devices.filter(d => d.id !== deviceId));
      toast.success('Device removed');
    } catch (error: any) {
      toast.error('Failed to remove device');
    }
  };

  const getDeviceIcon = (type: string) => {
    switch (type) {
      case 'mobile': return <Smartphone className="h-5 w-5" />;
      case 'tablet': return <Tablet className="h-5 w-5" />;
      default: return <Monitor className="h-5 w-5" />;
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Registered Devices</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {devices.map((device) => (
            <div key={device.id} className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex items-center gap-3">
                {getDeviceIcon(device.device_type)}
                <div>
                  <h4 className="font-semibold">{device.device_name}</h4>
                  <p className="text-sm text-muted-foreground">
                    {device.browser} on {device.os}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Last active: {new Date(device.last_active_at).toLocaleString()}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <Switch
                    checked={device.is_active}
                    onCheckedChange={(checked) => toggleDevice(device.id, checked)}
                  />
                  <Label>Active</Label>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => removeDevice(device.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
          {devices.length === 0 && (
            <p className="text-center text-muted-foreground py-8">
              No devices registered
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
