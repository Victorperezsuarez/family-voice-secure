import { useState } from 'react';
import { Search, Sparkles } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface SemanticSearchBarProps {
  onSearch: (query: string) => void;
  placeholder?: string;
}

export const SemanticSearchBar = ({
  onSearch,
  placeholder = "Ask anything about your recordings...",
}: SemanticSearchBarProps) => {
  const [query, setQuery] = useState('');
  const [isSemanticMode, setIsSemanticMode] = useState(true);

  const handleSearch = () => {
    if (query.trim()) {
      onSearch(query);
    }
  };

  const exampleQueries = [
    "When did grandma talk about her childhood?",
    "Find recordings about family recipes",
    "Show me conversations from last Christmas",
  ];

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
            placeholder={placeholder}
            className="pl-10 pr-4"
          />
        </div>
        <Button
          variant={isSemanticMode ? 'default' : 'outline'}
          size="icon"
          onClick={() => setIsSemanticMode(!isSemanticMode)}
          title="Toggle semantic search"
        >
          <Sparkles className="h-4 w-4" />
        </Button>
        <Button onClick={handleSearch}>Search</Button>
      </div>

      {isSemanticMode && (
        <div className="flex gap-2 flex-wrap">
          <span className="text-xs text-muted-foreground">Try:</span>
          {exampleQueries.map((example, idx) => (
            <Badge
              key={idx}
              variant="outline"
              className="cursor-pointer hover:bg-accent"
              onClick={() => {
                setQuery(example);
                onSearch(example);
              }}
            >
              {example}
            </Badge>
          ))}
        </div>
      )}
    </div>
  );
};
