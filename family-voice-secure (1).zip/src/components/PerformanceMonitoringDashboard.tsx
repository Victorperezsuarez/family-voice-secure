import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase-client';
import { PerformanceChart } from './performance/PerformanceChart';
import { PerformanceStatsCard } from './performance/PerformanceStatsCard';
import { AlertsList } from './performance/AlertsList';
import { Activity, TrendingUp, Zap, AlertTriangle, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';
import type { PerformanceMetric, PerformanceAlert, OptimizationRecommendation } from '@/types/performance';

interface PerformanceMonitoringDashboardProps {
  templateId: string;
}

export function PerformanceMonitoringDashboard({ templateId }: PerformanceMonitoringDashboardProps) {
  const [metrics, setMetrics] = useState<PerformanceMetric[]>([]);
  const [alerts, setAlerts] = useState<PerformanceAlert[]>([]);
  const [recommendations, setRecommendations] = useState<OptimizationRecommendation[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [timeRange, setTimeRange] = useState('7');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, [templateId, timeRange]);

  const loadData = async () => {
    setLoading(true);
    try {
      // Load metrics
      const daysAgo = new Date();
      daysAgo.setDate(daysAgo.getDate() - parseInt(timeRange));
      
      const { data: metricsData } = await supabase
        .from('performance_metrics')
        .select('*')
        .eq('template_id', templateId)
        .gte('created_at', daysAgo.toISOString())
        .order('created_at', { ascending: true });

      setMetrics(metricsData || []);

      // Load alerts
      const { data: alertsData } = await supabase
        .from('performance_alerts')
        .select('*')
        .eq('template_id', templateId)
        .eq('status', 'active')
        .order('created_at', { ascending: false });

      setAlerts(alertsData || []);

      // Analyze performance
      const { data: analysisData } = await supabase.functions.invoke('analyze-performance', {
        body: { templateId, timeRange }
      });

      if (analysisData) {
        setStats(analysisData.stats);
        setRecommendations(analysisData.recommendations || []);
      }
    } catch (error: any) {
      toast.error('Failed to load performance data');
    } finally {
      setLoading(false);
    }
  };

  const resolveAlert = async (alertId: string) => {
    const { error } = await supabase
      .from('performance_alerts')
      .update({ status: 'resolved', resolved_at: new Date().toISOString() })
      .eq('id', alertId);

    if (error) {
      toast.error('Failed to resolve alert');
    } else {
      toast.success('Alert resolved');
      loadData();
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Performance Monitoring</h2>
          <p className="text-muted-foreground">Track and optimize template performance</p>
        </div>
        <div className="flex gap-2">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1">Last 24h</SelectItem>
              <SelectItem value="7">Last 7 days</SelectItem>
              <SelectItem value="30">Last 30 days</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={loadData} variant="outline">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.load_time && (
            <PerformanceStatsCard
              title="Load Time (P95)"
              current={stats.load_time.p95}
              baseline={stats.load_time.p50}
              unit="ms"
            />
          )}
          {stats.memory_usage && (
            <PerformanceStatsCard
              title="Memory Usage (P95)"
              current={stats.memory_usage.p95}
              baseline={stats.memory_usage.p50}
              unit="MB"
            />
          )}
          {stats.permission_check && (
            <PerformanceStatsCard
              title="Permission Check (P95)"
              current={stats.permission_check.p95}
              baseline={stats.permission_check.p50}
              unit="ms"
            />
          )}
          {stats.render_time && (
            <PerformanceStatsCard
              title="Render Time (P95)"
              current={stats.render_time.p95}
              baseline={stats.render_time.p50}
              unit="ms"
            />
          )}
        </div>
      )}

      <Tabs defaultValue="charts" className="space-y-4">
        <TabsList>
          <TabsTrigger value="charts">Performance Charts</TabsTrigger>
          <TabsTrigger value="alerts">
            Alerts {alerts.length > 0 && <Badge className="ml-2">{alerts.length}</Badge>}
          </TabsTrigger>
          <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
        </TabsList>

        <TabsContent value="charts" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Performance Metrics Over Time</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <PerformanceChart metrics={metrics} metricType="load_time" title="Load Time (ms)" />
              <PerformanceChart metrics={metrics} metricType="memory_usage" title="Memory Usage (MB)" />
              <PerformanceChart metrics={metrics} metricType="permission_check" title="Permission Check (ms)" />
              <PerformanceChart metrics={metrics} metricType="render_time" title="Render Time (ms)" />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="alerts">
          <AlertsList alerts={alerts} onResolve={resolveAlert} />
        </TabsContent>

        <TabsContent value="recommendations" className="space-y-4">
          {recommendations.map((rec, idx) => (
            <Card key={idx}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-lg">{rec.title}</CardTitle>
                    <CardDescription>{rec.description}</CardDescription>
                  </div>
                  <Badge variant={rec.priority === 'high' ? 'destructive' : 'default'}>
                    {rec.priority}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm font-medium text-green-600 mb-2">
                  {rec.estimatedImpact}
                </p>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  );
}
