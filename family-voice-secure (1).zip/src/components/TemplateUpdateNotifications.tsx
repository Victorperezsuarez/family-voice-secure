import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase-client';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Bell, Download, X, AlertTriangle, Sparkles } from 'lucide-react';
import { toast } from 'sonner';
import { MigrationAssistant } from './MigrationAssistant';


interface Subscription {
  id: string;
  community_template_id: string;
  local_template_id: string;
  subscribed_version: number;
  current_version: number;
  community_templates: {
    name: string;
    description: string;
    permissions: Record<string, boolean>;
  };
}

interface Props {
  familyId: string;
}

export function TemplateUpdateNotifications({ familyId }: Props) {
  const [updates, setUpdates] = useState<Subscription[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedUpdate, setSelectedUpdate] = useState<Subscription | null>(null);
  const [showMigration, setShowMigration] = useState(false);


  useEffect(() => {
    checkForUpdates();
  }, [familyId]);

  const checkForUpdates = async () => {
    const { data, error } = await supabase
      .from('template_subscriptions')
      .select('*, community_templates(name, description, permissions)')
      .eq('family_id', familyId)
      .neq('subscribed_version', 'current_version');

    if (!error && data) {
      setUpdates(data as any);
    }
  };

  const handleUpdate = async (subscription: Subscription) => {
    setLoading(true);
    try {
      await supabase
        .from('permission_templates')
        .update({
          permissions: subscription.community_templates.permissions,
          description: subscription.community_templates.description
        })
        .eq('id', subscription.local_template_id);

      await supabase
        .from('template_subscriptions')
        .update({ subscribed_version: subscription.current_version })
        .eq('id', subscription.id);

      toast.success('Template updated successfully');
      checkForUpdates();
    } catch (error) {
      toast.error('Failed to update template');
    } finally {
      setLoading(false);
    }
  };

  const handleDismiss = async (id: string) => {
    await supabase
      .from('template_subscriptions')
      .update({ auto_update: false })
      .eq('id', id);
    checkForUpdates();
  };

  if (updates.length === 0) return null;

  return (
    <>
      <Card className="p-4 mb-4 border-blue-200 bg-blue-50">
        <div className="flex items-start gap-3">
          <Bell className="w-5 h-5 text-blue-600 mt-1" />
          <div className="flex-1">
            <h4 className="font-semibold text-blue-900 mb-2">Template Updates Available</h4>
            <div className="space-y-2">
              {updates.map(sub => (
                <div key={sub.id} className="flex items-center justify-between bg-white p-3 rounded">
                  <div>
                    <p className="font-medium">{sub.community_templates.name}</p>
                    <p className="text-sm text-muted-foreground">
                      Version {sub.subscribed_version} → {sub.current_version}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => {
                        setSelectedUpdate(sub);
                        setShowMigration(true);
                      }}
                    >
                      <Sparkles className="w-4 h-4 mr-1" />
                      View Migration
                    </Button>
                    <Button size="sm" onClick={() => handleUpdate(sub)} disabled={loading}>
                      <Download className="w-4 h-4 mr-1" />
                      Update
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => handleDismiss(sub.id)}>
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Card>

      {selectedUpdate && (
        <Dialog open={showMigration} onOpenChange={setShowMigration}>
          <DialogContent className="max-w-3xl max-h-[80vh]">
            <DialogHeader>
              <DialogTitle>Migration Guide: {selectedUpdate.community_templates.name}</DialogTitle>
            </DialogHeader>
            <div className="overflow-y-auto">
              <MigrationAssistant
                fromVersion={selectedUpdate.subscribed_version.toString()}
                toVersion={selectedUpdate.current_version.toString()}
                templateName={selectedUpdate.community_templates.name}
                permissionChanges={{
                  added: [],
                  removed: [],
                  changed: Object.keys(selectedUpdate.community_templates.permissions)
                }}
              />
            </div>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}