import { Mic, Square, Pause, Play } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface RecordingButtonProps {
  isRecording: boolean;
  isPaused: boolean;
  onStart: () => void;
  onStop: () => void;
  onPause: () => void;
  onResume: () => void;
}

export function RecordingButton({
  isRecording,
  isPaused,
  onStart,
  onStop,
  onPause,
  onResume
}: RecordingButtonProps) {
  if (!isRecording) {
    return (
      <Button
        onClick={onStart}
        size="lg"
        className="w-24 h-24 rounded-full bg-gradient-to-br from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 shadow-2xl hover:shadow-amber-500/50 transition-all duration-300 hover:scale-110"
      >
        <Mic className="w-10 h-10 text-white" />
      </Button>
    );
  }

  return (
    <div className="flex gap-4 items-center">
      <Button
        onClick={isPaused ? onResume : onPause}
        size="lg"
        className="w-16 h-16 rounded-full bg-amber-100 hover:bg-amber-200 text-amber-700"
      >
        {isPaused ? <Play className="w-6 h-6" /> : <Pause className="w-6 h-6" />}
      </Button>
      
      <Button
        onClick={onStop}
        size="lg"
        className="w-24 h-24 rounded-full bg-gradient-to-br from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 shadow-2xl hover:shadow-red-500/50 transition-all duration-300 animate-pulse"
      >
        <Square className="w-10 h-10 text-white fill-white" />
      </Button>
    </div>
  );
}
