import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BackupConfigModal } from './BackupConfigModal';
import { BackupHistoryView } from './BackupHistoryView';
import { RestoreBackupList } from './RestoreBackupList';
import { RestoreInterface } from './RestoreInterface';
import { SchedulerStatusPanel } from './SchedulerStatusPanel';
import { SchedulerSetupGuide } from './SchedulerSetupGuide';

import { BackupHistory } from '@/types/backup';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';



interface BackupManagementViewProps {
  isOpen: boolean;
  onClose: () => void;
  familyId: string;
}

export function BackupManagementView({ isOpen, onClose, familyId }: BackupManagementViewProps) {
  const [showConfigModal, setShowConfigModal] = useState(false);
  const [selectedBackup, setSelectedBackup] = useState<BackupHistory | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);

  const handleRefresh = () => {
    setRefreshKey(prev => prev + 1);
  };




  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Gestión de Respaldos Automáticos</DialogTitle>
          </DialogHeader>
          <Tabs defaultValue="history" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="history">Historial</TabsTrigger>
              <TabsTrigger value="restore">Restaurar</TabsTrigger>
              <TabsTrigger value="config">Configuración</TabsTrigger>
            </TabsList>

            <TabsContent value="history" className="space-y-4">
              <BackupHistoryView familyId={familyId} />
            </TabsContent>
            <TabsContent value="restore" className="space-y-4">
              {selectedBackup ? (
                <div>
                  <Button variant="ghost" onClick={() => setSelectedBackup(null)} className="mb-4">
                    ← Volver a la lista
                  </Button>
                  <RestoreInterface 
                    backup={selectedBackup} 
                    onRestoreComplete={() => setSelectedBackup(null)} 
                  />
                </div>
              ) : (
                <RestoreBackupList familyId={familyId} onSelectBackup={setSelectedBackup} />
              )}
            </TabsContent>

            <TabsContent value="config" className="space-y-4">
              <SchedulerStatusPanel 
                key={refreshKey} 
                familyId={familyId} 
                onRefresh={handleRefresh} 
              />
              <SchedulerSetupGuide />
              <div className="text-center py-4">
                <Button onClick={() => setShowConfigModal(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Configurar Nuevo Respaldo
                </Button>
              </div>

            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>

      <BackupConfigModal
        isOpen={showConfigModal}
        onClose={() => setShowConfigModal(false)}
        familyId={familyId}
        onSuccess={() => {
          setShowConfigModal(false);
          handleRefresh();
        }}

      />
    </>
  );
}
