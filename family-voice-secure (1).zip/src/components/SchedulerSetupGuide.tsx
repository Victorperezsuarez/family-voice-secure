import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Info, ExternalLink } from 'lucide-react';

export function SchedulerSetupGuide() {
  const functionUrl = 'https://iqrhacrtcgquvxmrlxnl.supabase.co/functions/v1/backup-scheduler';

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <Info className="h-5 w-5" />
          Automated Scheduler Setup
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Alert>
          <AlertDescription>
            To enable automatic backups, set up a cron job to call the scheduler endpoint every hour.
          </AlertDescription>
        </Alert>

        <div className="space-y-3">
          <div>
            <h4 className="font-semibold mb-2">Option 1: Cron-job.org (Easiest)</h4>
            <ol className="text-sm space-y-1 list-decimal list-inside text-muted-foreground">
              <li>Visit <a href="https://cron-job.org" target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline inline-flex items-center gap-1">cron-job.org <ExternalLink className="h-3 w-3" /></a></li>
              <li>Create a free account</li>
              <li>Add new cron job with URL: <code className="bg-muted px-1 rounded text-xs">{functionUrl}</code></li>
              <li>Set schedule to run every hour</li>
              <li>Method: POST</li>
            </ol>
          </div>

          <div>
            <h4 className="font-semibold mb-2">Option 2: GitHub Actions</h4>
            <p className="text-sm text-muted-foreground mb-2">
              Create a workflow file in your repository:
            </p>
            <pre className="bg-muted p-2 rounded text-xs overflow-x-auto">
{`name: Backup Scheduler
on:
  schedule:
    - cron: '0 * * * *'
jobs:
  trigger:
    runs-on: ubuntu-latest
    steps:
      - run: curl -X POST ${functionUrl}`}
            </pre>
          </div>

          <div>
            <h4 className="font-semibold mb-2">Option 3: Vercel Cron</h4>
            <p className="text-sm text-muted-foreground">
              If deployed on Vercel, add to <code className="bg-muted px-1 rounded">vercel.json</code>:
            </p>
            <pre className="bg-muted p-2 rounded text-xs overflow-x-auto">
{`{
  "crons": [{
    "path": "/api/trigger-backup",
    "schedule": "0 * * * *"
  }]
}`}
            </pre>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
