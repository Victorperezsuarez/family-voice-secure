import { useState, useEffect, useRef } from 'react';
import { supabase } from '@/lib/supabase-client';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Save, Users, History, Tag, MessageSquare, AlertTriangle } from 'lucide-react';
import { CollaborationSession } from '@/types/collaboration';
import { useToast } from '@/hooks/use-toast';
import { ConflictResolutionDialog } from './ConflictResolutionDialog';
import { detectConflicts, TextOperation, transform, applyOperation } from '@/utils/operationalTransform';

interface Props {
  recordingId: string;
  initialTranscription: string;
  onSave: (content: string) => void;
  onShowVersionHistory: () => void;
  onShowComments: () => void;
  onShowTags: () => void;
  onShowConflictHistory: () => void;
}


export default function CollaborativeTranscriptionEditor({
  recordingId,
  initialTranscription,
  onSave,
  onShowVersionHistory,
  onShowComments,
  onShowTags,
  onShowConflictHistory
}: Props) {
  const [content, setContent] = useState(initialTranscription);
  const [activeSessions, setActiveSessions] = useState<CollaborationSession[]>([]);
  const [cursorPosition, setCursorPosition] = useState(0);
  const [isSaving, setIsSaving] = useState(false);
  const [conflictDialogOpen, setConflictDialogOpen] = useState(false);
  const [currentConflict, setCurrentConflict] = useState<any>(null);
  const [pendingEdits, setPendingEdits] = useState<TextOperation[]>([]);
  const [hasUnresolvedConflicts, setHasUnresolvedConflicts] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const { toast } = useToast();
  const sessionIdRef = useRef<string | null>(null);
  const lastSavedContent = useRef(initialTranscription);


  useEffect(() => {
    const initSession = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data } = await supabase
        .from('collaboration_sessions')
        .upsert({
          recording_id: recordingId,
          user_id: user.id,
          is_active: true,
          last_activity: new Date().toISOString()
        }, { onConflict: 'recording_id,user_id' })
        .select()
        .single();

      if (data) sessionIdRef.current = data.id;
    };

    initSession();
    loadActiveSessions();

    const channel = supabase
      .channel(`recording:${recordingId}`)
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'collaboration_sessions',
        filter: `recording_id=eq.${recordingId}`
      }, loadActiveSessions)
      .subscribe();

    return () => {
      if (sessionIdRef.current) {
        supabase.from('collaboration_sessions')
          .update({ is_active: false })
          .eq('id', sessionIdRef.current)
          .then();
      }
      channel.unsubscribe();
    };
  }, [recordingId]);

  useEffect(() => {
    checkForConflicts();
    const conflictChannel = supabase
      .channel(`conflicts:${recordingId}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'transcription_conflicts',
        filter: `recording_id=eq.${recordingId}`
      }, handleNewConflict)
      .subscribe();

    return () => {
      supabase.removeChannel(conflictChannel);
    };
  }, [recordingId]);

  const checkForConflicts = async () => {
    const { data } = await supabase
      .from('transcription_conflicts')
      .select('*')
      .eq('recording_id', recordingId)
      .eq('resolved', false);
    
    setHasUnresolvedConflicts((data?.length || 0) > 0);
  };

  const handleNewConflict = (payload: any) => {
    toast({
      title: 'Conflict Detected',
      description: 'Another user edited the same section. Please resolve the conflict.',
      variant: 'destructive'
    });
    checkForConflicts();
  };

  const loadActiveSessions = async () => {
    const { data } = await supabase
      .from('collaboration_sessions')
      .select(`*, user:profiles(id, full_name, avatar_url)`)
      .eq('recording_id', recordingId)
      .eq('is_active', true);

    if (data) setActiveSessions(data as any);
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const conflicts = detectConflicts(lastSavedContent.current, content, content);
      
      if (conflicts.length > 0 && activeSessions.length > 1) {
        await supabase.from('transcription_conflicts').insert({
          recording_id: recordingId,
          user_a_id: user.id,
          user_b_id: activeSessions.find(s => s.user_id !== user.id)?.user_id,
          conflict_type: 'simultaneous_edit',
          conflict_range: conflicts[0],
          version_a_text: conflicts[0].textA,
          version_b_text: conflicts[0].textB
        });
        toast({ title: 'Conflict Detected', description: 'Please resolve conflicts before saving', variant: 'destructive' });
        return;
      }

      await onSave(content);
      lastSavedContent.current = content;
      toast({ title: 'Saved', description: 'Transcription updated successfully' });
    } catch (error) {
      toast({ title: 'Error', description: 'Failed to save', variant: 'destructive' });
    } finally {
      setIsSaving(false);
    }
  };

  const handleResolveConflict = async (conflictId: string, resolution: string, text?: string) => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    await supabase
      .from('transcription_conflicts')
      .update({
        resolved: true,
        resolution_type: resolution,
        resolved_text: text,
        resolved_by: user.id,
        resolved_at: new Date().toISOString()
      })
      .eq('id', conflictId);

    if (text) setContent(text);
    setConflictDialogOpen(false);
    checkForConflicts();
    toast({ title: 'Conflict Resolved', description: 'Changes have been applied' });
  };



  return (
    <>
      <div className="space-y-4">
        {hasUnresolvedConflicts && (
          <div className="flex items-center gap-2 p-3 bg-amber-50 border border-amber-200 rounded-lg">
            <AlertTriangle className="h-5 w-5 text-amber-600" />
            <span className="text-sm font-medium text-amber-900">
              Unresolved conflicts detected
            </span>
            <Button
              variant="outline"
              size="sm"
              className="ml-auto"
              onClick={onShowConflictHistory}
            >
              View Conflicts
            </Button>
          </div>
        )}

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            <span className="text-sm text-muted-foreground">
              {activeSessions.length} editing
            </span>
            <div className="flex -space-x-2">
              {activeSessions.slice(0, 3).map((session) => (
                <Avatar key={session.id} className="h-6 w-6 border-2 border-background">
                  <AvatarImage src={session.user?.avatar_url} />
                  <AvatarFallback>{session.user?.full_name?.[0]}</AvatarFallback>
                </Avatar>
              ))}
            </div>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={onShowTags}>
              <Tag className="h-4 w-4 mr-2" />
              Tags
            </Button>
            <Button variant="outline" size="sm" onClick={onShowComments}>
              <MessageSquare className="h-4 w-4 mr-2" />
              Comments
            </Button>
            <Button variant="outline" size="sm" onClick={onShowVersionHistory}>
              <History className="h-4 w-4 mr-2" />
              History
            </Button>
            <Button onClick={handleSave} disabled={isSaving}>
              <Save className="h-4 w-4 mr-2" />
              Save
            </Button>
          </div>
        </div>
        <Textarea
          ref={textareaRef}
          value={content}
          onChange={(e) => setContent(e.target.value)}
          onSelect={(e) => setCursorPosition(e.currentTarget.selectionStart)}
          className="min-h-[400px] font-mono"
          placeholder="Transcription will appear here..."
        />
      </div>

      <ConflictResolutionDialog
        open={conflictDialogOpen}
        onOpenChange={setConflictDialogOpen}
        conflict={currentConflict}
        onResolve={handleResolveConflict}
      />
    </>
  );
}

