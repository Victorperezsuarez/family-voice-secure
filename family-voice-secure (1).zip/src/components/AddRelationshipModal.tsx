import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { FamilyMember } from '@/types/familyTree';

interface AddRelationshipModalProps {
  isOpen: boolean;
  onClose: () => void;
  sourceMember: FamilyMember;
  availableMembers: FamilyMember[];
  onAdd: (type: string, targetId: string) => void;
}

export function AddRelationshipModal({
  isOpen,
  onClose,
  sourceMember,
  availableMembers,
  onAdd
}: AddRelationshipModalProps) {
  const [relationType, setRelationType] = useState<string>('');
  const [targetMemberId, setTargetMemberId] = useState<string>('');

  const handleSubmit = () => {
    if (relationType && targetMemberId) {
      onAdd(relationType, targetMemberId);
      setRelationType('');
      setTargetMemberId('');
      onClose();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add Relationship for {sourceMember.name}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Relationship Type</Label>
            <Select value={relationType} onValueChange={setRelationType}>
              <SelectTrigger>
                <SelectValue placeholder="Select type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="parent">Parent</SelectItem>
                <SelectItem value="child">Child</SelectItem>
                <SelectItem value="spouse">Spouse</SelectItem>
                <SelectItem value="sibling">Sibling</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Family Member</Label>
            <Select value={targetMemberId} onValueChange={setTargetMemberId}>
              <SelectTrigger>
                <SelectValue placeholder="Select member" />
              </SelectTrigger>
              <SelectContent>
                {availableMembers.map(member => (
                  <SelectItem key={member.id} value={member.id}>
                    {member.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <Button onClick={handleSubmit} className="w-full">Add Relationship</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
