import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Trash2 } from 'lucide-react';

interface ExperimentCreationDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onExperimentCreated: () => void;
}

export function ExperimentCreationDialog({ open, onOpenChange, onExperimentCreated }: ExperimentCreationDialogProps) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [experimentType, setExperimentType] = useState<'ab_test' | 'multivariate' | 'shadow_mode'>('ab_test');
  const [targetMetric, setTargetMetric] = useState('accuracy');
  const [controlFeatures, setControlFeatures] = useState<string[]>(['']);
  const [treatments, setTreatments] = useState<Array<{ name: string; features: string[] }>>([
    { name: 'Treatment A', features: [''] }
  ]);

  const addControlFeature = () => setControlFeatures([...controlFeatures, '']);
  const removeControlFeature = (index: number) => setControlFeatures(controlFeatures.filter((_, i) => i !== index));
  
  const addTreatment = () => setTreatments([...treatments, { name: `Treatment ${String.fromCharCode(65 + treatments.length)}`, features: [''] }]);
  const removeTreatment = (index: number) => setTreatments(treatments.filter((_, i) => i !== index));
  
  const addTreatmentFeature = (treatmentIndex: number) => {
    const updated = [...treatments];
    updated[treatmentIndex].features.push('');
    setTreatments(updated);
  };

  const handleSubmit = async () => {
    // Would call create-feature-experiment edge function
    console.log('Creating experiment:', { name, description, experimentType, targetMetric, controlFeatures, treatments });
    onExperimentCreated();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create Feature Experiment</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div>
            <Label>Experiment Name</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Time-series features vs derived features" />
          </div>
          
          <div>
            <Label>Description</Label>
            <Textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Compare model performance..." />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Experiment Type</Label>
              <Select value={experimentType} onValueChange={(v: any) => setExperimentType(v)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ab_test">A/B Test</SelectItem>
                  <SelectItem value="multivariate">Multivariate</SelectItem>
                  <SelectItem value="shadow_mode">Shadow Mode</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label>Target Metric</Label>
              <Select value={targetMetric} onValueChange={setTargetMetric}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="accuracy">Accuracy</SelectItem>
                  <SelectItem value="auc">AUC</SelectItem>
                  <SelectItem value="f1_score">F1 Score</SelectItem>
                  <SelectItem value="precision">Precision</SelectItem>
                  <SelectItem value="recall">Recall</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="border rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-semibold">Control Features</h4>
              <Button size="sm" variant="outline" onClick={addControlFeature}>
                <Plus className="h-4 w-4 mr-1" />
                Add Feature
              </Button>
            </div>
            {controlFeatures.map((feature, index) => (
              <div key={index} className="flex gap-2 mb-2">
                <Input 
                  value={feature} 
                  onChange={(e) => {
                    const updated = [...controlFeatures];
                    updated[index] = e.target.value;
                    setControlFeatures(updated);
                  }}
                  placeholder="feature_name"
                />
                <Button size="icon" variant="ghost" onClick={() => removeControlFeature(index)}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
          
          {treatments.map((treatment, tIndex) => (
            <div key={tIndex} className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <Input 
                  value={treatment.name} 
                  onChange={(e) => {
                    const updated = [...treatments];
                    updated[tIndex].name = e.target.value;
                    setTreatments(updated);
                  }}
                  className="w-48"
                />
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={() => addTreatmentFeature(tIndex)}>
                    <Plus className="h-4 w-4 mr-1" />
                    Add Feature
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => removeTreatment(tIndex)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              {treatment.features.map((feature, fIndex) => (
                <div key={fIndex} className="flex gap-2 mb-2">
                  <Input 
                    value={feature} 
                    onChange={(e) => {
                      const updated = [...treatments];
                      updated[tIndex].features[fIndex] = e.target.value;
                      setTreatments(updated);
                    }}
                    placeholder="feature_name"
                  />
                </div>
              ))}
            </div>
          ))}
          
          <Button onClick={addTreatment} variant="outline" className="w-full">
            <Plus className="h-4 w-4 mr-2" />
            Add Treatment Group
          </Button>
          
          <div className="flex justify-end gap-2 pt-4">
            <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button onClick={handleSubmit}>Create Experiment</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
