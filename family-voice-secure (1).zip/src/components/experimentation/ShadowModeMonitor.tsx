import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Eye, CheckCircle, XCircle, Clock } from 'lucide-react';
import { ShadowModeComputation } from '@/types/featureExperimentation';

interface ShadowModeMonitorProps {
  configId: string;
}

export function ShadowModeMonitor({ configId }: ShadowModeMonitorProps) {
  const [computations, setComputations] = useState<ShadowModeComputation[]>([]);
  const [stats, setStats] = useState({
    totalComputations: 0,
    avgComputationTime: 0,
    avgError: 0,
    successRate: 0
  });

  useEffect(() => {
    // Mock data - would fetch from shadow_mode_computations table
    const mockComputations: ShadowModeComputation[] = Array.from({ length: 50 }, (_, i) => ({
      id: `comp-${i}`,
      config_id: configId,
      user_id: `user-${i}`,
      feature_values: { feature1: Math.random(), feature2: Math.random() },
      prediction_value: Math.random() * 100,
      actual_value: Math.random() * 100,
      error_metric: Math.random() * 10,
      computation_time_ms: Math.floor(Math.random() * 100) + 20,
      computed_at: new Date(Date.now() - Math.random() * 86400000).toISOString()
    }));

    setComputations(mockComputations);

    const totalTime = mockComputations.reduce((sum, c) => sum + c.computation_time_ms, 0);
    const totalError = mockComputations.reduce((sum, c) => sum + (c.error_metric || 0), 0);
    const successful = mockComputations.filter(c => (c.error_metric || 0) < 5).length;

    setStats({
      totalComputations: mockComputations.length,
      avgComputationTime: totalTime / mockComputations.length,
      avgError: totalError / mockComputations.length,
      successRate: (successful / mockComputations.length) * 100
    });
  }, [configId]);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Computations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalComputations}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Avg Computation Time</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.avgComputationTime.toFixed(1)}ms</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Avg Error</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.avgError.toFixed(2)}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Success Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.successRate.toFixed(1)}%</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Eye className="h-5 w-5" />
            Shadow Computations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {computations.slice(0, 10).map((comp) => {
              const isSuccess = (comp.error_metric || 0) < 5;
              
              return (
                <div key={comp.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    {isSuccess ? (
                      <CheckCircle className="h-4 w-4 text-green-500" />
                    ) : (
                      <XCircle className="h-4 w-4 text-red-500" />
                    )}
                    <div>
                      <div className="text-sm font-medium">User {comp.user_id?.slice(-8)}</div>
                      <div className="text-xs text-muted-foreground">
                        Error: {comp.error_metric?.toFixed(2)} | Time: {comp.computation_time_ms}ms
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm">
                      Pred: {comp.prediction_value?.toFixed(2)}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Actual: {comp.actual_value?.toFixed(2)}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Validation Progress</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Sample Size</span>
                <span>{stats.totalComputations} / 1000</span>
              </div>
              <Progress value={(stats.totalComputations / 1000) * 100} />
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Success Rate Target</span>
                <span>{stats.successRate.toFixed(1)}% / 95%</span>
              </div>
              <Progress value={(stats.successRate / 95) * 100} className="bg-green-100" />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
