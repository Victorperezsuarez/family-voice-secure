import { Family } from '@/types/family';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Users, Mic, Settings } from 'lucide-react';

interface FamilyDashboardCardProps {
  family: Family;
  recordingCount: number;
  memberCount: number;
  role: string;
  onSelect: () => void;
  onSettings: () => void;
}

export function FamilyDashboardCard({
  family,
  recordingCount,
  memberCount,
  role,
  onSelect,
  onSettings
}: FamilyDashboardCardProps) {
  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <CardTitle>{family.name}</CardTitle>
            <CardDescription className="mt-1">
              {family.description || 'No description'}
            </CardDescription>
          </div>
          <Badge variant={role === 'admin' ? 'default' : 'secondary'}>
            {role}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex items-center gap-4 mb-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-1">
            <Mic className="h-4 w-4" />
            <span>{recordingCount} recordings</span>
          </div>
          <div className="flex items-center gap-1">
            <Users className="h-4 w-4" />
            <span>{memberCount} members</span>
          </div>
        </div>
        <div className="flex gap-2">
          <Button onClick={onSelect} className="flex-1">
            View Family
          </Button>
          {role === 'admin' && (
            <Button onClick={onSettings} variant="outline" size="icon">
              <Settings className="h-4 w-4" />
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
