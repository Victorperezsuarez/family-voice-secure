import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { AlertTriangle, Check, GitMerge, User } from 'lucide-react';

interface ConflictData {
  id: string;
  recordingId: string;
  conflictType: string;
  conflictRange: { start: number; end: number };
  versionAText: string;
  versionBText: string;
  userA: { id: string; name: string; avatar?: string };
  userB: { id: string; name: string; avatar?: string };
  createdAt: string;
}

interface ConflictResolutionDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  conflict: ConflictData | null;
  onResolve: (conflictId: string, resolution: 'keep_a' | 'keep_b' | 'manual_merge', text?: string) => Promise<void>;
}

export function ConflictResolutionDialog({
  open,
  onOpenChange,
  conflict,
  onResolve,
}: ConflictResolutionDialogProps) {
  const [resolution, setResolution] = useState<'keep_a' | 'keep_b' | 'manual_merge' | null>(null);
  const [mergedText, setMergedText] = useState('');
  const [loading, setLoading] = useState(false);

  if (!conflict) return null;

  const handleResolve = async () => {
    if (!resolution) return;
    
    setLoading(true);
    try {
      await onResolve(
        conflict.id,
        resolution,
        resolution === 'manual_merge' ? mergedText : undefined
      );
      onOpenChange(false);
    } catch (error) {
      console.error('Failed to resolve conflict:', error);
    } finally {
      setLoading(false);
    }
  };

  const getDiffHighlight = (text: string, isSelected: boolean) => {
    return (
      <div className={`p-4 rounded-lg border-2 transition-all ${
        isSelected 
          ? 'border-blue-500 bg-blue-50' 
          : 'border-gray-200 bg-gray-50'
      }`}>
        <pre className="whitespace-pre-wrap font-mono text-sm">{text}</pre>
      </div>
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-amber-500" />
            Transcription Conflict Detected
          </DialogTitle>
        </DialogHeader>

        <Alert>
          <AlertDescription>
            Multiple users edited the same section simultaneously. Choose which version to keep or merge them manually.
          </AlertDescription>
        </Alert>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Badge variant="outline">{conflict.conflictType.replace('_', ' ')}</Badge>
            <span className="text-sm text-muted-foreground">
              Position: {conflict.conflictRange.start} - {conflict.conflictRange.end}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={conflict.userA.avatar} />
                  <AvatarFallback>
                    <User className="h-4 w-4" />
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium text-sm">{conflict.userA.name}</p>
                  <p className="text-xs text-muted-foreground">Version A</p>
                </div>
              </div>
              <div onClick={() => setResolution('keep_a')} className="cursor-pointer">
                {getDiffHighlight(conflict.versionAText, resolution === 'keep_a')}
              </div>
              <Button
                variant={resolution === 'keep_a' ? 'default' : 'outline'}
                size="sm"
                className="w-full"
                onClick={() => setResolution('keep_a')}
              >
                <Check className="h-4 w-4 mr-2" />
                Keep This Version
              </Button>
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={conflict.userB.avatar} />
                  <AvatarFallback>
                    <User className="h-4 w-4" />
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium text-sm">{conflict.userB.name}</p>
                  <p className="text-xs text-muted-foreground">Version B</p>
                </div>
              </div>
              <div onClick={() => setResolution('keep_b')} className="cursor-pointer">
                {getDiffHighlight(conflict.versionBText, resolution === 'keep_b')}
              </div>
              <Button
                variant={resolution === 'keep_b' ? 'default' : 'outline'}
                size="sm"
                className="w-full"
                onClick={() => setResolution('keep_b')}
              >
                <Check className="h-4 w-4 mr-2" />
                Keep This Version
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <Button
              variant={resolution === 'manual_merge' ? 'default' : 'outline'}
              size="sm"
              className="w-full"
              onClick={() => {
                setResolution('manual_merge');
                setMergedText(conflict.versionAText + ' ' + conflict.versionBText);
              }}
            >
              <GitMerge className="h-4 w-4 mr-2" />
              Merge Manually
            </Button>

            {resolution === 'manual_merge' && (
              <Textarea
                value={mergedText}
                onChange={(e) => setMergedText(e.target.value)}
                placeholder="Edit and merge both versions..."
                className="min-h-[120px] font-mono text-sm"
              />
            )}
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleResolve} disabled={!resolution || loading}>
            {loading ? 'Resolving...' : 'Resolve Conflict'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
