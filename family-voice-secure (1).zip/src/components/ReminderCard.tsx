import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Calendar, Bell, Mail, MessageSquare, Edit, Trash2 } from 'lucide-react';
import { Reminder } from '@/types/reminder';
import { format } from 'date-fns';

interface ReminderCardProps {
  reminder: Reminder;
  onEdit: (reminder: Reminder) => void;
  onDelete: (id: string) => void;
  onSendNow: (reminder: Reminder) => void;
}

export function ReminderCard({ reminder, onEdit, onDelete, onSendNow }: ReminderCardProps) {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-lg">{reminder.occasion}</CardTitle>
            <div className="flex gap-2 mt-2">
              <Badge variant="outline">{reminder.occasion_type}</Badge>
              <Badge variant="secondary">{reminder.recurrence}</Badge>
              {!reminder.is_active && <Badge variant="destructive">Inactive</Badge>}
            </div>
          </div>
          <div className="flex gap-1">
            <Button size="icon" variant="ghost" onClick={() => onEdit(reminder)}>
              <Edit className="h-4 w-4" />
            </Button>
            <Button size="icon" variant="ghost" onClick={() => onDelete(reminder.id)}>
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center gap-2 text-sm">
          <Calendar className="h-4 w-4" />
          <span>{format(new Date(reminder.occasion_date), 'MMMM d, yyyy')}</span>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <Bell className="h-4 w-4" />
          <span>Remind {reminder.reminder_days_before} days before</span>
        </div>
        <div className="flex gap-2 text-sm">
          {reminder.send_email && <Mail className="h-4 w-4" />}
          {reminder.send_sms && <MessageSquare className="h-4 w-4" />}
        </div>
        {reminder.suggested_topics.length > 0 && (
          <div className="mt-3">
            <p className="text-sm font-medium mb-1">Suggested Topics:</p>
            <ul className="text-sm text-muted-foreground space-y-1">
              {reminder.suggested_topics.slice(0, 3).map((topic, idx) => (
                <li key={idx}>• {topic}</li>
              ))}
            </ul>
          </div>
        )}
        <Button size="sm" className="w-full mt-3" onClick={() => onSendNow(reminder)}>
          Send Reminder Now
        </Button>
      </CardContent>
    </Card>
  );
}
