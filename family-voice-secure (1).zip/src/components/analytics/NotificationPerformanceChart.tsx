import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/lib/supabase-client';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export function NotificationPerformanceChart() {
  const [chartData, setChartData] = useState<any[]>([]);

  useEffect(() => {
    loadChartData();
  }, []);

  const loadChartData = async () => {
    try {
      const { data: analytics } = await supabase
        .from('notification_analytics')
        .select('*')
        .gte('sent_at', new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString())
        .order('sent_at', { ascending: true });

      if (analytics) {
        const dailyData = analytics.reduce((acc: any, curr: any) => {
          const date = new Date(curr.sent_at).toISOString().split('T')[0];
          if (!acc[date]) {
            acc[date] = {
              date,
              sent: 0,
              delivered: 0,
              clicked: 0,
              actions: 0,
              conversions: 0
            };
          }
          acc[date].sent++;
          if (curr.delivered_at) acc[date].delivered++;
          if (curr.clicked_at) acc[date].clicked++;
          if (curr.action_taken) acc[date].actions++;
          if (curr.conversion_completed) acc[date].conversions++;
          return acc;
        }, {});

        const formattedData = Object.values(dailyData).map((day: any) => ({
          ...day,
          deliveryRate: day.sent > 0 ? (day.delivered / day.sent) * 100 : 0,
          clickRate: day.delivered > 0 ? (day.clicked / day.delivered) * 100 : 0,
          actionRate: day.clicked > 0 ? (day.actions / day.clicked) * 100 : 0,
          conversionRate: day.actions > 0 ? (day.conversions / day.actions) * 100 : 0
        }));

        setChartData(formattedData);
      }
    } catch (error) {
      console.error('Error loading chart data:', error);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Notification Performance Over Time (Last 30 Days)</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={400}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="deliveryRate" stroke="#8884d8" name="Delivery Rate %" />
            <Line type="monotone" dataKey="clickRate" stroke="#82ca9d" name="Click Rate %" />
            <Line type="monotone" dataKey="actionRate" stroke="#ffc658" name="Action Rate %" />
            <Line type="monotone" dataKey="conversionRate" stroke="#ff7c7c" name="Conversion Rate %" />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
