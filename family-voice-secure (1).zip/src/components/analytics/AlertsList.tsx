import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { AlertCircle, CheckCircle, Info } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface Alert {
  id: string;
  alert_type: string;
  message: string;
  severity: string;
  current_value: number;
  threshold_value: number;
  is_read: boolean;
  triggered_at: string;
}

interface AlertsListProps {
  alerts: Alert[];
  onMarkAsRead: (id: string) => void;
}

export function AlertsList({ alerts, onMarkAsRead }: AlertsListProps) {
  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'critical':
        return <AlertCircle className="w-5 h-5 text-red-500" />;
      case 'warning':
        return <AlertCircle className="w-5 h-5 text-yellow-500" />;
      default:
        return <Info className="w-5 h-5 text-blue-500" />;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':
        return 'destructive';
      case 'warning':
        return 'default';
      default:
        return 'secondary';
    }
  };

  return (
    <ScrollArea className="h-[500px]">
      <div className="space-y-3">
        {alerts.map((alert) => (
          <Card key={alert.id} className={`p-4 ${!alert.is_read ? 'border-l-4 border-l-primary' : ''}`}>
            <div className="flex items-start gap-3">
              {getSeverityIcon(alert.severity)}
              <div className="flex-1">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <p className="font-medium">{alert.message}</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      {formatDistanceToNow(new Date(alert.triggered_at), { addSuffix: true })}
                    </p>
                  </div>
                  <Badge variant={getSeverityColor(alert.severity) as any}>
                    {alert.severity}
                  </Badge>
                </div>
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <span>Current: {alert.current_value}</span>
                  <span>Threshold: {alert.threshold_value}</span>
                </div>
                {!alert.is_read && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="mt-2"
                    onClick={() => onMarkAsRead(alert.id)}
                  >
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Mark as Read
                  </Button>
                )}
              </div>
            </div>
          </Card>
        ))}
        {alerts.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            No alerts to display
          </div>
        )}
      </div>
    </ScrollArea>
  );
}