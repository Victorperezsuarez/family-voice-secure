import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Activity, User, Download, Eye } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface LiveActivityFeedProps {
  events: any[];
  isLive: boolean;
}

export default function LiveActivityFeed({ events, isLive }: LiveActivityFeedProps) {
  const getEventIcon = (eventType: string) => {
    switch (eventType) {
      case 'install': return <Download className="w-4 h-4" />;
      case 'view': return <Eye className="w-4 h-4" />;
      case 'feature_use': return <Activity className="w-4 h-4" />;
      default: return <User className="w-4 h-4" />;
    }
  };

  const getEventColor = (eventType: string) => {
    switch (eventType) {
      case 'install': return 'bg-green-500';
      case 'view': return 'bg-blue-500';
      case 'feature_use': return 'bg-purple-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">Live Activity Feed</CardTitle>
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${isLive ? 'bg-green-500 animate-pulse' : 'bg-gray-400'}`} />
            <span className="text-sm text-muted-foreground">
              {isLive ? 'Live' : 'Offline'}
            </span>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3 max-h-96 overflow-y-auto">
          {events.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-8">
              No recent activity
            </p>
          ) : (
            events.map((event, idx) => (
              <div key={event.id || idx} className="flex items-start gap-3 p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors">
                <div className={`p-2 rounded-full ${getEventColor(event.event_type)} text-white`}>
                  {getEventIcon(event.event_type)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-xs">
                      {event.event_type}
                    </Badge>
                    {event.country_code && (
                      <span className="text-xs text-muted-foreground">
                        {event.country_code}
                      </span>
                    )}
                  </div>
                  {event.feature_name && (
                    <p className="text-sm mt-1">Feature: {event.feature_name}</p>
                  )}
                  <p className="text-xs text-muted-foreground mt-1">
                    {formatDistanceToNow(new Date(event.created_at), { addSuffix: true })}
                  </p>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
