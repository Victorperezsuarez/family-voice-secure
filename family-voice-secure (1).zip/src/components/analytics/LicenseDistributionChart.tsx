import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface LicenseDistributionChartProps {
  data: {
    personal: number;
    commercial: number;
    enterprise: number;
  };
}

const COLORS = ['#3b82f6', '#8b5cf6', '#10b981'];

export default function LicenseDistributionChart({ data }: LicenseDistributionChartProps) {
  const chartData = [
    { name: 'Personal', value: data.personal },
    { name: 'Commercial', value: data.commercial },
    { name: 'Enterprise', value: data.enterprise }
  ].filter(item => item.value > 0);

  return (
    <Card>
      <CardHeader>
        <CardTitle>License Distribution</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie data={chartData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
              {chartData.map((_, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
