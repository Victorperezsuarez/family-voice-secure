import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/lib/supabase-client';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

export function ActionButtonAnalytics() {
  const [actionData, setActionData] = useState<any[]>([]);
  const [suggestionTypeData, setSuggestionTypeData] = useState<any[]>([]);

  useEffect(() => {
    loadActionAnalytics();
  }, []);

  const loadActionAnalytics = async () => {
    try {
      const { data: analytics } = await supabase
        .from('notification_analytics')
        .select('*')
        .not('action_taken', 'is', null);

      if (analytics) {
        // Action breakdown
        const actionCounts: Record<string, number> = {};
        analytics.forEach((item: any) => {
          const action = item.action_taken;
          actionCounts[action] = (actionCounts[action] || 0) + 1;
        });

        const formattedActions = Object.entries(actionCounts).map(([name, value]) => ({
          name: name.charAt(0).toUpperCase() + name.slice(1).replace('_', ' '),
          value
        }));

        setActionData(formattedActions);

        // Suggestion type breakdown
        const typeCounts: Record<string, any> = {};
        analytics.forEach((item: any) => {
          const type = item.suggestion_type || 'Unknown';
          if (!typeCounts[type]) {
            typeCounts[type] = { accept: 0, snooze: 0, view_details: 0, dismiss: 0 };
          }
          typeCounts[type][item.action_taken]++;
        });

        const formattedTypes = Object.entries(typeCounts).map(([name, actions]: [string, any]) => ({
          name,
          Accept: actions.accept || 0,
          Snooze: actions.snooze || 0,
          'View Details': actions.view_details || 0,
          Dismiss: actions.dismiss || 0
        }));

        setSuggestionTypeData(formattedTypes);
      }
    } catch (error) {
      console.error('Error loading action analytics:', error);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card>
        <CardHeader>
          <CardTitle>Action Button Usage</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={actionData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {actionData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Actions by Suggestion Type</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={suggestionTypeData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="Accept" fill="#00C49F" />
              <Bar dataKey="Snooze" fill="#FFBB28" />
              <Bar dataKey="View Details" fill="#0088FE" />
              <Bar dataKey="Dismiss" fill="#FF8042" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}
