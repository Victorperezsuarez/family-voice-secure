import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface BaselineDataPoint {
  date: string;
  mean: number;
  upperBound: number;
  lowerBound: number;
  confidence: number;
}

interface Props {
  data: BaselineDataPoint[];
}

export const BaselineTrendsChart: React.FC<Props> = ({ data }) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Baseline Trends</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Area type="monotone" dataKey="upperBound" stackId="1" stroke="#93c5fd" fill="#dbeafe" name="Upper Bound" />
            <Area type="monotone" dataKey="mean" stackId="2" stroke="#3b82f6" fill="#3b82f6" name="Mean" />
            <Area type="monotone" dataKey="lowerBound" stackId="1" stroke="#93c5fd" fill="#dbeafe" name="Lower Bound" />
          </AreaChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
};
