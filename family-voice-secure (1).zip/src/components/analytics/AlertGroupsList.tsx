import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { CheckCircle, AlertTriangle, Info, ChevronDown, ChevronUp } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';
import { useState } from 'react';
import { AlertCorrelationGraph } from './AlertCorrelationGraph';

interface AlertGroupsListProps {
  groups: any[];
  onUpdate: () => void;
}

export function AlertGroupsList({ groups, onUpdate }: AlertGroupsListProps) {
  const [expandedGroup, setExpandedGroup] = useState<string | null>(null);

  const handleAcknowledge = async (groupId: string) => {
    try {
      const { error } = await supabase
        .from('alert_groups')
        .update({ 
          status: 'acknowledged',
          acknowledged_at: new Date().toISOString()
        })
        .eq('id', groupId);
      if (error) throw error;
      toast.success('Alert group acknowledged');
      onUpdate();
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  const handleResolve = async (groupId: string) => {
    try {
      const { error } = await supabase
        .from('alert_groups')
        .update({ 
          status: 'resolved',
          resolved_at: new Date().toISOString()
        })
        .eq('id', groupId);
      if (error) throw error;
      toast.success('Alert group resolved');
      onUpdate();
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  const severityIcons = {
    info: <Info className="h-4 w-4" />,
    warning: <AlertTriangle className="h-4 w-4" />,
    critical: <AlertTriangle className="h-4 w-4" />
  };

  const severityColors = {
    info: 'bg-blue-500',
    warning: 'bg-yellow-500',
    critical: 'bg-red-500'
  };

  if (groups.length === 0) {
    return <p className="text-muted-foreground">No active alert groups</p>;
  }

  return (
    <div className="space-y-4">
      {groups.map(group => (
        <Card key={group.id}>
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="space-y-1">
                <CardTitle className="text-base">{group.group_name}</CardTitle>
                <div className="flex gap-2 flex-wrap">
                  <Badge className={severityColors[group.severity as keyof typeof severityColors]}>
                    {severityIcons[group.severity as keyof typeof severityIcons]}
                    <span className="ml-1">{group.severity}</span>
                  </Badge>
                  <Badge variant="outline">{group.group_type}</Badge>
                  <Badge variant="secondary">{group.alert_count} alerts</Badge>
                </div>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setExpandedGroup(expandedGroup === group.id ? null : group.id)}
              >
                {expandedGroup === group.id ? <ChevronUp /> : <ChevronDown />}
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                <p>First alert: {new Date(group.first_alert_at).toLocaleString()}</p>
                <p>Last alert: {new Date(group.last_alert_at).toLocaleString()}</p>
              </div>

              {group.root_cause_reasoning && (
                <div className="bg-muted p-3 rounded-lg">
                  <p className="text-sm font-medium mb-1">Root Cause Analysis</p>
                  <p className="text-sm text-muted-foreground">{group.root_cause_reasoning}</p>
                  {group.root_cause_confidence && (
                    <p className="text-xs text-muted-foreground mt-1">
                      Confidence: {(group.root_cause_confidence * 100).toFixed(0)}%
                    </p>
                  )}
                </div>
              )}

              {expandedGroup === group.id && (
                <AlertCorrelationGraph groupId={group.id} />
              )}

              <div className="flex gap-2">
                {group.status === 'active' && (
                  <Button size="sm" variant="outline" onClick={() => handleAcknowledge(group.id)}>
                    <CheckCircle className="h-3 w-3 mr-1" />
                    Acknowledge
                  </Button>
                )}
                {group.status !== 'resolved' && (
                  <Button size="sm" onClick={() => handleResolve(group.id)}>
                    Resolve
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}