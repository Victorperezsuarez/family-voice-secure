import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Trash2 } from 'lucide-react';

interface ConditionRule {
  metric: string;
  operator: string;
  threshold: number;
}

interface AdvancedConditionBuilderProps {
  conditionType: string;
  onConditionChange: (config: any) => void;
}

export default function AdvancedConditionBuilder({ conditionType, onConditionChange }: AdvancedConditionBuilderProps) {
  const [percentageThreshold, setPercentageThreshold] = useState(20);
  const [comparisonPeriod, setComparisonPeriod] = useState('week');
  const [combinedRules, setCombinedRules] = useState<ConditionRule[]>([{ metric: 'installs', operator: '>=', threshold: 100 }]);
  const [combinedOperator, setCombinedOperator] = useState('AND');
  const [customFormula, setCustomFormula] = useState('current > 100 && current < 1000');

  const handlePercentageChange = (value: number) => {
    setPercentageThreshold(value);
    onConditionChange({ percentage_threshold: value });
  };

  const handleComparisonChange = (period: string) => {
    setComparisonPeriod(period);
    onConditionChange({ comparison_period: period, percentage_threshold: percentageThreshold });
  };

  const handleAddRule = () => {
    const newRules = [...combinedRules, { metric: 'installs', operator: '>=', threshold: 0 }];
    setCombinedRules(newRules);
    onConditionChange({ combined_conditions: { operator: combinedOperator, rules: newRules } });
  };

  const handleRemoveRule = (index: number) => {
    const newRules = combinedRules.filter((_, i) => i !== index);
    setCombinedRules(newRules);
    onConditionChange({ combined_conditions: { operator: combinedOperator, rules: newRules } });
  };

  const handleRuleChange = (index: number, field: string, value: any) => {
    const newRules = [...combinedRules];
    newRules[index] = { ...newRules[index], [field]: value };
    setCombinedRules(newRules);
    onConditionChange({ combined_conditions: { operator: combinedOperator, rules: newRules } });
  };

  if (conditionType === 'percentage') {
    return (
      <div className="space-y-4">
        <div>
          <Label>Percentage Change Threshold</Label>
          <div className="flex items-center gap-2">
            <Input
              type="number"
              value={percentageThreshold}
              onChange={(e) => handlePercentageChange(Number(e.target.value))}
              min={1}
              max={1000}
            />
            <span className="text-sm text-muted-foreground">%</span>
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            Alert when metric changes by this percentage
          </p>
        </div>
      </div>
    );
  }

  if (conditionType === 'comparison') {
    return (
      <div className="space-y-4">
        <div>
          <Label>Compare To</Label>
          <Select value={comparisonPeriod} onValueChange={handleComparisonChange}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="hour">Previous Hour</SelectItem>
              <SelectItem value="day">Previous Day</SelectItem>
              <SelectItem value="week">Previous Week</SelectItem>
              <SelectItem value="month">Previous Month</SelectItem>
              <SelectItem value="quarter">Previous Quarter</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Minimum Increase (%)</Label>
          <Input
            type="number"
            value={percentageThreshold}
            onChange={(e) => setPercentageThreshold(Number(e.target.value))}
            min={1}
          />
        </div>
      </div>
    );
  }

  if (conditionType === 'combined') {
    return (
      <div className="space-y-4">
        <div>
          <Label>Logic Operator</Label>
          <Select value={combinedOperator} onValueChange={(v) => {
            setCombinedOperator(v);
            onConditionChange({ combined_conditions: { operator: v, rules: combinedRules } });
          }}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="AND">AND (all must be true)</SelectItem>
              <SelectItem value="OR">OR (any can be true)</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>Conditions</Label>
          {combinedRules.map((rule, index) => (
            <div key={index} className="flex items-center gap-2">
              <Input
                placeholder="Metric"
                value={rule.metric}
                onChange={(e) => handleRuleChange(index, 'metric', e.target.value)}
                className="flex-1"
              />
              <Select value={rule.operator} onValueChange={(v) => handleRuleChange(index, 'operator', v)}>
                <SelectTrigger className="w-24">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value=">=">&gt;=</SelectItem>
                  <SelectItem value="<=">&lt;=</SelectItem>
                  <SelectItem value=">">&gt;</SelectItem>
                  <SelectItem value="<">&lt;</SelectItem>
                </SelectContent>
              </Select>
              <Input
                type="number"
                value={rule.threshold}
                onChange={(e) => handleRuleChange(index, 'threshold', Number(e.target.value))}
                className="w-24"
              />
              <Button variant="ghost" size="icon" onClick={() => handleRemoveRule(index)}>
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          ))}
          <Button variant="outline" size="sm" onClick={handleAddRule}>
            <Plus className="h-4 w-4 mr-2" />
            Add Condition
          </Button>
        </div>
      </div>
    );
  }

  if (conditionType === 'formula') {
    return (
      <div className="space-y-4">
        <div>
          <Label>Custom Formula</Label>
          <Textarea
            value={customFormula}
            onChange={(e) => {
              setCustomFormula(e.target.value);
              onConditionChange({ custom_formula: e.target.value });
            }}
            placeholder="current > 100 && current < 1000"
            rows={4}
          />
          <p className="text-xs text-muted-foreground mt-1">
            Use 'current' to reference the current metric value. Example: current &gt; 100 &amp;&amp; current &lt; 1000
          </p>
        </div>
      </div>
    );
  }

  return null;
}