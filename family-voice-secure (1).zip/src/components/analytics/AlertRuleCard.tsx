import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Bell, Mail, Trash2, TrendingUp, Clock, Brain, Calendar, Settings } from 'lucide-react';


interface AlertRuleCardProps {
  rule: {
    id: string;
    rule_type: string;
    metric: string;
    threshold_value: number;
    comparison_operator: string;
    is_active: boolean;
    notification_channels: string[];
    last_triggered_at?: string;
    condition_type?: string;
    percentage_threshold?: number;
    comparison_period?: string;
    cooldown_minutes?: number;
    smart_threshold_enabled?: boolean;
    baseline_value?: number;
    schedule_enabled?: boolean;
    timezone?: string;
    business_hours_only?: boolean;
    weekdays_only?: boolean;
  };
  onToggle: (id: string, active: boolean) => void;
  onDelete: (id: string) => void;
  onScheduleClick?: (id: string) => void;
}


export function AlertRuleCard({ rule, onToggle, onDelete, onScheduleClick }: AlertRuleCardProps) {

  const ruleTypeLabels: Record<string, string> = {
    install_threshold: 'Install Threshold',
    usage_spike: 'Usage Spike',
    license_violation: 'License Violation',
    conversion_milestone: 'Conversion Milestone',
    feature_adoption: 'Feature Adoption'
  };

  const conditionTypeLabels: Record<string, string> = {
    simple: 'Simple',
    percentage: 'Percentage Change',
    comparison: 'Time Comparison',
    combined: 'Combined Logic',
    formula: 'Custom Formula'
  };

  const getConditionDescription = () => {
    if (rule.condition_type === 'percentage') {
      return `Alert when ${rule.metric} changes by ${rule.percentage_threshold}%`;
    } else if (rule.condition_type === 'comparison') {
      return `Alert when ${rule.metric} increases vs. last ${rule.comparison_period}`;
    } else if (rule.condition_type === 'combined') {
      return `Alert when combined conditions are met`;
    } else if (rule.condition_type === 'formula') {
      return `Alert based on custom formula`;
    }
    return `Alert when ${rule.metric} ${rule.comparison_operator.replace('_', ' ')} ${rule.threshold_value}`;
  };

  return (
    <Card className="p-4">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            <h4 className="font-semibold">{ruleTypeLabels[rule.rule_type]}</h4>
            <Badge variant={rule.is_active ? 'default' : 'secondary'}>
              {rule.is_active ? 'Active' : 'Inactive'}
            </Badge>
            {rule.condition_type && rule.condition_type !== 'simple' && (
              <Badge variant="outline" className="text-xs">
                <TrendingUp className="w-3 h-3 mr-1" />
                {conditionTypeLabels[rule.condition_type]}
              </Badge>
            )}
            {rule.smart_threshold_enabled && (
              <Badge variant="outline" className="text-xs">
                <Brain className="w-3 h-3 mr-1" />
                Smart
              </Badge>
            )}
            {rule.schedule_enabled && (

              <Badge variant="outline" className="text-xs">
                <Calendar className="w-3 h-3 mr-1" />
                Scheduled
              </Badge>
            )}
          </div>
          <p className="text-sm text-muted-foreground mb-2">
            {getConditionDescription()}
          </p>
          <div className="flex items-center gap-3 text-xs text-muted-foreground">
            <div className="flex items-center gap-1">
              {rule.notification_channels.includes('email') && <Mail className="w-3 h-3" />}
              {rule.notification_channels.includes('in_app') && <Bell className="w-3 h-3" />}
              <span>{rule.notification_channels.join(', ')}</span>
            </div>
            {rule.cooldown_minutes && (
              <div className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                <span>{rule.cooldown_minutes}m cooldown</span>
              </div>
            )}
            {rule.schedule_enabled && (
              <div className="flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                <span>{rule.timezone || 'UTC'}</span>
                {rule.weekdays_only && <span>• Weekdays</span>}
                {rule.business_hours_only && <span>• Business hrs</span>}
              </div>
            )}
            {rule.last_triggered_at && (
              <span>Last: {new Date(rule.last_triggered_at).toLocaleDateString()}</span>
            )}
          </div>
          {rule.smart_threshold_enabled && rule.baseline_value && (
            <p className="text-xs text-muted-foreground mt-1">
              Smart baseline: {rule.baseline_value}
            </p>
          )}

        </div>
        <div className="flex items-center gap-2">
          {onScheduleClick && (
            <Button
              variant="outline"
              size="icon"
              onClick={() => onScheduleClick(rule.id)}
              title="Schedule Settings"
            >
              <Settings className="w-4 h-4" />
            </Button>
          )}
          <Switch
            checked={rule.is_active}
            onCheckedChange={(checked) => onToggle(rule.id, checked)}
          />
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onDelete(rule.id)}
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>

      </div>
    </Card>
  );
}
