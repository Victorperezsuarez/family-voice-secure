import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Brain, TrendingUp, AlertTriangle, CheckCircle, RefreshCw } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';

interface AnomalyDetectionPanelProps {
  templateId: string;
}

export default function AnomalyDetectionPanel({ templateId }: AnomalyDetectionPanelProps) {
  const [config, setConfig] = useState<any>(null);
  const [baselines, setBaselines] = useState<any[]>([]);
  const [anomalies, setAnomalies] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadConfig();
    loadBaselines();
    loadAnomalies();
  }, [templateId]);

  const loadConfig = async () => {
    const { data } = await supabase
      .from('anomaly_detection_configs')
      .select('*')
      .eq('template_id', templateId)
      .single();
    setConfig(data);
  };

  const loadBaselines = async () => {
    const { data } = await supabase
      .from('alert_baselines')
      .select('*')
      .eq('template_id', templateId)
      .order('created_at', { ascending: false });
    setBaselines(data || []);
  };

  const loadAnomalies = async () => {
    const { data } = await supabase
      .from('alert_anomalies')
      .select('*')
      .eq('template_id', templateId)
      .order('detected_at', { ascending: false })
      .limit(20);
    setAnomalies(data || []);
  };

  const runBaselineLearning = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('learn-alert-baselines', {
        body: { templateId, metricName: 'default', learningPeriodDays: 30 }
      });
      if (error) throw error;
      toast.success('Baseline learning completed');
      loadBaselines();
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const toggleEnabled = async (enabled: boolean) => {
    await supabase
      .from('anomaly_detection_configs')
      .upsert({ template_id: templateId, enabled });
    setConfig({ ...config, enabled });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5" />
                Anomaly Detection
              </CardTitle>
              <CardDescription>ML-based pattern learning and anomaly detection</CardDescription>
            </div>
            <Switch checked={config?.enabled} onCheckedChange={toggleEnabled} />
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <Button onClick={runBaselineLearning} disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Learn Baselines
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Learned Baselines</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {baselines.map(baseline => (
              <div key={baseline.id} className="flex items-center justify-between p-3 border rounded">
                <div>
                  <div className="font-medium">{baseline.metric_name}</div>
                  <div className="text-sm text-muted-foreground">
                    {baseline.sample_count} samples
                  </div>
                </div>
                <Badge variant="outline">{baseline.confidence_score}% confidence</Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Recent Anomalies</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {anomalies.map(anomaly => (
              <div key={anomaly.id} className="flex items-center justify-between p-3 border rounded">
                <div className="flex items-center gap-3">
                  <AlertTriangle className="h-4 w-4 text-orange-500" />
                  <div>
                    <div className="font-medium">{anomaly.anomaly_type}</div>
                    <div className="text-sm text-muted-foreground">
                      {anomaly.metric_name}
                    </div>
                  </div>
                </div>
                <Badge variant={anomaly.anomaly_score > 80 ? 'destructive' : 'secondary'}>
                  {anomaly.anomaly_score} score
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}