import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Clock, Calendar, Globe } from 'lucide-react';

interface AlertScheduleEditorProps {
  ruleId: string;
  schedule: any;
  onUpdate: (schedule: any) => void;
}

const timezones = [
  'UTC', 'America/New_York', 'America/Chicago', 'America/Los_Angeles',
  'Europe/London', 'Europe/Paris', 'Asia/Tokyo', 'Asia/Shanghai',
  'Australia/Sydney', 'Pacific/Auckland'
];

export function AlertScheduleEditor({ ruleId, schedule, onUpdate }: AlertScheduleEditorProps) {
  const [enabled, setEnabled] = useState(schedule?.schedule_enabled || false);
  const [timezone, setTimezone] = useState(schedule?.timezone || 'UTC');
  const [businessHours, setBusinessHours] = useState(schedule?.business_hours_only || false);
  const [weekdaysOnly, setWeekdaysOnly] = useState(schedule?.weekdays_only || false);
  const [startTime, setStartTime] = useState(schedule?.active_hours_start || '09:00');
  const [endTime, setEndTime] = useState(schedule?.active_hours_end || '17:00');

  const handleSave = () => {
    onUpdate({
      schedule_enabled: enabled,
      timezone,
      business_hours_only: businessHours,
      weekdays_only: weekdaysOnly,
      active_hours_start: startTime,
      active_hours_end: endTime
    });
  };

  return (
    <Card className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Clock className="h-5 w-5 text-blue-500" />
          <h3 className="text-lg font-semibold">Alert Schedule</h3>
        </div>
        <Switch checked={enabled} onCheckedChange={setEnabled} />
      </div>

      {enabled && (
        <>
          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <Globe className="h-4 w-4" />
              Timezone
            </Label>
            <Select value={timezone} onValueChange={setTimezone}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {timezones.map(tz => (
                  <SelectItem key={tz} value={tz}>{tz}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-between">
            <Label>Business Hours Only (9 AM - 5 PM)</Label>
            <Switch checked={businessHours} onCheckedChange={setBusinessHours} />
          </div>

          <div className="flex items-center justify-between">
            <Label>Weekdays Only (Mon-Fri)</Label>
            <Switch checked={weekdaysOnly} onCheckedChange={setWeekdaysOnly} />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Active Hours Start</Label>
              <Input type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Active Hours End</Label>
              <Input type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} />
            </div>
          </div>

          <Button onClick={handleSave} className="w-full">Save Schedule</Button>
        </>
      )}
    </Card>
  );
}