import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/lib/supabase-client';
import { Bell, TrendingUp, MousePointer, CheckCircle, Clock } from 'lucide-react';
import { NotificationPerformanceChart } from './NotificationPerformanceChart';
import { EngagementHeatmapView } from './EngagementHeatmapView';
import { TemplateComparisonTable } from './TemplateComparisonTable';
import { ActionButtonAnalytics } from './ActionButtonAnalytics';

export function NotificationAnalyticsDashboard() {
  const [metrics, setMetrics] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAnalytics();
  }, []);

  const loadAnalytics = async () => {
    try {
      const { data: analytics } = await supabase
        .from('notification_analytics')
        .select('*')
        .order('sent_at', { ascending: false });

      if (analytics) {
        const totalSent = analytics.length;
        const totalDelivered = analytics.filter(a => a.delivered_at).length;
        const totalClicked = analytics.filter(a => a.clicked_at).length;
        const totalActions = analytics.filter(a => a.action_taken).length;
        const totalConversions = analytics.filter(a => a.conversion_completed).length;

        const clickTimes = analytics
          .filter(a => a.time_to_click_seconds)
          .map(a => a.time_to_click_seconds);
        const actionTimes = analytics
          .filter(a => a.time_to_action_seconds)
          .map(a => a.time_to_action_seconds);
        const conversionTimes = analytics
          .filter(a => a.time_to_conversion_seconds)
          .map(a => a.time_to_conversion_seconds);

        setMetrics({
          totalSent,
          totalDelivered,
          totalClicked,
          totalActions,
          totalConversions,
          deliveryRate: totalSent > 0 ? (totalDelivered / totalSent) * 100 : 0,
          clickThroughRate: totalDelivered > 0 ? (totalClicked / totalDelivered) * 100 : 0,
          actionRate: totalClicked > 0 ? (totalActions / totalClicked) * 100 : 0,
          conversionRate: totalActions > 0 ? (totalConversions / totalActions) * 100 : 0,
          avgTimeToClick: clickTimes.length > 0 
            ? clickTimes.reduce((a, b) => a + b, 0) / clickTimes.length : 0,
          avgTimeToAction: actionTimes.length > 0
            ? actionTimes.reduce((a, b) => a + b, 0) / actionTimes.length : 0,
          avgTimeToConversion: conversionTimes.length > 0
            ? conversionTimes.reduce((a, b) => a + b, 0) / conversionTimes.length : 0,
        });
      }
    } catch (error) {
      console.error('Error loading analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading || !metrics) {
    return <div>Loading analytics...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Sent</CardTitle>
            <Bell className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.totalSent}</div>
            <p className="text-xs text-muted-foreground">
              {metrics.deliveryRate.toFixed(1)}% delivered
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Click Rate</CardTitle>
            <MousePointer className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.clickThroughRate.toFixed(1)}%</div>
            <p className="text-xs text-muted-foreground">
              {metrics.totalClicked} clicks
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Action Rate</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.actionRate.toFixed(1)}%</div>
            <p className="text-xs text-muted-foreground">
              {metrics.totalActions} actions
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Conversion Rate</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.conversionRate.toFixed(1)}%</div>
            <p className="text-xs text-muted-foreground">
              {metrics.totalConversions} conversions
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Avg Time to Action</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {Math.round(metrics.avgTimeToAction / 60)}m
            </div>
            <p className="text-xs text-muted-foreground">
              {Math.round(metrics.avgTimeToClick / 60)}m to click
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="performance" className="space-y-4">
        <TabsList>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="heatmap">Engagement Heatmap</TabsTrigger>
          <TabsTrigger value="actions">Action Buttons</TabsTrigger>
        </TabsList>

        <TabsContent value="performance" className="space-y-4">
          <NotificationPerformanceChart />
        </TabsContent>

        <TabsContent value="templates" className="space-y-4">
          <TemplateComparisonTable />
        </TabsContent>

        <TabsContent value="heatmap" className="space-y-4">
          <EngagementHeatmapView />
        </TabsContent>

        <TabsContent value="actions" className="space-y-4">
          <ActionButtonAnalytics />
        </TabsContent>
      </Tabs>
    </div>
  );
}
