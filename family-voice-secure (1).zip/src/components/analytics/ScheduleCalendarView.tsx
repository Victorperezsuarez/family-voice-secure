import { useEffect, useState } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase-client';
import { Calendar, Clock } from 'lucide-react';

interface ScheduleCalendarViewProps {
  ruleId: string;
}

interface Schedule {
  id: string;
  schedule_name: string;
  days_of_week: number[];
  start_time: string;
  end_time: string;
  is_active: boolean;
}

const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const hours = Array.from({ length: 24 }, (_, i) => i);

export function ScheduleCalendarView({ ruleId }: ScheduleCalendarViewProps) {
  const [schedules, setSchedules] = useState<Schedule[]>([]);
  const [suspensions, setSuspensions] = useState<any[]>([]);

  useEffect(() => {
    loadSchedules();
    loadSuspensions();
  }, [ruleId]);

  const loadSchedules = async () => {
    const { data } = await supabase
      .from('alert_schedules')
      .select('*')
      .eq('alert_rule_id', ruleId)
      .eq('is_active', true);
    
    if (data) setSchedules(data);
  };

  const loadSuspensions = async () => {
    const { data } = await supabase
      .from('alert_suspensions')
      .select('*')
      .eq('alert_rule_id', ruleId)
      .eq('is_active', true)
      .gte('end_time', new Date().toISOString());
    
    if (data) setSuspensions(data);
  };

  const isTimeActive = (day: number, hour: number) => {
    return schedules.some(schedule => {
      if (!schedule.days_of_week.includes(day)) return false;
      
      const startHour = parseInt(schedule.start_time.split(':')[0]);
      const endHour = parseInt(schedule.end_time.split(':')[0]);
      
      return hour >= startHour && hour < endHour;
    });
  };

  return (
    <Card className="p-6">
      <div className="flex items-center gap-2 mb-4">
        <Calendar className="h-5 w-5 text-blue-500" />
        <h3 className="text-lg font-semibold">Weekly Schedule</h3>
      </div>

      {suspensions.length > 0 && (
        <div className="mb-4 p-3 bg-orange-50 border border-orange-200 rounded-lg">
          <p className="text-sm font-medium text-orange-800">Active Suspensions:</p>
          {suspensions.map(s => (
            <p key={s.id} className="text-xs text-orange-600 mt-1">
              {new Date(s.start_time).toLocaleString()} - {new Date(s.end_time).toLocaleString()}
            </p>
          ))}
        </div>
      )}

      <div className="overflow-x-auto">
        <div className="inline-block min-w-full">
          <div className="grid grid-cols-8 gap-1">
            <div className="text-xs font-medium text-gray-500 p-2">Time</div>
            {daysOfWeek.map(day => (
              <div key={day} className="text-xs font-medium text-gray-700 text-center p-2">
                {day}
              </div>
            ))}

            {hours.map(hour => (
              <>
                <div key={`hour-${hour}`} className="text-xs text-gray-500 p-2">
                  {hour.toString().padStart(2, '0')}:00
                </div>
                {daysOfWeek.map((_, dayIdx) => (
                  <div
                    key={`${dayIdx}-${hour}`}
                    className={`h-8 rounded ${
                      isTimeActive(dayIdx, hour)
                        ? 'bg-green-100 border border-green-300'
                        : 'bg-gray-50 border border-gray-200'
                    }`}
                  />
                ))}
              </>
            ))}
          </div>
        </div>
      </div>

      <div className="flex gap-4 mt-4 text-xs">
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 bg-green-100 border border-green-300 rounded" />
          <span>Active</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 bg-gray-50 border border-gray-200 rounded" />
          <span>Inactive</span>
        </div>
      </div>
    </Card>
  );
}