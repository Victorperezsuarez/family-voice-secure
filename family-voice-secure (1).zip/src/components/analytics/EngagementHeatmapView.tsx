import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/lib/supabase-client';

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const HOURS = Array.from({ length: 24 }, (_, i) => i);

export function EngagementHeatmapView() {
  const [heatmapData, setHeatmapData] = useState<Record<string, any>>({});

  useEffect(() => {
    loadHeatmapData();
  }, []);

  const loadHeatmapData = async () => {
    try {
      const { data: analytics } = await supabase
        .from('notification_analytics')
        .select('*');

      if (analytics) {
        const heatmap: Record<string, any> = {};
        
        analytics.forEach((item: any) => {
          const key = `${item.day_of_week}-${item.time_of_day}`;
          if (!heatmap[key]) {
            heatmap[key] = {
              day: item.day_of_week,
              hour: item.time_of_day,
              total: 0,
              clicked: 0,
              actions: 0
            };
          }
          heatmap[key].total++;
          if (item.clicked_at) heatmap[key].clicked++;
          if (item.action_taken) heatmap[key].actions++;
        });

        Object.keys(heatmap).forEach(key => {
          const data = heatmap[key];
          data.engagementScore = data.total > 0 
            ? ((data.clicked + data.actions * 2) / data.total) * 100 
            : 0;
        });

        setHeatmapData(heatmap);
      }
    } catch (error) {
      console.error('Error loading heatmap:', error);
    }
  };

  const getColor = (score: number) => {
    if (score === 0) return 'bg-gray-100';
    if (score < 20) return 'bg-blue-100';
    if (score < 40) return 'bg-blue-200';
    if (score < 60) return 'bg-blue-300';
    if (score < 80) return 'bg-blue-400';
    return 'bg-blue-500';
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Engagement Heatmap - Best Times to Send Notifications</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <div className="inline-block min-w-full">
            <div className="flex">
              <div className="w-16"></div>
              {DAYS.map(day => (
                <div key={day} className="w-12 text-center text-xs font-medium">
                  {day}
                </div>
              ))}
            </div>
            {HOURS.map(hour => (
              <div key={hour} className="flex items-center">
                <div className="w-16 text-xs text-right pr-2">
                  {hour.toString().padStart(2, '0')}:00
                </div>
                {DAYS.map((_, dayIndex) => {
                  const key = `${dayIndex}-${hour}`;
                  const data = heatmapData[key];
                  const score = data?.engagementScore || 0;
                  return (
                    <div
                      key={key}
                      className={`w-12 h-8 m-0.5 rounded ${getColor(score)} cursor-pointer hover:opacity-80 transition-opacity`}
                      title={`${DAYS[dayIndex]} ${hour}:00 - ${score.toFixed(1)}% engagement (${data?.total || 0} notifications)`}
                    />
                  );
                })}
              </div>
            ))}
          </div>
        </div>
        <div className="mt-4 flex items-center justify-center gap-4 text-xs">
          <span>Low Engagement</span>
          <div className="flex gap-1">
            <div className="w-6 h-6 bg-gray-100 rounded"></div>
            <div className="w-6 h-6 bg-blue-100 rounded"></div>
            <div className="w-6 h-6 bg-blue-200 rounded"></div>
            <div className="w-6 h-6 bg-blue-300 rounded"></div>
            <div className="w-6 h-6 bg-blue-400 rounded"></div>
            <div className="w-6 h-6 bg-blue-500 rounded"></div>
          </div>
          <span>High Engagement</span>
        </div>
      </CardContent>
    </Card>
  );
}
