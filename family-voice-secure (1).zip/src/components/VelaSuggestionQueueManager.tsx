import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/supabase-client';
import { useToast } from '@/hooks/use-toast';
import { Clock, AlertCircle, CheckCircle, XCircle, TrendingUp } from 'lucide-react';
import type { VelaSuggestionQueue } from '@/types/velaSuggestionScheduling';
import type { VelaProactiveSuggestion } from '@/types/vela';

interface QueueItemWithSuggestion extends VelaSuggestionQueue {
  suggestion?: VelaProactiveSuggestion;
}

export function VelaSuggestionQueueManager({ userId }: { userId: string }) {
  const [queueItems, setQueueItems] = useState<QueueItemWithSuggestion[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadQueue();
    const interval = setInterval(loadQueue, 30000); // Refresh every 30s
    return () => clearInterval(interval);
  }, [userId]);

  const loadQueue = async () => {
    try {
      const { data, error } = await supabase
        .from('vela_suggestion_queue')
        .select(`
          *,
          suggestion:vela_proactive_suggestions(*)
        `)
        .eq('user_id', userId)
        .in('status', ['queued', 'scheduled'])
        .order('priority_score', { ascending: false });

      if (error) throw error;
      setQueueItems(data || []);
    } catch (error) {
      console.error('Error loading queue:', error);
    } finally {
      setLoading(false);
    }
  };

  const cancelSuggestion = async (id: string) => {
    try {
      const { error } = await supabase
        .from('vela_suggestion_queue')
        .update({ status: 'cancelled', updated_at: new Date().toISOString() })
        .eq('id', id);

      if (error) throw error;
      toast({ title: 'Success', description: 'Suggestion cancelled' });
      loadQueue();
    } catch (error) {
      console.error('Error cancelling suggestion:', error);
      toast({ title: 'Error', description: 'Failed to cancel suggestion', variant: 'destructive' });
    }
  };

  const deliverNow = async (item: QueueItemWithSuggestion) => {
    try {
      // Log delivery
      const { error: logError } = await supabase
        .from('vela_suggestion_delivery_log')
        .insert({
          suggestion_id: item.suggestion_id,
          user_id: userId,
          persona_id: item.persona_id,
          delivered_at: new Date().toISOString(),
          scheduled_for: item.optimal_delivery_time,
          delivery_method: 'in_app'
        });

      if (logError) throw logError;

      // Update queue status
      const { error: updateError } = await supabase
        .from('vela_suggestion_queue')
        .update({ status: 'delivered', updated_at: new Date().toISOString() })
        .eq('id', item.id);

      if (updateError) throw updateError;

      toast({ title: 'Success', description: 'Suggestion delivered immediately' });
      loadQueue();
    } catch (error) {
      console.error('Error delivering suggestion:', error);
      toast({ title: 'Error', description: 'Failed to deliver suggestion', variant: 'destructive' });
    }
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'critical': return 'destructive';
      case 'high': return 'default';
      case 'medium': return 'secondary';
      default: return 'outline';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'queued': return <Clock className="h-4 w-4" />;
      case 'scheduled': return <CheckCircle className="h-4 w-4" />;
      case 'delivered': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'cancelled': return <XCircle className="h-4 w-4 text-red-500" />;
      default: return <AlertCircle className="h-4 w-4" />;
    }
  };

  if (loading) return <div>Loading queue...</div>;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="h-5 w-5" />
          Suggestion Queue ({queueItems.length})
        </CardTitle>
        <CardDescription>
          Prioritized suggestions waiting to be delivered at optimal times
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {queueItems.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">No suggestions in queue</p>
          ) : (
            queueItems.map((item) => (
              <div key={item.id} className="border rounded-lg p-4 space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      {getStatusIcon(item.status)}
                      <Badge variant={getUrgencyColor(item.urgency)}>
                        {item.urgency}
                      </Badge>
                      <span className="text-sm text-muted-foreground">
                        Priority: {item.priority_score.toFixed(1)}
                      </span>
                    </div>
                    <h4 className="font-medium">{item.suggestion?.title}</h4>
                    <p className="text-sm text-muted-foreground mt-1">
                      {item.suggestion?.content}
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between text-sm">
                  <div className="text-muted-foreground">
                    Scheduled: {new Date(item.optimal_delivery_time).toLocaleString()}
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => deliverNow(item)}
                    >
                      Deliver Now
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => cancelSuggestion(item.id)}
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
