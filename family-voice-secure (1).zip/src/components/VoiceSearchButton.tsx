import { Mic, MicOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useVoiceSemanticSearch } from '@/hooks/useVoiceSemanticSearch';
import { Badge } from '@/components/ui/badge';

interface VoiceSearchButtonProps {
  onResult: (text: string) => void;
  variant?: 'default' | 'outline' | 'ghost';
  size?: 'default' | 'sm' | 'lg' | 'icon';
}

export const VoiceSearchButton = ({
  onResult,
  variant = 'outline',
  size = 'icon',
}: VoiceSearchButtonProps) => {
  const { isListening, transcript, error, startListening, stopListening } = useVoiceSemanticSearch();

  const handleClick = () => {
    if (isListening) {
      stopListening();
    } else {
      startListening(onResult);
    }
  };

  return (
    <div className="relative">
      <Button
        variant={isListening ? 'destructive' : variant}
        size={size}
        onClick={handleClick}
        className="relative"
      >
        {isListening ? (
          <MicOff className="h-4 w-4 animate-pulse" />
        ) : (
          <Mic className="h-4 w-4" />
        )}
      </Button>
      
      {isListening && transcript && (
        <Badge className="absolute -bottom-8 left-1/2 -translate-x-1/2 whitespace-nowrap">
          {transcript}
        </Badge>
      )}
      
      {error && (
        <Badge variant="destructive" className="absolute -bottom-8 left-1/2 -translate-x-1/2 whitespace-nowrap">
          {error}
        </Badge>
      )}
    </div>
  );
};
