import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Download, TrendingUp, Users, Globe, BarChart3, Radio, Bell } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';
import { AnalyticsCharts } from './analytics/AnalyticsCharts';
import { GeographicMap } from './analytics/GeographicMap';
import { VersionAdoptionChart } from './analytics/VersionAdoptionChart';
import { TopFamiliesTable } from './analytics/TopFamiliesTable';
import LiveActivityFeed from './analytics/LiveActivityFeed';
import { useRealtimeAnalytics } from '@/hooks/useRealtimeAnalytics';
import { AnalyticsAlertsPanel } from './AnalyticsAlertsPanel';


interface TemplateAnalyticsDashboardProps {
  templateId: string;
  templateName: string;
}

export function TemplateAnalyticsDashboard({ templateId, templateName }: TemplateAnalyticsDashboardProps) {
  const [timeRange, setTimeRange] = useState('30d');
  const [analytics, setAnalytics] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const { analytics: realtimeData, isLive } = useRealtimeAnalytics(templateId);

  useEffect(() => {
    loadAnalytics();
  }, [templateId, timeRange]);

  const loadAnalytics = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('get-template-analytics', {
        body: { templateId, timeRange },
      });

      if (error) throw error;
      setAnalytics(data);
    } catch (error: any) {
      toast.error('Failed to load analytics');
    } finally {
      setLoading(false);
    }
  };

  const exportAnalytics = () => {
    const dataStr = JSON.stringify(analytics, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${templateName}-analytics-${new Date().toISOString()}.json`;
    link.click();
    URL.revokeObjectURL(url);
    toast.success('Analytics exported');
  };

  if (loading) {
    return <div className="text-center py-8">Loading analytics...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">{templateName} Analytics</h2>
          <p className="text-muted-foreground">Track usage and adoption metrics</p>
        </div>
        <div className="flex gap-2">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
              <SelectItem value="90d">Last 90 days</SelectItem>
              <SelectItem value="1y">Last year</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={exportAnalytics} variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Downloads</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analytics?.totalDownloads || 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Applications</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analytics?.totalApplications || 0}</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="trends" className="w-full">
        <TabsList>
          <TabsTrigger value="trends">Trends</TabsTrigger>
          <TabsTrigger value="geographic">Geographic</TabsTrigger>
          <TabsTrigger value="versions">Versions</TabsTrigger>
          <TabsTrigger value="families">Top Families</TabsTrigger>
          <TabsTrigger value="alerts">
            <Bell className="h-4 w-4 mr-2" />
            Alerts
          </TabsTrigger>
        </TabsList>
        <TabsContent value="trends">
          <AnalyticsCharts data={analytics?.downloadsByDay || {}} />
        </TabsContent>
        <TabsContent value="geographic">
          <GeographicMap data={analytics?.downloadsByCountry || {}} />
        </TabsContent>
        <TabsContent value="versions">
          <VersionAdoptionChart data={analytics?.versionAdoption || {}} />
        </TabsContent>
        <TabsContent value="families">
          <TopFamiliesTable families={analytics?.topFamilies || []} />
        </TabsContent>
        <TabsContent value="alerts">
          <AnalyticsAlertsPanel templateId={templateId} />
        </TabsContent>
      </Tabs>
    </div>
  );
}