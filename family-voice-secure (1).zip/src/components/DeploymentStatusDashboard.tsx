import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { CheckCircle2, XCircle, AlertCircle, RefreshCw, ExternalLink } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';

interface StatusCheck {
  name: string;
  status: 'success' | 'error' | 'warning' | 'pending';
  message: string;
  action?: { label: string; url: string };
}

export default function DeploymentStatusDashboard() {
  const [checks, setChecks] = useState<StatusCheck[]>([]);
  const [loading, setLoading] = useState(true);

  const runChecks = async () => {
    setLoading(true);
    const results: StatusCheck[] = [];

    // Check Supabase connection
    try {
      const { error } = await supabase.from('vela_personas').select('count').limit(1);
      results.push({
        name: 'Supabase Connection',
        status: error ? 'error' : 'success',
        message: error ? 'Cannot connect to Supabase' : 'Connected successfully',
        action: error ? { label: 'Check Config', url: 'https://supabase.com/dashboard' } : undefined
      });
    } catch (e) {
      results.push({
        name: 'Supabase Connection',
        status: 'error',
        message: 'Connection failed',
        action: { label: 'Setup Guide', url: '/docs/setup' }
      });
    }

    // Check environment variables
    const hasSupabaseUrl = !!import.meta.env.VITE_SUPABASE_URL;
    const hasSupabaseKey = !!import.meta.env.VITE_SUPABASE_ANON_KEY;
    results.push({
      name: 'Environment Variables',
      status: hasSupabaseUrl && hasSupabaseKey ? 'success' : 'error',
      message: hasSupabaseUrl && hasSupabaseKey ? 'All required variables set' : 'Missing required variables'
    });

    // Check VAPID key (optional)
    const hasVapid = !!import.meta.env.VITE_VAPID_PUBLIC_KEY;
    results.push({
      name: 'Push Notifications',
      status: hasVapid ? 'success' : 'warning',
      message: hasVapid ? 'VAPID key configured' : 'VAPID key not set (optional)',
      action: !hasVapid ? { label: 'Setup Guide', url: '/docs/vapid' } : undefined
    });

    // Check service worker
    const hasServiceWorker = 'serviceWorker' in navigator;
    results.push({
      name: 'PWA Support',
      status: hasServiceWorker ? 'success' : 'warning',
      message: hasServiceWorker ? 'Service worker supported' : 'PWA features unavailable'
    });

    // Check HTTPS
    const isHttps = window.location.protocol === 'https:' || window.location.hostname === 'localhost';
    results.push({
      name: 'Secure Connection',
      status: isHttps ? 'success' : 'warning',
      message: isHttps ? 'HTTPS enabled' : 'HTTP only (HTTPS required for PWA)'
    });

    setChecks(results);
    setLoading(false);
  };

  useEffect(() => {
    runChecks();
  }, []);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success': return <CheckCircle2 className="h-5 w-5 text-green-500" />;
      case 'error': return <XCircle className="h-5 w-5 text-red-500" />;
      case 'warning': return <AlertCircle className="h-5 w-5 text-yellow-500" />;
      default: return <RefreshCw className="h-5 w-5 text-gray-400 animate-spin" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, "default" | "destructive" | "outline" | "secondary"> = {
      success: 'default',
      error: 'destructive',
      warning: 'secondary',
      pending: 'outline'
    };
    return variants[status] || 'outline';
  };

  const successCount = checks.filter(c => c.status === 'success').length;
  const errorCount = checks.filter(c => c.status === 'error').length;
  const warningCount = checks.filter(c => c.status === 'warning').length;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Deployment Status</CardTitle>
        <CardDescription>
          System health and configuration checks
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex gap-4">
            <Badge variant="default">{successCount} Passed</Badge>
            {errorCount > 0 && <Badge variant="destructive">{errorCount} Failed</Badge>}
            {warningCount > 0 && <Badge variant="secondary">{warningCount} Warnings</Badge>}
          </div>
          <Button onClick={runChecks} disabled={loading} size="sm" variant="outline">
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Recheck
          </Button>
        </div>

        <div className="space-y-3">
          {checks.map((check, index) => (
            <div key={index} className="flex items-start justify-between p-3 border rounded-lg">
              <div className="flex items-start gap-3">
                {getStatusIcon(check.status)}
                <div>
                  <p className="font-medium">{check.name}</p>
                  <p className="text-sm text-muted-foreground">{check.message}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant={getStatusBadge(check.status)}>
                  {check.status}
                </Badge>
                {check.action && (
                  <Button size="sm" variant="ghost" asChild>
                    <a href={check.action.url} target="_blank" rel="noopener noreferrer">
                      {check.action.label}
                      <ExternalLink className="h-3 w-3 ml-1" />
                    </a>
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>

        {errorCount === 0 && warningCount === 0 && !loading && (
          <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
            <p className="text-green-800 font-medium">🎉 All systems operational!</p>
            <p className="text-sm text-green-600 mt-1">Your Vela deployment is ready to use.</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
