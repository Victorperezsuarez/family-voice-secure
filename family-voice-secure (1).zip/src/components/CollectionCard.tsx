import { Collection } from '@/types/family';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Edit, Trash2, FolderOpen, Users } from 'lucide-react';

interface CollectionCardProps {
  collection: Collection;
  onEdit: (collection: Collection) => void;
  onDelete: (id: string) => void;
  onOpen: (collection: Collection) => void;
  isOwner: boolean;
}

export function CollectionCard({ collection, onEdit, onDelete, onOpen, isOwner }: CollectionCardProps) {
  const defaultCover = 'https://d64gsuwffb70l.cloudfront.net/69010a7a5325e92f2828d404_1762356443084_f583ecad.webp';

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer group">
      <div onClick={() => onOpen(collection)}>
        <div className="relative h-48 overflow-hidden bg-gray-200">
          {collection.is_shared && (
            <Badge className="absolute top-3 right-3 z-10" variant="secondary">
              <Users className="h-3 w-3 mr-1" />
              Shared
            </Badge>
          )}
          <img
            src={collection.cover_image_url || defaultCover}
            alt={collection.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          <div className="absolute bottom-3 left-3 right-3">
            <h3 className="text-white font-semibold text-lg line-clamp-2">{collection.name}</h3>
          </div>
        </div>
      </div>

      <CardContent className="p-4">
        <p className="text-sm text-gray-600 mb-3 line-clamp-2 min-h-[40px]">
          {collection.description || 'No description'}
        </p>
        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-500">
            {collection.recording_count || 0} recordings
          </span>
          {isOwner && (
            <div className="flex gap-2">
              <Button size="sm" variant="ghost" onClick={() => onEdit(collection)}>
                <Edit className="h-4 w-4" />
              </Button>
              <Button size="sm" variant="ghost" onClick={() => onDelete(collection.id)}>
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
