import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from 'recharts';

interface EmotionSegment {
  speaker_label: string;
  start_time: number;
  end_time: number;
  emotion: string;
  emotion_confidence: number;
  emotion_intensity: number;
}

interface EmotionalJourneyVisualizationProps {
  segments: EmotionSegment[];
}

const emotionColors: Record<string, string> = {
  happy: '#10b981',
  sad: '#3b82f6',
  excited: '#f59e0b',
  nostalgic: '#8b5cf6',
  angry: '#ef4444',
  calm: '#06b6d4',
  anxious: '#f97316',
  surprised: '#ec4899',
  neutral: '#6b7280',
  frustrated: '#dc2626',
  joyful: '#84cc16',
  melancholic: '#6366f1',
  enthusiastic: '#eab308',
  worried: '#f43f5e',
  content: '#14b8a6'
};

export function EmotionalJourneyVisualization({ segments }: EmotionalJourneyVisualizationProps) {
  const chartData = segments.map(seg => ({
    time: seg.start_time,
    intensity: seg.emotion_intensity * 100,
    emotion: seg.emotion,
    speaker: seg.speaker_label,
    confidence: seg.emotion_confidence * 100
  }));

  const emotionCounts = segments.reduce((acc, seg) => {
    acc[seg.emotion] = (acc[seg.emotion] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const topEmotions = Object.entries(emotionCounts)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 5);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Emotional Journey</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="time" 
                label={{ value: 'Time (seconds)', position: 'insideBottom', offset: -5 }}
              />
              <YAxis 
                label={{ value: 'Emotion Intensity', angle: -90, position: 'insideLeft' }}
              />
              <Tooltip 
                content={({ active, payload }) => {
                  if (active && payload && payload[0]) {
                    const data = payload[0].payload;
                    return (
                      <div className="bg-white p-3 border rounded shadow-lg">
                        <p className="font-semibold">{data.emotion}</p>
                        <p className="text-sm">Speaker: {data.speaker}</p>
                        <p className="text-sm">Intensity: {data.intensity.toFixed(0)}%</p>
                        <p className="text-sm">Confidence: {data.confidence.toFixed(0)}%</p>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Area 
                type="monotone" 
                dataKey="intensity" 
                stroke="#8b5cf6" 
                fill="#8b5cf6" 
                fillOpacity={0.3}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div>
          <h4 className="font-semibold mb-3">Top Emotions Detected</h4>
          <div className="space-y-2">
            {topEmotions.map(([emotion, count]) => (
              <div key={emotion} className="flex items-center gap-3">
                <div 
                  className="w-4 h-4 rounded-full" 
                  style={{ backgroundColor: emotionColors[emotion] }}
                />
                <span className="capitalize flex-1">{emotion}</span>
                <span className="text-sm text-gray-600">{count} segments</span>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
