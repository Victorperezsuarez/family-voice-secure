import { useState, useRef, useEffect } from 'react';
import { Button } from './ui/button';
import { X, QrCode } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface QRCodeScannerProps {
  onScan: (data: string) => void;
  onClose: () => void;
}

export function QRCodeScanner({ onScan, onClose }: QRCodeScannerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [scanning, setScanning] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    startCamera();
    return () => {
      if (stream) stream.getTracks().forEach(track => track.stop());
    };
  }, []);

  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
        audio: false
      });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
        scanQRCode();
      }
    } catch (err) {
      console.error('Camera access error:', err);
    }
  };

  const scanQRCode = () => {
    if (!scanning) return;
    
    const video = videoRef.current;
    const canvas = canvasRef.current;
    
    if (video && canvas && video.readyState === video.HAVE_ENOUGH_DATA) {
      const ctx = canvas.getContext('2d');
      if (ctx) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        ctx.drawImage(video, 0, 0);
        
        // Simulate QR code detection (in production, use a library like jsQR)
        // For demo purposes, we'll just show the scanning interface
      }
    }
    
    requestAnimationFrame(scanQRCode);
  };

  const handleManualInput = () => {
    const code = prompt('Ingresa el código de familia:');
    if (code) {
      onScan(code);
      navigate(`/family/${code}`);
    }
  };

  return (
    <div className="fixed inset-0 bg-black z-50 flex flex-col">
      <video ref={videoRef} autoPlay playsInline className="flex-1 object-cover" />
      <canvas ref={canvasRef} className="hidden" />
      
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-64 h-64 border-4 border-amber-500 rounded-lg relative">
          <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-white rounded-tl-lg" />
          <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-white rounded-tr-lg" />
          <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-white rounded-bl-lg" />
          <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-white rounded-br-lg" />
        </div>
      </div>

      <div className="absolute top-4 left-4 right-4 flex justify-between items-start pointer-events-auto">
        <Button variant="ghost" size="icon" onClick={onClose} className="bg-black/50 text-white hover:bg-black/70">
          <X className="h-6 w-6" />
        </Button>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-4 pointer-events-auto">
        <p className="text-white text-center px-4">Escanea el código QR de un perfil familiar</p>
        <Button onClick={handleManualInput} variant="outline" className="bg-white/90">
          Ingresar código manualmente
        </Button>
      </div>
    </div>
  );
}
