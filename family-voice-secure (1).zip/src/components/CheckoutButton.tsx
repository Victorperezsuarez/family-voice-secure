import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/supabase-client';
import { Loader2 } from 'lucide-react';
import { toast } from 'sonner';

interface CheckoutButtonProps {
  planName: string;
  priceId: string;
  label?: string;
  variant?: 'default' | 'outline' | 'secondary';
}

export const CheckoutButton = ({ planName, priceId, label = 'Get Started', variant = 'default' }: CheckoutButtonProps) => {
  const [loading, setLoading] = useState(false);

  const handleCheckout = async () => {
    try {
      setLoading(true);

      // Get current user
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        toast.error('Please sign in to subscribe');
        window.location.href = '/?signup=true&plan=' + planName;
        return;
      }

      // Get the actual price ID from config if using placeholder
      let actualPriceId = priceId;
      if (priceId.startsWith('price_family') || priceId.startsWith('price_premium')) {
        const billingPeriod = priceId.includes('monthly') ? 'monthly' : 'annual';
        const plan = priceId.includes('family') ? 'family' : 'premium';
        
        const { data: configData } = await supabase
          .from('stripe_config')
          .select('monthly_price_id, annual_price_id')
          .eq('plan_name', plan)
          .single();
        
        if (configData) {
          actualPriceId = billingPeriod === 'monthly' 
            ? configData.monthly_price_id 
            : configData.annual_price_id;
        }
      }

      // Create checkout session
      const { data, error } = await supabase.functions.invoke('create-subscription', {
        body: {
          planName,
          priceId: actualPriceId,
          userId: user.id,
          email: user.email
        }
      });


      if (error) throw error;

      // Redirect to Stripe Checkout
      if (data.url) {
        window.location.href = data.url;
      }
    } catch (error) {
      console.error('Checkout error:', error);
      toast.error('Failed to start checkout');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Button onClick={handleCheckout} disabled={loading} variant={variant} className="w-full">
      {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : label}
    </Button>
  );
};
