import { RecordingWithMember } from '@/types/family';
import { Play, Download, Clock, FileText, Share2, Users, FolderPlus, Lock, Shield, Sparkles, UserCircle, Wand2, Lightbulb } from 'lucide-react';


import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { AIRecordingInsights } from './AIRecordingInsights';
import SpeakerDiarizationPanel from './SpeakerDiarizationPanel';
import AudioEnhancementPanel from './AudioEnhancementPanel';
import { AIStoryEnhancementPanel } from './AIStoryEnhancementPanel';





import { Button } from '@/components/ui/button';
import { useState, useEffect } from 'react';
import ShareRecordingModal, { ShareConfig } from './ShareRecordingModal';
import PrivacySettingsModal, { PrivacySettings } from './PrivacySettingsModal';
import { AddToCollectionModal } from './AddToCollectionModal';
import { supabase } from '@/lib/supabase-client';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';


interface RecordingCardProps {
  recording: RecordingWithMember;
  onPlay: () => void;
}


export function RecordingCard({ recording, onPlay }: RecordingCardProps) {
  const [currentTime, setCurrentTime] = useState(0);

  const [showFullSummary, setShowFullSummary] = useState(false);
  const [shareModalOpen, setShareModalOpen] = useState(false);
  const [privacyModalOpen, setPrivacyModalOpen] = useState(false);
  const [sharedWith, setSharedWith] = useState<string[]>(recording.shared_with || []);
  const [sharedUsers, setSharedUsers] = useState<any[]>([]);
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const [familyMembers, setFamilyMembers] = useState<any[]>([]);
  const { toast } = useToast();


  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      setCurrentUserId(data.user?.id || null);
    });
  }, []);

  useEffect(() => {
    if (sharedWith.length > 0) {
      loadSharedUsers();
    }
  }, [sharedWith]);

  const loadSharedUsers = async () => {
    const { data } = await supabase
      .from('profiles')
      .select('id, full_name, avatar_url')
      .in('id', sharedWith);
    
    if (data) {
      setSharedUsers(data);
    }
  };

  const isOwner = currentUserId === recording.created_by;


  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('es-ES', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });
  };

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = recording.audio_url;
    link.download = `${recording.title}.webm`;
    link.click();
  };

  return (
    <>
      <div className="bg-white/80 backdrop-blur-sm rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 border border-amber-100">
        <div className="flex items-center gap-4 p-4">
          <div className="w-16 h-16 rounded-full overflow-hidden flex-shrink-0 ring-2 ring-amber-200">
            <img
              src={recording.family_member.photo_url}
              alt={recording.family_member.name}
              className="w-full h-full object-cover"
            />
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h3 className="font-semibold text-gray-900 truncate">{recording.title}</h3>
              {sharedUsers.length > 0 && (
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <div className="flex items-center gap-1 px-2 py-0.5 bg-blue-50 rounded-full border border-blue-200">
                        <Users className="w-3 h-3 text-blue-600" />
                        <span className="text-xs text-blue-700 font-medium">{sharedUsers.length}</span>
                      </div>
                    </TooltipTrigger>
                    <TooltipContent>
                      <div className="space-y-1">
                        <p className="font-medium text-xs">Shared with:</p>
                        {sharedUsers.map(user => (
                          <p key={user.id} className="text-xs">{user.full_name}</p>
                        ))}
                      </div>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              )}
            </div>
            <p className="text-sm text-amber-700">{recording.family_member.name}</p>
            
            {recording.summary && (
              <div className="mt-2 p-2 bg-amber-50 rounded-lg border border-amber-200">
                <div className="flex items-start gap-2">
                  <FileText className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-gray-700 leading-relaxed">
                      {showFullSummary ? recording.summary : `${recording.summary.slice(0, 100)}${recording.summary.length > 100 ? '...' : ''}`}
                    </p>
                    {recording.summary.length > 100 && (
                      <button
                        onClick={() => setShowFullSummary(!showFullSummary)}
                        className="text-xs text-amber-600 hover:text-amber-700 font-medium mt-1"
                      >
                        {showFullSummary ? 'Show less' : 'Read more'}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            )}
            
            {recording.transcription && !recording.summary && (
              <p className="text-xs text-gray-600 mt-1 line-clamp-2">{recording.transcription}</p>
            )}
            
            <div className="flex items-center gap-3 mt-1 text-xs text-gray-500">
              <span className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {formatDuration(recording.duration)}
              </span>
              <span>{formatDate(recording.created_at)}</span>
            </div>
          </div>

          <div className="flex gap-2">
            <Button
              onClick={onPlay}
              size="sm"
              className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600"
            >
              <Play className="w-4 h-4" />
            </Button>
            {isOwner && recording.family_id && (
              <Button
                onClick={() => setShareModalOpen(true)}
                size="sm"
                variant="outline"
                className="border-blue-300 text-blue-700 hover:bg-blue-50"
              >
                <Share2 className="w-4 h-4" />
              </Button>
            )}

            {recording.transcription && (
              <Dialog>
                <DialogTrigger asChild>
                  <Button
                    size="sm"
                    variant="outline"
                    className="border-purple-300 text-purple-700 hover:bg-purple-50"
                  >
                    <Sparkles className="w-4 h-4" />
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>AI Insights</DialogTitle>
                  </DialogHeader>
                  <AIRecordingInsights
                    recordingId={recording.id}
                    transcription={recording.transcription}
                    title={recording.title}
                  />
                </DialogContent>
              </Dialog>
            )}
            
            {recording.transcription && (
              <Dialog>
                <DialogTrigger asChild>
                  <Button
                    size="sm"
                    variant="outline"
                    className="border-indigo-300 text-indigo-700 hover:bg-indigo-50"
                  >
                    <UserCircle className="w-4 h-4" />
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Speaker Diarization</DialogTitle>
                  </DialogHeader>
                  <SpeakerDiarizationPanel
                    recordingId={recording.id}
                    audioUrl={recording.audio_url}
                    transcription={recording.transcription}
                    duration={recording.duration}
                  />
                </DialogContent>
              </Dialog>
            )}

            <Dialog>
              <DialogTrigger asChild>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-green-300 text-green-700 hover:bg-green-50"
                >
                  <Wand2 className="w-4 h-4" />
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Audio Enhancement</DialogTitle>
                </DialogHeader>
                <AudioEnhancementPanel
                  recordingId={recording.id}
                  audioUrl={recording.audio_url}
                />
              </DialogContent>
            </Dialog>


            {recording.transcription && (
              <Dialog>
                <DialogTrigger asChild>
                  <Button
                    size="sm"
                    variant="outline"
                    className="border-yellow-300 text-yellow-700 hover:bg-yellow-50"
                  >
                    <Lightbulb className="w-4 h-4" />
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Story Enhancement</DialogTitle>
                  </DialogHeader>
                  <AIStoryEnhancementPanel
                    recordingId={recording.id}
                    transcription={recording.transcription}
                    duration={recording.duration}
                    currentTime={currentTime}
                    onSeekTo={(time) => setCurrentTime(time)}
                  />
                </DialogContent>
              </Dialog>
            )}


            <Button
              onClick={handleDownload}
              size="sm"
              variant="outline"
              className="border-amber-300 text-amber-700 hover:bg-amber-50"
            >
              <Download className="w-4 h-4" />
            </Button>




          </div>
        </div>
      </div>

      {isOwner && recording.family_id && (
        <ShareRecordingModal
          open={shareModalOpen}
          onOpenChange={setShareModalOpen}
          recordingId={recording.id}
          currentSharedWith={sharedWith}
          familyId={recording.family_id}
          onShareUpdate={setSharedWith}
        />
      )}
    </>
  );
}
