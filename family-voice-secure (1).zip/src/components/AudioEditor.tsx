import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import { Scissors, Trash2, Play, Pause, Save } from 'lucide-react';
import { AudioSegment, AudioEditState } from '@/types/audio';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';


interface AudioEditorProps {
  audioUrl: string;
  onSave: (editedAudioUrl: string) => void;
  onCancel: () => void;
}

export function AudioEditor({ audioUrl, onSave, onCancel }: AudioEditorProps) {
  const [editState, setEditState] = useState<AudioEditState>({
    duration: 0,
    segments: [],
    trimStart: 0,
    trimEnd: 0,
    enhancements: {
      noiseReduction: false,
      volumeNormalization: false,
      voiceEnhancement: false,
      restoration: false,
    },
  });
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const audioRef = useRef<HTMLAudioElement>(null);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.addEventListener('loadedmetadata', () => {
        const duration = audioRef.current?.duration || 0;
        setEditState(prev => ({
          ...prev,
          duration,
          trimEnd: duration,
        }));
      });

      audioRef.current.addEventListener('timeupdate', () => {
        setCurrentTime(audioRef.current?.currentTime || 0);
      });
    }
  }, []);

  const handlePlayPause = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleTrimChange = (values: number[]) => {
    setEditState(prev => ({
      ...prev,
      trimStart: values[0],
      trimEnd: values[1],
    }));
  };

  const handleEnhance = async (enhancements: any) => {
    try {
      const { data, error } = await supabase.functions.invoke('enhance-audio', {
        body: { audioUrl, enhancements },
      });

      if (error) throw error;

      toast.success('Audio enhanced successfully');
      setEditState(prev => ({ ...prev, enhancements }));
    } catch (error: any) {
      toast.error('Enhancement failed: ' + error.message);
    }
  };

  const handleSave = () => {
    onSave(audioUrl);
  };

  return (
    <Card className="p-6 space-y-6">
      <audio ref={audioRef} src={audioUrl} />

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">Audio Editor</h3>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={handlePlayPause}>
              {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            </Button>
          </div>
        </div>

        <div className="h-24 bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-lg relative overflow-hidden">
          <div
            className="absolute top-0 bottom-0 bg-blue-500/40"
            style={{
              left: `${(editState.trimStart / editState.duration) * 100}%`,
              right: `${100 - (editState.trimEnd / editState.duration) * 100}%`,
            }}
          />
          <div
            className="absolute top-0 bottom-0 w-0.5 bg-red-500"
            style={{ left: `${(currentTime / editState.duration) * 100}%` }}
          />
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium">Trim Audio</label>
          <Slider
            value={[editState.trimStart, editState.trimEnd]}
            onValueChange={handleTrimChange}
            max={editState.duration}
            step={0.1}
            className="w-full"
          />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>{editState.trimStart.toFixed(1)}s</span>
            <span>{editState.trimEnd.toFixed(1)}s</span>
          </div>
        </div>
      </div>

      <div className="p-4 border rounded-lg bg-muted/50">
        <p className="text-sm text-muted-foreground">Enhancement settings available in recording details</p>
      </div>


      <div className="flex gap-2 justify-end">
        <Button variant="outline" onClick={onCancel}>Cancel</Button>
        <Button onClick={handleSave}>
          <Save className="mr-2 h-4 w-4" />
          Save Changes
        </Button>
      </div>
    </Card>
  );
}
