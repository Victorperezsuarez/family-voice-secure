import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CheckCircle2, XCircle, Clock, Play, AlertTriangle } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';

interface TemplateTestingDashboardProps {
  templateId: string;
  version?: string;
}

export function TemplateTestingDashboard({ templateId, version }: TemplateTestingDashboardProps) {
  const [testResults, setTestResults] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [running, setRunning] = useState(false);

  useEffect(() => {
    loadTestResults();
  }, [templateId, version]);

  const loadTestResults = async () => {
    setLoading(true);
    try {
      let query = supabase
        .from('template_test_results')
        .select('*')
        .eq('template_id', templateId)
        .order('created_at', { ascending: false });

      if (version) {
        query = query.eq('version', version);
      }

      const { data, error } = await query.limit(1).single();

      if (error && error.code !== 'PGRST116') throw error;
      setTestResults(data);
    } catch (error: any) {
      console.error('Error loading test results:', error);
    } finally {
      setLoading(false);
    }
  };

  const runTests = async (testType: string = 'all') => {
    setRunning(true);
    try {
      const { data, error } = await supabase.functions.invoke('run-template-tests', {
        body: { templateId, version, testType }
      });

      if (error) throw error;

      toast.success('Tests completed successfully');
      setTestResults(data.results);
      await loadTestResults();
    } catch (error: any) {
      toast.error('Failed to run tests: ' + error.message);
    } finally {
      setRunning(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'passed': return <CheckCircle2 className="h-4 w-4 text-green-600" />;
      case 'failed': return <XCircle className="h-4 w-4 text-red-600" />;
      default: return <Clock className="h-4 w-4 text-gray-400" />;
    }
  };

  const getCoverageColor = (coverage: number) => {
    if (coverage >= 80) return 'text-green-600';
    if (coverage >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  if (loading) {
    return <div className="flex items-center justify-center p-8">Loading test results...</div>;
  }

  const results = testResults?.test_results || null;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Template Testing Dashboard</h2>
        <div className="flex gap-2">
          <Button onClick={() => runTests('all')} disabled={running}>
            <Play className="h-4 w-4 mr-2" />
            {running ? 'Running...' : 'Run All Tests'}
          </Button>
        </div>
      </div>

      {results && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium">Overall Coverage</CardTitle>
              </CardHeader>
              <CardContent>
                <div className={`text-3xl font-bold ${getCoverageColor(results.coverage.overall)}`}>
                  {results.coverage.overall}%
                </div>
                <Progress value={results.coverage.overall} className="mt-2" />
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium">Unit Tests</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">
                  {results.unitTests.passed}/{results.unitTests.total}
                </div>
                <p className="text-sm text-muted-foreground mt-1">
                  {results.unitTests.failed} failed
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium">Integration Tests</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">
                  {results.integrationTests.passed}/{results.integrationTests.total}
                </div>
                <p className="text-sm text-muted-foreground mt-1">
                  {results.integrationTests.failed} failed
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium">E2E Tests</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">
                  {results.e2eTests.passed}/{results.e2eTests.total}
                </div>
                <p className="text-sm text-muted-foreground mt-1">
                  {results.e2eTests.failed} failed
                </p>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="unit" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="unit">Unit Tests</TabsTrigger>
              <TabsTrigger value="integration">Integration</TabsTrigger>
              <TabsTrigger value="e2e">E2E Tests</TabsTrigger>
              <TabsTrigger value="coverage">Coverage</TabsTrigger>
            </TabsList>

            <TabsContent value="unit" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Unit Test Results</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {results.unitTests.tests.map((test: any, idx: number) => (
                      <div key={idx} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center gap-3">
                          {getStatusIcon(test.status)}
                          <div>
                            <p className="font-medium">{test.name}</p>
                            {test.error && (
                              <p className="text-sm text-red-600">{test.error}</p>
                            )}
                          </div>
                        </div>
                        <Badge variant={test.status === 'passed' ? 'default' : 'destructive'}>
                          {test.duration?.toFixed(0)}ms
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="integration" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Integration Test Results</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {results.integrationTests.tests.map((test: any, idx: number) => (
                      <div key={idx} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center gap-3">
                          {getStatusIcon(test.status)}
                          <div>
                            <p className="font-medium">{test.name}</p>
                            {test.error && (
                              <p className="text-sm text-red-600">{test.error}</p>
                            )}
                          </div>
                        </div>
                        <Badge variant={test.status === 'passed' ? 'default' : 'destructive'}>
                          {test.duration?.toFixed(0)}ms
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="e2e" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>End-to-End Test Results</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {results.e2eTests.tests.map((test: any, idx: number) => (
                      <div key={idx} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center gap-3">
                          {getStatusIcon(test.status)}
                          <p className="font-medium">{test.name}</p>
                        </div>
                        <Badge variant={test.status === 'passed' ? 'default' : 'destructive'}>
                          {test.duration?.toFixed(0)}ms
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="coverage" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Test Coverage Report</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="font-medium">Overall Coverage</span>
                      <span className={`font-bold ${getCoverageColor(results.coverage.overall)}`}>
                        {results.coverage.overall}%
                      </span>
                    </div>
                    <Progress value={results.coverage.overall} />
                  </div>

                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="font-medium">Permission Coverage</span>
                      <span className={`font-bold ${getCoverageColor(results.coverage.permissions)}`}>
                        {results.coverage.permissions}%
                      </span>
                    </div>
                    <Progress value={results.coverage.permissions} />
                  </div>

                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="font-medium">Workflow Coverage</span>
                      <span className={`font-bold ${getCoverageColor(results.coverage.workflows)}`}>
                        {results.coverage.workflows}%
                      </span>
                    </div>
                    <Progress value={results.coverage.workflows} />
                  </div>

                  {results.aiSuggestions && results.aiSuggestions.length > 0 && (
                    <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                      <div className="flex items-start gap-2">
                        <AlertTriangle className="h-5 w-5 text-blue-600 mt-0.5" />
                        <div>
                          <h4 className="font-semibold text-blue-900 mb-2">AI Recommendations</h4>
                          <ul className="space-y-1 text-sm text-blue-800">
                            {results.aiSuggestions.map((suggestion: string, idx: number) => (
                              <li key={idx}>• {suggestion}</li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </>
      )}

      {!results && (
        <Card>
          <CardContent className="flex flex-col items-center justify-center p-12">
            <AlertTriangle className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Test Results Available</h3>
            <p className="text-muted-foreground mb-4">Run tests to see results and coverage reports</p>
            <Button onClick={() => runTests('all')} disabled={running}>
              <Play className="h-4 w-4 mr-2" />
              Run Tests Now
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}