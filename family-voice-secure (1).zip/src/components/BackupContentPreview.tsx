import { BackupContent } from '@/types/backup';
import { Card } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Mic, FileText, Image } from 'lucide-react';

interface BackupContentPreviewProps {
  content: BackupContent;
  selectedItems: {
    recordings: string[];
    transcriptions: string[];
    photos: string[];
  };
  onSelectionChange: (type: 'recordings' | 'transcriptions' | 'photos', id: string) => void;
}

export function BackupContentPreview({ content, selectedItems, onSelectionChange }: BackupContentPreviewProps) {
  return (
    <div className="space-y-4">
      <Card className="p-4">
        <div className="flex items-center gap-2 mb-3">
          <Mic className="h-5 w-5" />
          <h3 className="font-semibold">Recordings ({content.recordings.length})</h3>
        </div>
        <ScrollArea className="h-48">
          {content.recordings.map((rec) => (
            <div key={rec.id} className="flex items-center gap-2 py-2">
              <Checkbox
                checked={selectedItems.recordings.includes(rec.id)}
                onCheckedChange={() => onSelectionChange('recordings', rec.id)}
              />
              <div className="flex-1">
                <p className="text-sm font-medium">{rec.title}</p>
                <p className="text-xs text-muted-foreground">
                  {new Date(rec.created_at).toLocaleDateString()}
                </p>
              </div>
            </div>
          ))}
        </ScrollArea>
      </Card>
    </div>
  );
}
