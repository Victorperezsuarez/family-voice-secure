import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Wand2, CheckCircle2, XCircle, Clock } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';

interface Recording {
  id: string;
  title: string;
  audio_url: string;
  enhancement_applied: boolean;
}

interface BatchAudioEnhancementProps {
  collectionId?: string;
  recordings: Recording[];
  onComplete?: () => void;
}

export default function BatchAudioEnhancement({ 
  collectionId, 
  recordings,
  onComplete 
}: BatchAudioEnhancementProps) {
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [processing, setProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [results, setResults] = useState<Record<string, 'success' | 'error' | 'pending'>>({});

  const unenhancedRecordings = recordings.filter(r => !r.enhancement_applied);

  const toggleSelection = (id: string) => {
    setSelectedIds(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const selectAll = () => {
    setSelectedIds(unenhancedRecordings.map(r => r.id));
  };

  const handleBatchEnhance = async () => {
    if (selectedIds.length === 0) {
      toast.error('Please select recordings to enhance');
      return;
    }

    setProcessing(true);
    setProgress(0);
    
    const newResults: Record<string, 'success' | 'error' | 'pending'> = {};
    selectedIds.forEach(id => newResults[id] = 'pending');
    setResults(newResults);

    let completed = 0;

    for (const id of selectedIds) {
      try {
        const recording = recordings.find(r => r.id === id);
        if (!recording) continue;

        const { data, error } = await supabase.functions.invoke('enhance-audio', {
          body: { 
            audioUrl: recording.audio_url,
            recordingId: id,
            settings: {
              intensity: 'medium',
              noise_reduction: true,
              volume_normalization: true,
              echo_reduction: true,
              clarity_enhancement: true,
              voice_separation: true
            }
          }
        });

        if (error) throw error;

        await supabase.from('recordings').update({
          enhanced_audio_url: data.enhanced_audio_url,
          enhancement_applied: true,
          enhancement_settings: data.settings_applied,
          quality_metrics: data.quality_metrics,
          enhancement_date: new Date().toISOString()
        }).eq('id', id);

        newResults[id] = 'success';
      } catch (error) {
        console.error(`Failed to enhance recording ${id}:`, error);
        newResults[id] = 'error';
      }

      completed++;
      setProgress((completed / selectedIds.length) * 100);
      setResults({ ...newResults });
    }

    setProcessing(false);
    toast.success(`Enhanced ${Object.values(newResults).filter(r => r === 'success').length} recordings`);
    onComplete?.();
  };

  return (
    <Card className="p-6">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">Batch Audio Enhancement</h3>
          <Badge variant="secondary">
            {unenhancedRecordings.length} recordings available
          </Badge>
        </div>

        {processing && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span>Processing...</span>
              <span>{Math.round(progress)}%</span>
            </div>
            <Progress value={progress} />
          </div>
        )}

        <div className="space-y-2 max-h-96 overflow-y-auto">
          {unenhancedRecordings.map(recording => (
            <div key={recording.id} 
              className="flex items-center justify-between p-3 border rounded-lg hover:bg-accent">
              <div className="flex items-center gap-3">
                <Checkbox 
                  checked={selectedIds.includes(recording.id)}
                  onCheckedChange={() => toggleSelection(recording.id)}
                  disabled={processing}
                />
                <span className="font-medium">{recording.title}</span>
              </div>
              
              {results[recording.id] === 'success' && (
                <CheckCircle2 className="w-5 h-5 text-green-500" />
              )}
              {results[recording.id] === 'error' && (
                <XCircle className="w-5 h-5 text-red-500" />
              )}
              {results[recording.id] === 'pending' && (
                <Clock className="w-5 h-5 text-yellow-500 animate-pulse" />
              )}
            </div>
          ))}
        </div>

        <div className="flex gap-2">
          <Button onClick={selectAll} variant="outline" disabled={processing}>
            Select All ({unenhancedRecordings.length})
          </Button>
          <Button onClick={handleBatchEnhance} disabled={processing || selectedIds.length === 0} 
            className="flex-1">
            <Wand2 className="w-4 h-4 mr-2" />
            Enhance {selectedIds.length} Recording{selectedIds.length !== 1 ? 's' : ''}
          </Button>
        </div>
      </div>
    </Card>
  );
}
