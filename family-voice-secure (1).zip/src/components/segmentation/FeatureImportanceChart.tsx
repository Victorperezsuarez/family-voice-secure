import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { BarChart3, Info } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { FeatureImportance } from '@/types/segmentPrediction';

const featureImportanceData: FeatureImportance[] = [
  { featureName: 'Engagement Score', importanceScore: 0.25, description: 'Overall user engagement level' },
  { featureName: 'Retention Score', importanceScore: 0.22, description: 'User retention and recency' },
  { featureName: 'Days Since Signup', importanceScore: 0.15, description: 'Account age' },
  { featureName: 'Total Sessions', importanceScore: 0.12, description: 'Number of app sessions' },
  { featureName: 'Notification Open Rate', importanceScore: 0.10, description: 'Notification engagement' },
  { featureName: 'Total Recordings', importanceScore: 0.08, description: 'Content creation activity' },
  { featureName: 'Feature Adoption Score', importanceScore: 0.05, description: 'Features used' },
  { featureName: 'Last Active Days Ago', importanceScore: 0.03, description: 'Recency of activity' }
];

export function FeatureImportanceChart() {
  const maxScore = Math.max(...featureImportanceData.map(f => f.importanceScore));

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BarChart3 className="h-5 w-5" />
          Feature Importance
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground">
          Features ranked by their impact on segment prediction accuracy
        </p>
        
        <div className="space-y-4">
          {featureImportanceData.map((feature, idx) => (
            <div key={idx} className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="font-medium text-sm">{feature.featureName}</span>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger>
                        <Info className="h-3 w-3 text-muted-foreground" />
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="text-xs">{feature.description}</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                <span className="text-sm text-muted-foreground">
                  {Math.round(feature.importanceScore * 100)}%
                </span>
              </div>
              <Progress 
                value={(feature.importanceScore / maxScore) * 100} 
                className="h-2"
              />
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
