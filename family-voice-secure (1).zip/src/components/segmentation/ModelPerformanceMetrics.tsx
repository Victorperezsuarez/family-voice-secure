import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Target, CheckCircle2, TrendingUp } from 'lucide-react';
import { ModelMetrics } from '@/types/segmentPrediction';

const mockMetrics: ModelMetrics = {
  modelVersion: '1.0.0',
  accuracy: 0.87,
  precision: 0.85,
  recall: 0.83,
  f1Score: 0.84,
  segmentMetrics: {
    power_user: { precision: 0.92, recall: 0.88, f1Score: 0.90, support: 245 },
    high_engagement: { precision: 0.86, recall: 0.84, f1Score: 0.85, support: 512 },
    moderate_engagement: { precision: 0.84, recall: 0.82, f1Score: 0.83, support: 678 },
    low_engagement: { precision: 0.81, recall: 0.79, f1Score: 0.80, support: 423 },
    new_user: { precision: 0.89, recall: 0.91, f1Score: 0.90, support: 334 },
    at_risk: { precision: 0.78, recall: 0.76, f1Score: 0.77, support: 198 }
  },
  confusionMatrix: [],
  trainingSamples: 2390,
  validationSamples: 598,
  trainingDate: new Date().toISOString()
};

export function ModelPerformanceMetrics() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            Overall Model Performance
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-muted rounded-lg">
              <div className="text-2xl font-bold text-green-600">
                {Math.round(mockMetrics.accuracy * 100)}%
              </div>
              <div className="text-sm text-muted-foreground mt-1">Accuracy</div>
            </div>
            <div className="text-center p-4 bg-muted rounded-lg">
              <div className="text-2xl font-bold text-blue-600">
                {Math.round(mockMetrics.precision * 100)}%
              </div>
              <div className="text-sm text-muted-foreground mt-1">Precision</div>
            </div>
            <div className="text-center p-4 bg-muted rounded-lg">
              <div className="text-2xl font-bold text-purple-600">
                {Math.round(mockMetrics.recall * 100)}%
              </div>
              <div className="text-sm text-muted-foreground mt-1">Recall</div>
            </div>
            <div className="text-center p-4 bg-muted rounded-lg">
              <div className="text-2xl font-bold text-orange-600">
                {Math.round(mockMetrics.f1Score * 100)}%
              </div>
              <div className="text-sm text-muted-foreground mt-1">F1 Score</div>
            </div>
          </div>
          
          <div className="mt-4 flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Training Samples:</span>
            <Badge variant="secondary">{mockMetrics.trainingSamples.toLocaleString()}</Badge>
          </div>
          <div className="flex items-center justify-between text-sm mt-2">
            <span className="text-muted-foreground">Validation Samples:</span>
            <Badge variant="secondary">{mockMetrics.validationSamples.toLocaleString()}</Badge>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle2 className="h-5 w-5" />
            Per-Segment Performance
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Object.entries(mockMetrics.segmentMetrics).map(([segment, metrics]) => (
              <div key={segment} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-medium capitalize">
                    {segment.replace('_', ' ')}
                  </h4>
                  <Badge variant="outline">{metrics.support} samples</Badge>
                </div>
                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div>
                    <div className="text-muted-foreground">Precision</div>
                    <div className="font-semibold text-lg">
                      {Math.round(metrics.precision * 100)}%
                    </div>
                  </div>
                  <div>
                    <div className="text-muted-foreground">Recall</div>
                    <div className="font-semibold text-lg">
                      {Math.round(metrics.recall * 100)}%
                    </div>
                  </div>
                  <div>
                    <div className="text-muted-foreground">F1 Score</div>
                    <div className="font-semibold text-lg">
                      {Math.round(metrics.f1Score * 100)}%
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
