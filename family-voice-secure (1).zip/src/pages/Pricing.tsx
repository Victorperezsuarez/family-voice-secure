import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Check, X } from 'lucide-react';
import { CheckoutButton } from '@/components/CheckoutButton';


const Pricing = () => {
  const [isAnnual, setIsAnnual] = useState(false);
  const navigate = useNavigate();

  const handleGetStarted = (plan: string) => {
    navigate(`/?signup=true&plan=${plan.toLowerCase()}`);
  };

  // Stripe Price IDs - Replace with your actual Stripe Price IDs
  const stripePriceIds = {
    free: '',
    family: {
      monthly: 'price_family_monthly',
      annual: 'price_family_annual'
    },
    premium: {
      monthly: 'price_premium_monthly',
      annual: 'price_premium_annual'
    },
    enterprise: {
      monthly: 'price_enterprise_monthly',
      annual: 'price_enterprise_annual'
    }
  };

  const plans = [
    {
      name: 'Free',
      monthlyPrice: 0,
      annualPrice: 0,
      description: 'Perfect for individuals exploring family history',
      features: [
        { text: 'Up to 10 recordings', included: true },
        { text: '1 family tree', included: true },
        { text: 'Basic transcription', included: true },
        { text: '1GB storage', included: true },
        { text: 'AI story generation', included: false },
        { text: 'Priority support', included: false },
        { text: 'Advanced analytics', included: false },
      ],
      popular: false,
      stripePriceId: stripePriceIds.free
    },
    {
      name: 'Family',
      monthlyPrice: 12,
      annualPrice: 120,
      description: 'Ideal for families preserving memories together',
      features: [
        { text: 'Unlimited recordings', included: true },
        { text: 'Up to 5 family trees', included: true },
        { text: 'Advanced transcription', included: true },
        { text: '50GB storage', included: true },
        { text: 'AI story generation', included: true },
        { text: 'Email support', included: true },
        { text: 'Collaboration tools', included: true },
      ],
      popular: true,
      stripePriceId: isAnnual ? stripePriceIds.family.annual : stripePriceIds.family.monthly
    },
    {
      name: 'Premium',
      monthlyPrice: 29,
      annualPrice: 290,
      description: 'For serious genealogists and historians',
      features: [
        { text: 'Unlimited recordings', included: true },
        { text: 'Unlimited family trees', included: true },
        { text: 'Premium transcription', included: true },
        { text: '500GB storage', included: true },
        { text: 'Advanced AI features', included: true },
        { text: 'Priority support', included: true },
        { text: 'Advanced analytics', included: true },
      ],
      popular: false,
      stripePriceId: isAnnual ? stripePriceIds.premium.annual : stripePriceIds.premium.monthly
    },
    {
      name: 'Enterprise',
      monthlyPrice: 99,
      annualPrice: 990,
      description: 'Custom solutions for organizations',
      features: [
        { text: 'Everything in Premium', included: true },
        { text: 'Custom storage limits', included: true },
        { text: 'Dedicated support', included: true },
        { text: 'Custom integrations', included: true },
        { text: 'SLA guarantees', included: true },
        { text: 'Training & onboarding', included: true },
        { text: 'White-label options', included: true },
      ],
      popular: false,
      stripePriceId: isAnnual ? stripePriceIds.enterprise.annual : stripePriceIds.enterprise.monthly
    },
  ];


  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      {/* Navigation */}
      <nav className="bg-white border-b sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-indigo-600">Family Voice Secure</h1>
          <Button variant="outline" onClick={() => navigate('/')}>Back to Home</Button>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Choose Your Plan</h2>
          <p className="text-xl text-gray-600 mb-8">Start preserving your family's legacy today</p>
          
          {/* Toggle */}
          <div className="flex items-center justify-center gap-4 mb-8">
            <span className={`text-lg ${!isAnnual ? 'font-semibold text-gray-900' : 'text-gray-500'}`}>Monthly</span>
            <button
              onClick={() => setIsAnnual(!isAnnual)}
              className="relative w-14 h-7 bg-indigo-600 rounded-full transition-colors"
            >
              <span className={`absolute top-1 left-1 w-5 h-5 bg-white rounded-full transition-transform ${isAnnual ? 'translate-x-7' : ''}`} />
            </button>
            <span className={`text-lg ${isAnnual ? 'font-semibold text-gray-900' : 'text-gray-500'}`}>
              Annual <span className="text-green-600 text-sm">(Save 17%)</span>
            </span>
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {plans.map((plan) => (
            <Card key={plan.name} className={`p-6 relative ${plan.popular ? 'border-indigo-600 border-2 shadow-xl' : ''}`}>
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-indigo-600 text-white px-4 py-1 rounded-full text-sm font-semibold">
                  Most Popular
                </div>
              )}
              <h3 className="text-2xl font-bold text-gray-900 mb-2">{plan.name}</h3>
              <p className="text-gray-600 text-sm mb-4 h-12">{plan.description}</p>
              <div className="mb-6">
                <span className="text-4xl font-bold text-gray-900">
                  ${isAnnual ? Math.floor(plan.annualPrice / 12) : plan.monthlyPrice}
                </span>
                <span className="text-gray-600">/month</span>
                {isAnnual && plan.annualPrice > 0 && (
                  <p className="text-sm text-gray-500 mt-1">Billed ${plan.annualPrice} annually</p>
                )}
              </div>
              {plan.name === 'Free' ? (
                <Button 
                  onClick={() => handleGetStarted(plan.name)}
                  className="w-full mb-2"
                  variant="outline"
                >
                  Get Started Free
                </Button>
              ) : (
                <>
                  <CheckoutButton
                    planName={plan.name.toLowerCase()}
                    priceId={plan.stripePriceId}
                    label="Start Free Trial"
                    variant={plan.popular ? 'default' : 'outline'}
                  />
                  <p className="text-xs text-center text-gray-500 mt-2 mb-4">14-day free trial • No credit card required</p>
                </>
              )}

              <ul className="space-y-3">
                {plan.features.map((feature, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    {feature.included ? (
                      <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                    ) : (
                      <X className="w-5 h-5 text-gray-300 flex-shrink-0 mt-0.5" />
                    )}
                    <span className={feature.included ? 'text-gray-700' : 'text-gray-400'}>{feature.text}</span>
                  </li>
                ))}
              </ul>
            </Card>
          ))}
        </div>


        {/* FAQ Section */}
        <div className="max-w-3xl mx-auto">
          <h3 className="text-3xl font-bold text-center mb-8">Frequently Asked Questions</h3>
          <div className="space-y-6">
            {[
              {
                q: 'Can I change my plan later?',
                a: 'Yes! You can upgrade or downgrade your plan at any time. Changes take effect immediately, and we\'ll prorate any charges.',
              },
              {
                q: 'What payment methods do you accept?',
                a: 'We accept all major credit cards (Visa, Mastercard, American Express) and PayPal for your convenience.',
              },
              {
                q: 'Is there a free trial?',
                a: 'Yes! All paid plans include a 14-day free trial. No credit card required to start your trial. You can cancel anytime during the trial period with no charges.',
              },

              {
                q: 'What happens to my data if I cancel?',
                a: 'Your data remains accessible for 30 days after cancellation. You can export all your recordings and family trees before deletion.',
              },
              {
                q: 'Do you offer discounts for non-profits?',
                a: 'Yes! We offer special pricing for educational institutions and non-profit organizations. Contact our sales team for details.',
              },
              {
                q: 'How secure is my family data?',
                a: 'We use bank-level encryption (AES-256) for all data at rest and in transit. Your privacy and security are our top priorities.',
              },
            ].map((faq, idx) => (
              <Card key={idx} className="p-6">
                <h4 className="text-lg font-semibold text-gray-900 mb-2">{faq.q}</h4>
                <p className="text-gray-600">{faq.a}</p>
              </Card>
            ))}
          </div>
        </div>

        {/* Final CTA */}
        <div className="mt-16 text-center">
          <h3 className="text-2xl font-bold text-gray-900 mb-4">Still have questions?</h3>
          <p className="text-gray-600 mb-6">Our team is here to help you choose the right plan</p>
          <Button size="lg" onClick={() => navigate('/?contact=true')}>Contact Sales</Button>
        </div>
      </div>
    </div>
  );
};

export default Pricing;
