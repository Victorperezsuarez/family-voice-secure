import React from 'react';
import LandingPage from './LandingPage';

const Index: React.FC = () => {
  return <LandingPage />;
};

export default Index;

