import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase-client';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import ComplianceDashboard from '@/components/compliance/ComplianceDashboard';
import ComplianceTemplateCard from '@/components/compliance/ComplianceTemplateCard';
import { EmailNotificationPreferences } from '@/components/compliance/EmailNotificationPreferences';
import { EmailDeliveryDashboard } from '@/components/compliance/EmailDeliveryDashboard';
import ABTestAnalyticsDashboard from '@/components/compliance/ABTestAnalyticsDashboard';
import { MVTTestCreationDialog } from '@/components/mvt/MVTTestCreationDialog';
import { MVTAnalyticsDashboard } from '@/components/mvt/MVTAnalyticsDashboard';

import { DeliverabilityHealthDashboard } from '@/components/compliance/DeliverabilityHealthDashboard';
import { ComplianceReportTemplate, ComplianceReport, ComplianceCertificate, ComplianceSchedule } from '@/types/compliance';
import { Plus, FileText, Calendar, Award, Download, Mail, Edit, Shield } from 'lucide-react';
import { EmailTemplateEditor } from '@/components/compliance/EmailTemplateEditor';
import { TemplateVersionHistory } from '@/components/compliance/TemplateVersionHistory';
import { toast } from 'sonner';



export default function ComplianceReporting() {
  const [templates, setTemplates] = useState<ComplianceReportTemplate[]>([]);
  const [reports, setReports] = useState<ComplianceReport[]>([]);
  const [certificates, setCertificates] = useState<ComplianceCertificate[]>([]);
  const [schedules, setSchedules] = useState<ComplianceSchedule[]>([]);
  const [showGenerateDialog, setShowGenerateDialog] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<ComplianceReportTemplate | null>(null);
  const [generating, setGenerating] = useState(false);
  const [periodStart, setPeriodStart] = useState('');
  const [periodEnd, setPeriodEnd] = useState('');
  const [orgName, setOrgName] = useState('');
  const [showEmailEditor, setShowEmailEditor] = useState(false);
  const [editingEmailTemplate, setEditingEmailTemplate] = useState<string | undefined>();
  const [emailTemplates, setEmailTemplates] = useState<any[]>([]);
  const [showMVTDialog, setShowMVTDialog] = useState(false);
  const [selectedMVTTest, setSelectedMVTTest] = useState<string | null>(null);
  const [mvtTests, setMVTTests] = useState<any[]>([]);


  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const [templatesRes, reportsRes, certsRes, schedulesRes, emailTemplatesRes, mvtRes] = await Promise.all([
      supabase.from('compliance_report_templates').select('*').order('created_at', { ascending: false }),
      supabase.from('compliance_reports').select('*').order('generated_at', { ascending: false }).limit(20),
      supabase.from('compliance_certificates').select('*').order('issued_date', { ascending: false }).limit(20),
      supabase.from('compliance_schedules').select('*').order('created_at', { ascending: false }),
      supabase.from('email_templates').select('*').order('created_at', { ascending: false }),
      supabase.from('notification_ab_tests').select('*').eq('test_type', 'mvt').order('created_at', { ascending: false })
    ]);

    if (templatesRes.data) setTemplates(templatesRes.data);
    if (reportsRes.data) setReports(reportsRes.data);
    if (certsRes.data) setCertificates(certsRes.data);
    if (schedulesRes.data) setSchedules(schedulesRes.data);
    if (emailTemplatesRes.data) setEmailTemplates(emailTemplatesRes.data);
    if (mvtRes.data) setMVTTests(mvtRes.data);
  };



  const generateReport = async () => {
    if (!selectedTemplate || !periodStart || !periodEnd || !orgName) {
      toast.error('Please fill all fields');
      return;
    }

    setGenerating(true);
    try {
      const { data: reportData } = await supabase.functions.invoke('generate-compliance-report', {
        body: { 
          templateId: selectedTemplate.id, 
          periodStart, 
          periodEnd,
          organizationName: orgName
        }
      });

      const { data: report } = await supabase.from('compliance_reports').insert({
        template_id: selectedTemplate.id,
        title: `${selectedTemplate.standard} Compliance Report`,
        standard: selectedTemplate.standard,
        report_period_start: periodStart,
        report_period_end: periodEnd,
        report_data: reportData.reportData,
        summary: reportData.summary,
        status: 'completed'
      }).select().single();

      if (report && reportData.complianceScore >= 75) {
        const { data: certData } = await supabase.functions.invoke('generate-compliance-certificate', {
          body: {
            reportId: report.id,
            organizationName: orgName,
            standard: selectedTemplate.standard,
            complianceScore: reportData.complianceScore
          }
        });

        await supabase.from('compliance_certificates').insert({
          report_id: report.id,
          certificate_number: certData.certificateNumber,
          standard: certData.standard,
          issued_to: orgName,
          valid_from: certData.validFrom,
          valid_until: certData.validUntil,
          compliance_score: certData.complianceScore,
          findings: certData.findings,
          digital_signature: certData.digitalSignature,
          certificate_data: certData
        });
      }

      toast.success('Report generated successfully');
      setShowGenerateDialog(false);
      loadData();
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setGenerating(false);
    }
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Compliance Reporting</h1>
          <p className="text-muted-foreground">Automated compliance reports and certificates</p>
        </div>
      </div>

      <Tabs defaultValue="dashboard" className="space-y-6">
        <TabsList>
          <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
          <TabsTrigger value="certificates">Certificates</TabsTrigger>
          <TabsTrigger value="schedules">Schedules</TabsTrigger>
          <TabsTrigger value="email-templates">
            <Edit className="h-4 w-4 mr-2" />
            Email Templates
          </TabsTrigger>
          <TabsTrigger value="ab-testing">
            <FileText className="h-4 w-4 mr-2" />
            A/B Testing
          </TabsTrigger>
          <TabsTrigger value="mvt-testing">
            <FileText className="h-4 w-4 mr-2" />
            MVT Testing
          </TabsTrigger>
          <TabsTrigger value="notifications">
            <Mail className="h-4 w-4 mr-2" />
            Preferences
          </TabsTrigger>
          <TabsTrigger value="delivery">Tracking</TabsTrigger>
          <TabsTrigger value="deliverability">
            <Shield className="h-4 w-4 mr-2" />
            Deliverability
          </TabsTrigger>
        </TabsList>




        <TabsContent value="dashboard">
          <ComplianceDashboard />
        </TabsContent>

        <TabsContent value="templates">
          <div className="space-y-4">
            <div className="flex justify-between">
              <h2 className="text-xl font-semibold">Report Templates</h2>
              <Button><Plus className="h-4 w-4 mr-2" />New Template</Button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {templates.map(template => (
                <ComplianceTemplateCard
                  key={template.id}
                  template={template}
                  onEdit={() => {}}
                  onDelete={() => {}}
                  onGenerate={(t) => {
                    setSelectedTemplate(t);
                    setShowGenerateDialog(true);
                  }}
                />
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="email-templates">
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Email Templates</h2>
              <Button onClick={() => { setEditingEmailTemplate(undefined); setShowEmailEditor(true); }}>
                <Plus className="h-4 w-4 mr-2" />New Email Template
              </Button>
            </div>

            <div className="grid gap-4">
              {emailTemplates.map(template => (
                <Card key={template.id}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle>{template.name}</CardTitle>
                        <CardDescription>{template.subject}</CardDescription>
                      </div>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => { setEditingEmailTemplate(template.id); setShowEmailEditor(true); }}
                      >
                        <Edit className="h-4 w-4 mr-2" />Edit
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <TemplateVersionHistory templateId={template.id} />
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="reports">
          <div className="space-y-4">
            <h2 className="text-xl font-semibold">Generated Reports</h2>
            {reports.map(report => (
              <Card key={report.id}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle>{report.title}</CardTitle>
                      <CardDescription>
                        {new Date(report.report_period_start).toLocaleDateString()} - {new Date(report.report_period_end).toLocaleDateString()}
                      </CardDescription>
                    </div>
                    <Badge>{report.standard}</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between items-center">
                    <div className="text-sm">
                      <span className="font-medium">Score:</span> {report.summary?.complianceScore?.toFixed(1)}%
                    </div>
                    <Button size="sm" variant="outline">
                      <Download className="h-4 w-4 mr-2" />Export
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="certificates">
          <div className="space-y-4">
            <h2 className="text-xl font-semibold">Compliance Certificates</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {certificates.map(cert => (
                <Card key={cert.id}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-2">
                        <Award className="h-5 w-5 text-yellow-500" />
                        <div>
                          <CardTitle className="text-lg">{cert.standard} Certificate</CardTitle>
                          <CardDescription>{cert.certificate_number}</CardDescription>
                        </div>
                      </div>
                      <Badge variant={cert.status === 'valid' ? 'default' : 'secondary'}>{cert.status}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 text-sm">
                      <div><span className="font-medium">Issued to:</span> {cert.issued_to}</div>
                      <div><span className="font-medium">Valid until:</span> {new Date(cert.valid_until).toLocaleDateString()}</div>
                      <div><span className="font-medium">Score:</span> {cert.compliance_score?.toFixed(1)}%</div>
                      <Button size="sm" className="w-full mt-2">
                        <Download className="h-4 w-4 mr-2" />Download Certificate
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="schedules">
          <div className="space-y-4">
            <div className="flex justify-between">
              <h2 className="text-xl font-semibold">Report Schedules</h2>
              <Button><Plus className="h-4 w-4 mr-2" />New Schedule</Button>
            </div>
            {schedules.map(schedule => (
              <Card key={schedule.id}>
                <CardHeader>
                  <CardTitle>{schedule.name}</CardTitle>
                  <CardDescription>Frequency: {schedule.frequency}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-sm">
                    <div>Recipients: {schedule.email_recipients.join(', ')}</div>
                    {schedule.next_run_at && (
                      <div className="text-muted-foreground mt-1">
                        Next run: {new Date(schedule.next_run_at).toLocaleString()}
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="ab-testing">
          <ABTestAnalyticsDashboard />
        </TabsContent>

        <TabsContent value="mvt-testing">
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Multi-Variate Testing</h2>
              <Button onClick={() => setShowMVTDialog(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Create MVT Test
              </Button>
            </div>

            <div className="grid gap-4">
              {mvtTests.map(test => (
                <Card key={test.id} className="cursor-pointer hover:bg-gray-50" onClick={() => setSelectedMVTTest(test.id)}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle>{test.name}</CardTitle>
                        <CardDescription>{test.description}</CardDescription>
                      </div>
                      <Badge>{test.status}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="text-sm text-gray-600">
                      Elements: {test.elements?.length || 0} | 
                      Factorial Design: {test.factorial_design || 'full'}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {selectedMVTTest && (
              <MVTAnalyticsDashboard testId={selectedMVTTest} />
            )}
          </div>
        </TabsContent>

        <TabsContent value="notifications">
          <div className="space-y-4">
            <h2 className="text-xl font-semibold">Email Notification Preferences</h2>
            <EmailNotificationPreferences />
          </div>
        </TabsContent>

        <TabsContent value="delivery">
          <div className="space-y-4">
            <h2 className="text-xl font-semibold">Email Delivery Tracking</h2>
            <EmailDeliveryDashboard />
          </div>
        </TabsContent>

        <TabsContent value="deliverability">
          <DeliverabilityHealthDashboard />
        </TabsContent>
      </Tabs>

      <Dialog open={showGenerateDialog} onOpenChange={setShowGenerateDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Generate Compliance Report</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Organization Name</Label>
              <Input value={orgName} onChange={(e) => setOrgName(e.target.value)} placeholder="Your Organization" />
            </div>
            <div>
              <Label>Period Start</Label>
              <Input type="date" value={periodStart} onChange={(e) => setPeriodStart(e.target.value)} />
            </div>
            <div>
              <Label>Period End</Label>
              <Input type="date" value={periodEnd} onChange={(e) => setPeriodEnd(e.target.value)} />
            </div>
            <Button onClick={generateReport} disabled={generating} className="w-full">
              {generating ? 'Generating...' : 'Generate Report'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>


      <Dialog open={showEmailEditor} onOpenChange={setShowEmailEditor}>
        <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingEmailTemplate ? 'Edit Email Template' : 'Create Email Template'}</DialogTitle>
          </DialogHeader>
          <EmailTemplateEditor 
            templateId={editingEmailTemplate} 
            onSave={() => {
              setShowEmailEditor(false);
              loadData();
            }}
          />
        </DialogContent>
      </Dialog>

      <MVTTestCreationDialog 
        open={showMVTDialog} 
        onOpenChange={(open) => {
          setShowMVTDialog(open);
          if (!open) loadData();
        }} 
      />
    </div>
  );
}
