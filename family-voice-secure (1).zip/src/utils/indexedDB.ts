const DB_NAME = 'VelaOfflineDB';
const DB_VERSION = 2;

export interface OfflineRecording {
  id: string;
  title: string;
  audio_url: string;
  audioBlob?: Blob;
  transcription?: string;
  member_id: string;
  family_id: string;
  tags?: string[];
  duration?: number;
  created_at: string;
  updated_at?: string;
  synced: boolean;
  version?: number;
}

export interface OfflinePhoto {
  id: string;
  photo_url: string;
  photoBlob?: Blob;
  caption?: string;
  member_id?: string;
  family_id: string;
  tags?: string[];
  created_at: string;
  updated_at?: string;
  synced: boolean;
  version?: number;
}

export interface OfflineFamilyMember {
  id: string;
  name: string;
  relationship: string;
  photo_url?: string;
  family_id: string;
  birth_date?: string;
  updated_at?: string;
  synced: boolean;
  version?: number;
}

class IndexedDBManager {
  private db: IDBDatabase | null = null;

  async init(): Promise<void> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        this.db = request.result;
        resolve();
      };

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;

        if (!db.objectStoreNames.contains('recordings')) {
          db.createObjectStore('recordings', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('photos')) {
          db.createObjectStore('photos', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('familyMembers')) {
          db.createObjectStore('familyMembers', { keyPath: 'id' });
        }
      };
    });
  }

  async addRecording(recording: OfflineRecording): Promise<void> {
    if (!this.db) await this.init();
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['recordings'], 'readwrite');
      const store = transaction.objectStore('recordings');
      const request = store.put(recording);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async getRecordings(familyId: string): Promise<OfflineRecording[]> {
    if (!this.db) await this.init();
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['recordings'], 'readonly');
      const store = transaction.objectStore('recordings');
      const request = store.getAll();
      request.onsuccess = () => {
        const all = request.result as OfflineRecording[];
        resolve(all.filter(r => r.family_id === familyId));
      };
      request.onerror = () => reject(request.error);
    });
  }

  async addPhoto(photo: OfflinePhoto): Promise<void> {
    if (!this.db) await this.init();
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['photos'], 'readwrite');
      const store = transaction.objectStore('photos');
      const request = store.put(photo);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async getPhotos(familyId: string): Promise<OfflinePhoto[]> {
    if (!this.db) await this.init();
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['photos'], 'readonly');
      const store = transaction.objectStore('photos');
      const request = store.getAll();
      request.onsuccess = () => {
        const all = request.result as OfflinePhoto[];
        resolve(all.filter(p => p.family_id === familyId));
      };
      request.onerror = () => reject(request.error);
    });
  }

  async addFamilyMember(member: OfflineFamilyMember): Promise<void> {
    if (!this.db) await this.init();
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['familyMembers'], 'readwrite');
      const store = transaction.objectStore('familyMembers');
      const request = store.put(member);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async getFamilyMembers(familyId: string): Promise<OfflineFamilyMember[]> {
    if (!this.db) await this.init();
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['familyMembers'], 'readonly');
      const store = transaction.objectStore('familyMembers');
      const request = store.getAll();
      request.onsuccess = () => {
        const all = request.result as OfflineFamilyMember[];
        resolve(all.filter(m => m.family_id === familyId));
      };
      request.onerror = () => reject(request.error);
    });
  }

  async deleteRecording(id: string): Promise<void> {
    if (!this.db) await this.init();
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['recordings'], 'readwrite');
      const store = transaction.objectStore('recordings');
      const request = store.delete(id);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async clearSyncedData(): Promise<void> {
    if (!this.db) await this.init();
    const stores = ['recordings', 'photos', 'familyMembers'];
    for (const storeName of stores) {
      const transaction = this.db!.transaction([storeName], 'readwrite');
      const store = transaction.objectStore(storeName);
      const request = store.getAll();
      request.onsuccess = () => {
        const items = request.result;
        items.forEach((item: any) => {
          if (item.synced) {
            store.delete(item.id);
          }
        });
      };
    }
  }
}

export const indexedDB = new IndexedDBManager();
