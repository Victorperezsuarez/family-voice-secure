import { UserBehaviorFeatures, SegmentPrediction } from '@/types/segmentPrediction';

export function calculateEngagementScore(features: Partial<UserBehaviorFeatures>): number {
  let score = 0;
  
  score += Math.min(features.totalSessions || 0, 30);
  score += Math.min((features.totalRecordings || 0) * 2, 15);
  score += Math.min((features.totalPhotos || 0) * 0.5, 10);
  score += Math.min((features.totalCollections || 0) * 3, 15);
  score += (features.notificationOpenRate || 0) * 10;
  score += (features.notificationClickRate || 0) * 10;
  score += (features.featureAdoptionScore || 0) * 10;
  
  return Math.min(score, 100);
}

export function calculateRetentionScore(features: Partial<UserBehaviorFeatures>): number {
  let score = 0;
  
  score += Math.min((features.daysActive || 0) * 2, 40);
  
  const lastActiveDays = features.lastActiveDaysAgo || 999;
  if (lastActiveDays === 0) score += 30;
  else if (lastActiveDays <= 1) score += 25;
  else if (lastActiveDays <= 3) score += 20;
  else if (lastActiveDays <= 7) score += 15;
  else if (lastActiveDays <= 14) score += 10;
  else if (lastActiveDays <= 30) score += 5;
  
  const daysSinceSignup = features.daysSinceSignup || 1;
  const sessionFrequency = (features.totalSessions || 0) / Math.max(daysSinceSignup, 1);
  score += Math.min(sessionFrequency * 30, 30);
  
  return Math.min(score, 100);
}

export function predictUserSegment(
  userId: string,
  features: Partial<UserBehaviorFeatures>
): SegmentPrediction {
  const engagement = calculateEngagementScore(features);
  const retention = calculateRetentionScore(features);
  
  const scores = calculateSegmentScores(features, engagement, retention);
  const { segment, confidence, probabilities } = selectSegment(scores);
  
  return {
    userId,
    predictedSegment: segment,
    confidenceScore: confidence,
    segmentProbabilities: probabilities,
    featuresUsed: { ...features, engagementScore: engagement, retentionScore: retention },
    modelVersion: '1.0.0',
    predictionMethod: 'hybrid',
    timestamp: new Date().toISOString()
  };
}

function calculateSegmentScores(
  features: Partial<UserBehaviorFeatures>,
  engagement: number,
  retention: number
) {
  const scores: Record<string, number> = {
    high_engagement: 0,
    moderate_engagement: 0,
    low_engagement: 0,
    new_user: 0,
    at_risk: 0,
    power_user: 0
  };
  
  const daysSinceSignup = features.daysSinceSignup || 0;
  
  if (daysSinceSignup < 7) {
    scores.new_user = 80 + (engagement * 0.2);
    scores.high_engagement = engagement * 0.3;
    scores.moderate_engagement = 20;
  } else if (engagement >= 70 && retention >= 70) {
    scores.power_user = (engagement + retention) / 2;
    scores.high_engagement = engagement * 0.5;
  } else if (retention < 30) {
    scores.at_risk = 100 - retention;
    scores.low_engagement = 50 - engagement * 0.3;
  } else if (engagement >= 60) {
    scores.high_engagement = engagement;
    scores.moderate_engagement = 100 - engagement;
  } else if (engagement >= 30) {
    scores.moderate_engagement = 60 + (engagement - 30);
    scores.high_engagement = engagement * 0.5;
    scores.low_engagement = (60 - engagement) * 0.5;
  } else {
    scores.low_engagement = 70 + (30 - engagement);
    scores.moderate_engagement = engagement;
  }
  
  return scores;
}

function selectSegment(scores: Record<string, number>) {
  const temperature = 0.5;
  const expScores: Record<string, number> = {};
  let sumExp = 0;
  
  for (const [segment, score] of Object.entries(scores)) {
    const exp = Math.exp(score / 100 * temperature);
    expScores[segment] = exp;
    sumExp += exp;
  }
  
  const probabilities: Record<string, number> = {};
  let maxProb = 0;
  let predictedSegment = 'moderate_engagement';
  
  for (const [segment, exp] of Object.entries(expScores)) {
    const prob = exp / sumExp;
    probabilities[segment] = Math.round(prob * 1000) / 1000;
    if (prob > maxProb) {
      maxProb = prob;
      predictedSegment = segment;
    }
  }
  
  const confidence = Math.round(maxProb * 100) / 100;
  
  return { segment: predictedSegment, confidence, probabilities };
}
