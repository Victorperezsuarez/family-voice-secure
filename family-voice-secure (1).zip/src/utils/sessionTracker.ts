import { supabase } from '@/lib/supabase-client';

let sessionId: string | null = null;
let heartbeatInterval: NodeJS.Timeout | null = null;

export async function startSession(templateId: string) {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    // Check for existing active session
    const { data: existing } = await supabase
      .from('template_active_sessions')
      .select('id')
      .eq('template_id', templateId)
      .eq('user_id', user.id)
      .eq('is_active', true)
      .single();

    if (existing) {
      sessionId = existing.id;
      await updateSession();
    } else {
      // Create new session
      const { data: newSession } = await supabase
        .from('template_active_sessions')
        .insert({
          template_id: templateId,
          user_id: user.id,
          is_active: true
        })
        .select('id')
        .single();

      sessionId = newSession?.id || null;
    }

    // Start heartbeat (update every 2 minutes)
    if (heartbeatInterval) clearInterval(heartbeatInterval);
    heartbeatInterval = setInterval(() => updateSession(), 120000);

    // Update on page visibility change
    document.addEventListener('visibilitychange', handleVisibilityChange);
  } catch (error) {
    console.error('Failed to start session:', error);
  }
}

async function updateSession() {
  if (!sessionId) return;

  try {
    await supabase
      .from('template_active_sessions')
      .update({ last_activity: new Date().toISOString() })
      .eq('id', sessionId);
  } catch (error) {
    console.error('Failed to update session:', error);
  }
}

export async function endSession() {
  if (!sessionId) return;

  try {
    await supabase
      .from('template_active_sessions')
      .update({ is_active: false })
      .eq('id', sessionId);

    if (heartbeatInterval) {
      clearInterval(heartbeatInterval);
      heartbeatInterval = null;
    }

    document.removeEventListener('visibilitychange', handleVisibilityChange);
    sessionId = null;
  } catch (error) {
    console.error('Failed to end session:', error);
  }
}

function handleVisibilityChange() {
  if (document.hidden) {
    endSession();
  } else if (sessionId) {
    updateSession();
  }
}
