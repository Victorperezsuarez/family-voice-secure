// Operational Transformation (OT) for text editing
export interface TextOperation {
  type: 'insert' | 'delete' | 'retain';
  position: number;
  text?: string;
  length?: number;
  userId: string;
  timestamp: number;
}

export interface TransformResult {
  transformed: TextOperation;
  conflict: boolean;
}

// Transform operation A against operation B
export function transform(opA: TextOperation, opB: TextOperation): TransformResult {
  // If operations don't overlap, no conflict
  if (!operationsOverlap(opA, opB)) {
    return { transformed: adjustPosition(opA, opB), conflict: false };
  }

  // Handle conflicts based on operation types
  if (opA.type === 'insert' && opB.type === 'insert') {
    return transformInsertInsert(opA, opB);
  } else if (opA.type === 'delete' && opB.type === 'delete') {
    return transformDeleteDelete(opA, opB);
  } else if (opA.type === 'insert' && opB.type === 'delete') {
    return transformInsertDelete(opA, opB);
  } else if (opA.type === 'delete' && opB.type === 'insert') {
    return transformDeleteInsert(opA, opB);
  }

  return { transformed: opA, conflict: true };
}

function operationsOverlap(opA: TextOperation, opB: TextOperation): boolean {
  const aStart = opA.position;
  const aEnd = opA.position + (opA.length || opA.text?.length || 0);
  const bStart = opB.position;
  const bEnd = opB.position + (opB.length || opB.text?.length || 0);

  return !(aEnd <= bStart || bEnd <= aStart);
}

function adjustPosition(op: TextOperation, reference: TextOperation): TextOperation {
  if (reference.type === 'insert' && reference.position <= op.position) {
    return { ...op, position: op.position + (reference.text?.length || 0) };
  } else if (reference.type === 'delete' && reference.position < op.position) {
    return { ...op, position: Math.max(reference.position, op.position - (reference.length || 0)) };
  }
  return op;
}

function transformInsertInsert(opA: TextOperation, opB: TextOperation): TransformResult {
  if (opA.position === opB.position) {
    // Use timestamp to determine order
    if (opA.timestamp < opB.timestamp) {
      return { transformed: opA, conflict: false };
    } else {
      return { 
        transformed: { ...opA, position: opA.position + (opB.text?.length || 0) }, 
        conflict: false 
      };
    }
  }
  return { transformed: adjustPosition(opA, opB), conflict: false };
}

function transformDeleteDelete(opA: TextOperation, opB: TextOperation): TransformResult {
  // If deleting same range, keep one
  if (opA.position === opB.position && opA.length === opB.length) {
    return { transformed: { ...opA, length: 0 }, conflict: false };
  }
  return { transformed: opA, conflict: true };
}

function transformInsertDelete(opA: TextOperation, opB: TextOperation): TransformResult {
  if (opB.position <= opA.position && opA.position < opB.position + (opB.length || 0)) {
    return { transformed: { ...opA, position: opB.position }, conflict: false };
  }
  return { transformed: adjustPosition(opA, opB), conflict: false };
}

function transformDeleteInsert(opA: TextOperation, opB: TextOperation): TransformResult {
  if (opB.position <= opA.position) {
    return { 
      transformed: { ...opA, position: opA.position + (opB.text?.length || 0) }, 
      conflict: false 
    };
  }
  return { transformed: opA, conflict: false };
}

// Apply operation to text
export function applyOperation(text: string, op: TextOperation): string {
  switch (op.type) {
    case 'insert':
      return text.slice(0, op.position) + (op.text || '') + text.slice(op.position);
    case 'delete':
      return text.slice(0, op.position) + text.slice(op.position + (op.length || 0));
    case 'retain':
      return text;
    default:
      return text;
  }
}

// Detect conflicts between two versions
export function detectConflicts(
  baseText: string,
  versionA: string,
  versionB: string
): Array<{ start: number; end: number; textA: string; textB: string }> {
  const conflicts: Array<{ start: number; end: number; textA: string; textB: string }> = [];
  const diffsA = computeDiff(baseText, versionA);
  const diffsB = computeDiff(baseText, versionB);

  for (const diffA of diffsA) {
    for (const diffB of diffsB) {
      if (rangesOverlap(diffA, diffB)) {
        conflicts.push({
          start: Math.min(diffA.start, diffB.start),
          end: Math.max(diffA.end, diffB.end),
          textA: versionA.slice(diffA.start, diffA.end),
          textB: versionB.slice(diffB.start, diffB.end),
        });
      }
    }
  }

  return conflicts;
}

function computeDiff(oldText: string, newText: string): Array<{ start: number; end: number }> {
  const changes: Array<{ start: number; end: number }> = [];
  let i = 0;
  let j = 0;

  while (i < oldText.length || j < newText.length) {
    if (oldText[i] !== newText[j]) {
      const start = j;
      while (j < newText.length && oldText[i] !== newText[j]) {
        j++;
      }
      changes.push({ start, end: j });
    }
    i++;
    j++;
  }

  return changes;
}

function rangesOverlap(a: { start: number; end: number }, b: { start: number; end: number }): boolean {
  return !(a.end <= b.start || b.end <= a.start);
}
