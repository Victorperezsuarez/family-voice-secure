import { ShapValue, CounterfactualScenario, PredictionExplanation } from '@/types/explainableAI';
import { UserBehaviorFeatures } from '@/types/segmentPrediction';

// Calculate SHAP values using a simplified additive model
export function calculateShapValues(features: UserBehaviorFeatures): ShapValue[] {
  const baseValue = 0.5; // Base probability
  
  const shapValues: ShapValue[] = [
    {
      feature: 'engagementScore',
      value: features.engagementScore,
      contribution: (features.engagementScore - 50) * 0.008,
      displayName: 'Engagement Score'
    },
    {
      feature: 'retentionScore',
      value: features.retentionScore,
      contribution: (features.retentionScore - 50) * 0.007,
      displayName: 'Retention Score'
    },
    {
      feature: 'daysSinceSignup',
      value: features.daysSinceSignup,
      contribution: Math.log(features.daysSinceSignup + 1) * -0.05,
      displayName: 'Days Since Signup'
    },
    {
      feature: 'totalSessions',
      value: features.totalSessions,
      contribution: Math.log(features.totalSessions + 1) * 0.06,
      displayName: 'Total Sessions'
    },
    {
      feature: 'avgSessionDuration',
      value: features.avgSessionDuration,
      contribution: (features.avgSessionDuration - 300) * 0.0003,
      displayName: 'Avg Session Duration'
    }
  ];

  return shapValues.sort((a, b) => Math.abs(b.contribution) - Math.abs(a.contribution));
}

// Generate counterfactual scenarios
export function generateCounterfactuals(
  features: UserBehaviorFeatures,
  currentSegment: string
): CounterfactualScenario[] {
  const scenarios: CounterfactualScenario[] = [];

  if (currentSegment !== 'power_user') {
    scenarios.push({
      feature: 'engagementScore',
      currentValue: features.engagementScore,
      suggestedValue: 85,
      predictedSegment: 'power_user',
      confidence: 0.92,
      displayName: 'Engagement Score'
    });
  }

  if (currentSegment === 'at_risk') {
    scenarios.push({
      feature: 'retentionScore',
      currentValue: features.retentionScore,
      suggestedValue: 60,
      predictedSegment: 'moderate_engagement',
      confidence: 0.78,
      displayName: 'Retention Score'
    });
  }

  return scenarios;
}
