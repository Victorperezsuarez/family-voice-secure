import { FeatureExperiment, ExperimentResult } from '@/types/featureExperimentation';

export function calculateStatisticalSignificance(
  controlMean: number,
  treatmentMean: number,
  controlStd: number,
  treatmentStd: number,
  controlSize: number,
  treatmentSize: number
): { pValue: number; isSignificant: boolean; confidenceInterval: { lower: number; upper: number } } {
  // Two-sample t-test
  const pooledStd = Math.sqrt(
    (controlStd ** 2 / controlSize) + (treatmentStd ** 2 / treatmentSize)
  );
  const tStatistic = (treatmentMean - controlMean) / pooledStd;
  
  // Approximate p-value (simplified)
  const pValue = 2 * (1 - normalCDF(Math.abs(tStatistic)));
  
  // 95% confidence interval
  const marginOfError = 1.96 * pooledStd;
  const difference = treatmentMean - controlMean;
  
  return {
    pValue,
    isSignificant: pValue < 0.05,
    confidenceInterval: {
      lower: difference - marginOfError,
      upper: difference + marginOfError
    }
  };
}

function normalCDF(x: number): number {
  const t = 1 / (1 + 0.2316419 * Math.abs(x));
  const d = 0.3989423 * Math.exp(-x * x / 2);
  const prob = d * t * (0.3193815 + t * (-0.3565638 + t * (1.781478 + t * (-1.821256 + t * 1.330274))));
  return x > 0 ? 1 - prob : prob;
}

export function shouldPromoteConfiguration(
  results: ExperimentResult[],
  minimumImprovement: number = 0.05
): { shouldPromote: boolean; reason: string; improvement: number } {
  const controlResults = results.filter(r => r.config_id.includes('control'));
  const treatmentResults = results.filter(r => !r.config_id.includes('control'));
  
  if (controlResults.length === 0 || treatmentResults.length === 0) {
    return { shouldPromote: false, reason: 'Insufficient data', improvement: 0 };
  }
  
  const controlMean = controlResults.reduce((sum, r) => sum + r.metric_value, 0) / controlResults.length;
  const treatmentMean = treatmentResults.reduce((sum, r) => sum + r.metric_value, 0) / treatmentResults.length;
  
  const improvement = (treatmentMean - controlMean) / controlMean;
  
  const hasSignificance = treatmentResults.some(r => r.statistical_significance);
  const meetsThreshold = improvement >= minimumImprovement;
  
  if (hasSignificance && meetsThreshold) {
    return { 
      shouldPromote: true, 
      reason: `${(improvement * 100).toFixed(2)}% improvement with statistical significance`,
      improvement 
    };
  }
  
  return { shouldPromote: false, reason: 'Does not meet promotion criteria', improvement };
}

export function allocateTraffic(
  userId: string,
  allocation: { control: number; treatments: Record<string, number> }
): string {
  const hash = hashString(userId);
  const random = hash % 100;
  
  let cumulative = 0;
  
  if (random < allocation.control) {
    return 'control';
  }
  cumulative += allocation.control;
  
  for (const [treatment, percentage] of Object.entries(allocation.treatments)) {
    cumulative += percentage;
    if (random < cumulative) {
      return treatment;
    }
  }
  
  return 'control';
}

function hashString(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash);
}
