import { GeneratedFeature, FeatureCorrelation, AggregationType } from '@/types/featureEngineering';
import { UserBehaviorFeatures } from '@/types/segmentPrediction';

// Generate time-series features from raw behavior data
export function generateTimeSeriesFeatures(
  behaviorHistory: Array<{ timestamp: Date; action: string; value?: number }>,
  windows: string[] = ['1h', '24h', '7d', '30d']
): GeneratedFeature[] {
  const features: GeneratedFeature[] = [];
  const now = new Date();

  windows.forEach(window => {
    const windowMs = parseTimeWindow(window);
    const recentActions = behaviorHistory.filter(
      b => now.getTime() - b.timestamp.getTime() <= windowMs
    );

    // Count-based features
    features.push({
      name: `action_count_${window}`,
      type: 'time_series',
      description: `Number of actions in last ${window}`,
      importance: 0.7,
      value: recentActions.length
    });

    // Unique action types
    const uniqueActions = new Set(recentActions.map(a => a.action)).size;
    features.push({
      name: `unique_actions_${window}`,
      type: 'time_series',
      description: `Unique action types in last ${window}`,
      importance: 0.6,
      value: uniqueActions
    });

    // Average value if present
    const withValues = recentActions.filter(a => a.value !== undefined);
    if (withValues.length > 0) {
      const avgValue = withValues.reduce((sum, a) => sum + (a.value || 0), 0) / withValues.length;
      features.push({
        name: `avg_value_${window}`,
        type: 'time_series',
        description: `Average value in last ${window}`,
        importance: 0.5,
        value: avgValue
      });
    }
  });

  return features;
}

// Generate derived features from base features
export function generateDerivedFeatures(baseFeatures: UserBehaviorFeatures): GeneratedFeature[] {
  const derived: GeneratedFeature[] = [];

  // Engagement intensity
  const engagementIntensity = baseFeatures.total_sessions > 0
    ? baseFeatures.total_duration / baseFeatures.total_sessions
    : 0;
  derived.push({
    name: 'engagement_intensity',
    type: 'derived',
    description: 'Average session duration (intensity)',
    importance: 0.85,
    value: engagementIntensity
  });

  // Activity frequency
  const daysSinceSignup = Math.max(1, 
    (Date.now() - new Date(baseFeatures.signup_date).getTime()) / (1000 * 60 * 60 * 24)
  );
  const activityFrequency = baseFeatures.total_sessions / daysSinceSignup;
  derived.push({
    name: 'activity_frequency',
    type: 'derived',
    description: 'Sessions per day since signup',
    importance: 0.9,
    value: activityFrequency
  });

  // Engagement momentum (recent vs historical)
  const recentEngagement = baseFeatures.sessions_last_7d / 7;
  const historicalEngagement = baseFeatures.total_sessions / daysSinceSignup;
  const momentum = historicalEngagement > 0 ? recentEngagement / historicalEngagement : 0;
  derived.push({
    name: 'engagement_momentum',
    type: 'derived',
    description: 'Recent engagement vs historical average',
    importance: 0.8,
    value: momentum
  });

  return derived;
}

// Calculate correlation matrix for features
export function calculateCorrelationMatrix(
  features: Array<Record<string, number>>
): { features: string[]; matrix: number[][] } {
  if (features.length === 0) return { features: [], matrix: [] };

  const featureNames = Object.keys(features[0]);
  const n = featureNames.length;
  const matrix: number[][] = Array(n).fill(0).map(() => Array(n).fill(0));

  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) {
      if (i === j) {
        matrix[i][j] = 1;
      } else {
        matrix[i][j] = pearsonCorrelation(
          features.map(f => f[featureNames[i]]),
          features.map(f => f[featureNames[j]])
        );
      }
    }
  }

  return { features: featureNames, matrix };
}

// Pearson correlation coefficient
function pearsonCorrelation(x: number[], y: number[]): number {
  const n = x.length;
  if (n === 0) return 0;

  const meanX = x.reduce((a, b) => a + b, 0) / n;
  const meanY = y.reduce((a, b) => a + b, 0) / n;

  let numerator = 0;
  let denomX = 0;
  let denomY = 0;

  for (let i = 0; i < n; i++) {
    const dx = x[i] - meanX;
    const dy = y[i] - meanY;
    numerator += dx * dy;
    denomX += dx * dx;
    denomY += dy * dy;
  }

  const denom = Math.sqrt(denomX * denomY);
  return denom === 0 ? 0 : numerator / denom;
}

// Feature selection using mutual information approximation
export function selectFeaturesByImportance(
  features: GeneratedFeature[],
  topK: number = 10
): GeneratedFeature[] {
  return features
    .sort((a, b) => b.importance - a.importance)
    .slice(0, topK);
}

// Parse time window string to milliseconds
function parseTimeWindow(window: string): number {
  const value = parseInt(window);
  const unit = window.slice(-1);
  
  switch (unit) {
    case 'h': return value * 60 * 60 * 1000;
    case 'd': return value * 24 * 60 * 60 * 1000;
    case 'w': return value * 7 * 24 * 60 * 60 * 1000;
    default: return value;
  }
}
