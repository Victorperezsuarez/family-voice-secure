import { SyncQueueItem, SyncOperationType, SyncStatus, ConflictResolution } from '@/types/sync';
import { supabase } from '@/lib/supabase-client';

const SYNC_QUEUE_KEY = 'vela_sync_queue';
const MAX_RETRIES = 5;
const RETRY_DELAYS = [1000, 2000, 5000, 10000, 30000]; // Exponential backoff

class SyncQueueManager {
  private queue: SyncQueueItem[] = [];
  private isSyncing = false;
  private listeners: Set<() => void> = new Set();

  constructor() {
    this.loadQueue();
    this.setupOnlineListener();
  }

  private loadQueue() {
    const stored = localStorage.getItem(SYNC_QUEUE_KEY);
    if (stored) {
      this.queue = JSON.parse(stored);
    }
  }

  private saveQueue() {
    localStorage.setItem(SYNC_QUEUE_KEY, JSON.stringify(this.queue));
    this.notifyListeners();
  }

  private setupOnlineListener() {
    window.addEventListener('online', () => {
      console.log('Device online, starting sync...');
      this.processQueue();
    });
  }

  addToQueue(type: SyncOperationType, data: any): string {
    const item: SyncQueueItem = {
      id: `${Date.now()}_${Math.random()}`,
      type,
      data,
      timestamp: Date.now(),
      retryCount: 0,
      status: 'pending'
    };
    this.queue.push(item);
    this.saveQueue();
    
    if (navigator.onLine) {
      this.processQueue();
    }
    
    return item.id;
  }

  async processQueue() {
    if (this.isSyncing || !navigator.onLine) return;
    
    this.isSyncing = true;
    const pendingItems = this.queue.filter(item => 
      item.status === 'pending' || item.status === 'error'
    );

    for (const item of pendingItems) {
      await this.syncItem(item);
    }

    this.isSyncing = false;
    this.saveQueue();
  }

  private async syncItem(item: SyncQueueItem) {
    item.status = 'syncing';
    this.saveQueue();

    try {
      await this.executeSync(item);
      item.status = 'success';
      this.removeFromQueue(item.id);
    } catch (error: any) {
      item.retryCount++;
      
      if (error.code === 'CONFLICT') {
        item.status = 'conflict';
        item.conflictData = error.conflictData;
      } else if (item.retryCount >= MAX_RETRIES) {
        item.status = 'error';
        item.error = error.message;
      } else {
        item.status = 'error';
        const delay = RETRY_DELAYS[item.retryCount - 1] || 30000;
        setTimeout(() => this.processQueue(), delay);
      }
      this.saveQueue();
    }
  }

  private async executeSync(item: SyncQueueItem) {
    switch (item.type) {
      case 'create_recording':
        return await supabase.from('recordings').insert(item.data);
      case 'update_recording':
        return await supabase.from('recordings').update(item.data).eq('id', item.data.id);
      case 'delete_recording':
        return await supabase.from('recordings').delete().eq('id', item.data.id);
      case 'upload_photo':
        const { photoBlob, path } = item.data;
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('photos')
          .upload(path, photoBlob);
        if (uploadError) throw uploadError;
        return await supabase.from('photos').insert({
          ...item.data.metadata,
          photo_url: uploadData.path
        });
      case 'create_member':
        return await supabase.from('family_members').insert(item.data);
      case 'update_member':
        return await supabase.from('family_members').update(item.data).eq('id', item.data.id);
      default:
        throw new Error(`Unknown sync type: ${item.type}`);
    }
  }


  removeFromQueue(id: string) {
    this.queue = this.queue.filter(item => item.id !== id);
    this.saveQueue();
  }

  getQueue(): SyncQueueItem[] {
    return [...this.queue];
  }

  subscribe(callback: () => void) {
    this.listeners.add(callback);
    return () => this.listeners.delete(callback);
  }

  private notifyListeners() {
    this.listeners.forEach(callback => callback());
  }

  async resolveConflict(itemId: string, resolution: ConflictResolution) {
    const item = this.queue.find(i => i.id === itemId);
    if (!item) return;

    if (resolution.strategy === 'local') {
      item.status = 'pending';
      item.conflictData = undefined;
      await this.processQueue();
    } else if (resolution.strategy === 'remote') {
      this.removeFromQueue(itemId);
    }
  }
}

export const syncQueue = new SyncQueueManager();
