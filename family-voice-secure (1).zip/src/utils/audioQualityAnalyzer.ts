export interface AudioQualityMetrics {
  volumeLevel: number; // 0-100
  backgroundNoise: number; // 0-100 (lower is better)
  clarity: number; // 0-100
  duration: number; // seconds
  overallScore: number; // 0-100
  passed: boolean;
}

export async function analyzeAudioQuality(
  audioBlob: Blob
): Promise<AudioQualityMetrics> {
  const audioContext = new AudioContext();
  const arrayBuffer = await audioBlob.arrayBuffer();
  const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
  
  const channelData = audioBuffer.getChannelData(0);
  const duration = audioBuffer.duration;
  
  // Calculate RMS (volume level)
  let sumSquares = 0;
  for (let i = 0; i < channelData.length; i++) {
    sumSquares += channelData[i] * channelData[i];
  }
  const rms = Math.sqrt(sumSquares / channelData.length);
  const volumeLevel = Math.min(100, rms * 1000);
  
  // Estimate background noise (first 0.5s)
  const noiseFrames = Math.min(audioBuffer.sampleRate * 0.5, channelData.length);
  let noiseSumSquares = 0;
  for (let i = 0; i < noiseFrames; i++) {
    noiseSumSquares += channelData[i] * channelData[i];
  }
  const noiseRms = Math.sqrt(noiseSumSquares / noiseFrames);
  const backgroundNoise = Math.min(100, noiseRms * 2000);
  
  // Clarity (signal-to-noise ratio estimate)
  const snr = rms / (noiseRms + 0.001);
  const clarity = Math.min(100, snr * 10);
  
  // Overall score
  const volumeScore = volumeLevel > 20 && volumeLevel < 80 ? 100 : 50;
  const noiseScore = 100 - backgroundNoise;
  const clarityScore = clarity;
  const durationScore = duration >= 3 && duration <= 10 ? 100 : 70;
  
  const overallScore = (volumeScore + noiseScore + clarityScore + durationScore) / 4;
  
  return {
    volumeLevel,
    backgroundNoise,
    clarity,
    duration,
    overallScore,
    passed: overallScore >= 70 && duration >= 3
  };
}
