export type VoiceCommand = 
  | { type: 'SELECT_MEMBER'; name: string }
  | { type: 'START_RECORDING' }
  | { type: 'STOP_RECORDING' }
  | { type: 'PAUSE_RECORDING' }
  | { type: 'RESUME_RECORDING' }
  | { type: 'PLAY_LAST' }
  | { type: 'DELETE_RECORDING' }
  | { type: 'SEARCH'; keyword: string }
  | { type: 'SEMANTIC_SEARCH'; query: string }
  | { type: 'ADD_MEMBER'; name?: string }
  | { type: 'CHANGE_LANGUAGE'; language: string }
  | { type: 'SHOW_MEMBER_RECORDINGS'; name: string }
  | { type: 'CANCEL' }
  | { type: 'UNKNOWN'; text: string };


const LANGUAGE_MAP: Record<string, string> = {
  'spanish': 'es-MX', 'español': 'es-MX', 'castellano': 'es-MX',
  'english': 'en-US', 'inglés': 'en-US', 'ingles': 'en-US',
  'french': 'fr-FR', 'francés': 'fr-FR', 'frances': 'fr-FR',
  'german': 'de-DE', 'alemán': 'de-DE', 'aleman': 'de-DE',
  'italian': 'it-IT', 'italiano': 'it-IT',
  'portuguese': 'pt-BR', 'portugués': 'pt-BR', 'portugues': 'pt-BR'
};

export function parseVoiceCommand(transcription: string): VoiceCommand {
  const text = transcription.toLowerCase().trim();

  // Change language
  const langPatterns = [
    /(?:change|switch|cambiar|cambio|cambia)\s+(?:language|idioma|lenguaje)?\s*(?:to|a)?\s+(\w+)/i,
    /(?:set|establecer|pon|poner)\s+(?:language|idioma)\s+(?:to|a)?\s*(\w+)/i
  ];
  for (const pattern of langPatterns) {
    const match = text.match(pattern);
    if (match) {
      const lang = LANGUAGE_MAP[match[1].toLowerCase()] || match[1];
      return { type: 'CHANGE_LANGUAGE', language: lang };
    }
  }

  // Delete recording
  if (/(delete|remove|erase|elimina|borra|quita|borrar).*(recording|grabación|grabacion)/i.test(text)) {
    return { type: 'DELETE_RECORDING' };
  }

  // Semantic search patterns (more natural language)
  const semanticPatterns = [
    /(?:find|busca|encuentra|search for|buscar)\s+(?:recordings?|stories|memories|grabaciones?|historias|recuerdos)\s+(?:about|where|that|de|sobre|donde|que)\s+(.+)/i,
    /(?:show me|muéstrame|muestra)\s+(?:recordings?|stories|memories|grabaciones?|historias)\s+(?:about|where|that|de|sobre|donde|que)\s+(.+)/i,
    /(?:recordings?|stories|memories|grabaciones?|historias)\s+(?:about|where|mentioning|talking about|de|sobre|que mencionan|que hablan de)\s+(.+)/i
  ];
  for (const pattern of semanticPatterns) {
    const match = text.match(pattern);
    if (match) {
      return { type: 'SEMANTIC_SEARCH', query: match[1].trim() };
    }
  }

  // Basic search (keyword-based)
  const searchPatterns = [
    /(?:search|busca|buscar|encuentra|find)\s+(?:for|por)?\s*(.+)/i,
    /(?:show|muestra|mostrar|ver)\s+(?:recordings?|grabaciones?)\s+(?:about|de|con|with)\s+(.+)/i
  ];
  for (const pattern of searchPatterns) {
    const match = text.match(pattern);
    if (match && !/(member|miembro|familiar)/i.test(text)) {
      return { type: 'SEARCH', keyword: match[1].trim() };
    }
  }


  // Show member recordings
  const memberRecPatterns = [
    /(?:show|muestra|mostrar|ver)\s+(?:all\s+)?(?:recordings?|grabaciones?)\s+(?:for|de|from)\s+(.+)/i,
    /(?:recordings?|grabaciones?)\s+(?:for|de|from)\s+(.+)/i
  ];
  for (const pattern of memberRecPatterns) {
    const match = text.match(pattern);
    if (match) {
      return { type: 'SHOW_MEMBER_RECORDINGS', name: match[1].trim() };
    }
  }

  // Add member
  if (/(add|agregar|añadir|nuevo|new).*(member|miembro|familiar|person|persona)/i.test(text)) {
    const nameMatch = text.match(/(?:add|agregar|añadir)\s+(?:new\s+)?(?:member|miembro|familiar)?\s*(.+)/i);
    return { type: 'ADD_MEMBER', name: nameMatch?.[1]?.trim() };
  }

  // Select member
  const selectPatterns = [
    /(?:select|choose|pick|selecciona|elige|escoge)\s+(.+)/i,
  ];
  for (const pattern of selectPatterns) {
    const match = text.match(pattern);
    if (match && !/record|play|stop|language|idioma/.test(text)) {
      return { type: 'SELECT_MEMBER', name: match[1].trim() };
    }
  }

  // Start recording
  if (/(start|begin|record|graba|comienza|empie|iniciar)/i.test(text) && !/stop|para/.test(text)) {
    return { type: 'START_RECORDING' };
  }

  // Stop recording
  if (/(stop|finish|end|termina|para|detén|finaliza)/i.test(text) && /record/i.test(text)) {
    return { type: 'STOP_RECORDING' };
  }

  // Pause
  if (/pause|pausa/i.test(text)) {
    return { type: 'PAUSE_RECORDING' };
  }

  // Resume
  if (/(resume|continue|reanuda|continua|reanudar)/i.test(text)) {
    return { type: 'RESUME_RECORDING' };
  }

  // Play last
  if (/(play|reproduce|escucha|listen)/i.test(text) && /(last|recent|última|último|latest)/i.test(text)) {
    return { type: 'PLAY_LAST' };
  }

  // Cancel
  if (/(cancel|cancela|abort|abortar)/i.test(text)) {
    return { type: 'CANCEL' };
  }

  return { type: 'UNKNOWN', text };
}
