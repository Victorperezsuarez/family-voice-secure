import { supabase } from '@/lib/supabase-client';
import type { DriftDetectionResult, FeatureDistributionSnapshot } from '@/types/realtimeFeatures';

export async function processStreamingUpdate(
  userId: string,
  eventType: string,
  eventData: Record<string, any>
): Promise<void> {
  const features = computeFeaturesFromEvent(userId, eventType, eventData);
  
  for (const [featureName, featureValue] of Object.entries(features)) {
    await supabase.from('streaming_feature_updates').insert({
      user_id: userId,
      feature_name: featureName,
      feature_value: featureValue as number,
      update_source: eventType,
      processed_at: new Date().toISOString()
    });
  }
}

function computeFeaturesFromEvent(
  userId: string,
  eventType: string,
  eventData: Record<string, any>
): Record<string, number> {
  const features: Record<string, number> = {};
  
  if (eventType === 'recording_created') {
    features['total_recordings'] = 1;
    features['recording_duration'] = eventData.duration || 0;
  } else if (eventType === 'collection_viewed') {
    features['collection_views'] = 1;
  }
  
  return features;
}

export async function detectDistributionDrift(
  featureName: string,
  windowDays: number = 7
): Promise<DriftDetectionResult> {
  const { data: snapshots } = await supabase
    .from('feature_distribution_snapshots')
    .select('*')
    .eq('feature_name', featureName)
    .order('snapshot_date', { ascending: false })
    .limit(windowDays);

  if (!snapshots || snapshots.length < 2) {
    return {
      feature_name: featureName,
      drift_detected: false,
      drift_score: 0,
      current_distribution: { mean: 0, std_dev: 0 },
      baseline_distribution: { mean: 0, std_dev: 0 },
      recommendation: 'Insufficient data'
    };
  }

  const current = snapshots[0];
  const baseline = snapshots[snapshots.length - 1];
  
  const meanDiff = Math.abs(current.mean_value - baseline.mean_value);
  const stdDiff = Math.abs(current.std_dev - baseline.std_dev);
  const driftScore = (meanDiff / (baseline.std_dev || 1)) * 100;
  
  return {
    feature_name: featureName,
    drift_detected: driftScore > 20,
    drift_score: driftScore,
    current_distribution: {
      mean: current.mean_value,
      std_dev: current.std_dev
    },
    baseline_distribution: {
      mean: baseline.mean_value,
      std_dev: baseline.std_dev
    },
    recommendation: driftScore > 20 ? 'Model retraining recommended' : 'No action needed'
  };
}
