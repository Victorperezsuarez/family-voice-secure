import { FamilyMember, FamilyTreeNode, TreeLayout, Connection } from '@/types/familyTree';

export function calculateTreeLayout(members: FamilyMember[]): TreeLayout {
  const nodes: FamilyTreeNode[] = [];
  const connections: Connection[] = [];
  const memberMap = new Map<string, FamilyMember>();
  
  members.forEach(m => memberMap.set(m.id, m));
  
  // Find root members (those without parents)
  const roots = members.filter(m => 
    !m.relationships.some(r => r.type === 'child')
  );
  
  let currentY = 50;
  const generationGap = 200;
  const siblingGap = 150;
  
  function layoutGeneration(parentNodes: FamilyTreeNode[], generation: number) {
    const newNodes: FamilyTreeNode[] = [];
    let currentX = 50;
    
    parentNodes.forEach(parentNode => {
      const children = parentNode.member.relationships
        .filter(r => r.type === 'parent')
        .map(r => memberMap.get(r.relatedMemberId))
        .filter(Boolean) as FamilyMember[];
      
      children.forEach((child, idx) => {
        const childNode: FamilyTreeNode = {
          member: child,
          x: currentX + (idx * siblingGap),
          y: currentY,
          generation,
          children: []
        };
        
        newNodes.push(childNode);
        nodes.push(childNode);
        connections.push({
          from: parentNode.member.id,
          to: child.id,
          type: 'parent-child'
        });
        
        parentNode.children.push(childNode);
      });
      
      currentX += children.length * siblingGap + 100;
    });
    
    return newNodes;
  }
  
  // Layout root generation
  roots.forEach((root, idx) => {
    const node: FamilyTreeNode = {
      member: root,
      x: 50 + (idx * siblingGap),
      y: currentY,
      generation: 0,
      children: []
    };
    nodes.push(node);
  });
  
  return {
    width: Math.max(...nodes.map(n => n.x)) + 200,
    height: Math.max(...nodes.map(n => n.y)) + 200,
    nodes,
    connections
  };
}
