import { useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';

interface UsageLimitCheck {
  allowed: boolean;
  current: number;
  max: number;
  percentage: number;
  planName: string;
  shouldUpgrade: boolean;
}

export function useUsageLimit() {
  const [checking, setChecking] = useState(false);
  const navigate = useNavigate();

  const checkLimit = useCallback(async (resource: string): Promise<boolean> => {
    setChecking(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast.error('Please sign in to continue');
        return false;
      }

      const { data, error } = await supabase.functions.invoke('check-usage-limit', {
        body: { resource, userId: user.id }
      });

      if (error) throw error;

      const result = data as UsageLimitCheck;

      if (!result.allowed) {
        toast.error(`You've reached your ${resource} limit`, {
          description: `Upgrade to continue using this feature`,
          action: {
            label: 'Upgrade',
            onClick: () => navigate('/pricing')
          }
        });
        return false;
      }

      if (result.shouldUpgrade) {
        toast.warning(`You're at ${result.percentage.toFixed(0)}% of your ${resource} limit`, {
          description: 'Consider upgrading your plan',
          action: {
            label: 'View Plans',
            onClick: () => navigate('/pricing')
          }
        });
      }

      return true;
    } catch (error) {
      console.error('Error checking limit:', error);
      toast.error('Failed to check usage limit');
      return false;
    } finally {
      setChecking(false);
    }
  }, [navigate]);

  return { checkLimit, checking };
}