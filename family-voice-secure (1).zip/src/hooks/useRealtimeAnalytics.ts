import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase-client';
import { RealtimeChannel } from '@supabase/supabase-js';

interface RealtimeAnalytics {
  activeSessions: number;
  recentEvents: any[];
  liveUsers: any[];
}

export function useRealtimeAnalytics(templateId: string) {
  const [analytics, setAnalytics] = useState<RealtimeAnalytics>({
    activeSessions: 0,
    recentEvents: [],
    liveUsers: []
  });
  const [isLive, setIsLive] = useState(false);

  useEffect(() => {
    let channel: RealtimeChannel;

    const setupRealtimeSubscription = async () => {
      // Initial fetch
      await fetchCurrentData();

      // Subscribe to real-time updates
      channel = supabase
        .channel(`template-analytics-${templateId}`)
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'template_usage_events',
            filter: `template_id=eq.${templateId}`
          },
          (payload) => {
            handleUsageEvent(payload);
          }
        )
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'template_active_sessions',
            filter: `template_id=eq.${templateId}`
          },
          (payload) => {
            handleSessionChange(payload);
          }
        )
        .subscribe((status) => {
          setIsLive(status === 'SUBSCRIBED');
        });
    };

    setupRealtimeSubscription();

    return () => {
      if (channel) {
        supabase.removeChannel(channel);
      }
    };
  }, [templateId]);

  const fetchCurrentData = async () => {
    const [sessionsRes, eventsRes] = await Promise.all([
      supabase
        .from('template_active_sessions')
        .select('*')
        .eq('template_id', templateId)
        .eq('is_active', true),
      supabase
        .from('template_usage_events')
        .select('*')
        .eq('template_id', templateId)
        .order('created_at', { ascending: false })
        .limit(10)
    ]);

    setAnalytics({
      activeSessions: sessionsRes.data?.length || 0,
      recentEvents: eventsRes.data || [],
      liveUsers: sessionsRes.data || []
    });
  };

  const handleUsageEvent = (payload: any) => {
    setAnalytics(prev => ({
      ...prev,
      recentEvents: [payload.new, ...prev.recentEvents.slice(0, 9)]
    }));
  };

  const handleSessionChange = async (payload: any) => {
    await fetchCurrentData();
  };

  return { analytics, isLive, refresh: fetchCurrentData };
}
