import { useState, useCallback, useRef } from 'react';
import { supabase } from '@/lib/supabase-client';
import { parseVoiceCommand, VoiceCommand } from '@/utils/commandParser';

export interface VoiceCommandState {
  isListening: boolean;
  lastCommand: VoiceCommand | null;
  error: string | null;
}

export function useVoiceCommands() {
  const [state, setState] = useState<VoiceCommandState>({
    isListening: false,
    lastCommand: null,
    error: null
  });

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  const startListening = useCallback(async (language = 'es-MX') => {
    try {
      setState(prev => ({ ...prev, isListening: true, error: null }));
      
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        stream.getTracks().forEach(track => track.stop());

        // Upload and transcribe
        const fileName = `command-${Date.now()}.webm`;
        const { error: uploadError } = await supabase.storage
          .from('recordings')
          .upload(fileName, audioBlob);

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from('recordings')
          .getPublicUrl(fileName);

        const { data } = await supabase.functions.invoke('transcribe-audio', {
          body: { audioUrl: publicUrl, language }
        });

        const transcription = data?.transcription || '';
        const command = parseVoiceCommand(transcription);

        setState(prev => ({ ...prev, lastCommand: command, isListening: false }));
      };

      mediaRecorder.start();

      // Auto-stop after 5 seconds
      setTimeout(() => {
        if (mediaRecorderRef.current?.state === 'recording') {
          mediaRecorderRef.current.stop();
        }
      }, 5000);

    } catch (error: any) {
      setState(prev => ({ ...prev, error: error.message, isListening: false }));
    }
  }, []);

  const stopListening = useCallback(() => {
    if (mediaRecorderRef.current?.state === 'recording') {
      mediaRecorderRef.current.stop();
    }
  }, []);

  return {
    ...state,
    startListening,
    stopListening
  };
}
