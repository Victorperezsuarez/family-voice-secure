import { useCallback } from 'react';
import { useOfflineSync } from '@/contexts/OfflineSyncContext';
import { toast } from 'sonner';

export function useOfflineSyncActions() {
  const { isOnline, addToQueue } = useOfflineSync();

  const createRecording = useCallback(async (data: any) => {
    const queueId = addToQueue('create_recording', data);
    
    if (isOnline) {
      toast.success('Recording saved and uploading...');
    } else {
      toast.info('Recording saved offline. Will sync when online.');
    }
    
    return queueId;
  }, [isOnline, addToQueue]);

  const updateRecording = useCallback(async (data: any) => {
    const queueId = addToQueue('update_recording', data);
    
    if (isOnline) {
      toast.success('Changes saved and syncing...');
    } else {
      toast.info('Changes saved offline. Will sync when online.');
    }
    
    return queueId;
  }, [isOnline, addToQueue]);

  const uploadPhoto = useCallback(async (data: any) => {
    const queueId = addToQueue('upload_photo', data);
    
    if (isOnline) {
      toast.success('Photo uploading...');
    } else {
      toast.info('Photo saved offline. Will upload when online.');
    }
    
    return queueId;
  }, [isOnline, addToQueue]);

  const createMember = useCallback(async (data: any) => {
    const queueId = addToQueue('create_member', data);
    
    if (isOnline) {
      toast.success('Family member added');
    } else {
      toast.info('Family member saved offline. Will sync when online.');
    }
    
    return queueId;
  }, [isOnline, addToQueue]);

  return {
    createRecording,
    updateRecording,
    uploadPhoto,
    createMember,
    isOnline
  };
}
