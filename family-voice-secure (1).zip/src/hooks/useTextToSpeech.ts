import { useState, useRef } from 'react';
import { supabase } from '@/lib/supabase-client';

interface TTSState {
  isSpeaking: boolean;
  error: string | null;
}

export const useTextToSpeech = () => {
  const [state, setState] = useState<TTSState>({
    isSpeaking: false,
    error: null,
  });

  const audioRef = useRef<HTMLAudioElement | null>(null);

  const speak = async (text: string, language = 'es-MX') => {
    try {
      setState({ isSpeaking: true, error: null });

      const { data, error } = await supabase.functions.invoke('text-to-speech', {
        body: { text, language },
      });


      if (error) throw error;

      if (data?.audioContent) {
        const audioBlob = base64ToBlob(data.audioContent, 'audio/mp3');
        const audioUrl = URL.createObjectURL(audioBlob);

        if (audioRef.current) {
          audioRef.current.pause();
          URL.revokeObjectURL(audioRef.current.src);
        }

        const audio = new Audio(audioUrl);
        audioRef.current = audio;

        audio.onended = () => {
          setState({ isSpeaking: false, error: null });
          URL.revokeObjectURL(audioUrl);
        };

        audio.onerror = () => {
          setState({ isSpeaking: false, error: 'Error playing audio' });
        };

        await audio.play();
      }
    } catch (error) {
      setState({ isSpeaking: false, error: (error as Error).message });
      console.error('TTS Error:', error);
    }
  };

  const stop = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
      setState({ isSpeaking: false, error: null });
    }
  };

  return { ...state, speak, stop };
};

function base64ToBlob(base64: string, mimeType: string): Blob {
  const byteCharacters = atob(base64);
  const byteNumbers = new Array(byteCharacters.length);
  for (let i = 0; i < byteCharacters.length; i++) {
    byteNumbers[i] = byteCharacters.charCodeAt(i);
  }
  const byteArray = new Uint8Array(byteNumbers);
  return new Blob([byteArray], { type: mimeType });
}