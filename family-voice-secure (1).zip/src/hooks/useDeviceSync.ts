import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';

export function useDeviceSync() {
  const [deviceId, setDeviceId] = useState<string>('');
  const [isRegistered, setIsRegistered] = useState(false);

  useEffect(() => {
    registerDevice();
    setupSyncListener();
  }, []);

  const registerDevice = async () => {
    try {
      // Get or create device ID
      let storedDeviceId = localStorage.getItem('deviceId');
      if (!storedDeviceId) {
        storedDeviceId = `device_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        localStorage.setItem('deviceId', storedDeviceId);
      }
      setDeviceId(storedDeviceId);

      // Detect device info
      const deviceInfo = {
        deviceId: storedDeviceId,
        deviceName: getDeviceName(),
        deviceType: getDeviceType(),
        browser: getBrowser(),
        os: getOS()
      };

      // Register with backend
      const { error } = await supabase.functions.invoke('register-device', {
        body: deviceInfo
      });

      if (error) throw error;
      setIsRegistered(true);
    } catch (error: any) {
      console.error('Device registration failed:', error);
    }
  };

  const setupSyncListener = () => {
    const channel = supabase
      .channel('notification_sync')
      .on('postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'notification_history' },
        (payload) => {
          // Notification was updated on another device
          const notification = payload.new;
          if (notification.is_read || notification.dismissed_at) {
            // Sync UI state
            window.dispatchEvent(new CustomEvent('notification-synced', {
              detail: notification
            }));
          }
        }
      )
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  };

  const syncNotificationStatus = async (
    notificationId: string,
    eventType: 'read' | 'dismissed' | 'action_taken'
  ) => {
    try {
      await supabase.functions.invoke('sync-notification-status', {
        body: { notificationId, eventType, deviceId }
      });
    } catch (error: any) {
      console.error('Sync failed:', error);
    }
  };

  return { deviceId, isRegistered, syncNotificationStatus };
}

function getDeviceName(): string {
  return `${getBrowser()} on ${getOS()}`;
}

function getDeviceType(): 'desktop' | 'mobile' | 'tablet' {
  const ua = navigator.userAgent;
  if (/(tablet|ipad|playbook|silk)|(android(?!.*mobi))/i.test(ua)) {
    return 'tablet';
  }
  if (/Mobile|Android|iP(hone|od)|IEMobile|BlackBerry|Kindle|Silk-Accelerated|(hpw|web)OS|Opera M(obi|ini)/.test(ua)) {
    return 'mobile';
  }
  return 'desktop';
}

function getBrowser(): string {
  const ua = navigator.userAgent;
  if (ua.includes('Chrome')) return 'Chrome';
  if (ua.includes('Firefox')) return 'Firefox';
  if (ua.includes('Safari')) return 'Safari';
  if (ua.includes('Edge')) return 'Edge';
  return 'Unknown';
}

function getOS(): string {
  const ua = navigator.userAgent;
  if (ua.includes('Win')) return 'Windows';
  if (ua.includes('Mac')) return 'macOS';
  if (ua.includes('Linux')) return 'Linux';
  if (ua.includes('Android')) return 'Android';
  if (ua.includes('iOS')) return 'iOS';
  return 'Unknown';
}
