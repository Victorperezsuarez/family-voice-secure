import { useState, useCallback, useEffect } from 'react';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';

interface VideoUploadProgress {
  videoId: string;
  progress: number;
  status: 'pending' | 'uploading' | 'completed' | 'failed';
}

export function useVideoSync() {
  const [uploads, setUploads] = useState<Map<string, VideoUploadProgress>>(new Map());
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const uploadVideo = useCallback(async (
    videoBlob: Blob,
    metadata: {
      title: string;
      description?: string;
      duration: number;
      quality: string;
      orientation: string;
    }
  ) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      // Create video record
      const { data: video, error: dbError } = await supabase
        .from('videos')
        .insert({
          user_id: user.id,
          title: metadata.title,
          description: metadata.description,
          duration: metadata.duration,
          quality: metadata.quality,
          orientation: metadata.orientation,
          file_size: videoBlob.size,
          storage_path: '',
          upload_status: 'uploading',
          upload_progress: 0
        })
        .select()
        .single();

      if (dbError) throw dbError;

      const videoId = video.id;
      setUploads(prev => new Map(prev).set(videoId, { videoId, progress: 0, status: 'uploading' }));

      // Upload to storage
      const fileName = `${user.id}/${videoId}.mp4`;
      const { error: uploadError } = await supabase.storage
        .from('videos')
        .upload(fileName, videoBlob, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) throw uploadError;

      // Update video record
      await supabase
        .from('videos')
        .update({
          storage_path: fileName,
          upload_status: 'completed',
          upload_progress: 100,
          synced_at: new Date().toISOString()
        })
        .eq('id', videoId);

      setUploads(prev => new Map(prev).set(videoId, { videoId, progress: 100, status: 'completed' }));
      toast.success('Video uploaded successfully');

      return videoId;
    } catch (error) {
      console.error('Upload error:', error);
      toast.error('Failed to upload video');
      throw error;
    }
  }, []);

  return {
    uploadVideo,
    uploads,
    isOnline
  };
}
