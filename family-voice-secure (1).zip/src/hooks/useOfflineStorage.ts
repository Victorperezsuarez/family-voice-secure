import { useState, useEffect } from 'react';
import { indexedDB, OfflineRecording, OfflinePhoto } from '@/utils/indexedDB';
import { useOfflineSync } from '@/contexts/OfflineSyncContext';

export function useOfflineStorage(familyId: string) {
  const [recordings, setRecordings] = useState<OfflineRecording[]>([]);
  const [photos, setPhotos] = useState<OfflinePhoto[]>([]);
  const [loading, setLoading] = useState(true);
  const { isOnline, addToQueue } = useOfflineSync();

  useEffect(() => {
    loadOfflineData();
  }, [familyId]);

  const loadOfflineData = async () => {
    try {
      const [offlineRecordings, offlinePhotos] = await Promise.all([
        indexedDB.getRecordings(familyId),
        indexedDB.getPhotos(familyId)
      ]);
      setRecordings(offlineRecordings);
      setPhotos(offlinePhotos);
    } catch (error) {
      console.error('Failed to load offline data:', error);
    } finally {
      setLoading(false);
    }
  };

  const saveRecording = async (recording: OfflineRecording) => {
    await indexedDB.addRecording(recording);
    if (isOnline) {
      addToQueue('create_recording', recording);
    }
    await loadOfflineData();
  };

  const savePhoto = async (photo: OfflinePhoto) => {
    await indexedDB.addPhoto(photo);
    if (isOnline) {
      addToQueue('upload_photo', photo);
    }
    await loadOfflineData();
  };

  const deleteRecording = async (id: string) => {
    await indexedDB.deleteRecording(id);
    await loadOfflineData();
  };

  return {
    recordings,
    photos,
    loading,
    saveRecording,
    savePhoto,
    deleteRecording,
    refresh: loadOfflineData
  };
}
