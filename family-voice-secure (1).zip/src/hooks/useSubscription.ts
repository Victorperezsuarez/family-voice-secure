import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase-client';
import { Subscription, Invoice } from '@/types/subscription';

export const useSubscription = (userId: string | undefined) => {
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!userId) {
      setLoading(false);
      return;
    }

    const fetchSubscription = async () => {
      const { data } = await supabase
        .from('subscriptions')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(1)
        .single();

      setSubscription(data);
      setLoading(false);
    };

    const fetchInvoices = async () => {
      const { data } = await supabase
        .from('invoices')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      setInvoices(data || []);
    };

    fetchSubscription();
    fetchInvoices();

    // Subscribe to changes
    const channel = supabase
      .channel('subscription-changes')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'subscriptions',
        filter: `user_id=eq.${userId}`
      }, fetchSubscription)
      .subscribe();

    return () => {
      channel.unsubscribe();
    };
  }, [userId]);

  return { subscription, invoices, loading };
};
