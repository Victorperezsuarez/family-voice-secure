# ⚡ Quick Start - Vela AI Assistant

## 🚀 Get Running in 3 Steps

### Step 1: Run Setup Script

**Mac/Linux:**
```bash
chmod +x scripts/setup-vela.sh
./scripts/setup-vela.sh
```

**Windows:**
```bash
scripts\setup-vela.bat
```

The script will:
- ✅ Create `.env` file
- ✅ Install dependencies
- ✅ Guide you through database setup

---

### Step 2: Add Your Keys

Edit `.env` file and replace placeholder values:

```env
VITE_SUPABASE_URL=https://iqrhacrtcgquvxmrlxnl.supabase.co
VITE_SUPABASE_ANON_KEY=your_actual_anon_key
VITE_VAPID_PUBLIC_KEY=your_actual_vapid_key
```

**Where to get keys:**
- **Supabase Anon Key**: [Get it here](https://supabase.com/dashboard/project/iqrhacrtcgquvxmrlxnl/settings/api)
- **VAPID Key**: Run `npm run generate-vapid` (optional for push notifications)

---

### Step 3: Run the App

```bash
npm run dev
```

Open: **http://localhost:8080**

---

## 🎯 What You'll See

1. **Landing Page** - Beautiful hero section
2. **Sign Up** - Create your account
3. **Dashboard** - Family memory management
4. **Vela Assistant** - AI-powered help

---

## 📱 Install as Mobile App

Once running:

**iOS:** Safari → Share → Add to Home Screen  
**Android:** Chrome → Menu → Install app

---

## 🌐 Deploy to Production

### Vercel (1-Click Deploy)

```bash
npm install -g vercel
vercel
```

Add environment variables in Vercel dashboard, then:
```bash
vercel --prod
```

### Netlify

```bash
npm install -g netlify-cli
netlify deploy --prod
```

---

## ✅ Verify Everything Works

- [ ] App loads at localhost:8080
- [ ] Can sign up/login
- [ ] Dashboard displays
- [ ] Can create Vela persona
- [ ] Notifications appear

---

## 🆘 Issues?

**App won't start?**
```bash
rm -rf node_modules
npm install
npm run dev
```

**Database errors?**
- Run the SQL migration from `supabase/migrations/20240112_vela_tables.sql`
- Go to [Supabase SQL Editor](https://supabase.com/dashboard/project/iqrhacrtcgquvxmrlxnl/sql/new)

**Build errors?**
```bash
npm run build
```
Check console for specific errors

---

## 📚 Full Documentation

- **Complete Setup**: `VELA_DEPLOYMENT_SETUP.md`
- **Deployment Guide**: `DEPLOYMENT_GUIDE.md`
- **Stripe Setup**: `STRIPE_SETUP.md`
- **VAPID Keys**: `VAPID_KEY_GENERATION.md`

---

## 💡 Pro Tips

- Use `.env.local` for local development
- Keep `.env.production` for deployed version
- Test locally before deploying
- Monitor Supabase dashboard for errors

---

**Ready to deploy?** See `DEPLOYMENT_GUIDE.md` for custom domains, SSL, and email setup!
