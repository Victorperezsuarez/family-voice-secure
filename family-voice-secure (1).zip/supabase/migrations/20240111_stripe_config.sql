-- Create stripe_config table to store Stripe Price IDs
CREATE TABLE IF NOT EXISTS stripe_config (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_name TEXT UNIQUE NOT NULL,
  monthly_price_id TEXT NOT NULL,
  annual_price_id TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE stripe_config ENABLE ROW LEVEL SECURITY;

-- Allow admins to read/write
CREATE POLICY "Admins can manage stripe config"
  ON stripe_config
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM family_members
      WHERE user_id = auth.uid()
      AND role IN ('owner', 'admin')
    )
  );

-- Allow all authenticated users to read config (needed for checkout)
CREATE POLICY "Authenticated users can read stripe config"
  ON stripe_config
  FOR SELECT
  TO authenticated
  USING (true);

-- Create index
CREATE INDEX idx_stripe_config_plan_name ON stripe_config(plan_name);

-- Insert default placeholder values
INSERT INTO stripe_config (plan_name, monthly_price_id, annual_price_id)
VALUES 
  ('family', 'price_family_monthly', 'price_family_annual'),
  ('premium', 'price_premium_monthly', 'price_premium_annual')
ON CONFLICT (plan_name) DO NOTHING;
