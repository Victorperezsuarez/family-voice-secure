-- Routing Analytics Tables
CREATE TABLE IF NOT EXISTS routing_analytics_metrics (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  family_id UUID NOT NULL REFERENCES families(id) ON DELETE CASCADE,
  metric_date DATE NOT NULL,
  total_assignments INTEGER DEFAULT 0,
  successful_assignments INTEGER DEFAULT 0,
  failed_assignments INTEGER DEFAULT 0,
  average_response_time_seconds INTEGER DEFAULT 0,
  total_escalations INTEGER DEFAULT 0,
  routing_efficiency_score DECIMAL(5,2) DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS team_member_performance (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  team_member_id UUID NOT NULL REFERENCES team_members(id) ON DELETE CASCADE,
  metric_date DATE NOT NULL,
  alerts_assigned INTEGER DEFAULT 0,
  alerts_resolved INTEGER DEFAULT 0,
  average_response_time_seconds INTEGER DEFAULT 0,
  average_resolution_time_seconds INTEGER DEFAULT 0,
  escalated_alerts INTEGER DEFAULT 0,
  success_rate DECIMAL(5,2) DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS skill_utilization_metrics (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  family_id UUID NOT NULL REFERENCES families(id) ON DELETE CASCADE,
  skill_name VARCHAR(100) NOT NULL,
  metric_date DATE NOT NULL,
  total_requests INTEGER DEFAULT 0,
  fulfilled_requests INTEGER DEFAULT 0,
  average_wait_time_seconds INTEGER DEFAULT 0,
  utilization_rate DECIMAL(5,2) DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_routing_analytics_family_date ON routing_analytics_metrics(family_id, metric_date);
CREATE INDEX idx_team_performance_member_date ON team_member_performance(team_member_id, metric_date);
CREATE INDEX idx_skill_utilization_family_date ON skill_utilization_metrics(family_id, metric_date);
