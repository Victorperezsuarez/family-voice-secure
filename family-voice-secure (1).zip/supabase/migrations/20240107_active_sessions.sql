-- Active sessions tracking for real-time analytics
CREATE TABLE IF NOT EXISTS template_active_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  template_id UUID NOT NULL REFERENCES templates(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  session_start TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  last_activity TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  is_active BOOLEAN DEFAULT true,
  user_agent TEXT,
  ip_address INET,
  country_code VARCHAR(2),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for fast queries
CREATE INDEX idx_active_sessions_template ON template_active_sessions(template_id, is_active);
CREATE INDEX idx_active_sessions_user ON template_active_sessions(user_id, is_active);
CREATE INDEX idx_active_sessions_activity ON template_active_sessions(last_activity);

-- Enable RLS
ALTER TABLE template_active_sessions ENABLE ROW LEVEL SECURITY;

-- Policy: Users can view sessions for templates they own
CREATE POLICY "Authors can view sessions"
  ON template_active_sessions FOR SELECT
  USING (
    template_id IN (
      SELECT id FROM templates WHERE author_id = auth.uid()
    )
  );

-- Policy: Users can insert their own sessions
CREATE POLICY "Users can create sessions"
  ON template_active_sessions FOR INSERT
  WITH CHECK (user_id = auth.uid());

-- Policy: Users can update their own sessions
CREATE POLICY "Users can update own sessions"
  ON template_active_sessions FOR UPDATE
  USING (user_id = auth.uid());

-- Function to cleanup inactive sessions
CREATE OR REPLACE FUNCTION cleanup_inactive_sessions()
RETURNS void AS $$
BEGIN
  UPDATE template_active_sessions
  SET is_active = false
  WHERE last_activity < NOW() - INTERVAL '5 minutes'
    AND is_active = true;
END;
$$ LANGUAGE plpgsql;
