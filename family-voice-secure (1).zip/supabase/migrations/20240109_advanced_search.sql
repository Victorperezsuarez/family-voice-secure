-- Advanced search capabilities for recordings and transcriptions

-- Create search index for transcriptions with full-text search
CREATE INDEX IF NOT EXISTS idx_transcriptions_search 
ON transcriptions USING gin(to_tsvector('english', content));

-- Create search index for recording metadata
CREATE INDEX IF NOT EXISTS idx_recordings_title_search 
ON recordings USING gin(to_tsvector('english', title));

-- Create search history table
CREATE TABLE IF NOT EXISTS search_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  family_id UUID REFERENCES families(id) ON DELETE CASCADE,
  query TEXT NOT NULL,
  filters JSONB DEFAULT '{}',
  results_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create speaker index table
CREATE TABLE IF NOT EXISTS transcription_speakers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  transcription_id UUID REFERENCES transcriptions(id) ON DELETE CASCADE,
  speaker_name TEXT NOT NULL,
  start_time FLOAT NOT NULL,
  end_time FLOAT NOT NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create topic tags table
CREATE TABLE IF NOT EXISTS transcription_topics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  transcription_id UUID REFERENCES transcriptions(id) ON DELETE CASCADE,
  topic TEXT NOT NULL,
  confidence FLOAT DEFAULT 0.0,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- RLS policies
ALTER TABLE search_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE transcription_speakers ENABLE ROW LEVEL SECURITY;
ALTER TABLE transcription_topics ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own search history"
ON search_history FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "Family members can view speakers"
ON transcription_speakers FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM transcriptions t
    JOIN recordings r ON t.recording_id = r.id
    JOIN family_members fm ON r.family_id = fm.family_id
    WHERE t.id = transcription_speakers.transcription_id
    AND fm.user_id = auth.uid()
  )
);

CREATE POLICY "Family members can view topics"
ON transcription_topics FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM transcriptions t
    JOIN recordings r ON t.recording_id = r.id
    JOIN family_members fm ON r.family_id = fm.family_id
    WHERE t.id = transcription_topics.transcription_id
    AND fm.user_id = auth.uid()
  )
);
