-- Vela AI Assistant Tables Migration
-- This creates all necessary tables for the Vela AI assistant feature

-- Vela Personas Table
CREATE TABLE IF NOT EXISTS vela_personas (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  profession TEXT,
  prompt_template TEXT NOT NULL,
  is_active BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Vela Conversations Table
CREATE TABLE IF NOT EXISTS vela_conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  persona_id UUID NOT NULL REFERENCES vela_personas(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  message TEXT NOT NULL,
  response TEXT,
  user_rating INTEGER,
  user_feedback TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Vela Proactive Suggestions Table
CREATE TABLE IF NOT EXISTS vela_proactive_suggestions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  persona_id UUID NOT NULL REFERENCES vela_personas(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  suggestion_text TEXT NOT NULL,
  suggestion_type TEXT NOT NULL,
  priority TEXT DEFAULT 'medium',
  status TEXT DEFAULT 'pending',
  accepted_at TIMESTAMPTZ,
  dismissed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Vela Conversation Topics Table
CREATE TABLE IF NOT EXISTS vela_conversation_topics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  persona_id UUID NOT NULL REFERENCES vela_personas(id) ON DELETE CASCADE,
  topic TEXT NOT NULL,
  frequency INTEGER DEFAULT 1,
  last_mentioned TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Vela Learned Knowledge Table
CREATE TABLE IF NOT EXISTS vela_learned_knowledge (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  persona_id UUID NOT NULL REFERENCES vela_personas(id) ON DELETE CASCADE,
  knowledge_text TEXT NOT NULL,
  source_conversation_id UUID REFERENCES vela_conversations(id) ON DELETE SET NULL,
  confidence_score FLOAT DEFAULT 0.5,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Vela Notification Preferences Table
CREATE TABLE IF NOT EXISTS vela_notification_preferences (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  suggestion_type TEXT NOT NULL,
  urgency_level TEXT NOT NULL,
  push_enabled BOOLEAN DEFAULT true,
  email_enabled BOOLEAN DEFAULT false,
  in_app_enabled BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, suggestion_type, urgency_level)
);

-- Vela Suggestion Queue Table
CREATE TABLE IF NOT EXISTS vela_suggestion_queue (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  suggestion_id UUID NOT NULL REFERENCES vela_proactive_suggestions(id) ON DELETE CASCADE,
  scheduled_for TIMESTAMPTZ NOT NULL,
  status TEXT DEFAULT 'pending',
  delivered_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Vela Suggestion Delivery Log Table
CREATE TABLE IF NOT EXISTS vela_suggestion_delivery_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  suggestion_id UUID NOT NULL REFERENCES vela_proactive_suggestions(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  delivery_channel TEXT NOT NULL,
  delivery_status TEXT NOT NULL,
  delivered_at TIMESTAMPTZ DEFAULT NOW()
);

-- Vela Suggestion Schedules Table
CREATE TABLE IF NOT EXISTS vela_suggestion_schedules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  day_of_week INTEGER NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  is_enabled BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Vela Optimal Timing Patterns Table
CREATE TABLE IF NOT EXISTS vela_optimal_timing_patterns (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  hour_of_day INTEGER NOT NULL,
  day_of_week INTEGER NOT NULL,
  engagement_score FLOAT DEFAULT 0,
  sample_size INTEGER DEFAULT 0,
  last_updated TIMESTAMPTZ DEFAULT NOW()
);

-- Vela Notification Delivery Table
CREATE TABLE IF NOT EXISTS vela_notification_delivery (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  notification_type TEXT NOT NULL,
  status TEXT NOT NULL,
  delivered_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_vela_personas_user_id ON vela_personas(user_id);
CREATE INDEX IF NOT EXISTS idx_vela_personas_active ON vela_personas(user_id, is_active);
CREATE INDEX IF NOT EXISTS idx_vela_conversations_persona ON vela_conversations(persona_id);
CREATE INDEX IF NOT EXISTS idx_vela_suggestions_persona ON vela_proactive_suggestions(persona_id);
CREATE INDEX IF NOT EXISTS idx_vela_suggestions_status ON vela_proactive_suggestions(status);
CREATE INDEX IF NOT EXISTS idx_vela_queue_scheduled ON vela_suggestion_queue(scheduled_for, status);

-- Enable Row Level Security
ALTER TABLE vela_personas ENABLE ROW LEVEL SECURITY;
ALTER TABLE vela_conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE vela_proactive_suggestions ENABLE ROW LEVEL SECURITY;
ALTER TABLE vela_conversation_topics ENABLE ROW LEVEL SECURITY;
ALTER TABLE vela_learned_knowledge ENABLE ROW LEVEL SECURITY;
ALTER TABLE vela_notification_preferences ENABLE ROW LEVEL SECURITY;
ALTER TABLE vela_suggestion_queue ENABLE ROW LEVEL SECURITY;
ALTER TABLE vela_suggestion_delivery_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE vela_suggestion_schedules ENABLE ROW LEVEL SECURITY;
ALTER TABLE vela_optimal_timing_patterns ENABLE ROW LEVEL SECURITY;
ALTER TABLE vela_notification_delivery ENABLE ROW LEVEL SECURITY;

-- RLS Policies: Users can only access their own data
CREATE POLICY "Users can view own personas" ON vela_personas FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own personas" ON vela_personas FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own personas" ON vela_personas FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own personas" ON vela_personas FOR DELETE USING (auth.uid() = user_id);

CREATE POLICY "Users can view own conversations" ON vela_conversations FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own conversations" ON vela_conversations FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own conversations" ON vela_conversations FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can view own suggestions" ON vela_proactive_suggestions FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can update own suggestions" ON vela_proactive_suggestions FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can view own preferences" ON vela_notification_preferences FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can manage own preferences" ON vela_notification_preferences FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "Users can view own queue" ON vela_suggestion_queue FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can manage own queue" ON vela_suggestion_queue FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "Users can view own schedules" ON vela_suggestion_schedules FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can manage own schedules" ON vela_suggestion_schedules FOR ALL USING (auth.uid() = user_id);
