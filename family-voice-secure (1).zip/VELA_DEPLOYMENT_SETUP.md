# 🤖 Vela AI Assistant - Complete Deployment Setup

## 🚀 Quick Start (5 Minutes)

### Step 1: Environment Setup

Create `.env` file in project root:

```env
VITE_SUPABASE_URL=https://iqrhacrtcgquvxmrlxnl.supabase.co
VITE_SUPABASE_ANON_KEY=your_anon_key_here
VITE_VAPID_PUBLIC_KEY=your_vapid_key_here
```

**Get your keys:**
- Supabase Anon Key: [Dashboard → API Settings](https://supabase.com/dashboard/project/iqrhacrtcgquvxmrlxnl/settings/api)
- VAPID Key: See `VAPID_KEY_GENERATION.md` for instructions

---

### Step 2: Install Dependencies

```bash
npm install
```

---

### Step 3: Setup Supabase Database

**Option A: Using Supabase Dashboard (Easiest)**

1. Go to [Supabase SQL Editor](https://supabase.com/dashboard/project/iqrhacrtcgquvxmrlxnl/sql/new)
2. Copy contents from `supabase/migrations/20240112_vela_tables.sql`
3. Paste into SQL Editor
4. Click "Run" to create all Vela tables

**Option B: Using Supabase CLI**

```bash
# Install Supabase CLI (if not installed)
npm install -g supabase

# Login to Supabase
supabase login

# Link to your project
supabase link --project-ref iqrhacrtcgquvxmrlxnl

# Run migrations
supabase db push
```

---

### Step 4: Run Development Server

```bash
npm run dev
```

Visit: `http://localhost:8080`

---

## 📦 What Gets Deployed

### Vela Features Included:
- ✅ AI Personas (Family, Professional, Custom)
- ✅ Proactive Suggestions
- ✅ Conversation History
- ✅ Smart Notifications
- ✅ Personalized Timing
- ✅ Multi-context Learning
- ✅ Push Notifications (PWA)

### Database Tables Created:
- `vela_personas` - AI assistant personalities
- `vela_conversations` - Chat history
- `vela_proactive_suggestions` - Smart recommendations
- `vela_notification_preferences` - User settings
- `vela_suggestion_queue` - Scheduled suggestions
- `vela_optimal_timing_patterns` - Learning patterns
- And 5 more supporting tables

---

## 🌐 Deploy to Production

### Deploy to Vercel (Recommended)

```bash
# Install Vercel CLI
npm install -g vercel

# Deploy
vercel

# Add environment variables in Vercel dashboard
# Then redeploy
vercel --prod
```

### Deploy to Netlify

```bash
# Install Netlify CLI
npm install -g netlify-cli

# Deploy
netlify deploy --prod
```

**Don't forget to add environment variables in hosting dashboard!**

---

## ✅ Deployment Checklist

- [ ] `.env` file created with all keys
- [ ] Dependencies installed (`npm install`)
- [ ] Supabase migration run successfully
- [ ] Dev server runs without errors
- [ ] Can create Vela persona
- [ ] Notifications work
- [ ] Deployed to Vercel/Netlify
- [ ] Environment variables added to hosting
- [ ] Production site tested
- [ ] PWA installs on mobile

---

## 🧪 Test Vela Features

After deployment, test these features:

1. **Create Persona**: Dashboard → Vela → Create new persona
2. **Chat**: Send message to Vela assistant
3. **Suggestions**: Check for proactive suggestions
4. **Notifications**: Enable push notifications
5. **Timing**: Check optimal timing insights

---

## 🆘 Troubleshooting

**"Table does not exist" error?**
- Run the Supabase migration (Step 3)
- Verify tables exist in Supabase dashboard

**Vela not responding?**
- Check Supabase URL and key are correct
- Verify RLS policies are enabled
- Check browser console for errors

**Push notifications not working?**
- Generate VAPID keys (see `VAPID_KEY_GENERATION.md`)
- Add VAPID public key to `.env`
- Test on HTTPS (localhost or deployed site)

**Build fails?**
- Clear node_modules: `rm -rf node_modules && npm install`
- Clear cache: `npm run build -- --force`

---

## 📚 Additional Resources

- Full Deployment Guide: `DEPLOYMENT_GUIDE.md`
- VAPID Setup: `VAPID_KEY_GENERATION.md`
- Stripe Setup: `STRIPE_SETUP.md`
- Trial Setup: `TRIAL_SETUP.md`

---

## 🎯 Next Steps

After successful deployment:

1. **Customize Personas**: Edit profession templates in `src/types/vela.ts`
2. **Adjust Timing**: Configure suggestion schedules
3. **Brand Notifications**: Customize notification templates
4. **Monitor Usage**: Check Supabase dashboard for analytics
5. **Add Custom Domain**: See `DEPLOYMENT_GUIDE.md` for DNS setup

---

## 💡 Pro Tips

- Test locally before deploying to production
- Use environment-specific keys (dev vs prod)
- Monitor Supabase logs for errors
- Set up error tracking (Sentry, LogRocket)
- Enable Supabase backups
- Document custom persona templates

---

**Need Help?** Check the troubleshooting section or review error logs in:
- Browser Console (F12)
- Supabase Dashboard → Logs
- Vercel/Netlify Deployment Logs
