#!/bin/bash

# Vela Deployment Setup Script
# This script automates the setup process for Vela AI Assistant

set -e  # Exit on error

echo "🤖 Vela AI Assistant - Automated Setup"
echo "======================================"
echo ""

# Check if .env exists
if [ ! -f .env ]; then
    echo "⚠️  .env file not found!"
    echo "Creating .env file..."
    
    cat > .env << EOF
VITE_SUPABASE_URL=https://iqrhacrtcgquvxmrlxnl.supabase.co
VITE_SUPABASE_ANON_KEY=your_anon_key_here
VITE_VAPID_PUBLIC_KEY=your_vapid_key_here
EOF
    
    echo "✅ .env file created"
    echo "⚠️  Please edit .env and add your actual keys:"
    echo "   - Get Supabase keys from: https://supabase.com/dashboard/project/iqrhacrtcgquvxmrlxnl/settings/api"
    echo "   - Generate VAPID keys using: npm run generate-vapid"
    echo ""
    read -p "Press Enter after updating .env file..."
else
    echo "✅ .env file found"
fi

# Check if node_modules exists
if [ ! -d "node_modules" ]; then
    echo ""
    echo "📦 Installing dependencies..."
    npm install
    echo "✅ Dependencies installed"
else
    echo "✅ Dependencies already installed"
fi

# Check if Supabase CLI is installed
if ! command -v supabase &> /dev/null; then
    echo ""
    echo "⚠️  Supabase CLI not found"
    echo "Install it with: npm install -g supabase"
    echo ""
    echo "Or run the migration manually:"
    echo "1. Go to: https://supabase.com/dashboard/project/iqrhacrtcgquvxmrlxnl/sql/new"
    echo "2. Copy contents from: supabase/migrations/20240112_vela_tables.sql"
    echo "3. Paste and click 'Run'"
else
    echo ""
    echo "🗄️  Setting up Supabase database..."
    
    # Check if already linked
    if [ ! -f ".supabase/config.toml" ]; then
        echo "Linking to Supabase project..."
        supabase link --project-ref iqrhacrtcgquvxmrlxnl
    fi
    
    echo "Running migrations..."
    supabase db push
    echo "✅ Database setup complete"
fi

echo ""
echo "🎉 Setup Complete!"
echo ""
echo "Next steps:"
echo "1. Verify .env has correct keys"
echo "2. Run: npm run dev"
echo "3. Visit: http://localhost:8080"
echo ""
echo "📚 Documentation:"
echo "   - Full guide: VELA_DEPLOYMENT_SETUP.md"
echo "   - Deployment: DEPLOYMENT_GUIDE.md"
echo ""
