# Fix "Invalid API Key" Error

## Problem
Getting "Invalid API key" error when trying to sign up or reset password.

## Quick Fix

### Option 1: Use Existing Supabase Project (Recommended)
1. Go to your Supabase dashboard: https://supabase.com/dashboard
2. Select your project (or create a new one)
3. Go to **Settings** → **API**
4. Copy your **Project URL** and **anon/public key**
5. Update your `.env` file:
```env
VITE_SUPABASE_URL=https://your-project-id.supabase.co
VITE_SUPABASE_ANON_KEY=your-actual-anon-key-here
```
6. Restart your dev server: `npm run dev`

### Option 2: Deploy to Vercel
If deployed on Vercel, add environment variables:
1. Go to Vercel Dashboard → Your Project → Settings → Environment Variables
2. Add:
   - `VITE_SUPABASE_URL` = your Supabase project URL
   - `VITE_SUPABASE_ANON_KEY` = your Supabase anon key
3. Redeploy

### Option 3: Disable Auth Temporarily (Development Only)
If you just want to test the UI without authentication:
1. Comment out the ProtectedRoute wrapper in App.tsx
2. Mock the auth context

## Verify Setup
Run this in browser console on your app:
```javascript
console.log('Supabase URL:', import.meta.env.VITE_SUPABASE_URL);
console.log('Has Key:', !!import.meta.env.VITE_SUPABASE_ANON_KEY);
```

Both should show valid values (not undefined or empty).
