# 🚨 Vercel Deployment Troubleshooting Guide

## ✅ Environment Variables Added - What's Next?

Since you added env vars **7+ hours ago**, follow this checklist:

### 1️⃣ **CRITICAL: Did You Redeploy After Adding Env Vars?**

**Environment variables only apply to NEW deployments!**

```bash
# Trigger new deployment
git commit --allow-empty -m "chore: redeploy with env vars"
git push origin main
```

OR in Vercel Dashboard:
- Go to Deployments → Click "Redeploy" on latest deployment

---

### 2️⃣ **Check Build Logs in Vercel**

1. Go to **Vercel Dashboard** → Your Project
2. Click **"Deployments"** tab
3. Click on the **latest deployment**
4. Check **"Building"** logs

**✅ Success looks like:**
```
Running "npm install"
✓ Dependencies installed
Running "npm run build"  
✓ Build completed successfully
```

**❌ Common Errors:**

#### Error: "Cannot find module"
```
Module not found: Can't resolve '@/components/...'
```
**Fix:** TypeScript path issue - check tsconfig.json

#### Error: "Environment variable undefined"
```
VITE_SUPABASE_URL is undefined
```
**Fix:** Env vars not loaded - redeploy after adding them

#### Error: "Build failed"
```
npm ERR! code ELIFECYCLE
```
**Fix:** Check specific error in logs

---

### 3️⃣ **Verify Environment Variables Are Set**

In Vercel Dashboard:
1. Go to **Settings** → **Environment Variables**
2. Verify ALL these exist:
   - ✅ `VITE_SUPABASE_URL`
   - ✅ `VITE_SUPABASE_ANON_KEY`
   - ✅ `VITE_VAPID_PUBLIC_KEY`
   - ✅ `VITE_STRIPE_PUBLISHABLE_KEY` (optional)

3. Check they're enabled for:
   - ✅ Production
   - ✅ Preview
   - ✅ Development

---

### 4️⃣ **Test Runtime Issues**

If build succeeds but app doesn't work:

**Open Browser Console (F12):**

```javascript
// Check if env vars are accessible
console.log(import.meta.env.VITE_SUPABASE_URL)
```

**❌ Shows `undefined`:**
- Env vars not loaded → Redeploy
- Missing `VITE_` prefix → Rename vars

**✅ Shows actual URL:**
- Env vars working → Check Supabase connection

---

### 5️⃣ **Common Runtime Errors**

#### Error: "Failed to fetch"
**Cause:** Supabase URL/Key incorrect or Supabase project paused

**Fix:**
1. Verify Supabase project is active
2. Check URL format: `https://xxx.supabase.co`
3. Verify anon key is correct

#### Error: "Service Worker registration failed"
**Cause:** HTTPS required for PWA features

**Fix:** Vercel provides HTTPS automatically - check domain

#### Error: "CORS error"
**Cause:** Supabase CORS not configured

**Fix:** In Supabase Dashboard:
- Settings → API → CORS
- Add your Vercel domain

---

### 6️⃣ **Vercel Build Settings**

Verify in **Settings** → **General**:

```
Framework Preset: Vite
Build Command: npm run build
Output Directory: dist
Install Command: npm install
Node Version: 18.x or 20.x
```

---

### 7️⃣ **Force Clean Deployment**

If nothing works, force clean build:

```bash
# Delete .vercel folder locally
rm -rf .vercel

# Clear Vercel cache
# In Vercel Dashboard: Settings → General → Clear Build Cache

# Trigger fresh deployment
git commit --allow-empty -m "chore: force clean build"
git push origin main
```

---

## 🔍 Quick Diagnostic Commands

### Check Deployment Status
```bash
vercel ls
```

### View Logs
```bash
vercel logs [deployment-url]
```

### Test Build Locally
```bash
npm run build
npm run preview
```

---

## 📞 Still Not Working?

### Share These Details:

1. **Build Status:** Success or Failed?
2. **Build Logs:** Copy error from Vercel logs
3. **Browser Console:** Any errors? (F12 → Console)
4. **Network Tab:** Failed requests? (F12 → Network)
5. **Deployment URL:** Share the URL

### Most Likely Issues:

| Symptom | Cause | Fix |
|---------|-------|-----|
| White screen | Build failed | Check Vercel logs |
| "Cannot connect" | Supabase config wrong | Verify env vars |
| 404 on routes | Rewrites not working | Check vercel.json |
| No PWA features | HTTPS/SW issue | Check service worker |
| Slow loading | No caching | Check network tab |

---

## ✅ Success Checklist

- [ ] Environment variables added in Vercel
- [ ] New deployment triggered after adding env vars
- [ ] Build logs show success
- [ ] App loads without errors
- [ ] Browser console has no errors
- [ ] Supabase connection works
- [ ] PWA features work (offline, install)
- [ ] All routes work (no 404s)

---

## 🎯 Next Steps After Success

1. **Test PWA:** Try installing app on mobile
2. **Test Offline:** Disable network, app should still load
3. **Test Auth:** Try signup/login
4. **Monitor:** Check Vercel Analytics for errors

