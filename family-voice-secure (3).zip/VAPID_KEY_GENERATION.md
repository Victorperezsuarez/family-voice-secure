# VAPID Keys Generation Guide

## What are VAPID Keys?
VAPID (Voluntary Application Server Identification) keys are used to authenticate push notifications from your server to users' browsers/devices.

## Quick Generation Methods

### Method 1: Using web-push CLI (Easiest)

1. **Install web-push globally:**
```bash
npm install -g web-push
```

2. **Generate keys:**
```bash
web-push generate-vapid-keys
```

3. **Output will look like:**
```
=======================================
Public Key:
BEl62iUYgUivxIkv69yViEuiBIa-Ib9-SkvMeAtA3LFgDzkrxZJjSgSnfckjBJuBkr3qBUYIHBQFLXYp5Nksh8U

Private Key:
UUxI4O8-FbRouAevSmBQ6o18hgE4nSG3qwvJTfKc-ls
=======================================
```

4. **Add to Supabase:**
   - Go to Supabase Dashboard
   - Navigate to Edge Functions → Manage secrets
   - Add `VAPID_PUBLIC_KEY` with the public key
   - Add `VAPID_PRIVATE_KEY` with the private key

### Method 2: Using Node.js Script

1. **Create a file `generate-vapid.js`:**
```javascript
const webpush = require('web-push');

const vapidKeys = webpush.generateVAPIDKeys();

console.log('=======================================');
console.log('Public Key:');
console.log(vapidKeys.publicKey);
console.log('\nPrivate Key:');
console.log(vapidKeys.privateKey);
console.log('=======================================');
console.log('\nAdd these to Supabase Edge Functions secrets:');
console.log('VAPID_PUBLIC_KEY=' + vapidKeys.publicKey);
console.log('VAPID_PRIVATE_KEY=' + vapidKeys.privateKey);
```

2. **Install web-push locally:**
```bash
npm install web-push
```

3. **Run the script:**
```bash
node generate-vapid.js
```

### Method 3: Online Generator (No Installation)

Visit one of these websites:
- https://vapidkeys.com/
- https://www.attheminute.com/vapid-key-generator
- https://d3v.one/vapid-key-generator/

Click "Generate Keys" and copy both keys.

### Method 4: Using OpenSSL (Advanced)

```bash
# Generate private key
openssl ecparam -genkey -name prime256v1 -out vapid_private.pem

# Extract public key
openssl ec -in vapid_private.pem -pubout -out vapid_public.pem

# Convert to base64 URL-safe format (requires additional processing)
```

## Adding Keys to Supabase

### Via Supabase Dashboard:
1. Go to https://supabase.com/dashboard
2. Select your project
3. Navigate to **Edge Functions** → **Manage secrets**
4. Click **Add new secret**
5. Add `VAPID_PUBLIC_KEY` with the public key value
6. Add `VAPID_PRIVATE_KEY` with the private key value

### Via Supabase CLI:
```bash
supabase secrets set VAPID_PUBLIC_KEY="your-public-key-here"
supabase secrets set VAPID_PRIVATE_KEY="your-private-key-here"
```

## Important Notes

- **Keep private key secret**: Never commit it to version control
- **Use same keys**: Use the same VAPID keys for all push notifications in your app
- **Store securely**: Save keys in a password manager or secure location
- **One-time generation**: You only need to generate these once per application

## Verification

After adding to Supabase, verify in your edge function:
```typescript
const vapidPrivateKey = Deno.env.get("VAPID_PRIVATE_KEY");
console.log("VAPID key available:", !!vapidPrivateKey);
```

## Troubleshooting

**Error: "web-push: command not found"**
- Make sure you installed globally: `npm install -g web-push`
- Try using npx: `npx web-push generate-vapid-keys`

**Keys not working in edge functions**
- Verify secrets are set in Supabase dashboard
- Redeploy edge functions after adding secrets
- Check for typos in secret names

**Need to regenerate keys?**
- You can regenerate anytime, but all existing subscriptions will be invalidated
- Users will need to re-subscribe to push notifications
