import { test, expect } from '@playwright/test';

test.describe('Family Management', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
    await page.getByLabel(/email/i).fill('test@example.com');
    await page.getByLabel(/password/i).fill('password123');
    await page.getByRole('button', { name: /sign in/i }).click();
    await page.waitForURL(/\/dashboard/);
  });

  test('should create new family', async ({ page }) => {
    await page.getByRole('button', { name: /create family/i }).click();
    await page.getByLabel(/family name/i).fill('Smith Family');
    await page.getByRole('button', { name: /create/i }).click();
    
    await expect(page.getByText(/smith family/i)).toBeVisible();
  });

  test('should invite family member', async ({ page }) => {
    await page.getByText(/smith family/i).click();
    await page.getByRole('button', { name: /invite/i }).click();
    await page.getByLabel(/email/i).fill('member@example.com');
    await page.getByRole('button', { name: /send invitation/i }).click();
    
    await expect(page.getByText(/invitation sent/i)).toBeVisible();
  });

  test('should display family tree', async ({ page }) => {
    await page.getByText(/family tree/i).click();
    await expect(page.locator('.family-tree-node')).toBeVisible();
  });
});
