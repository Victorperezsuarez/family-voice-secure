import { test, expect } from '@playwright/test';
import path from 'path';

test.describe('Photo Management', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
    await page.getByLabel(/email/i).fill('test@example.com');
    await page.getByLabel(/password/i).fill('password123');
    await page.getByRole('button', { name: /sign in/i }).click();
    await page.waitForURL(/\/dashboard/);
  });

  test('should upload photo', async ({ page }) => {
    await page.getByRole('button', { name: /upload photo/i }).click();
    
    const fileInput = page.locator('input[type="file"]');
    await fileInput.setInputFiles(path.join(__dirname, 'fixtures', 'test-image.jpg'));
    
    await expect(page.getByText(/upload successful/i)).toBeVisible();
  });

  test('should display photo gallery', async ({ page }) => {
    await page.getByText(/photos/i).click();
    await expect(page.locator('.photo-grid')).toBeVisible();
    await expect(page.locator('.photo-card').first()).toBeVisible();
  });

  test('should tag people in photos', async ({ page }) => {
    await page.locator('.photo-card').first().click();
    await page.getByRole('button', { name: /tag people/i }).click();
    await page.getByLabel(/name/i).fill('John Smith');
    await page.getByRole('button', { name: /save/i }).click();
    
    await expect(page.getByText(/john smith/i)).toBeVisible();
  });
});
