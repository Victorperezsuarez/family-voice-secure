import { test, expect } from '@playwright/test';
import { checkAccessibility } from '../helpers/accessibility';

test.describe('Form Accessibility @a11y', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
  });

  test('forms should have no accessibility violations', async ({ page }) => {
    // Navigate to a page with forms (adjust URL as needed)
    const results = await checkAccessibility(page, 'forms', {
      wcagLevel: 'AA',
      tags: ['cat.forms'],
    });

    expect(results.violations).toHaveLength(0);
  });

  test('all form inputs should have labels', async ({ page }) => {
    const inputs = await page.locator('input[type="text"], input[type="email"], input[type="password"], textarea').all();
    
    for (const input of inputs) {
      const id = await input.getAttribute('id');
      const ariaLabel = await input.getAttribute('aria-label');
      const ariaLabelledBy = await input.getAttribute('aria-labelledby');
      
      if (id) {
        const label = await page.locator(`label[for="${id}"]`).count();
        const hasLabel = label > 0 || ariaLabel || ariaLabelledBy;
        expect(hasLabel).toBeTruthy();
      }
    }
  });

  test('required fields should be marked', async ({ page }) => {
    const requiredInputs = await page.locator('input[required], textarea[required]').all();
    
    for (const input of requiredInputs) {
      const ariaRequired = await input.getAttribute('aria-required');
      const required = await input.getAttribute('required');
      
      expect(ariaRequired === 'true' || required !== null).toBeTruthy();
    }
  });

  test('error messages should be associated with inputs', async ({ page }) => {
    const inputs = await page.locator('input[aria-describedby], textarea[aria-describedby]').all();
    
    for (const input of inputs) {
      const describedBy = await input.getAttribute('aria-describedby');
      if (describedBy) {
        const errorElement = await page.locator(`#${describedBy}`).count();
        expect(errorElement).toBeGreaterThan(0);
      }
    }
  });
});
