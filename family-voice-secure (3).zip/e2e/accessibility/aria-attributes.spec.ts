import { test, expect } from '@playwright/test';
import { checkAccessibility } from '../helpers/accessibility';

test.describe('ARIA Attributes @a11y', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
  });

  test('should have valid ARIA attributes', async ({ page }) => {
    const results = await checkAccessibility(page, 'aria-attributes', {
      wcagLevel: 'AA',
      tags: ['cat.aria'],
    });

    expect(results.violations).toHaveLength(0);
  });

  test('buttons should have accessible names', async ({ page }) => {
    const buttons = await page.locator('button').all();
    
    for (const button of buttons) {
      const text = await button.textContent();
      const ariaLabel = await button.getAttribute('aria-label');
      const ariaLabelledBy = await button.getAttribute('aria-labelledby');
      
      const hasAccessibleName = text?.trim() || ariaLabel || ariaLabelledBy;
      expect(hasAccessibleName).toBeTruthy();
    }
  });

  test('links should have accessible names', async ({ page }) => {
    const links = await page.locator('a').all();
    
    for (const link of links) {
      const text = await link.textContent();
      const ariaLabel = await link.getAttribute('aria-label');
      
      const hasAccessibleName = text?.trim() || ariaLabel;
      expect(hasAccessibleName).toBeTruthy();
    }
  });

  test('interactive elements should have proper roles', async ({ page }) => {
    const results = await checkAccessibility(page, 'aria-roles', {
      tags: ['cat.aria', 'best-practice'],
    });

    expect(results.violations).toHaveLength(0);
  });

  test('landmarks should be properly used', async ({ page }) => {
    const nav = await page.locator('nav, [role="navigation"]').count();
    const main = await page.locator('main, [role="main"]').count();
    
    expect(nav).toBeGreaterThan(0);
    expect(main).toBeGreaterThan(0);
  });
});
