import { test, expect } from '@playwright/test';

test.describe('Keyboard Navigation @a11y', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
  });

  test('should navigate through interactive elements with Tab', async ({ page }) => {
    // Tab through focusable elements
    const focusableElements = await page.locator(
      'a, button, input, select, textarea, [tabindex]:not([tabindex="-1"])'
    ).all();

    expect(focusableElements.length).toBeGreaterThan(0);

    for (let i = 0; i < Math.min(5, focusableElements.length); i++) {
      await page.keyboard.press('Tab');
      const focused = await page.evaluate(() => document.activeElement?.tagName);
      expect(focused).toBeTruthy();
    }
  });

  test('should activate buttons with Enter key', async ({ page }) => {
    const button = page.locator('button').first();
    await button.focus();
    
    const isVisible = await button.isVisible();
    if (isVisible) {
      await page.keyboard.press('Enter');
      // Button should have been activated
    }
  });

  test('should activate buttons with Space key', async ({ page }) => {
    const button = page.locator('button').first();
    await button.focus();
    
    const isVisible = await button.isVisible();
    if (isVisible) {
      await page.keyboard.press('Space');
      // Button should have been activated
    }
  });

  test('should have visible focus indicators', async ({ page }) => {
    await page.keyboard.press('Tab');
    
    const focused = await page.evaluate(() => {
      const el = document.activeElement;
      if (!el) return null;
      
      const styles = window.getComputedStyle(el);
      return {
        outline: styles.outline,
        outlineWidth: styles.outlineWidth,
        boxShadow: styles.boxShadow,
      };
    });

    expect(focused).toBeTruthy();
  });
});
