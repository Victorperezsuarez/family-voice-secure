import { test, expect } from '@playwright/test';
import { checkAccessibility } from '../helpers/accessibility';

test.describe('Landing Page Accessibility @a11y', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('networkidle');
  });

  test('should have no WCAG 2.1 AA violations', async ({ page }) => {
    const results = await checkAccessibility(page, 'landing-page', {
      wcagLevel: 'AA',
    });

    expect(results.violations).toHaveLength(0);
  });

  test('should have proper heading hierarchy', async ({ page }) => {
    const headings = await page.locator('h1, h2, h3, h4, h5, h6').all();
    
    expect(headings.length).toBeGreaterThan(0);
    
    // Check for h1
    const h1Count = await page.locator('h1').count();
    expect(h1Count).toBe(1);
  });

  test('should have proper color contrast', async ({ page }) => {
    const results = await checkAccessibility(page, 'landing-page-contrast', {
      tags: ['cat.color'],
    });

    expect(results.violations).toHaveLength(0);
  });

  test('all images should have alt text', async ({ page }) => {
    const images = await page.locator('img').all();
    
    for (const img of images) {
      const alt = await img.getAttribute('alt');
      expect(alt).not.toBeNull();
    }
  });
});
