import { Page } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
import { createHtmlReport } from 'axe-html-reporter';
import * as fs from 'fs';
import * as path from 'path';

export interface AccessibilityTestOptions {
  wcagLevel?: 'A' | 'AA' | 'AAA';
  tags?: string[];
  disableRules?: string[];
}

export async function checkAccessibility(
  page: Page,
  context: string,
  options: AccessibilityTestOptions = {}
) {
  const { wcagLevel = 'AA', tags = [], disableRules = [] } = options;

  const builder = new AxeBuilder({ page })
    .withTags([`wcag2${wcagLevel.toLowerCase()}`, 'wcag21aa', ...tags]);

  if (disableRules.length > 0) {
    builder.disableRules(disableRules);
  }

  const results = await builder.analyze();

  // Generate HTML report
  const reportDir = path.join(process.cwd(), 'test-results', 'accessibility');
  if (!fs.existsSync(reportDir)) {
    fs.mkdirSync(reportDir, { recursive: true });
  }

  const reportPath = path.join(reportDir, `${context.replace(/\s+/g, '-')}.html`);
  createHtmlReport({
    results,
    options: {
      outputDir: reportDir,
      reportFileName: `${context.replace(/\s+/g, '-')}.html`,
    },
  });

  return results;
}
