import { test, expect } from '@playwright/test';

test.describe('Recording Management', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
    // Login
    await page.getByLabel(/email/i).fill('test@example.com');
    await page.getByLabel(/password/i).fill('password123');
    await page.getByRole('button', { name: /sign in/i }).click();
    await page.waitForURL(/\/dashboard/);
  });

  test('should display recording interface', async ({ page }) => {
    await expect(page.getByRole('button', { name: /start recording/i })).toBeVisible();
  });

  test('should create new recording', async ({ page }) => {
    await page.getByRole('button', { name: /start recording/i }).click();
    await expect(page.getByText(/recording/i)).toBeVisible();
    
    // Stop recording
    await page.getByRole('button', { name: /stop/i }).click();
    
    // Save recording
    await page.getByLabel(/title/i).fill('Test Recording');
    await page.getByRole('button', { name: /save/i }).click();
    
    await expect(page.getByText(/test recording/i)).toBeVisible();
  });

  test('should play recording', async ({ page }) => {
    await page.getByText(/test recording/i).click();
    await expect(page.getByRole('button', { name: /play/i })).toBeVisible();
  });
});
