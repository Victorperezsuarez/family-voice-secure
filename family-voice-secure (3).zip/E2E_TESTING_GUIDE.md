# End-to-End Testing Guide

## Overview

This project uses Playwright for comprehensive end-to-end testing, including:
- Multi-browser testing (Chrome, Firefox, Safari)
- Mobile device testing (iOS, Android)
- Visual regression testing
- Automated CI/CD integration

## Setup

### Install Dependencies

```bash
npm install
npx playwright install
```

### Install Browsers

```bash
# Install all browsers
npx playwright install

# Install specific browser
npx playwright install chromium
```

## Running Tests

### Run All Tests

```bash
npm run test:e2e
```

### Run Tests in UI Mode

```bash
npm run test:e2e:ui
```

### Run Tests in Headed Mode

```bash
npm run test:e2e:headed
```

### Debug Tests

```bash
npm run test:e2e:debug
```

### Run Specific Test File

```bash
npx playwright test e2e/auth.spec.ts
```

### Run Tests on Specific Browser

```bash
npx playwright test --project=chromium
npx playwright test --project=firefox
npx playwright test --project=webkit
```

### Run Mobile Tests

```bash
npx playwright test --project="Mobile Chrome"
npx playwright test --project="Mobile Safari"
```

## Test Structure

### Test Files

- `e2e/auth.spec.ts` - Authentication flow tests
- `e2e/recording.spec.ts` - Recording creation and playback
- `e2e/family.spec.ts` - Family management features
- `e2e/photos.spec.ts` - Photo upload and management
- `e2e/visual-regression.spec.ts` - Visual regression tests

### Test Organization

```typescript
test.describe('Feature Name', () => {
  test.beforeEach(async ({ page }) => {
    // Setup before each test
  });

  test('should do something', async ({ page }) => {
    // Test implementation
  });
});
```

## Visual Regression Testing

### Update Baseline Screenshots

```bash
npx playwright test --update-snapshots
```

### Compare Screenshots

Playwright automatically compares screenshots and fails if differences exceed threshold.

## CI/CD Integration

Tests run automatically on:
- Push to main/develop branches
- Pull requests
- Daily schedule (midnight UTC)

### GitHub Actions Workflow

The E2E tests workflow:
1. Runs tests on multiple browsers in parallel
2. Uploads test results and HTML reports
3. Retains artifacts for 30 days

## Best Practices

### 1. Use Semantic Selectors

```typescript
// Good
await page.getByRole('button', { name: /sign in/i });
await page.getByLabel(/email/i);

// Avoid
await page.locator('#login-button');
```

### 2. Wait for Navigation

```typescript
await page.getByRole('button', { name: /sign in/i }).click();
await page.waitForURL(/\/dashboard/);
```

### 3. Use Auto-Waiting

Playwright automatically waits for elements to be actionable.

```typescript
// Automatically waits for element to be visible and enabled
await page.getByRole('button').click();
```

### 4. Isolate Tests

Each test should be independent and not rely on other tests.

```typescript
test.beforeEach(async ({ page }) => {
  // Reset state before each test
});
```

## Debugging

### Debug Specific Test

```bash
npx playwright test e2e/auth.spec.ts --debug
```

### View Test Report

```bash
npm run test:e2e:report
```

### Generate Test Code

```bash
npm run test:e2e:codegen
```

This opens a browser where you can interact with your app, and Playwright generates test code.

## Configuration

### playwright.config.ts

Key configuration options:
- `testDir`: Test directory location
- `use.baseURL`: Base URL for tests
- `projects`: Browser and device configurations
- `webServer`: Auto-start dev server

### Environment Variables

```bash
# Set custom base URL
export PLAYWRIGHT_TEST_BASE_URL=http://localhost:3000
```

## Troubleshooting

### Tests Failing Locally

1. Ensure dev server is running
2. Clear browser cache: `npx playwright clean`
3. Update browsers: `npx playwright install`

### Visual Regression Failures

1. Review screenshot diffs in test report
2. Update baselines if changes are intentional:
   ```bash
   npx playwright test --update-snapshots
   ```

### CI/CD Failures

1. Check GitHub Actions logs
2. Download artifacts for detailed reports
3. Verify environment variables are set

## Resources

- [Playwright Documentation](https://playwright.dev)
- [Best Practices](https://playwright.dev/docs/best-practices)
- [API Reference](https://playwright.dev/docs/api/class-playwright)
