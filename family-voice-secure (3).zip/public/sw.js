const CACHE_NAME = 'vela-cache-v1';
const urlsToCache = [
  '/',
  '/index.html',
  '/manifest.json'
];

// Install event - cache resources
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(urlsToCache))
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

// Fetch event - serve from cache, fallback to network
self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request)
      .then((response) => response || fetch(event.request))
  );
});

// Push notification event with rich notification support
self.addEventListener('push', (event) => {
  if (!event.data) return;

  const data = event.data.json();
  const options = {
    body: data.body,
    icon: data.icon || '/placeholder.svg',
    badge: data.badge || '/placeholder.svg',
    image: data.image,
    data: {
      url: data.url || '/',
      notificationId: data.notificationId,
      instanceId: data.instanceId,
      templateId: data.templateId,
      userId: data.userId,
      deviceId: data.deviceId,
      suggestionType: data.suggestionType,
      suggestionPriority: data.suggestionPriority
    },

    badge: data.badge || '/badge-72x72.png',
    image: data.image, // Hero image for notification
    vibrate: data.vibrate || [200, 100, 200],
    tag: data.tag || 'vela-notification',
    requireInteraction: data.requireInteraction || false,
    silent: data.silent || false,
    data: {
      ...data.data,
      notificationId: data.notificationId,
      deviceId: data.deviceId,
      url: data.url || '/',
      progress: data.progress,
      progressMax: data.progressMax,
      progressLabel: data.progressLabel
    },
    actions: data.actions || [
      { action: 'accept', title: 'Accept', icon: '/icons/check.png' },
      { action: 'snooze', title: 'Snooze', icon: '/icons/clock.png' },
      { action: 'view', title: 'View Details', icon: '/icons/eye.png' },
      { action: 'dismiss', title: 'Dismiss', icon: '/icons/x.png' }
    ]
  };

  // Play custom sound if provided
  if (data.sound) {
    // Note: Custom sounds in service workers are limited
    // This would need to be handled in the main app
    options.data.customSound = data.sound;
  }

  event.waitUntil(
    self.registration.showNotification(data.title, options).then(() => {
      // Auto-close after delay if specified
      if (data.autoCloseDelay && data.autoCloseDelay > 0) {
        setTimeout(() => {
          self.registration.getNotifications({ tag: options.tag }).then(notifications => {
            notifications.forEach(notification => notification.close());
          });
        }, data.autoCloseDelay);
      }
    })
  );
});

// Notification click event - handle action buttons
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  const action = event.action;
  const notificationData = event.notification.data || {};
  const notificationId = notificationData.notificationId;
  const deviceId = notificationData.deviceId || 'default';

  // Sync notification status across devices
  const syncPromise = fetch('/api/sync-notification-status', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      notificationId,
      eventType: action || 'clicked',
      deviceId,
      actionTaken: action
    })
  }).catch(err => console.error('Failed to sync notification:', err));

  // Handle different actions
  let navigationPromise = Promise.resolve();
  
  if (action === 'accept') {
    navigationPromise = clients.openWindow(notificationData.url || '/');
  } else if (action === 'snooze') {
    // Snooze logic - will be handled by the app
    navigationPromise = clients.openWindow('/?action=snooze&id=' + notificationId);
  } else if (action === 'view') {
    navigationPromise = clients.openWindow(notificationData.url || '/');
  } else if (!action) {
    // Default click (no action button)
    navigationPromise = clients.openWindow(notificationData.url || '/');
  }

  event.waitUntil(Promise.all([syncPromise, navigationPromise]));
});

// Notification close event - track dismissals
self.addEventListener('notificationclose', (event) => {
  const notificationData = event.notification.data || {};
  const notificationId = notificationData.notificationId;
  const deviceId = notificationData.deviceId || 'default';

  if (notificationId) {
    event.waitUntil(
      fetch('/api/sync-notification-status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          notificationId,
          eventType: 'dismissed',
          deviceId
        })
      }).catch(err => console.error('Failed to sync notification close:', err))
    );
  }
});

// Background sync for offline notification actions
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-notifications') {
    event.waitUntil(
      // Sync any pending notification actions
      fetch('/api/sync-notification-status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ syncAll: true })
      }).catch(err => console.error('Failed to sync notifications:', err))
    );
  }
});
