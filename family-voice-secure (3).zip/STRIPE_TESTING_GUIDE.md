# Stripe Payment Integration Testing Guide

## Overview

This guide walks you through testing the complete Stripe payment flow for Family Voice Secure, from initial setup through subscription management.

## Prerequisites

- Completed STRIPE_SETUP.md steps 1-4
- Admin access to the application
- Stripe test mode enabled
- Test Price IDs configured in admin panel

## Testing Checklist

### Phase 1: Configuration Testing

#### 1.1 Verify Admin Panel Access
- [ ] Log in as admin user
- [ ] Navigate to `/admin`
- [ ] Click on "Stripe Config" tab
- [ ] Verify all 4 price ID fields are visible

#### 1.2 Configure Price IDs
- [ ] Enter Family Monthly Price ID
- [ ] Enter Family Annual Price ID
- [ ] Enter Premium Monthly Price ID
- [ ] Enter Premium Annual Price ID
- [ ] Click "Save Configuration"
- [ ] Verify success message appears

#### 1.3 Verify Configuration Saved
- [ ] Refresh the page
- [ ] Check that all Price IDs are still populated
- [ ] Open Supabase dashboard
- [ ] Query `stripe_config` table
- [ ] Verify 2 rows exist (family, premium)

### Phase 2: Checkout Flow Testing

#### 2.1 Test Family Monthly Plan
- [ ] Log out (if logged in)
- [ ] Navigate to `/pricing`
- [ ] Click "Get Started" on Family plan (Monthly selected)
- [ ] Should redirect to signup if not logged in
- [ ] Complete signup/login
- [ ] Should redirect to Stripe Checkout
- [ ] Verify plan details are correct
- [ ] Use test card: 4242 4242 4242 4242
- [ ] Complete checkout
- [ ] Should redirect back to app

#### 2.2 Test Family Annual Plan
- [ ] Navigate to `/pricing`
- [ ] Toggle to "Annual" billing
- [ ] Click "Get Started" on Family plan
- [ ] Should go directly to Stripe Checkout (already logged in)
- [ ] Verify annual pricing is shown
- [ ] Complete checkout with test card

#### 2.3 Test Premium Plans
- [ ] Repeat 2.1 and 2.2 for Premium plan
- [ ] Verify correct pricing for each

### Phase 3: Subscription Verification

#### 3.1 Check Database
- [ ] Open Supabase dashboard
- [ ] Query `subscriptions` table
- [ ] Verify new subscription row exists
- [ ] Check `status` is 'active'
- [ ] Verify `plan_name` matches selected plan
- [ ] Check `current_period_end` is in future

#### 3.2 Check Stripe Dashboard
- [ ] Open Stripe Dashboard → Payments
- [ ] Verify payment appears
- [ ] Click on payment to see details
- [ ] Open Stripe Dashboard → Subscriptions
- [ ] Verify subscription is active
- [ ] Check customer details

#### 3.3 Check Application State
- [ ] Navigate to `/billing` in app
- [ ] Verify subscription status shows "Active"
- [ ] Check plan name is correct
- [ ] Verify next billing date is shown
- [ ] Check amount is correct

### Phase 4: Billing Portal Testing

#### 4.1 Access Billing Portal
- [ ] Navigate to `/billing`
- [ ] Click "Manage Subscription" button
- [ ] Should redirect to Stripe Customer Portal
- [ ] Verify customer information is correct

#### 4.2 Update Payment Method
- [ ] In Customer Portal, click "Update payment method"
- [ ] Enter new test card: 5555 5555 5555 4444
- [ ] Save changes
- [ ] Verify success message
- [ ] Return to app
- [ ] Check `payment_methods` table in Supabase

#### 4.3 View Invoices
- [ ] In Customer Portal, view invoice history
- [ ] Verify initial invoice appears
- [ ] Click to download invoice PDF
- [ ] Verify invoice details are correct

#### 4.4 Cancel Subscription
- [ ] In Customer Portal, click "Cancel subscription"
- [ ] Confirm cancellation
- [ ] Return to app
- [ ] Navigate to `/billing`
- [ ] Verify status shows cancellation pending
- [ ] Check `subscriptions` table - status should be 'canceled'

### Phase 5: Webhook Testing

#### 5.1 Verify Webhook Endpoint
- [ ] Open Stripe Dashboard → Developers → Webhooks
- [ ] Click on your webhook endpoint
- [ ] Check "Recent deliveries" section
- [ ] Verify events are being received

#### 5.2 Test Specific Events
- [ ] Create new subscription (checkout.session.completed)
- [ ] Check webhook delivery was successful
- [ ] Update payment method (customer.updated)
- [ ] Check webhook delivery
- [ ] Cancel subscription (customer.subscription.deleted)
- [ ] Check webhook delivery

#### 5.3 Check Supabase Logs
- [ ] Open Supabase Dashboard
- [ ] Go to Edge Functions → stripe-webhook
- [ ] View logs
- [ ] Verify events are being processed
- [ ] Check for any errors

### Phase 6: Error Handling Testing

#### 6.1 Test Declined Card
- [ ] Start new checkout
- [ ] Use declined card: 4000 0000 0000 0002
- [ ] Verify error message appears
- [ ] Check no subscription was created

#### 6.2 Test Insufficient Funds
- [ ] Start new checkout
- [ ] Use card: 4000 0000 0000 9995
- [ ] Verify appropriate error

#### 6.3 Test 3D Secure
- [ ] Start new checkout
- [ ] Use card: 4000 0025 0000 3155
- [ ] Complete 3D Secure authentication
- [ ] Verify checkout completes

#### 6.4 Test Network Errors
- [ ] Disable internet connection
- [ ] Try to start checkout
- [ ] Verify error message appears
- [ ] Re-enable connection
- [ ] Verify retry works

### Phase 7: Edge Cases

#### 7.1 Multiple Subscriptions
- [ ] Try to subscribe to second plan while active
- [ ] Verify appropriate handling (upgrade/downgrade or error)

#### 7.2 Expired Session
- [ ] Start checkout
- [ ] Wait 24 hours
- [ ] Try to complete checkout
- [ ] Verify session expiry is handled

#### 7.3 Webhook Replay
- [ ] In Stripe Dashboard, replay a webhook event
- [ ] Verify idempotency (no duplicate subscriptions)

## Test Results Template

```
Test Date: ___________
Tester: ___________

Phase 1: Configuration Testing
- Admin Panel Access: PASS / FAIL
- Configure Price IDs: PASS / FAIL
- Verify Configuration: PASS / FAIL

Phase 2: Checkout Flow
- Family Monthly: PASS / FAIL
- Family Annual: PASS / FAIL
- Premium Monthly: PASS / FAIL
- Premium Annual: PASS / FAIL

Phase 3: Subscription Verification
- Database Check: PASS / FAIL
- Stripe Dashboard: PASS / FAIL
- Application State: PASS / FAIL

Phase 4: Billing Portal
- Access Portal: PASS / FAIL
- Update Payment: PASS / FAIL
- View Invoices: PASS / FAIL
- Cancel Subscription: PASS / FAIL

Phase 5: Webhooks
- Endpoint Verification: PASS / FAIL
- Event Processing: PASS / FAIL
- Supabase Logs: PASS / FAIL

Phase 6: Error Handling
- Declined Card: PASS / FAIL
- Insufficient Funds: PASS / FAIL
- 3D Secure: PASS / FAIL
- Network Errors: PASS / FAIL

Phase 7: Edge Cases
- Multiple Subscriptions: PASS / FAIL
- Expired Session: PASS / FAIL
- Webhook Replay: PASS / FAIL

Notes:
_______________________________
_______________________________
```

## Common Issues & Solutions

### Issue: Checkout button does nothing
**Solution**: Check browser console for errors. Verify Stripe publishable key is set in environment variables.

### Issue: Webhook not receiving events
**Solution**: Verify webhook URL is correct and publicly accessible. Check signing secret matches.

### Issue: Subscription not appearing in database
**Solution**: Check webhook logs. Verify RLS policies allow inserts. Check user authentication.

### Issue: Billing portal not opening
**Solution**: Verify customer exists in Stripe. Check edge function logs for errors.

## Production Readiness Checklist

Before going live:
- [ ] All test phases pass
- [ ] Live Stripe keys configured
- [ ] Live products and prices created
- [ ] Live webhook endpoint configured
- [ ] Environment variables updated
- [ ] Error monitoring in place
- [ ] Customer support process defined
- [ ] Refund policy documented
- [ ] Terms of service updated
