# Usage Limits System - Family Voice Secure

## Overview
The usage limits system tracks and enforces feature usage based on subscription plans, preventing users from exceeding their plan limits and prompting upgrades when necessary.

## Database Structure

### Tables Created
1. **plan_limits** - Defines limits for each subscription tier
2. **usage_tracking** - Tracks actual usage per user

### Default Plan Limits
- **Free**: 10 recordings, 0.5GB storage, 1 family tree, 5 members, 20 photos, 2 collections
- **Family**: 100 recordings, 10GB storage, 3 family trees, 25 members, 500 photos, 10 collections
- **Premium**: Unlimited recordings, 100GB storage, 10 family trees, 100 members, 5000 photos, 50 collections
- **Enterprise**: Unlimited everything

## Implementation

### Edge Function
**check-usage-limit** - Checks if user can perform an action
- Input: `{ resource: string, userId: string }`
- Returns: `{ allowed: boolean, current: number, max: number, percentage: number, shouldUpgrade: boolean }`

### React Hook
**useUsageLimit** - Custom hook for checking limits before actions
```typescript
const { checkLimit, checking } = useUsageLimit();
const allowed = await checkLimit('recordings');
if (allowed) {
  // Perform action
}
```

### UI Components
1. **UsageMeterCard** - Shows individual resource usage with progress bar
2. **UsageDashboard** - Grid of all usage meters
3. Integrated into Profile page

## Usage in Code

### Before Recording
```typescript
onStart={async () => {
  const allowed = await checkLimit('recordings');
  if (allowed) startRecording();
}}
```

### Before Creating Family Tree
```typescript
const allowed = await checkLimit('family_trees');
if (allowed) createFamilyTree();
```

### Before Uploading Photo
```typescript
const allowed = await checkLimit('photos');
if (allowed) uploadPhoto();
```

## User Experience
- **Below 80%**: No warnings
- **80-99%**: Yellow warning with upgrade suggestion
- **100%**: Red alert, action blocked, upgrade required
- Toast notifications guide users to pricing page

## Admin Configuration
Plan limits can be updated directly in the `plan_limits` table via SQL or admin interface.

## Monitoring
Usage is recalculated on-demand via the `calculate_user_usage` database function.
