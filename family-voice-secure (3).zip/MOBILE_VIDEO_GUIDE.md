# Mobile Video Recording Guide

## Overview
The Mobile Vela app now includes comprehensive video recording capabilities with professional editing tools, quality settings, and offline support.

## Features

### Video Recording
- **Front/Back Camera Switching**: Toggle between selfie and rear cameras
- **Quality Settings**: Choose from HD (720p), Full HD (1080p), or 4K UHD
- **Portrait & Landscape Support**: Automatic orientation detection
- **Pause/Resume**: Control recording with pause and resume functionality
- **Local Storage**: Videos saved locally for offline access
- **Recording Timer**: Real-time duration display

### Video Editing
- **Trim Tool**: Adjust start and end points of your video
- **Filters**: Apply 6 professional filters (Vintage, B&W, Bright, Cool, Warm)
- **Text Overlays**: Add custom text to your videos
- **Preview**: Play and preview edits before saving
- **Non-destructive**: Original video preserved

### Mobile Optimizations
- **Touch-Optimized UI**: Large buttons for easy mobile interaction
- **Gesture Support**: Swipe and tap controls
- **Offline Recording**: Record without internet connection
- **Auto-sync**: Videos sync when connection restored
- **Battery Efficient**: Optimized for mobile battery life

## How to Use

### Recording a Video
1. Navigate to Mobile Vela page
2. Tap "Quick Memo" tab
3. Tap "Start Video Recording" button
4. Grant camera and microphone permissions if prompted
5. Tap settings icon to change quality (720p/1080p/4K)
6. Tap camera switch icon to toggle front/back camera
7. Tap red record button to start
8. Tap pause to pause, resume to continue
9. Tap stop (square) button to finish
10. Choose "Save Video" or "Edit" from the preview

### Editing a Video
1. After recording, tap "Edit" button
2. Use trim sliders to adjust start/end points
3. Tap play button to preview current selection
4. Select a filter from the 6 available options
5. Add text overlay if desired
6. Tap "Save Edited Video" when finished

### Quality Settings
- **720p HD**: Balanced quality and file size (1280x720)
- **1080p Full HD**: High quality, larger files (1920x1080)
- **4K UHD**: Maximum quality, very large files (3840x2160)

## Technical Details

### Supported Formats
- Recording: WebM with VP9 codec
- Audio: Included with video stream
- Storage: Local IndexedDB and localStorage

### Browser Compatibility
- Chrome/Edge: Full support
- Safari: iOS 14.3+ required
- Firefox: Full support on Android

### Storage Limits
- Videos stored in localStorage (base64)
- Recommended: Keep videos under 50MB each
- Auto-cleanup of old videos when storage full

### Permissions Required
- Camera access
- Microphone access
- Storage access (automatic)

## Offline Capability
Videos are automatically saved to local storage and will sync to the cloud when internet connection is restored. The offline indicator shows current connection status.

## Tips & Best Practices

### Recording Tips
- Use landscape mode for wider shots
- Ensure good lighting for best quality
- Keep videos under 5 minutes for easier sharing
- Use 1080p for best balance of quality/size

### Editing Tips
- Trim unnecessary footage before applying filters
- Test different filters to find the best look
- Keep text overlays short and readable
- Preview before saving to ensure satisfaction

### Performance Tips
- Close other apps while recording 4K
- Ensure sufficient storage space (500MB+ free)
- Use WiFi for syncing large videos
- Clear old videos regularly to free space

## Troubleshooting

### Camera Not Working
- Check browser permissions in settings
- Ensure no other app is using camera
- Try refreshing the page
- Restart browser if issue persists

### Video Not Saving
- Check available storage space
- Ensure localStorage not disabled
- Try shorter video duration
- Clear browser cache if needed

### Poor Video Quality
- Increase quality setting to 1080p or 4K
- Ensure good lighting conditions
- Clean camera lens
- Check available bandwidth for streaming

### Editing Not Working
- Ensure video fully loaded before editing
- Try smaller video file
- Refresh page and try again
- Check browser console for errors

## Future Enhancements
- Video compression options
- More advanced filters and effects
- Multi-clip editing
- Background music integration
- Direct social media sharing
- Cloud storage integration
