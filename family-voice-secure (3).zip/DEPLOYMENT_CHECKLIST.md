# 📋 Vercel Deployment Checklist

## Pre-Deployment Setup

### 1. Supabase Configuration
- [ ] Supabase project created
- [ ] Database tables migrated
- [ ] Row Level Security (RLS) policies configured
- [ ] Storage buckets created
- [ ] Edge functions deployed (if any)

### 2. Environment Variables Prepared
Create `.env` file locally with:
```env
VITE_SUPABASE_URL=https://xxxxx.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGc...
VITE_VAPID_PUBLIC_KEY=BNxxx... (optional)
VITE_STRIPE_PUBLISHABLE_KEY=pk_xxx... (optional)
```

### 3. Test Locally
```bash
npm install
npm run build
npm run preview
```
- [ ] Build succeeds without errors
- [ ] Preview works correctly
- [ ] No console errors

---

## Vercel Deployment Steps

### Step 1: Import Repository
1. Go to [vercel.com](https://vercel.com)
2. Click **"Add New"** → **"Project"**
3. Import your GitHub repository
4. Click **"Import"**

### Step 2: Configure Project
```
Framework Preset: Vite
Root Directory: ./ (leave empty)
Build Command: npm run build
Output Directory: dist
Install Command: npm install
```

### Step 3: Add Environment Variables
In **"Environment Variables"** section, add:

| Variable | Value | Environment |
|----------|-------|-------------|
| VITE_SUPABASE_URL | `https://xxx.supabase.co` | Production, Preview, Development |
| VITE_SUPABASE_ANON_KEY | `eyJhbGc...` | Production, Preview, Development |
| VITE_VAPID_PUBLIC_KEY | `BNxxx...` | Production, Preview, Development |
| VITE_STRIPE_PUBLISHABLE_KEY | `pk_xxx...` | Production, Preview, Development |

### Step 4: Deploy
- [ ] Click **"Deploy"**
- [ ] Wait for build to complete
- [ ] Check build logs for errors

---

## Post-Deployment Verification

### 1. Check Deployment Status
- [ ] Build completed successfully
- [ ] No errors in build logs
- [ ] Deployment shows "Ready"

### 2. Test Production URL
Visit your Vercel URL and verify:
- [ ] App loads without white screen
- [ ] No console errors (F12 → Console)
- [ ] Routes work (navigate between pages)
- [ ] Authentication works (signup/login)
- [ ] Supabase connection works

### 3. Test PWA Features
- [ ] Service worker registers
- [ ] Install prompt appears (mobile)
- [ ] Offline mode works
- [ ] Push notifications work (if enabled)

### 4. Configure Custom Domain (Optional)
1. Go to **Settings** → **Domains**
2. Add your custom domain
3. Configure DNS records
4. Wait for SSL certificate

### 5. Update Supabase CORS
In Supabase Dashboard:
1. Go to **Settings** → **API**
2. Under **CORS**, add your Vercel domain:
   ```
   https://your-app.vercel.app
   https://your-custom-domain.com
   ```

---

## Troubleshooting

### Build Fails
1. Check build logs in Vercel
2. Test build locally: `npm run build`
3. Fix TypeScript errors
4. Check for missing dependencies

### App Loads But Errors
1. Open browser console (F12)
2. Check for environment variable errors
3. Verify Supabase connection
4. Check network tab for failed requests

### Environment Variables Not Working
1. Verify variables are set in Vercel
2. Check they have `VITE_` prefix
3. Redeploy after adding variables
4. Run validation: `node scripts/validate-env.js`

### Service Worker Issues
1. Check HTTPS is enabled (automatic on Vercel)
2. Verify `sw.js` is in `public/` folder
3. Check service worker registration in console
4. Clear browser cache and reload

---

## Continuous Deployment

### Automatic Deployments
- [ ] Push to `main` branch → Production deployment
- [ ] Push to other branches → Preview deployment
- [ ] Pull requests → Preview deployment

### GitHub Actions (Optional)
The project includes CI/CD workflows:
- `.github/workflows/deploy-production.yml`
- `.github/workflows/deploy-staging.yml`

Configure GitHub secrets:
```
VERCEL_TOKEN
VERCEL_ORG_ID
VERCEL_PROJECT_ID
```

---

## Monitoring & Maintenance

### Regular Checks
- [ ] Monitor Vercel Analytics
- [ ] Check error logs
- [ ] Monitor Supabase usage
- [ ] Review performance metrics

### Updates
```bash
# Update dependencies
npm update

# Test locally
npm run build
npm run preview

# Deploy
git add .
git commit -m "chore: update dependencies"
git push origin main
```

---

## Quick Commands

```bash
# Validate environment variables
node scripts/validate-env.js

# Build locally
npm run build

# Preview build
npm run preview

# Deploy via CLI
vercel --prod

# View logs
vercel logs

# List deployments
vercel ls
```

---

## Success Criteria ✅

Your deployment is successful when:
- ✅ Build completes without errors
- ✅ App loads on production URL
- ✅ No console errors
- ✅ Authentication works
- ✅ Database operations work
- ✅ PWA features work
- ✅ All routes accessible
- ✅ Performance is good (< 3s load time)

