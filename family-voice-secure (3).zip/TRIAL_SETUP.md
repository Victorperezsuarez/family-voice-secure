# Free Trial System Setup Guide

Family Voice Secure includes a comprehensive 14-day free trial system for all paid subscription plans.

## Features

- **Automatic Trial Period**: All new subscriptions start with a configurable trial period (default: 14 days)
- **Trial Reminders**: Automated email notifications sent before trial ends (default: 3 days before)
- **Trial Status Indicators**: Real-time trial status displayed in billing portal
- **Admin Controls**: Configure trial duration, reminder timing, and auto-cancel behavior
- **Stripe Integration**: Full integration with Stripe's trial period functionality

## How It Works

### 1. User Flow

1. User selects a paid plan on the pricing page
2. Clicks "Start Free Trial" button
3. Completes Stripe checkout (no payment required during trial)
4. Trial subscription is created with trial_end date
5. User receives trial confirmation email
6. 3 days before trial ends, user receives reminder email
7. At trial end, subscription automatically converts to paid (or cancels if configured)

### 2. Trial Configuration

Admins can configure trial settings in the Admin Dashboard:

**Navigate to**: Admin Dashboard → Stripe Config tab

**Settings**:
- **Trial Duration**: Number of days for the trial period (default: 14)
- **Reminder Days Before**: When to send reminder email (default: 3)
- **Auto-cancel on Trial End**: Whether to cancel subscription if no payment method (default: false)

### 3. Email Notifications

The system sends automated emails at key trial milestones:

**Trial Started**:
- Sent immediately after checkout
- Confirms trial period and end date
- Explains what happens after trial

**Trial Ending Soon**:
- Sent X days before trial ends (configurable)
- Reminds user of trial end date
- Provides link to manage subscription
- Explains automatic conversion to paid

**Trial Ended**:
- Sent when trial converts to paid subscription
- Confirms first payment
- Provides invoice and billing portal link

## Setup Instructions

### 1. Database Setup

The trial system requires these database tables (already created):

```sql
-- Trial configuration table
CREATE TABLE trial_config (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  trial_days INTEGER NOT NULL DEFAULT 14,
  reminder_days_before INTEGER NOT NULL DEFAULT 3,
  auto_cancel_on_trial_end BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Subscriptions table with trial fields
ALTER TABLE subscriptions 
ADD COLUMN trial_end TIMESTAMP WITH TIME ZONE,
ADD COLUMN trial_reminder_sent BOOLEAN DEFAULT FALSE;
```

### 2. Stripe Configuration

In Stripe Dashboard, ensure your products are configured for trials:

1. Go to Products → Select your product
2. Under pricing, trials are automatically handled by checkout
3. No special product configuration needed

### 3. Configure Trial Settings

1. Log in as admin
2. Navigate to Admin Dashboard
3. Click "Stripe Config" tab
4. Under "Trial Settings":
   - Set trial duration (days)
   - Set reminder timing (days before end)
   - Toggle auto-cancel if needed
5. Click "Save All Configuration"

### 4. Test the Trial Flow

**Test Mode Checklist**:

1. **Start Trial**:
   - Go to /pricing
   - Click "Start Free Trial" on any paid plan
   - Complete checkout (use test card: 4242 4242 4242 4242)
   - Verify trial subscription created

2. **Check Trial Status**:
   - Go to /billing
   - Verify trial badge shows "trialing"
   - Confirm trial end date is displayed
   - Check days remaining counter

3. **Test Trial Reminder**:
   - In database, update trial_end to 3 days from now
   - Trigger webhook: `customer.subscription.trial_will_end`
   - Verify reminder email sent
   - Check trial_reminder_sent flag updated

4. **Test Trial Conversion**:
   - In Stripe Dashboard, end trial early
   - Verify subscription converts to "active"
   - Check first invoice created
   - Confirm payment processed

## Edge Functions

### send-trial-reminder

Sends email notification before trial ends.

**Triggered by**: Stripe webhook `customer.subscription.trial_will_end`

**Functionality**:
- Fetches user profile
- Calculates days until trial end
- Sends formatted email via SendGrid
- Updates trial_reminder_sent flag

### stripe-webhook

Handles all Stripe subscription events including trial events.

**Trial Events Handled**:
- `customer.subscription.created` - Creates subscription with trial_end
- `customer.subscription.updated` - Updates trial status
- `customer.subscription.trial_will_end` - Triggers reminder
- `invoice.payment_succeeded` - Records first payment after trial

## Monitoring Trial Subscriptions

### Admin Dashboard

View trial statistics in Admin Dashboard:
- Total active trials
- Trials ending soon
- Trial conversion rate
- Average trial duration

### Database Queries

**Active Trials**:
```sql
SELECT * FROM subscriptions 
WHERE status = 'trialing' 
AND trial_end > NOW()
ORDER BY trial_end ASC;
```

**Trials Ending Soon**:
```sql
SELECT * FROM subscriptions 
WHERE status = 'trialing' 
AND trial_end BETWEEN NOW() AND NOW() + INTERVAL '3 days'
AND trial_reminder_sent = false;
```

**Trial Conversion Rate**:
```sql
SELECT 
  COUNT(*) FILTER (WHERE status = 'active' AND trial_end IS NOT NULL) * 100.0 / 
  COUNT(*) FILTER (WHERE trial_end IS NOT NULL) as conversion_rate
FROM subscriptions;
```

## Customization

### Email Templates

Customize trial reminder emails in:
`supabase/functions/send-trial-reminder/index.ts`

### Trial Duration

Change default trial period:
1. Admin Dashboard → Stripe Config
2. Update "Trial Duration (days)"
3. Save configuration

### Reminder Timing

Adjust when reminders are sent:
1. Admin Dashboard → Stripe Config
2. Update "Reminder Days Before End"
3. Save configuration

## Troubleshooting

### Trial Not Starting

**Issue**: Subscription created without trial
**Solution**: 
- Check trial_config table has valid trial_days
- Verify create-subscription function includes trial_period_days
- Ensure Stripe API key is correct

### Reminder Not Sent

**Issue**: No email received before trial end
**Solution**:
- Check SendGrid API key configured
- Verify webhook endpoint receiving events
- Check trial_reminder_sent flag not already true
- Test webhook manually in Stripe Dashboard

### Trial Not Converting

**Issue**: Trial doesn't convert to paid subscription
**Solution**:
- Verify payment method attached to customer
- Check Stripe subscription settings
- Review webhook logs for errors
- Ensure invoice.payment_succeeded webhook processed

## Best Practices

1. **Clear Communication**: Always inform users about trial terms upfront
2. **Reminder Timing**: Send reminder 3-7 days before trial ends
3. **Easy Cancellation**: Make it simple to cancel during trial
4. **Value Demonstration**: Highlight features during trial period
5. **Conversion Optimization**: Track and optimize trial-to-paid conversion

## Support

For issues or questions:
- Check webhook logs in Stripe Dashboard
- Review edge function logs in Supabase
- Test with Stripe test mode first
- Contact support with subscription ID for assistance
