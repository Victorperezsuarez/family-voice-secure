# 🚀 Vela Deployment Guide

## Quick Deploy Options

### Option 1: Deploy to Vercel (Recommended - Easiest)

1. **Push your code to GitHub:**
   ```bash
   git add .
   git commit -m "Ready for deployment"
   git push origin main
   ```

2. **Deploy to Vercel:**
   - Go to [vercel.com](https://vercel.com)
   - Click "Add New Project"
   - Import your GitHub repository
   - Vercel auto-detects settings ✅
   - Click "Deploy"

3. **Add Environment Variables:**
   - In Vercel dashboard → Settings → Environment Variables
   - Add: `VITE_SUPABASE_URL` = `https://iqrhacrtcgquvxmrlxnl.supabase.co`
   - Add: `VITE_SUPABASE_ANON_KEY` = (your Supabase anon key)
   - Redeploy

4. **Done!** Your URL: `https://your-app.vercel.app`

---

### Option 2: Deploy to Netlify

1. **Push code to GitHub** (same as above)

2. **Deploy to Netlify:**
   - Go to [netlify.com](https://netlify.com)
   - Click "Add new site" → "Import existing project"
   - Connect to GitHub and select your repo
   - Build settings are auto-detected ✅
   - Click "Deploy"

3. **Add Environment Variables:**
   - Site settings → Environment variables
   - Add the same Supabase variables
   - Redeploy

---

## 📱 Install on Mobile

Once deployed, visit your URL on mobile:

**iOS:** Safari → Share → Add to Home Screen
**Android:** Chrome → Menu → Install app

---

## 🔧 Environment Variables Needed

```
VITE_SUPABASE_URL=https://iqrhacrtcgquvxmrlxnl.supabase.co
VITE_SUPABASE_ANON_KEY=your_anon_key_here
```

Find your anon key in Supabase Dashboard → Settings → API

---

## ✅ Deployment Checklist

- [ ] Code pushed to GitHub
- [ ] Connected to Vercel/Netlify
- [ ] Environment variables added
- [ ] First deployment successful
- [ ] Tested on mobile browser
- [ ] Installed as PWA on phone

---

## 🆘 Troubleshooting

**Build fails?**
- Check that all dependencies are in package.json
- Run `npm install` locally first

**App loads but features don't work?**
- Verify environment variables are set correctly
- Check Supabase URL is accessible

**PWA won't install?**
- Ensure HTTPS is enabled (Vercel/Netlify do this automatically)
- Check manifest.json is accessible at /manifest.json


---

## 🌐 Custom Domain Setup with SSL

### Vercel Custom Domain Configuration

#### Step 1: Purchase a Domain
- Buy from: Namecheap, GoDaddy, Google Domains, Cloudflare, etc.
- Example: `vela-family.com`

#### Step 2: Add Domain to Vercel
1. Go to your project in Vercel Dashboard
2. Click **Settings** → **Domains**
3. Enter your domain: `vela-family.com`
4. Click **Add**
5. Vercel will show DNS records to configure

#### Step 3: Configure DNS (at your domain registrar)

**For Root Domain (vela-family.com):**
- Type: `A`
- Name: `@`
- Value: `76.76.21.21`

**For www subdomain (www.vela-family.com):**
- Type: `CNAME`
- Name: `www`
- Value: `cname.vercel-dns.com`

**Alternative: Use CNAME for root (if registrar supports ANAME/ALIAS):**
- Type: `CNAME` (or `ANAME`/`ALIAS`)
- Name: `@`
- Value: `cname.vercel-dns.com`

#### Step 4: Wait for DNS Propagation
- Usually takes 5-60 minutes
- Can take up to 48 hours
- Check status at: [whatsmydns.net](https://whatsmydns.net)

#### Step 5: SSL Certificate (Automatic)
- Vercel automatically provisions SSL via Let's Encrypt
- HTTPS enabled within minutes after DNS propagates
- Certificate auto-renews every 90 days
- No action needed! ✅

#### Step 6: Verify Setup
- Visit `https://vela-family.com`
- Check for 🔒 padlock in browser
- Test PWA installation on mobile

---

### Netlify Custom Domain Configuration

#### Step 1: Purchase Domain (same as Vercel)

#### Step 2: Add Domain to Netlify
1. Go to **Site settings** → **Domain management**
2. Click **Add custom domain**
3. Enter: `vela-family.com`
4. Click **Verify**
5. Netlify will guide you through DNS setup

#### Step 3: Configure DNS

**Option A: Use Netlify DNS (Recommended - Easiest)**
1. In Netlify, click **Set up Netlify DNS**
2. Netlify provides nameservers (e.g., `dns1.p03.nsone.net`)
3. Go to your domain registrar
4. Replace nameservers with Netlify's nameservers
5. Wait for propagation (2-48 hours)
6. Netlify handles all DNS automatically ✅

**Option B: External DNS (Keep current registrar DNS)**

At your domain registrar, add:

**For Root Domain:**
- Type: `A`
- Name: `@`
- Value: `75.2.60.5` (Netlify load balancer)

**For www subdomain:**
- Type: `CNAME`
- Name: `www`
- Value: `your-site-name.netlify.app`

**Alternative: Use Netlify's CNAME (if registrar supports ANAME/ALIAS):**
- Type: `ALIAS` or `ANAME`
- Name: `@`
- Value: `your-site-name.netlify.app`

#### Step 4: Enable HTTPS in Netlify
1. Go to **Domain settings** → **HTTPS**
2. Click **Verify DNS configuration**
3. Once verified, click **Provision certificate**
4. Netlify uses Let's Encrypt (automatic, free)
5. Certificate provisions in 1-5 minutes
6. Auto-renews every 90 days ✅

#### Step 5: Force HTTPS (Recommended)
1. In **HTTPS** settings
2. Enable **Force HTTPS redirect**
3. All HTTP traffic redirects to HTTPS

---

## 🔧 DNS Configuration Examples

### Example 1: Namecheap DNS Settings

```
Type     Host    Value                      TTL
A        @       76.76.21.21 (Vercel)       Automatic
CNAME    www     cname.vercel-dns.com       Automatic
```

### Example 2: Cloudflare DNS Settings

```
Type     Name    Content                    Proxy Status
A        @       76.76.21.21                DNS only (gray cloud)
CNAME    www     cname.vercel-dns.com       DNS only (gray cloud)
```

**Note:** Disable Cloudflare proxy (orange cloud) initially for SSL setup

### Example 3: Google Domains DNS Settings

```
Type     Host    Data                       TTL
A        @       76.76.21.21                1h
CNAME    www     cname.vercel-dns.com       1h
```

---

## 🎯 Subdomain Setup (Optional)

Want `app.vela-family.com` instead of root domain?

**Add CNAME record:**
- Type: `CNAME`
- Name: `app`
- Value: `cname.vercel-dns.com` (Vercel) or `your-site.netlify.app` (Netlify)

Then add `app.vela-family.com` in Vercel/Netlify domain settings.

---

## ✅ Custom Domain Checklist

- [ ] Domain purchased from registrar
- [ ] Domain added in Vercel/Netlify dashboard
- [ ] DNS records configured (A and CNAME)
- [ ] DNS propagation complete (check whatsmydns.net)
- [ ] SSL certificate provisioned (look for 🔒)
- [ ] HTTPS redirect enabled
- [ ] Tested on desktop browser
- [ ] Tested on mobile browser
- [ ] PWA installs with custom domain

---

## 🆘 Custom Domain Troubleshooting

**Domain not resolving?**
- Wait longer (DNS can take 24-48 hours)
- Verify DNS records are correct (no typos)
- Clear browser cache and DNS cache
- Try incognito/private browsing

**SSL certificate not provisioning?**
- Ensure DNS is fully propagated first
- Check CAA records don't block Let's Encrypt
- Wait 30 minutes and try "Renew certificate"

**"Not Secure" warning?**
- SSL may still be provisioning (wait 5-10 min)
- Hard refresh browser (Ctrl+Shift+R)
- Check certificate status in Vercel/Netlify

**WWW not working?**
- Add separate CNAME record for `www`
- Add `www.vela-family.com` as domain in dashboard
- Enable redirect from www to non-www (or vice versa)

**Cloudflare users:**
- Disable proxy (gray cloud) during initial setup
- Re-enable after SSL is working
- Or use Cloudflare's "Full (strict)" SSL mode

---

## 🔐 Security Best Practices

1. **Always use HTTPS** - Enabled automatically with Vercel/Netlify
2. **Enable HSTS** - Vercel/Netlify handle this
3. **Set up CAA records** (optional but recommended):
   ```
   Type: CAA
   Name: @
   Value: 0 issue "letsencrypt.org"
   ```
4. **Enable force HTTPS redirect** - In hosting dashboard
5. **Monitor SSL expiry** - Auto-renewed, but check occasionally

---

## 📊 DNS Propagation Checker Tools

- [whatsmydns.net](https://whatsmydns.net) - Global DNS checker
- [dnschecker.org](https://dnschecker.org) - Alternative checker
- Command line: `nslookup vela-family.com`
- Command line: `dig vela-family.com`


---

## 📧 Custom Email Setup (hello@vela-family.com)

### Option 1: ImprovMX (Free, Easiest)

**Best for:** Email forwarding to personal Gmail/Outlook

#### Step 1: Sign Up
1. Go to [improvmx.com](https://improvmx.com)
2. Sign up (free plan: unlimited aliases)
3. Add domain: `vela-family.com`

#### Step 2: Configure MX Records
Add these records at your DNS provider:

```
Type: MX    Name: @    Value: mx1.improvmx.com    Priority: 10
Type: MX    Name: @    Value: mx2.improvmx.com    Priority: 20
```

#### Step 3: Add Email Aliases
- `hello@vela-family.com` → forwards to `your-personal@gmail.com`
- `support@vela-family.com` → forwards to `your-personal@gmail.com`
- `noreply@vela-family.com` → forwards to `your-personal@gmail.com`

#### Step 4: Add SPF Record
```
Type: TXT    Name: @    Value: v=spf1 include:spf.improvmx.com ~all
```

#### Step 5: Verify & Test
- Wait 10-30 minutes for DNS propagation
- Send test email to `hello@vela-family.com`
- Check it arrives in your personal inbox

**Sending Emails:**
- Reply from your personal email (shows your personal address)
- Or upgrade to ImprovMX Premium ($9/mo) for SMTP sending

---

### Option 2: Cloudflare Email Routing (Free)

**Best for:** Cloudflare users, simple forwarding

#### Prerequisites
- Domain must use Cloudflare nameservers
- Free Cloudflare account

#### Step 1: Enable Email Routing
1. Login to Cloudflare Dashboard
2. Select your domain
3. Go to **Email** → **Email Routing**
4. Click **Get started**

#### Step 2: Configure Destination
1. Add destination email: `your-personal@gmail.com`
2. Verify email (check inbox for verification link)

#### Step 3: Create Routing Rules
- `hello@vela-family.com` → `your-personal@gmail.com`
- `support@vela-family.com` → `your-personal@gmail.com`
- Catch-all: `*@vela-family.com` → `your-personal@gmail.com`

#### Step 4: DNS Records (Auto-configured)
Cloudflare automatically adds:
```
MX records (priority 1-3)
SPF: v=spf1 include:_spf.mx.cloudflare.net ~all
```

#### Step 5: Test
- Send email to `hello@vela-family.com`
- Arrives in 1-2 minutes

**Limitations:**
- Forwarding only (no sending from custom domain)
- Must use Cloudflare DNS

---

### Option 3: Google Workspace (Paid, Professional)

**Best for:** Professional email with full features

**Cost:** $6/user/month (Business Starter)

#### Features
- Full email client (like Gmail)
- Send/receive from `hello@vela-family.com`
- 30GB storage per user
- Calendar, Drive, Meet included

#### Step 1: Sign Up
1. Go to [workspace.google.com](https://workspace.google.com)
2. Start free 14-day trial
3. Enter domain: `vela-family.com`

#### Step 2: Verify Domain Ownership
Add TXT record:
```
Type: TXT
Name: @
Value: google-site-verification=xxxxxxxxxxxxx
```

#### Step 3: Configure MX Records
Replace existing MX records with:
```
Type: MX    Name: @    Value: aspmx.l.google.com           Priority: 1
Type: MX    Name: @    Value: alt1.aspmx.l.google.com      Priority: 5
Type: MX    Name: @    Value: alt2.aspmx.l.google.com      Priority: 5
Type: MX    Name: @    Value: alt3.aspmx.l.google.com      Priority: 10
Type: MX    Name: @    Value: alt4.aspmx.l.google.com      Priority: 10
```

#### Step 4: Add SPF Record
```
Type: TXT    Name: @    Value: v=spf1 include:_spf.google.com ~all
```

#### Step 5: Add DKIM Record
1. In Google Admin → Apps → Gmail → Authenticate email
2. Click **Generate new record**
3. Copy the DKIM TXT record
4. Add to DNS:
```
Type: TXT
Name: google._domainkey
Value: v=DKIM1; k=rsa; p=MIGfMA0GCSqGSIb3DQEBA... (long key)
```

#### Step 6: Add DMARC Record (Optional but Recommended)
```
Type: TXT
Name: _dmarc
Value: v=DMARC1; p=quarantine; rua=mailto:hello@vela-family.com
```

#### Step 7: Create Email Accounts
- `hello@vela-family.com`
- `support@vela-family.com`
- `admin@vela-family.com`

---

## 📋 Email DNS Records Summary

### Complete DNS Setup for Email Authentication

```
# MX Records (choose ONE provider)
MX    @    mx1.improvmx.com              10    (ImprovMX)
MX    @    mx2.improvmx.com              20    (ImprovMX)

# OR Cloudflare (auto-configured)
# OR Google Workspace (5 MX records - see above)

# SPF Record (prevents spoofing)
TXT   @    v=spf1 include:spf.improvmx.com ~all

# DKIM Record (email signing - Google Workspace only)
TXT   google._domainkey    v=DKIM1; k=rsa; p=YOUR_KEY_HERE

# DMARC Record (email policy - recommended)
TXT   _dmarc    v=DMARC1; p=quarantine; rua=mailto:hello@vela-family.com
```

---

## 🔍 Email Authentication Explained

### SPF (Sender Policy Framework)
- Specifies which servers can send email from your domain
- Prevents spammers from spoofing your domain
- Format: `v=spf1 include:provider.com ~all`

### DKIM (DomainKeys Identified Mail)
- Adds digital signature to outgoing emails
- Verifies email wasn't tampered with
- Requires public/private key pair

### DMARC (Domain-based Message Authentication)
- Tells receiving servers what to do with failed SPF/DKIM
- Options: `p=none` (monitor), `p=quarantine` (spam), `p=reject` (block)
- Provides reports on email authentication

---

## ✅ Email Setup Checklist

- [ ] Choose email provider (ImprovMX/Cloudflare/Google)
- [ ] Configure MX records
- [ ] Add SPF record
- [ ] Add DKIM record (if using Google Workspace)
- [ ] Add DMARC record (recommended)
- [ ] Wait for DNS propagation (30-60 min)
- [ ] Send test email to custom address
- [ ] Verify email arrives at destination
- [ ] Test SPF/DKIM at [mail-tester.com](https://mail-tester.com)
- [ ] Set up email signature
- [ ] Configure email client (if using Google Workspace)

---

## 🆘 Email Troubleshooting

**Emails not arriving?**
- Check MX records are correct (use `dig vela-family.com MX`)
- Wait longer for DNS propagation (up to 24 hours)
- Check spam folder
- Verify destination email is correct

**Emails going to spam?**
- Add SPF record
- Add DKIM record (Google Workspace)
- Add DMARC record
- Test at [mail-tester.com](https://mail-tester.com) (should score 9+/10)

**Can't send from custom domain?**
- ImprovMX free: Can't send (forwarding only)
- Cloudflare: Can't send (forwarding only)
- Google Workspace: Full send/receive capability

**SPF/DKIM failures?**
- Verify TXT records are correct (no typos)
- Don't have multiple SPF records (combine into one)
- DKIM key must match exactly (copy entire key)

---

## 💡 Email Best Practices

1. **Use catch-all carefully** - Can receive spam
2. **Set up multiple aliases** - hello@, support@, noreply@
3. **Enable 2FA** - On email provider account
4. **Monitor email reputation** - Use [mxtoolbox.com](https://mxtoolbox.com)
5. **Regular backups** - Export important emails
6. **Professional signature** - Include name, title, website
7. **Auto-responders** - Set up for support@ emails
8. **Email retention policy** - Delete old emails regularly

---

## 🔗 Useful Email Tools

- [mail-tester.com](https://mail-tester.com) - Test email deliverability
- [mxtoolbox.com](https://mxtoolbox.com) - Check MX/SPF/DKIM records
- [dmarcian.com](https://dmarcian.com) - DMARC analyzer
- [dkimvalidator.com](https://dkimvalidator.com) - Test DKIM signatures
