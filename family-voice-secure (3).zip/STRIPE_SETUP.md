# Stripe Payment Integration Setup Guide

## Prerequisites

- Stripe account (sign up at https://stripe.com)
- Supabase project with edge functions enabled
- Admin access to your application

## Step 1: Create Stripe Products and Prices

### 1.1 Access Stripe Dashboard

1. Log in to https://dashboard.stripe.com
2. Switch to **Test mode** (toggle in top right)
3. Navigate to **Products** → **Add product**

### 1.2 Create Products

Create 3 products with the following details:

#### Family Plan
- **Name**: Family Voice Secure - Family Plan
- **Description**: Perfect for families wanting to preserve their stories
- **Pricing**:
  - Monthly: $9.99/month (recurring)
  - Annual: $99/year (recurring)
- **Features** (add as metadata):
  - 5 family members
  - 50 hours recording storage
  - AI transcription
  - Photo storage (5GB)
  - Family tree builder

#### Premium Plan
- **Name**: Family Voice Secure - Premium Plan
- **Description**: Advanced features for growing families
- **Pricing**:
  - Monthly: $19.99/month (recurring)
  - Annual: $199/year (recurring)
- **Features** (add as metadata):
  - 15 family members
  - Unlimited recording storage
  - Advanced AI features
  - Photo storage (50GB)
  - Priority support

#### Enterprise Plan
- **Name**: Family Voice Secure - Enterprise Plan
- **Description**: Custom solution for large families and organizations
- **Pricing**: Custom (contact sales)
- **Features**: Custom features based on needs

### 1.3 Copy Price IDs

After creating each price, copy the Price ID (starts with `price_`):
- Family Monthly: `price_xxxxxxxxxxxxx`
- Family Annual: `price_xxxxxxxxxxxxx`
- Premium Monthly: `price_xxxxxxxxxxxxx`
- Premium Annual: `price_xxxxxxxxxxxxx`

## Step 2: Configure Stripe API Keys

### 2.1 Get API Keys

1. In Stripe Dashboard, go to **Developers** → **API keys**
2. Copy **Publishable key** (starts with `pk_test_`)
3. Copy **Secret key** (starts with `sk_test_`)

### 2.2 Add to Supabase

1. Go to Supabase Dashboard → **Edge Functions** → **Secrets**
2. Add the following secrets:
   ```
   STRIPE_SECRET_KEY=sk_test_xxxxxxxxxxxxx
   STRIPE_PUBLISHABLE_KEY=pk_test_xxxxxxxxxxxxx
   STRIPE_WEBHOOK_SECRET=(we'll add this in Step 3)
   ```

3. Add to your `.env.local` file:
   ```
   VITE_STRIPE_PUBLISHABLE_KEY=pk_test_xxxxxxxxxxxxx
   ```

## Step 3: Configure Webhooks

### 3.1 Create Webhook Endpoint

1. In Stripe Dashboard, go to **Developers** → **Webhooks**
2. Click **Add endpoint**
3. Enter your webhook URL:
   ```
   https://[your-project-ref].supabase.co/functions/v1/stripe-webhook
   ```
4. Select events to listen to:
   - `checkout.session.completed`
   - `customer.subscription.created`
   - `customer.subscription.updated`
   - `customer.subscription.deleted`
   - `invoice.payment_succeeded`
   - `invoice.payment_failed`

5. Click **Add endpoint**
6. Copy the **Signing secret** (starts with `whsec_`)
7. Add to Supabase secrets:
   ```
   STRIPE_WEBHOOK_SECRET=whsec_xxxxxxxxxxxxx
   ```

## Step 4: Configure Price IDs in Application

### Option A: Using Admin Interface (Recommended)

1. Log in as an admin user
2. Navigate to `/admin` or `/settings`
3. Find **Stripe Configuration** panel
4. Enter your Price IDs:
   - Family Monthly Price ID
   - Family Annual Price ID
   - Premium Monthly Price ID
   - Premium Annual Price ID
5. Click **Save Configuration**
6. Test the configuration

### Option B: Direct Database Insert

Run this SQL in Supabase SQL Editor:

```sql
INSERT INTO stripe_config (
  plan_name,
  monthly_price_id,
  annual_price_id,
  created_at,
  updated_at
) VALUES 
  ('family', 'price_xxxxxxxxxxxxx', 'price_xxxxxxxxxxxxx', NOW(), NOW()),
  ('premium', 'price_xxxxxxxxxxxxx', 'price_xxxxxxxxxxxxx', NOW(), NOW())
ON CONFLICT (plan_name) 
DO UPDATE SET
  monthly_price_id = EXCLUDED.monthly_price_id,
  annual_price_id = EXCLUDED.annual_price_id,
  updated_at = NOW();
```

## Step 5: Test Payment Flow

### 5.1 Test Checkout

1. Go to `/pricing` page
2. Click **Get Started** on Family or Premium plan
3. You should be redirected to Stripe Checkout
4. Use test card: `4242 4242 4242 4242`
5. Use any future expiry date and any CVC
6. Complete checkout

### 5.2 Verify Subscription Created

1. Check Supabase `subscriptions` table - new row should appear
2. Check Stripe Dashboard → **Payments** - payment should be listed
3. Check Stripe Dashboard → **Subscriptions** - subscription should be active

### 5.3 Test Billing Portal

1. Log in to your application
2. Navigate to `/billing`
3. Click **Manage Subscription**
4. You should see Stripe Customer Portal
5. Test updating payment method
6. Test canceling subscription

### 5.4 Test Webhooks

1. In Stripe Dashboard, go to **Developers** → **Webhooks**
2. Click on your webhook endpoint
3. View **Recent deliveries** - should show successful events
4. If failures, check logs in Supabase Edge Functions

## Step 6: Production Deployment

### 6.1 Switch to Live Mode

1. In Stripe Dashboard, toggle to **Live mode**
2. Create products and prices again (repeat Step 1)
3. Get live API keys (repeat Step 2)
4. Create live webhook (repeat Step 3)
5. Update Price IDs in admin interface (repeat Step 4)

### 6.2 Update Environment Variables

Replace all test keys with live keys:
```
STRIPE_SECRET_KEY=sk_live_xxxxxxxxxxxxx
STRIPE_PUBLISHABLE_KEY=pk_live_xxxxxxxxxxxxx
STRIPE_WEBHOOK_SECRET=whsec_xxxxxxxxxxxxx
VITE_STRIPE_PUBLISHABLE_KEY=pk_live_xxxxxxxxxxxxx
```

## Troubleshooting

### Checkout not opening
- Verify `VITE_STRIPE_PUBLISHABLE_KEY` is set correctly
- Check browser console for errors
- Ensure Stripe.js is loaded

### Webhook not receiving events
- Verify webhook URL is correct and accessible
- Check webhook signing secret matches
- View webhook logs in Stripe Dashboard
- Check Supabase Edge Function logs

### Subscription not appearing in database
- Check webhook is configured and receiving events
- Verify `checkout.session.completed` event is enabled
- Check Supabase logs for errors
- Ensure RLS policies allow inserts

### Payment method update not working
- Verify billing portal session creation is working
- Check Stripe Customer Portal settings
- Ensure customer has valid subscription

## Support

For issues:
1. Check Stripe Dashboard → Developers → Logs
2. Check Supabase Dashboard → Edge Functions → Logs
3. Review webhook delivery attempts
4. Contact support with error details

## Testing Cards

Use these test cards in test mode:

- **Success**: 4242 4242 4242 4242
- **Decline**: 4000 0000 0000 0002
- **3D Secure**: 4000 0025 0000 3155
- **Insufficient funds**: 4000 0000 0000 9995

More test cards: https://stripe.com/docs/testing
