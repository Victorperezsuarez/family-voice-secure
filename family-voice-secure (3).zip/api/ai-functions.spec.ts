import { test, expect } from '@playwright/test';
import { invokeEdgeFunction, authenticateUser } from './helpers/api-client';

test.describe('AI/ML Edge Functions', () => {
  let authToken: string;

  test.beforeAll(async () => {
    const { data } = await authenticateUser('test@example.com', 'password123');
    authToken = data.session?.access_token || '';
  });

  test('should analyze recording with AI', async () => {
    const { data, error } = await invokeEdgeFunction(
      'analyze-recording-ai',
      {
        transcription: 'Sample transcription text',
        title: 'Test Recording',
        recordingId: 'test-id',
      },
      authToken
    );

    expect(error).toBeNull();
    expect(data.insights).toBeDefined();
    expect(data.sentiment).toBeDefined();
  });

  test('should generate story from recordings', async () => {
    const { data, error } = await invokeEdgeFunction(
      'generate-story-from-recordings',
      {
        recordings: ['rec-1', 'rec-2'],
        theme: 'family',
        familyName: 'Smith Family',
      },
      authToken
    );

    expect(error).toBeNull();
    expect(data.story).toBeDefined();
    expect(data.story.length).toBeGreaterThan(0);
  });

  test('should perform semantic search', async () => {
    const { data, error } = await invokeEdgeFunction(
      'semantic-search',
      {
        query: 'birthday celebration',
        familyId: 'test-family-id',
        threshold: 0.6,
        limit: 20,
      },
      authToken
    );

    expect(error).toBeNull();
    expect(Array.isArray(data.results)).toBe(true);
  });

  test('should detect faces in photo', async () => {
    const { data, error } = await invokeEdgeFunction(
      'detect-faces',
      {
        photoUrl: 'https://example.com/photo.jpg',
        photoId: 'test-photo-id',
      },
      authToken
    );

    expect(error).toBeNull();
    expect(Array.isArray(data.faces)).toBe(true);
  });
});
