import { test, expect } from '@playwright/test';
import { invokeEdgeFunction, authenticateUser } from './helpers/api-client';

test.describe('Billing and Subscription API', () => {
  let authToken: string;

  test.beforeAll(async () => {
    const { data } = await authenticateUser('test@example.com', 'password123');
    authToken = data.session?.access_token || '';
  });

  test('should create subscription checkout session', async () => {
    const { data, error } = await invokeEdgeFunction(
      'create-subscription',
      {
        planName: 'pro',
        priceId: 'price_test123',
        successUrl: 'https://example.com/success',
        cancelUrl: 'https://example.com/cancel',
      },
      authToken
    );

    expect(error).toBeNull();
    expect(data.sessionId).toBeDefined();
    expect(data.url).toContain('stripe.com');
  });

  test('should create billing portal session', async () => {
    const { data, error } = await invokeEdgeFunction(
      'create-billing-portal-session',
      {
        customerId: 'cus_test123',
      },
      authToken
    );

    expect(error).toBeNull();
    expect(data.url).toBeDefined();
  });

  test('should handle webhook events', async () => {
    const { data, error } = await invokeEdgeFunction(
      'stripe-webhook',
      {
        type: 'customer.subscription.created',
        data: {
          object: {
            id: 'sub_test123',
            customer: 'cus_test123',
            status: 'active',
          },
        },
      }
    );

    expect(error).toBeNull();
    expect(data.received).toBe(true);
  });

  test('should check usage limits', async () => {
    const { data, error } = await invokeEdgeFunction(
      'check-usage-limit',
      {
        resource: 'recordings',
        userId: 'test-user-id',
      },
      authToken
    );

    expect(error).toBeNull();
    expect(data.allowed).toBeDefined();
    expect(data.remaining).toBeGreaterThanOrEqual(0);
  });
});
