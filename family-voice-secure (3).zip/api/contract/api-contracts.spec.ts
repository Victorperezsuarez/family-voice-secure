import { test, expect } from '@playwright/test';
import { invokeEdgeFunction, authenticateUser } from '../helpers/api-client';

test.describe('API Contract Testing', () => {
  let authToken: string;

  test.beforeAll(async () => {
    const { data } = await authenticateUser('test@example.com', 'password123');
    authToken = data.session?.access_token || '';
  });

  test('transcribe-audio contract', async () => {
    const { data, error } = await invokeEdgeFunction(
      'transcribe-audio',
      {
        recordingId: 'test-id',
        audioUrl: 'https://example.com/audio.mp3',
        language: 'en',
      },
      authToken
    );

    // Contract: Response must have specific structure
    expect(data).toHaveProperty('id');
    expect(data).toHaveProperty('recording_id');
    expect(data).toHaveProperty('text');
    expect(data).toHaveProperty('language');
    expect(data).toHaveProperty('confidence');
    expect(typeof data.confidence).toBe('number');
  });

  test('enhance-audio contract', async () => {
    const { data } = await invokeEdgeFunction(
      'enhance-audio',
      { audioUrl: 'https://example.com/audio.mp3' },
      authToken
    );

    expect(data).toHaveProperty('enhancedUrl');
    expect(data).toHaveProperty('processingTime');
    expect(data.enhancedUrl).toMatch(/^https?:\/\//);
  });

  test('semantic-search contract', async () => {
    const { data } = await invokeEdgeFunction(
      'semantic-search',
      { query: 'test', familyId: 'test-id' },
      authToken
    );

    expect(Array.isArray(data.results)).toBe(true);
    if (data.results.length > 0) {
      expect(data.results[0]).toHaveProperty('id');
      expect(data.results[0]).toHaveProperty('similarity');
    }
  });
});
