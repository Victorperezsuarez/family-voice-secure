import { test, expect } from '@playwright/test';
import { supabase, authenticateUser } from './helpers/api-client';

test.describe('Authentication API', () => {
  test('should sign up new user', async () => {
    const email = `test-${Date.now()}@example.com`;
    const password = 'TestPassword123!';

    const { data, error } = await supabase.auth.signUp({
      email,
      password,
    });

    expect(error).toBeNull();
    expect(data.user).toBeDefined();
    expect(data.user?.email).toBe(email);
  });

  test('should sign in existing user', async () => {
    const { data, error } = await authenticateUser(
      'test@example.com',
      'password123'
    );

    expect(error).toBeNull();
    expect(data.session).toBeDefined();
    expect(data.session?.access_token).toBeTruthy();
  });

  test('should reject invalid credentials', async () => {
    const { data, error } = await authenticateUser(
      'invalid@example.com',
      'wrongpassword'
    );

    expect(error).toBeDefined();
    expect(data.session).toBeNull();
  });

  test('should sign out user', async () => {
    const { error } = await supabase.auth.signOut();
    expect(error).toBeNull();
  });

  test('should refresh session token', async () => {
    const { data: authData } = await authenticateUser(
      'test@example.com',
      'password123'
    );

    const { data, error } = await supabase.auth.refreshSession({
      refresh_token: authData.session?.refresh_token!,
    });

    expect(error).toBeNull();
    expect(data.session).toBeDefined();
  });
});
