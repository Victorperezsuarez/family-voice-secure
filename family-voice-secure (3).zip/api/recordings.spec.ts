import { test, expect } from '@playwright/test';
import { invokeEdgeFunction, authenticateUser } from './helpers/api-client';
import { validateSchema, RecordingSchema, TranscriptionSchema } from './helpers/schema-validator';

test.describe('Recording API', () => {
  let authToken: string;

  test.beforeAll(async () => {
    const { data } = await authenticateUser('test@example.com', 'password123');
    authToken = data.session?.access_token || '';
  });

  test('should transcribe audio recording', async () => {
    const { data, error, status } = await invokeEdgeFunction(
      'transcribe-audio',
      {
        recordingId: 'test-recording-id',
        audioUrl: 'https://example.com/audio.mp3',
        language: 'en',
      },
      authToken
    );

    expect(status).toBe(200);
    expect(error).toBeNull();
    expect(data).toBeDefined();
    
    const validation = validateSchema(data, TranscriptionSchema);
    expect(validation.valid).toBe(true);
  });

  test('should enhance audio quality', async () => {
    const { data, error } = await invokeEdgeFunction(
      'enhance-audio',
      {
        audioUrl: 'https://example.com/audio.mp3',
        enhancements: { noiseReduction: true, normalize: true },
      },
      authToken
    );

    expect(error).toBeNull();
    expect(data.enhancedUrl).toBeDefined();
  });

  test('should identify speaker', async () => {
    const { data, error } = await invokeEdgeFunction(
      'identify-speaker',
      {
        audioUrl: 'https://example.com/audio.mp3',
        familyId: 'test-family-id',
      },
      authToken
    );

    expect(error).toBeNull();
    expect(data.speakerId).toBeDefined();
    expect(data.confidence).toBeGreaterThan(0);
  });
});
