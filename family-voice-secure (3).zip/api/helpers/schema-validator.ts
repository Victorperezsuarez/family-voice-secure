import { z, ZodSchema } from 'zod';

export const RecordingSchema = z.object({
  id: z.string().uuid(),
  title: z.string(),
  audio_url: z.string().url(),
  duration: z.number().positive(),
  created_at: z.string().datetime(),
  family_id: z.string().uuid(),
  member_id: z.string().uuid().optional(),
});

export const TranscriptionSchema = z.object({
  id: z.string().uuid(),
  recording_id: z.string().uuid(),
  text: z.string(),
  language: z.string(),
  confidence: z.number().min(0).max(1),
});

export const FamilySchema = z.object({
  id: z.string().uuid(),
  name: z.string().min(1),
  created_at: z.string().datetime(),
  owner_id: z.string().uuid(),
});

export const PhotoSchema = z.object({
  id: z.string().uuid(),
  url: z.string().url(),
  family_id: z.string().uuid(),
  uploaded_at: z.string().datetime(),
});

export function validateSchema<T>(data: unknown, schema: ZodSchema<T>): {
  valid: boolean;
  errors?: z.ZodError;
  data?: T;
} {
  const result = schema.safeParse(data);
  if (result.success) {
    return { valid: true, data: result.data };
  }
  return { valid: false, errors: result.error };
}
