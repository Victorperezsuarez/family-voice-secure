import { test, expect } from '@playwright/test';
import { invokeEdgeFunction, authenticateUser } from '../helpers/api-client';

test.describe('Load Testing', () => {
  let authToken: string;

  test.beforeAll(async () => {
    const { data } = await authenticateUser('test@example.com', 'password123');
    authToken = data.session?.access_token || '';
  });

  test('concurrent transcription requests', async () => {
    const requests = Array.from({ length: 10 }, (_, i) =>
      invokeEdgeFunction(
        'transcribe-audio',
        {
          recordingId: `test-${i}`,
          audioUrl: 'https://example.com/audio.mp3',
        },
        authToken
      )
    );

    const results = await Promise.all(requests);
    const successCount = results.filter(r => r.error === null).length;
    
    expect(successCount).toBeGreaterThan(7); // 70% success rate
  });

  test('rate limiting enforcement', async () => {
    const requests = Array.from({ length: 100 }, () =>
      invokeEdgeFunction('semantic-search', { query: 'test' }, authToken)
    );

    const results = await Promise.all(requests);
    const rateLimited = results.filter(r => 
      r.error?.message?.includes('rate limit')
    );

    expect(rateLimited.length).toBeGreaterThan(0);
  });

  test('sustained load performance', async () => {
    const startTime = Date.now();
    const duration = 30000; // 30 seconds
    let requestCount = 0;
    let errorCount = 0;

    while (Date.now() - startTime < duration) {
      const { error } = await invokeEdgeFunction(
        'semantic-search',
        { query: 'test', familyId: 'test-id' },
        authToken
      );
      requestCount++;
      if (error) errorCount++;
      await new Promise(resolve => setTimeout(resolve, 100));
    }

    const errorRate = errorCount / requestCount;
    expect(errorRate).toBeLessThan(0.05); // < 5% error rate
  });
});
