#!/usr/bin/env node

/**
 * Environment Variable Validation Script
 * Run this to check if all required env vars are set
 * Usage: node scripts/validate-env.js
 */

const requiredVars = [
  'VITE_SUPABASE_URL',
  'VITE_SUPABASE_ANON_KEY',
];

const optionalVars = [
  'VITE_VAPID_PUBLIC_KEY',
  'VITE_STRIPE_PUBLISHABLE_KEY',
];

console.log('🔍 Validating Environment Variables...\n');

let hasErrors = false;

// Check required variables
console.log('📋 Required Variables:');
requiredVars.forEach(varName => {
  const value = process.env[varName];
  if (!value) {
    console.log(`  ❌ ${varName} - MISSING`);
    hasErrors = true;
  } else {
    const preview = value.substring(0, 20) + '...';
    console.log(`  ✅ ${varName} - ${preview}`);
  }
});

// Check optional variables
console.log('\n📋 Optional Variables:');
optionalVars.forEach(varName => {
  const value = process.env[varName];
  if (!value) {
    console.log(`  ⚠️  ${varName} - Not set (optional)`);
  } else {
    const preview = value.substring(0, 20) + '...';
    console.log(`  ✅ ${varName} - ${preview}`);
  }
});

// Validate Supabase URL format
const supabaseUrl = process.env.VITE_SUPABASE_URL;
if (supabaseUrl && !supabaseUrl.startsWith('https://')) {
  console.log('\n❌ VITE_SUPABASE_URL must start with https://');
  hasErrors = true;
}

if (supabaseUrl && !supabaseUrl.includes('.supabase.co')) {
  console.log('\n⚠️  VITE_SUPABASE_URL should contain .supabase.co');
}

console.log('\n' + '='.repeat(50));

if (hasErrors) {
  console.log('❌ Validation Failed - Missing required variables');
  console.log('\nAdd missing variables to:');
  console.log('  - Vercel: Settings → Environment Variables');
  console.log('  - Local: Create .env file in project root');
  process.exit(1);
} else {
  console.log('✅ All required environment variables are set!');
  process.exit(0);
}
