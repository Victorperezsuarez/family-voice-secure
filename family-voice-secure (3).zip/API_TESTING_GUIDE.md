# API Testing Guide

Comprehensive guide for testing Supabase Edge Functions with Playwright.

## Table of Contents
- [Overview](#overview)
- [Setup](#setup)
- [Running Tests](#running-tests)
- [Test Types](#test-types)
- [Writing Tests](#writing-tests)
- [CI/CD Integration](#cicd-integration)
- [Best Practices](#best-practices)

## Overview

This project includes comprehensive API testing for all Supabase Edge Functions:
- **Authentication endpoints** - Login, signup, token refresh
- **Recording APIs** - Transcription, enhancement, speaker identification
- **AI/ML functions** - Semantic search, face detection, story generation
- **Billing APIs** - Stripe integration, subscriptions, webhooks
- **Contract testing** - Response structure validation
- **Load testing** - Performance under concurrent requests
- **Schema validation** - Data integrity checks

## Setup

### Prerequisites
```bash
npm install
npx playwright install
```

### Environment Variables
Create `.env.test` file:
```env
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=your-anon-key
TEST_USER_EMAIL=test@example.com
TEST_USER_PASSWORD=password123
```

## Running Tests

### All API Tests
```bash
npm run test:api
```

### Specific Test Suites
```bash
# Authentication tests
npx playwright test api/auth.spec.ts

# Recording API tests
npx playwright test api/recordings.spec.ts

# AI function tests
npx playwright test api/ai-functions.spec.ts

# Billing tests
npx playwright test api/billing.spec.ts
```

### Contract Tests
```bash
npm run test:api:contract
```

### Load Tests
```bash
npm run test:api:load
```

### With UI
```bash
npm run test:api:headed
```

### View Reports
```bash
npm run test:api:report
```

## Test Types

### 1. Functional Tests
Test individual edge function endpoints:
```typescript
test('should transcribe audio', async () => {
  const { data, error } = await invokeEdgeFunction(
    'transcribe-audio',
    { recordingId: 'test-id', audioUrl: 'url' },
    authToken
  );
  expect(error).toBeNull();
  expect(data.text).toBeDefined();
});
```

### 2. Schema Validation
Ensure response data matches expected schemas:
```typescript
const validation = validateSchema(data, RecordingSchema);
expect(validation.valid).toBe(true);
```

### 3. Contract Testing
Verify API contracts remain consistent:
```typescript
test('API contract', async () => {
  const { data } = await invokeEdgeFunction('function-name');
  expect(data).toHaveProperty('expectedField');
  expect(typeof data.expectedField).toBe('string');
});
```

### 4. Error Handling
Test error scenarios:
```typescript
test('should handle invalid input', async () => {
  const { error } = await invokeEdgeFunction('function', {});
  expect(error).toBeDefined();
  expect(error.message).toContain('required');
});
```

### 5. Load Testing
Test performance under load:
```typescript
test('concurrent requests', async () => {
  const requests = Array.from({ length: 100 }, () =>
    invokeEdgeFunction('function', data, token)
  );
  const results = await Promise.all(requests);
  // Verify success rate and response times
});
```

### 6. Rate Limiting
Verify rate limits are enforced:
```typescript
test('rate limiting', async () => {
  const requests = Array.from({ length: 1000 }, () =>
    invokeEdgeFunction('function')
  );
  const results = await Promise.all(requests);
  const rateLimited = results.filter(r => 
    r.error?.message?.includes('rate limit')
  );
  expect(rateLimited.length).toBeGreaterThan(0);
});
```

## Writing Tests

### Test Structure
```typescript
import { test, expect } from '@playwright/test';
import { invokeEdgeFunction, authenticateUser } from './helpers/api-client';

test.describe('Feature API', () => {
  let authToken: string;

  test.beforeAll(async () => {
    const { data } = await authenticateUser('email', 'password');
    authToken = data.session?.access_token || '';
  });

  test('should perform action', async () => {
    const { data, error } = await invokeEdgeFunction(
      'function-name',
      { param: 'value' },
      authToken
    );

    expect(error).toBeNull();
    expect(data).toBeDefined();
  });
});
```

### Helper Functions

#### API Client
```typescript
import { invokeEdgeFunction } from './helpers/api-client';

const { data, error, status } = await invokeEdgeFunction(
  'function-name',
  { body: 'data' },
  'auth-token'
);
```

#### Schema Validation
```typescript
import { validateSchema, RecordingSchema } from './helpers/schema-validator';

const validation = validateSchema(data, RecordingSchema);
if (!validation.valid) {
  console.error(validation.errors);
}
```

## CI/CD Integration

### GitHub Actions
Tests run automatically on:
- Push to main/develop branches
- Pull requests
- Scheduled runs (every 6 hours)

### Workflow Configuration
See `.github/workflows/api-tests.yml`

### Secrets Required
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`
- `TEST_USER_EMAIL`
- `TEST_USER_PASSWORD`

## Best Practices

### 1. Use Test Data
```typescript
const testEmail = `test-${Date.now()}@example.com`;
```

### 2. Clean Up After Tests
```typescript
test.afterAll(async () => {
  // Delete test data
  await supabase.from('recordings').delete().eq('id', testId);
});
```

### 3. Test Edge Cases
```typescript
test('should handle empty input', async () => {
  const { error } = await invokeEdgeFunction('function', {});
  expect(error).toBeDefined();
});

test('should handle malformed data', async () => {
  const { error } = await invokeEdgeFunction('function', { invalid: 123 });
  expect(error).toBeDefined();
});
```

### 4. Verify Response Times
```typescript
test('should respond quickly', async () => {
  const start = Date.now();
  await invokeEdgeFunction('function', data, token);
  const duration = Date.now() - start;
  expect(duration).toBeLessThan(3000); // 3 seconds
});
```

### 5. Test Authentication
```typescript
test('should require authentication', async () => {
  const { error } = await invokeEdgeFunction('protected-function', data);
  expect(error?.message).toContain('unauthorized');
});
```

## Troubleshooting

### Tests Failing
1. Check environment variables are set correctly
2. Verify Supabase project is accessible
3. Ensure test user exists in database
4. Check edge functions are deployed

### Rate Limiting Issues
- Use different test accounts
- Add delays between requests
- Run load tests separately

### Timeout Errors
- Increase timeout in playwright.config.ts
- Check network connectivity
- Verify edge function performance

## Monitoring

### View Test Results
```bash
npm run test:api:report
```

### CI/CD Dashboard
Check GitHub Actions tab for:
- Test pass/fail status
- Performance metrics
- Error logs
- Coverage reports

## Support

For issues or questions:
- Check test logs in CI/CD
- Review edge function logs in Supabase Dashboard
- Verify API contracts haven't changed
- Contact development team with test failure details
