# CI/CD Pipeline Guide

## Overview

This project includes a comprehensive automated testing and deployment pipeline using GitHub Actions that ensures code quality, runs tests, validates environment variables, and provides deployment notifications.

## Pipeline Components

### 1. Continuous Integration (CI)

**Workflow File**: `.github/workflows/ci.yml`

**Triggers**:
- Push to `main` or `develop` branches
- Pull requests to `main` or `develop` branches

**Jobs**:

#### a. Validate Environment Variables
- Checks all required environment variables are set
- Validates URL formats
- Runs before other jobs to fail fast

#### b. Lint and Type Check
- Runs ESLint to check code quality
- Runs TypeScript type checking
- Ensures code follows standards

#### c. Run Tests
- Executes all unit and integration tests
- Generates coverage reports
- Uploads coverage to Codecov (optional)

#### d. Build Application
- Builds production bundle
- Validates build succeeds
- Uploads build artifacts

### 2. Staging Deployment

**Workflow File**: `.github/workflows/deploy-staging.yml`

**Triggers**:
- Push to `develop` branch
- Manual workflow dispatch

**Features**:
- Runs tests before deployment
- Deploys to Vercel staging environment
- Comments PR with deployment URL
- Sends Slack notifications

### 3. Production Deployment

**Workflow File**: `.github/workflows/deploy-production.yml`

**Triggers**:
- Push to `main` branch
- Manual workflow dispatch

**Features**:
- Full environment validation
- Test coverage requirements
- Production build
- Creates GitHub release
- Deployment notifications

## Setup Instructions

### 1. Required GitHub Secrets

Add these secrets in GitHub repository settings:

```
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
VERCEL_TOKEN=your_vercel_token
VERCEL_ORG_ID=your_vercel_org_id
VERCEL_PROJECT_ID=your_vercel_project_id
SLACK_WEBHOOK=your_slack_webhook_url (optional)
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Run Tests Locally

```bash
# Run all tests
npm test

# Run tests in watch mode
npm run test:watch

# Run tests with coverage
npm run test:coverage

# Open test UI
npm run test:ui
```

### 4. Validate Environment

```bash
npm run validate-env
```

### 5. Type Check

```bash
npm run type-check
```

## Writing Tests

### Test Structure

Tests are located in `src/components/__tests__/` directory.

Example test:

```typescript
import { describe, it, expect, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import { MyComponent } from '../MyComponent';

describe('MyComponent', () => {
  it('renders correctly', () => {
    render(<MyComponent />);
    expect(screen.getByText('Hello')).toBeInTheDocument();
  });
});
```

### Testing Best Practices

1. **Test user behavior**, not implementation
2. **Use semantic queries** (getByRole, getByLabelText)
3. **Mock external dependencies** (API calls, context)
4. **Test edge cases** and error states
5. **Keep tests simple** and focused

## Deployment Notifications

### Slack Integration

Configure Slack webhook to receive deployment notifications:

1. Create Slack webhook URL
2. Add to GitHub secrets as `SLACK_WEBHOOK`
3. Notifications include:
   - Deployment status (success/failure)
   - Deployment URL
   - Commit information

### PR Comments

Staging deployments automatically comment on PRs with:
- Deployment URL
- Build status
- Preview link

## Environment Validation

The `validate-env.js` script checks:

**Required Variables**:
- `VITE_SUPABASE_URL` - Must be valid URL
- `VITE_SUPABASE_ANON_KEY` - Must be set

**Optional Variables**:
- `VITE_STRIPE_PUBLISHABLE_KEY`
- `VITE_VAPID_PUBLIC_KEY`

## Troubleshooting

### Tests Failing Locally

```bash
# Clear cache and reinstall
rm -rf node_modules package-lock.json
npm install

# Run tests with verbose output
npm run test -- --reporter=verbose
```

### Environment Validation Fails

```bash
# Check .env file exists
cp .env.example .env

# Edit .env with your values
nano .env

# Test validation
npm run validate-env
```

### Build Fails in CI

1. Check GitHub Actions logs
2. Verify all secrets are set
3. Test build locally: `npm run build`
4. Check for TypeScript errors: `npm run type-check`

## Coverage Requirements

- Minimum coverage: 80% (configurable)
- Coverage reports generated in `coverage/` directory
- View HTML report: `open coverage/index.html`

## Manual Deployment

Trigger manual deployment from GitHub Actions:

1. Go to Actions tab
2. Select workflow (Staging or Production)
3. Click "Run workflow"
4. Select branch
5. Click "Run workflow" button

## Monitoring

### Build Status Badge

Add to README.md:

```markdown
![CI](https://github.com/your-username/your-repo/workflows/CI%20Pipeline/badge.svg)
```

### Coverage Badge

Add Codecov badge (if configured):

```markdown
[![codecov](https://codecov.io/gh/your-username/your-repo/branch/main/graph/badge.svg)](https://codecov.io/gh/your-username/your-repo)
```
