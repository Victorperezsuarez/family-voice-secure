import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useRoleCheck } from '@/hooks/useRoleCheck';
import { RetentionManagementView } from '@/components/retention/RetentionManagementView';
import { Loader2 } from 'lucide-react';

export default function RetentionManagement() {
  const navigate = useNavigate();
  const { hasRole, loading } = useRoleCheck(['admin']);

  useEffect(() => {
    if (!loading && !hasRole) {
      navigate('/unauthorized');
    }
  }, [hasRole, loading, navigate]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  if (!hasRole) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto py-8 px-4">
        <RetentionManagementView />
      </div>
    </div>
  );
}
