import { useState, useEffect } from 'react';
import { Users, FolderTree, HardDrive, Activity, Download, FileText, Shield, Archive, Award } from 'lucide-react';

import { useNavigate } from 'react-router-dom';

import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { MetricCard } from '@/components/admin/MetricCard';
import { UserGrowthChart } from '@/components/admin/UserGrowthChart';
import { StorageUsageChart } from '@/components/admin/StorageUsageChart';
import { PopularFeaturesTable } from '@/components/admin/PopularFeaturesTable';
import { SystemHealthMonitor } from '@/components/admin/SystemHealthMonitor';
import { StripeConfigPanel } from '@/components/admin/StripeConfigPanel';

import { exportToCSV, exportToPDF } from '@/utils/exportUtils';
import { useAuth } from '@/contexts/AuthContext';
import { useRoleCheck } from '@/hooks/useRoleCheck';
import { supabase } from '@/lib/supabase-client';
import { Navigate } from 'react-router-dom';
import { Alert, AlertDescription } from '@/components/ui/alert';

export default function AdminDashboard() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { hasRole, loading: roleLoading } = useRoleCheck('admin');

  const [loading, setLoading] = useState(true);
  const [metrics, setMetrics] = useState({
    totalUsers: 0,
    totalFamilies: 0,
    totalStorage: 0,
    activeUsers: 0,
  });

  const [growthData] = useState([
    { date: 'Jan', users: 120, families: 45 },
    { date: 'Feb', users: 180, families: 68 },
    { date: 'Mar', users: 250, families: 92 },
    { date: 'Apr', users: 340, families: 125 },
    { date: 'May', users: 450, families: 168 },
    { date: 'Jun', users: 580, families: 215 },
  ]);

  const [storageData] = useState([
    { category: 'Audio', size: 45.2 },
    { category: 'Photos', size: 128.7 },
    { category: 'Videos', size: 89.3 },
    { category: 'Documents', size: 12.8 },
  ]);

  const [features] = useState([
    { name: 'Audio Recording', usage: 3420, trend: 'up' as const },
    { name: 'Photo Upload', usage: 2890, trend: 'up' as const },
    { name: 'Family Tree', usage: 1560, trend: 'stable' as const },
    { name: 'Timeline View', usage: 1240, trend: 'up' as const },
    { name: 'AI Transcription', usage: 980, trend: 'down' as const },
  ]);

  const [systemMetrics] = useState([
    { name: 'API Response Time', value: 85, status: 'healthy' as const, icon: Activity },
    { name: 'Database Performance', value: 92, status: 'healthy' as const, icon: Activity },
    { name: 'Storage Capacity', value: 68, status: 'warning' as const, icon: HardDrive },
    { name: 'Server Load', value: 45, status: 'healthy' as const, icon: Activity },
  ]);

  useEffect(() => {
    fetchMetrics();
  }, []);

  const fetchMetrics = async () => {
    try {
      const [usersRes, familiesRes] = await Promise.all([
        supabase.from('profiles').select('id', { count: 'exact' }),
        supabase.from('families').select('id', { count: 'exact' }),
      ]);

      setMetrics({
        totalUsers: usersRes.count || 0,
        totalFamilies: familiesRes.count || 0,
        totalStorage: 276,
        activeUsers: Math.floor((usersRes.count || 0) * 0.65),
      });
    } catch (error) {
      console.error('Error fetching metrics:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleExportCSV = () => {
    exportToCSV(features, 'popular_features');
  };

  const handleExportPDF = () => {
    exportToPDF('Admin Analytics Report', features, 'analytics_report');
  };

  // Check authentication and role
  if (!user) {
    return <Navigate to="/auth" replace />;
  }

  if (roleLoading || loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <Activity className="h-8 w-8 animate-spin mx-auto mb-4" />
          <p>Loading dashboard...</p>
        </div>
      </div>
    );
  }

  if (!hasRole) {
    return <Navigate to="/unauthorized" replace />;
  }


  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-4xl font-bold">Admin Analytics</h1>
          <p className="text-muted-foreground mt-2">Comprehensive platform insights and metrics</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => navigate('/admin/audit-logs')} variant="outline">
            <Shield className="w-4 h-4 mr-2" />
            Audit Logs
          </Button>
          <Button onClick={() => navigate('/admin/retention')} variant="outline">
            <Archive className="w-4 h-4 mr-2" />
            Retention
          </Button>
          <Button onClick={() => navigate('/admin/compliance')} variant="outline">
            <Award className="w-4 h-4 mr-2" />
            Compliance
          </Button>

          <Button onClick={handleExportCSV} variant="outline">
            <FileText className="w-4 h-4 mr-2" />
            Export CSV
          </Button>
          <Button onClick={handleExportPDF}>
            <Download className="w-4 h-4 mr-2" />
            Export PDF
          </Button>
        </div>
      </div>


      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard title="Total Users" value={metrics.totalUsers} change={12.5} icon={Users} iconColor="text-blue-600" />
        <MetricCard title="Total Families" value={metrics.totalFamilies} change={8.3} icon={FolderTree} iconColor="text-green-600" />
        <MetricCard title="Storage Used" value={`${metrics.totalStorage} GB`} change={15.2} icon={HardDrive} iconColor="text-orange-600" />
        <MetricCard title="Active Users" value={metrics.activeUsers} change={-2.1} icon={Activity} iconColor="text-purple-600" />
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="features">Features</TabsTrigger>
          <TabsTrigger value="system">System Health</TabsTrigger>
          <TabsTrigger value="stripe">Stripe Config</TabsTrigger>
        </TabsList>


        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <UserGrowthChart data={growthData} />
            <StorageUsageChart data={storageData} />
          </div>
        </TabsContent>

        <TabsContent value="features">
          <PopularFeaturesTable features={features} />
        </TabsContent>

        <TabsContent value="system">
          <SystemHealthMonitor metrics={systemMetrics} />
        </TabsContent>

        <TabsContent value="stripe">
          <StripeConfigPanel />
        </TabsContent>

      </Tabs>
    </div>
  );
}
