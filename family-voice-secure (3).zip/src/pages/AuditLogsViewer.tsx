import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase-client';
import { AuditLog, AuditLogFilters } from '@/types/audit';
import { Download, FileDown } from 'lucide-react';
import { format } from 'date-fns';
import { useNavigate } from 'react-router-dom';
import { useRoleCheck } from '@/hooks/useRoleCheck';

export default function AuditLogsViewer() {
  const navigate = useNavigate();
  const { hasRole, loading: roleLoading } = useRoleCheck(['admin']);
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState<AuditLogFilters>({
    startDate: null, endDate: null, userId: null, actionCategory: null,
    actionType: null, status: null, severity: null, searchTerm: ''
  });

  useEffect(() => {
    if (!roleLoading && !hasRole) {
      navigate('/unauthorized');
    }
  }, [hasRole, roleLoading, navigate]);

  useEffect(() => {
    if (hasRole) fetchLogs();
  }, [filters, hasRole]);

  const fetchLogs = async () => {
    setLoading(true);
    let query = supabase.from('audit_logs').select('*').order('created_at', { ascending: false }).limit(200);
    if (filters.startDate) query = query.gte('created_at', filters.startDate);
    if (filters.endDate) query = query.lte('created_at', filters.endDate);
    if (filters.actionCategory) query = query.eq('action_category', filters.actionCategory);
    if (filters.status) query = query.eq('status', filters.status);
    if (filters.severity) query = query.eq('severity', filters.severity);
    const { data } = await query;
    if (data) setLogs(data.filter(log => !filters.searchTerm || 
      log.description.toLowerCase().includes(filters.searchTerm.toLowerCase()) ||
      log.user_email?.toLowerCase().includes(filters.searchTerm.toLowerCase())
    ));
    setLoading(false);
  };

  const exportCSV = () => {
    const csv = [['Timestamp', 'User', 'Action', 'Category', 'Status', 'Severity', 'Description'].join(','),
      ...logs.map(l => [l.created_at, l.user_email || 'System', l.action_type, l.action_category, l.status, l.severity, `"${l.description}"`].join(','))
    ].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `audit-logs-${format(new Date(), 'yyyy-MM-dd')}.csv`;
    a.click();
  };

  if (roleLoading || !hasRole) return null;

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Audit Logs</h1>
        <Button onClick={exportCSV}><Download className="h-4 w-4 mr-2" />Export CSV</Button>
      </div>

      <Card>
        <CardHeader><CardTitle>Filters</CardTitle></CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Select value={filters.actionCategory || ''} onValueChange={(v) => setFilters({...filters, actionCategory: v || null})}>
              <SelectTrigger><SelectValue placeholder="Category" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="">All</SelectItem>
                <SelectItem value="role_change">Role Changes</SelectItem>
                <SelectItem value="user_action">User Actions</SelectItem>
                <SelectItem value="system_event">System Events</SelectItem>
                <SelectItem value="data_access">Data Access</SelectItem>
                <SelectItem value="security">Security</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filters.status || ''} onValueChange={(v) => setFilters({...filters, status: v || null})}>
              <SelectTrigger><SelectValue placeholder="Status" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="">All</SelectItem>
                <SelectItem value="success">Success</SelectItem>
                <SelectItem value="failure">Failure</SelectItem>
                <SelectItem value="warning">Warning</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filters.severity || ''} onValueChange={(v) => setFilters({...filters, severity: v || null})}>
              <SelectTrigger><SelectValue placeholder="Severity" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="">All</SelectItem>
                <SelectItem value="info">Info</SelectItem>
                <SelectItem value="warning">Warning</SelectItem>
                <SelectItem value="error">Error</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
              </SelectContent>
            </Select>
            <Input placeholder="Search..." value={filters.searchTerm} onChange={(e) => setFilters({...filters, searchTerm: e.target.value})} />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Logs ({logs.length})</CardTitle></CardHeader>
        <CardContent>
          {loading ? <div className="text-center py-8">Loading...</div> : logs.length === 0 ? <div className="text-center py-8">No logs found</div> : (
            <div className="space-y-2">
              {logs.map(log => (
                <div key={log.id} className="border rounded-lg p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <Badge variant={log.severity === 'critical' || log.severity === 'error' ? 'destructive' : 'secondary'}>{log.severity}</Badge>
                        <Badge variant="outline">{log.action_category}</Badge>
                        <span className="text-sm text-muted-foreground">{format(new Date(log.created_at), 'MMM dd, yyyy HH:mm:ss')}</span>
                      </div>
                      <p className="font-medium">{log.description}</p>
                      <p className="text-sm text-muted-foreground">By: {log.user_email || 'System'} • {log.action_type}</p>
                      {log.ip_address && <p className="text-xs text-muted-foreground">IP: {log.ip_address}</p>}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
