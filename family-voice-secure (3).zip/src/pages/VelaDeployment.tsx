import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { CheckCircle2, XCircle, Loader2, Database, Server, Zap, Users, Mic2, Brain, Shield, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function VelaDeployment() {
  const navigate = useNavigate();
  const [systemStatus, setSystemStatus] = useState({
    database: 'checking',
    api: 'checking',
    ai: 'checking',
    storage: 'checking'
  });

  useEffect(() => {
    checkSystemHealth();
  }, []);

  const checkSystemHealth = async () => {
    // Simulate health checks
    setTimeout(() => {
      setSystemStatus({
        database: 'healthy',
        api: 'healthy',
        ai: 'healthy',
        storage: 'healthy'
      });
    }, 1500);
  };

  const StatusIcon = ({ status }: { status: string }) => {
    if (status === 'checking') return <Loader2 className="w-5 h-5 animate-spin text-blue-500" />;
    if (status === 'healthy') return <CheckCircle2 className="w-5 h-5 text-green-500" />;
    return <XCircle className="w-5 h-5 text-red-500" />;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-orange-50 to-yellow-50 p-8">
      <div className="max-w-6xl mx-auto">
        <Button variant="ghost" onClick={() => navigate('/dashboard')} className="mb-6">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Volver al Dashboard
        </Button>

        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-amber-500 rounded-full mb-4">
            <Mic2 className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl font-bold text-amber-900 mb-4">Vela AI Deployed</h1>
          <p className="text-xl text-gray-600">Sistema de Preservación de Memorias Familiares</p>
          <Badge className="mt-4 bg-green-500 text-white text-lg px-4 py-2">
            <CheckCircle2 className="w-5 h-5 mr-2" />
            Sistema Activo
          </Badge>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="w-5 h-5" />
                Base de Datos
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <span className="text-gray-600">Estado de Conexión</span>
                <StatusIcon status={systemStatus.database} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Server className="w-5 h-5" />
                API Services
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <span className="text-gray-600">Estado del Servidor</span>
                <StatusIcon status={systemStatus.api} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="w-5 h-5" />
                AI Engine
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <span className="text-gray-600">Transcripción & Análisis</span>
                <StatusIcon status={systemStatus.ai} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5" />
                Storage
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <span className="text-gray-600">Almacenamiento de Audio</span>
                <StatusIcon status={systemStatus.storage} />
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Características Desplegadas</CardTitle>
            <CardDescription>Todas las funcionalidades están activas</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-4">
              {[
                'Grabación de Audio HD',
                'Transcripción Automática',
                'Búsqueda Semántica',
                'Gestión de Familias',
                'Árbol Genealógico',
                'Colecciones Inteligentes',
                'Recordatorios Personalizados',
                'Gestión de Privacidad',
                'Sincronización Offline',
                'Control por Voz',
                'Generación de Audiolibros',
                'Backup Automático'
              ].map((feature, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-500 flex-shrink-0" />
                  <span className="text-sm">{feature}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <div className="text-center">
          <Button size="lg" onClick={() => navigate('/dashboard')} className="bg-amber-500 hover:bg-amber-600">
            <Zap className="w-5 h-5 mr-2" />
            Comenzar a Usar Vela
          </Button>
        </div>
      </div>
    </div>
  );
}
