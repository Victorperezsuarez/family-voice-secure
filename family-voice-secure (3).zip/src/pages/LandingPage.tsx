import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowRight, Mic, Users, Shield, Sparkles, Menu, X } from 'lucide-react';

const LandingPage: React.FC = () => {
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    setMobileMenuOpen(false);
  };

  const features = [
    {
      icon: Mic,
      title: 'Voice Recording',
      description: 'Capture family stories with crystal-clear audio quality and AI-powered transcription.',
      image: 'https://d64gsuwffb70l.cloudfront.net/69010a7a5325e92f2828d404_1763052089047_cb93d124.webp'
    },
    {
      icon: Users,
      title: 'Family Tree',
      description: 'Build and visualize your family connections with an interactive genealogy tree.',
      image: 'https://d64gsuwffb70l.cloudfront.net/69010a7a5325e92f2828d404_1763052093888_741c4623.webp'
    },
    {
      icon: Shield,
      title: 'Secure Storage',
      description: 'Enterprise-grade encryption keeps your precious memories safe and private forever.',
      image: 'https://d64gsuwffb70l.cloudfront.net/69010a7a5325e92f2828d404_1763052097789_75d34e8d.webp'
    },
    {
      icon: Sparkles,
      title: 'AI Insights',
      description: 'Discover patterns, generate timelines, and unlock stories with intelligent analysis.',
      image: 'https://d64gsuwffb70l.cloudfront.net/69010a7a5325e92f2828d404_1763052102467_d2b9d4ef.webp'
    }
  ];

  const testimonials = [
    {
      name: 'Sarah Mitchell',
      role: 'Family Historian',
      image: 'https://d64gsuwffb70l.cloudfront.net/69010a7a5325e92f2828d404_1763052107009_42526c14.webp',
      quote: 'This app helped me preserve my grandmother\'s stories before it was too late. Priceless!'
    },
    {
      name: 'David Chen',
      role: 'Genealogy Enthusiast',
      image: 'https://d64gsuwffb70l.cloudfront.net/69010a7a5325e92f2828d404_1763052108964_b8849274.webp',
      quote: 'The AI transcription is incredibly accurate. I\'ve documented 50+ hours of family history.'
    },
    {
      name: 'Maria Rodriguez',
      role: 'Mother of Three',
      image: 'https://d64gsuwffb70l.cloudfront.net/69010a7a5325e92f2828d404_1763052110859_85f0dfe4.webp',
      quote: 'My kids will have their great-grandparents\' voices forever. This is a gift beyond measure.'
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-white/95 backdrop-blur-sm border-b z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <Mic className="h-8 w-8 text-purple-600" />
              <span className="text-xl font-bold text-gray-900">Family Voice Secure</span>
            </div>
            
            {/* Desktop Nav */}
            <div className="hidden md:flex items-center space-x-8">
              <button onClick={() => scrollToSection('features')} className="text-gray-600 hover:text-purple-600 transition">Features</button>
              <button onClick={() => navigate('/pricing')} className="text-gray-600 hover:text-purple-600 transition">Pricing</button>
              <button onClick={() => scrollToSection('testimonials')} className="text-gray-600 hover:text-purple-600 transition">Testimonials</button>
              <Button variant="outline" onClick={() => navigate('/dashboard')}>Sign In</Button>
              <Button onClick={() => navigate('/dashboard')} className="bg-purple-600 hover:bg-purple-700">
                Get Started <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>

            {/* Mobile Menu Button */}
            <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="md:hidden">
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t bg-white">
            <div className="px-4 py-4 space-y-3">
              <button onClick={() => scrollToSection('features')} className="block w-full text-left py-2 text-gray-600">Features</button>
              <button onClick={() => navigate('/pricing')} className="block w-full text-left py-2 text-gray-600">Pricing</button>
              <button onClick={() => scrollToSection('testimonials')} className="block w-full text-left py-2 text-gray-600">Testimonials</button>
              <Button variant="outline" onClick={() => navigate('/dashboard')} className="w-full">Sign In</Button>
              <Button onClick={() => navigate('/dashboard')} className="w-full bg-purple-600 hover:bg-purple-700">Get Started</Button>
            </div>
          </div>
        )}

      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-purple-50 via-blue-50 to-pink-50">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-5xl md:text-6xl font-bold text-gray-900 leading-tight mb-6">
                Preserve Your Family's <span className="text-purple-600">Voice</span> Forever
              </h1>
              <p className="text-xl text-gray-600 mb-8">
                Record, transcribe, and cherish the stories that matter most. AI-powered tools help you capture and organize your family's legacy for generations to come.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button onClick={() => navigate('/dashboard')} size="lg" className="bg-purple-600 hover:bg-purple-700 text-lg px-8">
                  Start Recording Free <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
                <Button onClick={() => scrollToSection('features')} variant="outline" size="lg" className="text-lg px-8">
                  Learn More
                </Button>
              </div>
              <p className="text-sm text-gray-500 mt-4">No credit card required • Free forever plan</p>
            </div>
            <div className="relative">
              <img 
                src="https://d64gsuwffb70l.cloudfront.net/69010a7a5325e92f2828d404_1763052083418_870fe67c.webp" 
                alt="Family recording memories" 
                className="rounded-2xl shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Everything You Need to Preserve Memories</h2>
            <p className="text-xl text-gray-600">Powerful features designed for families who value their heritage</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="border-2 hover:border-purple-300 hover:shadow-lg transition cursor-pointer" onClick={() => navigate('/dashboard')}>
                <CardContent className="p-6">
                  <img src={feature.image} alt={feature.title} className="w-full h-48 object-cover rounded-lg mb-4" />
                  <feature.icon className="h-10 w-10 text-purple-600 mb-4" />
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Loved by Families Worldwide</h2>
            <p className="text-xl text-gray-600">Join thousands preserving their family stories</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="bg-white">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <img src={testimonial.image} alt={testimonial.name} className="w-16 h-16 rounded-full mr-4" />
                    <div>
                      <h4 className="font-bold text-gray-900">{testimonial.name}</h4>
                      <p className="text-sm text-gray-600">{testimonial.role}</p>
                    </div>
                  </div>
                  <p className="text-gray-700 italic">"{testimonial.quote}"</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-purple-600 to-blue-600">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-white mb-6">Ready to Start Your Family's Story?</h2>
          <p className="text-xl text-purple-100 mb-8">Join thousands of families preserving their legacy today</p>
          <Button onClick={() => navigate('/dashboard')} size="lg" className="bg-white text-purple-600 hover:bg-gray-100 text-lg px-8">
            Get Started Free <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto grid md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <Mic className="h-6 w-6 text-purple-400" />
              <span className="text-lg font-bold text-white">Family Voice Secure</span>
            </div>
            <p className="text-sm">Preserving family stories for generations to come.</p>
          </div>
          <div>
            <h3 className="font-bold text-white mb-4">Product</h3>
            <ul className="space-y-2 text-sm">
              <li><button onClick={() => scrollToSection('features')} className="hover:text-purple-400">Features</button></li>
              <li><button onClick={() => navigate('/pricing')} className="hover:text-purple-400">Pricing</button></li>

              <li><button onClick={() => navigate('/dashboard')} className="hover:text-purple-400">Security</button></li>
            </ul>
          </div>
          <div>
            <h3 className="font-bold text-white mb-4">Company</h3>
            <ul className="space-y-2 text-sm">
              <li><button onClick={() => navigate('/dashboard')} className="hover:text-purple-400">About</button></li>
              <li><button onClick={() => navigate('/dashboard')} className="hover:text-purple-400">Blog</button></li>
              <li><button onClick={() => navigate('/dashboard')} className="hover:text-purple-400">Contact</button></li>
            </ul>
          </div>
          <div>
            <h3 className="font-bold text-white mb-4">Legal</h3>
            <ul className="space-y-2 text-sm">
              <li><button onClick={() => navigate('/dashboard')} className="hover:text-purple-400">Privacy</button></li>
              <li><button onClick={() => navigate('/dashboard')} className="hover:text-purple-400">Terms</button></li>
              <li><button onClick={() => navigate('/dashboard')} className="hover:text-purple-400">Cookie Policy</button></li>
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto mt-8 pt-8 border-t border-gray-800 text-center text-sm">
          <p>&copy; 2025 Family Voice Secure. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
