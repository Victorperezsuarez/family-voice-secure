import { useState } from 'react';
import { ArrowLeft, Mic, Camera, Bell, Wifi, WifiOff, Video, Library } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { MobileRecordingInterface } from '@/components/MobileRecordingInterface';
import { QuickVoiceMemo } from '@/components/QuickVoiceMemo';
import { MobilePhotoIntegration } from '@/components/MobilePhotoIntegration';
import { ReminderPushNotifications } from '@/components/ReminderPushNotifications';
import { MobileBottomNavigation } from '@/components/MobileBottomNavigation';
import { OfflineIndicator } from '@/components/OfflineIndicator';
import { VideoRecorder } from '@/components/VideoRecorder';
import { VideoEditor } from '@/components/VideoEditor';
import { VideoLibrary } from '@/components/VideoLibrary';
import { isOnline } from '@/utils/pwaUtils';
import { useNavigate } from 'react-router-dom';


export default function MobileVela() {
  const [activeTab, setActiveTab] = useState('quick');
  const [online, setOnline] = useState(isOnline());
  const [showVideoRecorder, setShowVideoRecorder] = useState(false);
  const [videoToEdit, setVideoToEdit] = useState<Blob | null>(null);
  const [savedVideos, setSavedVideos] = useState<Array<{ blob: Blob; metadata: any }>>([]);
  const navigate = useNavigate();

  const handleSaveVideo = (blob: Blob, metadata: any) => {
    setSavedVideos([...savedVideos, { blob, metadata }]);
    setShowVideoRecorder(false);
    setVideoToEdit(null);
  };

  const handleEditVideo = (blob: Blob) => {
    setVideoToEdit(blob);
    setShowVideoRecorder(false);
  };


  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 pb-20">
      <div className="sticky top-0 z-40 bg-white/80 backdrop-blur-lg border-b">
        <div className="flex items-center justify-between p-4">
          <Button variant="ghost" size="sm" onClick={() => navigate('/dashboard')}>
            <ArrowLeft className="w-4 h-4 mr-2" />Back
          </Button>
          <h1 className="text-xl font-bold">Mobile Vela</h1>
          <div className="flex items-center gap-2">
            {online ? <Wifi className="w-5 h-5 text-green-600" /> : <WifiOff className="w-5 h-5 text-red-600" />}
          </div>
        </div>
      </div>

      <OfflineIndicator />

      <div className="p-4 space-y-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="quick">Quick</TabsTrigger>
            <TabsTrigger value="record">Record</TabsTrigger>
            <TabsTrigger value="library">Library</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>


          <TabsContent value="quick" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Mic className="w-5 h-5" />
                  Quick Voice Memo
                </CardTitle>
              </CardHeader>
              <CardContent>
                <QuickVoiceMemo />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Video className="w-5 h-5" />
                  Video Recording
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Button 
                  onClick={() => setShowVideoRecorder(true)} 
                  className="w-full bg-gradient-to-r from-red-600 to-pink-600 hover:from-red-700 hover:to-pink-700"
                >
                  <Video className="w-4 h-4 mr-2" />
                  Start Video Recording
                </Button>
                {savedVideos.length > 0 && (
                  <div className="mt-4">
                    <p className="text-sm text-gray-600 mb-2">Saved Videos: {savedVideos.length}</p>
                    <div className="grid grid-cols-2 gap-2">
                      {savedVideos.slice(-4).map((video, idx) => (
                        <div key={idx} className="aspect-video bg-gray-200 rounded-lg flex items-center justify-center">
                          <Video className="w-8 h-8 text-gray-400" />
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Camera className="w-5 h-5" />
                  Photo Integration
                </CardTitle>
              </CardHeader>
              <CardContent>
                <MobilePhotoIntegration />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="record">
            <MobileRecordingInterface />
          </TabsContent>

          <TabsContent value="library" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Library className="w-5 h-5" />
                  Video Library
                </CardTitle>
              </CardHeader>
              <CardContent>
                <VideoLibrary />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-4">
            <ReminderPushNotifications />
          </TabsContent>
        </Tabs>
      </div>

      <MobileBottomNavigation activeTab="record" onTabChange={(tab) => {
        if (tab === 'dashboard') navigate('/dashboard');
        else if (tab === 'record') setActiveTab('quick');
      }} />

      {showVideoRecorder && (
        <VideoRecorder
          onSave={handleSaveVideo}
          onEdit={handleEditVideo}
          onClose={() => setShowVideoRecorder(false)}
        />
      )}

      {videoToEdit && (
        <VideoEditor
          videoBlob={videoToEdit}
          onSave={(blob) => {
            handleSaveVideo(blob, { edited: true });
          }}
          onClose={() => setVideoToEdit(null)}
        />
      )}
    </div>
  );
}

