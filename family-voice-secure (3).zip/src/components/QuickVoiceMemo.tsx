import { useState, useRef, useEffect } from 'react';
import { Mic, StopCircle, Save, X, Volume2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { saveOfflineRecording, isOnline } from '@/utils/pwaUtils';
import { toast } from 'sonner';

const haptic = (type: 'light' | 'medium' | 'heavy' = 'medium') => {
  if ('vibrate' in navigator) {
    navigator.vibrate(type === 'light' ? 10 : type === 'medium' ? 20 : 30);
  }
};

export function QuickVoiceMemo() {
  const [isRecording, setIsRecording] = useState(false);
  const [duration, setDuration] = useState(0);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => () => { if (timerRef.current) clearInterval(timerRef.current); }, []);

  const startRecording = async () => {
    haptic('heavy');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;
      chunksRef.current = [];

      recorder.ondataavailable = (e) => { if (e.data.size > 0) chunksRef.current.push(e.data); };
      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        setAudioUrl(URL.createObjectURL(blob));
        stream.getTracks().forEach(t => t.stop());
      };

      recorder.start();
      setIsRecording(true);
      timerRef.current = setInterval(() => setDuration(p => p + 1), 1000);
    } catch (err) {
      toast.error('Microphone access denied');
      haptic('heavy');
    }
  };

  const stopRecording = () => {
    haptic('medium');
    mediaRecorderRef.current?.stop();
    setIsRecording(false);
    if (timerRef.current) clearInterval(timerRef.current);
  };

  const save = () => {
    if (audioUrl) {
      const recording = { url: audioUrl, type: 'audio', duration, createdAt: new Date().toISOString() };
      isOnline() ? toast.success('Saved!') : saveOfflineRecording(recording);
      reset();
    }
  };

  const reset = () => { setAudioUrl(null); setDuration(0); setIsRecording(false); };

  return (
    <div className="flex flex-col items-center gap-4 p-6 bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl">
      <div className="text-3xl font-mono font-bold">{Math.floor(duration/60)}:{(duration%60).toString().padStart(2,'0')}</div>
      {!isRecording && !audioUrl && (
        <Button size="lg" className="w-20 h-20 rounded-full" onClick={startRecording}>
          <Mic className="w-8 h-8" />
        </Button>
      )}
      {isRecording && (
        <Button size="lg" variant="destructive" className="w-20 h-20 rounded-full animate-pulse" onClick={stopRecording}>
          <StopCircle className="w-8 h-8" />
        </Button>
      )}
      {audioUrl && (
        <div className="flex gap-3">
          <Button variant="outline" size="lg" onClick={reset}><X className="w-5 h-5" /></Button>
          <Button size="lg" onClick={save}><Save className="w-5 h-5 mr-2" />Save</Button>
        </div>
      )}
    </div>
  );
}
