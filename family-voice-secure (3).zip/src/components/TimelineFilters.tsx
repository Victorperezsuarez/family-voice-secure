import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { FamilyMember } from '@/types/family';

interface TimelineFiltersProps {
  familyMembers: FamilyMember[];
  selectedMember: string;
  selectedYear: string;
  selectedEventType: string;
  onMemberChange: (value: string) => void;
  onYearChange: (value: string) => void;
  onEventTypeChange: (value: string) => void;
  years: string[];
}

export function TimelineFilters({
  familyMembers,
  selectedMember,
  selectedYear,
  selectedEventType,
  onMemberChange,
  onYearChange,
  onEventTypeChange,
  years
}: TimelineFiltersProps) {
  return (
    <div className="flex flex-wrap gap-4 mb-6">
      <div className="flex-1 min-w-[200px]">
        <Select value={selectedMember} onValueChange={onMemberChange}>
          <SelectTrigger>
            <SelectValue placeholder="All Family Members" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Family Members</SelectItem>
            {familyMembers.map(member => (
              <SelectItem key={member.id} value={member.id}>{member.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="flex-1 min-w-[200px]">
        <Select value={selectedYear} onValueChange={onYearChange}>
          <SelectTrigger>
            <SelectValue placeholder="All Years" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Years</SelectItem>
            {years.map(year => (
              <SelectItem key={year} value={year}>{year}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="flex-1 min-w-[200px]">
        <Select value={selectedEventType} onValueChange={onEventTypeChange}>
          <SelectTrigger>
            <SelectValue placeholder="All Event Types" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Event Types</SelectItem>
            <SelectItem value="recording">Recordings</SelectItem>
            <SelectItem value="milestone">Milestones</SelectItem>
            <SelectItem value="birthday">Birthdays</SelectItem>
            <SelectItem value="anniversary">Anniversaries</SelectItem>
            <SelectItem value="achievement">Achievements</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}
