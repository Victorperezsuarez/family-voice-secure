import { useOfflineSync } from '@/contexts/OfflineSyncContext';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { CloudOff, RefreshCw, WifiOff } from 'lucide-react';
import { cn } from '@/lib/utils';

export function OfflineSyncBanner() {
  const { isOnline, syncStats, retrySync } = useOfflineSync();

  if (isOnline && syncStats.pending === 0 && syncStats.failed === 0) {
    return null;
  }

  return (
    <Alert className={cn(
      'mb-4',
      !isOnline ? 'border-amber-500 bg-amber-50' : 'border-blue-500 bg-blue-50'
    )}>
      {!isOnline ? (
        <WifiOff className="h-4 w-4 text-amber-600" />
      ) : (
        <CloudOff className="h-4 w-4 text-blue-600" />
      )}
      <AlertDescription className="flex items-center justify-between">
        <div>
          {!isOnline ? (
            <span>You're offline. Changes will sync automatically when connection is restored.</span>
          ) : (
            <span>
              {syncStats.pending > 0 && `${syncStats.pending} items waiting to sync. `}
              {syncStats.failed > 0 && `${syncStats.failed} items failed to sync.`}
            </span>
          )}
        </div>
        {isOnline && (syncStats.pending > 0 || syncStats.failed > 0) && (
          <Button size="sm" variant="outline" onClick={retrySync}>
            <RefreshCw className="h-3.5 w-3.5 mr-1.5" />
            Sync Now
          </Button>
        )}
      </AlertDescription>
    </Alert>
  );
}
