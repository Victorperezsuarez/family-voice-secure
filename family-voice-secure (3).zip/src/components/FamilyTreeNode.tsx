import { FamilyMember } from '@/types/familyTree';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card } from '@/components/ui/card';
import { Mic } from 'lucide-react';

interface FamilyTreeNodeProps {
  member: FamilyMember;
  x: number;
  y: number;
  isSelected: boolean;
  onClick: () => void;
}

export function FamilyTreeNode({ member, x, y, isSelected, onClick }: FamilyTreeNodeProps) {
  return (
    <div
      className="absolute cursor-pointer transition-transform hover:scale-105"
      style={{ left: `${x}px`, top: `${y}px`, transform: 'translate(-50%, -50%)' }}
      onClick={onClick}
    >
      <Card className={`p-3 w-32 ${isSelected ? 'ring-2 ring-primary' : ''}`}>
        <div className="flex flex-col items-center gap-2">
          <Avatar className="h-16 w-16">
            <AvatarImage src={member.photoUrl} alt={member.name} />
            <AvatarFallback>{member.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
          </Avatar>
          <div className="text-center">
            <p className="text-xs font-medium truncate w-full">{member.name}</p>
            {member.birthDate && (
              <p className="text-xs text-muted-foreground">
                {new Date(member.birthDate).getFullYear()}
              </p>
            )}
          </div>
          {member.recordingCount > 0 && (
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <Mic className="h-3 w-3" />
              <span>{member.recordingCount}</span>
            </div>
          )}
        </div>
      </Card>
    </div>
  );
}
