import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/lib/supabase-client';
import { PersonaInsights, VelaPersona } from '@/types/vela';
import { Brain, TrendingUp, MessageSquare, Star, Heart, Lightbulb } from 'lucide-react';

interface VelaPersonaInsightsProps {
  persona: VelaPersona;
}

export function VelaPersonaInsights({ persona }: VelaPersonaInsightsProps) {
  const [insights, setInsights] = useState<PersonaInsights | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadInsights();
  }, [persona.id]);

  const loadInsights = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Fetch conversation stats
      const { data: conversations } = await supabase
        .from('vela_conversations')
        .select('*')
        .eq('persona_id', persona.id)
        .eq('user_id', user.id);

      // Fetch topics
      const { data: topics } = await supabase
        .from('vela_conversation_topics')
        .select('*')
        .eq('persona_id', persona.id)
        .order('frequency', { ascending: false })
        .limit(5);

      // Fetch learned knowledge
      const { data: knowledge } = await supabase
        .from('vela_learned_knowledge')
        .select('*')
        .eq('persona_id', persona.id);

      // Calculate insights
      const totalConversations = conversations?.length || 0;
      const rated = conversations?.filter(c => c.user_rating) || [];
      const avgRating = rated.length > 0
        ? rated.reduce((sum, c) => sum + (c.user_rating || 0), 0) / rated.length
        : 0;

      const sentimentCounts = {
        positive: conversations?.filter(c => c.sentiment === 'positive').length || 0,
        neutral: conversations?.filter(c => c.sentiment === 'neutral').length || 0,
        negative: conversations?.filter(c => c.sentiment === 'negative').length || 0
      };

      const mostHelpful = conversations
        ?.filter(c => c.user_rating && c.user_rating >= 4)
        .sort((a, b) => (b.user_rating || 0) - (a.user_rating || 0))
        .slice(0, 3)
        .map(c => ({
          question: c.message,
          response: c.response,
          rating: c.user_rating || 0
        })) || [];

      setInsights({
        totalConversations,
        avgRating,
        topTopics: topics?.map(t => ({ topic: t.topic, frequency: t.frequency })) || [],
        learnedFAQs: knowledge?.filter(k => k.knowledge_type === 'faq').length || 0,
        learnedPreferences: knowledge?.filter(k => k.knowledge_type === 'preference').length || 0,
        learnedPatterns: knowledge?.filter(k => k.knowledge_type === 'pattern').length || 0,
        sentimentDistribution: sentimentCounts,
        mostHelpfulResponses: mostHelpful
      });
    } catch (error) {
      console.error('Error loading insights:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="text-center py-8">Loading insights...</div>;
  }

  if (!insights) {
    return <div className="text-center py-8">No insights available yet</div>;
  }

  const totalSentiment = insights.sentimentDistribution.positive + 
    insights.sentimentDistribution.neutral + 
    insights.sentimentDistribution.negative;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Conversations</CardTitle>
            <MessageSquare className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{insights.totalConversations}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Average Rating</CardTitle>
            <Star className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{insights.avgRating.toFixed(1)}/5</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Knowledge Learned</CardTitle>
            <Brain className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {insights.learnedFAQs + insights.learnedPreferences + insights.learnedPatterns}
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="topics" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="topics">Topics</TabsTrigger>
          <TabsTrigger value="knowledge">Knowledge</TabsTrigger>
          <TabsTrigger value="sentiment">Sentiment</TabsTrigger>
          <TabsTrigger value="helpful">Top Responses</TabsTrigger>
        </TabsList>

        <TabsContent value="topics" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Most Discussed Topics
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {insights.topTopics.length > 0 ? (
                insights.topTopics.map((topic, idx) => (
                  <div key={idx} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="font-medium">{topic.topic}</span>
                      <Badge variant="secondary">{topic.frequency} times</Badge>
                    </div>
                    <Progress value={(topic.frequency / insights.totalConversations) * 100} />
                  </div>
                ))
              ) : (
                <p className="text-muted-foreground">No topics tracked yet</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="knowledge" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">FAQs Learned</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{insights.learnedFAQs}</div>
                <p className="text-xs text-muted-foreground mt-1">Frequently asked questions</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Preferences</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{insights.learnedPreferences}</div>
                <p className="text-xs text-muted-foreground mt-1">User preferences learned</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Patterns</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{insights.learnedPatterns}</div>
                <p className="text-xs text-muted-foreground mt-1">Behavioral patterns identified</p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="sentiment" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Heart className="h-5 w-5" />
                Conversation Sentiment
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-green-600 font-medium">Positive</span>
                  <span>{insights.sentimentDistribution.positive}</span>
                </div>
                <Progress 
                  value={(insights.sentimentDistribution.positive / totalSentiment) * 100} 
                  className="bg-green-100"
                />
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600 font-medium">Neutral</span>
                  <span>{insights.sentimentDistribution.neutral}</span>
                </div>
                <Progress 
                  value={(insights.sentimentDistribution.neutral / totalSentiment) * 100}
                  className="bg-gray-100"
                />
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-red-600 font-medium">Negative</span>
                  <span>{insights.sentimentDistribution.negative}</span>
                </div>
                <Progress 
                  value={(insights.sentimentDistribution.negative / totalSentiment) * 100}
                  className="bg-red-100"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="helpful" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lightbulb className="h-5 w-5" />
                Most Helpful Responses
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {insights.mostHelpfulResponses.length > 0 ? (
                insights.mostHelpfulResponses.map((item, idx) => (
                  <div key={idx} className="border-l-4 border-primary pl-4 py-2 space-y-2">
                    <div className="flex items-center gap-2">
                      <Badge variant="default">{item.rating} stars</Badge>
                    </div>
                    <p className="font-medium text-sm">{item.question}</p>
                    <p className="text-sm text-muted-foreground line-clamp-2">{item.response}</p>
                  </div>
                ))
              ) : (
                <p className="text-muted-foreground">No rated responses yet</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}