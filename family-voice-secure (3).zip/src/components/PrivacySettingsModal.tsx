import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Checkbox } from '@/components/ui/checkbox';
import { Switch } from '@/components/ui/switch';
import { VisibilityLevel } from '@/types/privacy';
import { FamilyMember } from '@/types/family';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onSave: (settings: PrivacySettings) => void;
  familyMembers: FamilyMember[];
  currentSettings?: PrivacySettings;
}

export interface PrivacySettings {
  visibility: VisibilityLevel;
  allowed_members: string[];
  requires_approval: boolean;
}

export default function PrivacySettingsModal({ isOpen, onClose, onSave, familyMembers, currentSettings }: Props) {
  const [visibility, setVisibility] = useState<VisibilityLevel>(currentSettings?.visibility || 'family');
  const [allowedMembers, setAllowedMembers] = useState<string[]>(currentSettings?.allowed_members || []);
  const [requiresApproval, setRequiresApproval] = useState(currentSettings?.requires_approval || false);

  const handleSave = () => {
    onSave({ visibility, allowed_members: allowedMembers, requires_approval: requiresApproval });
    onClose();
  };

  const toggleMember = (memberId: string) => {
    setAllowedMembers(prev => 
      prev.includes(memberId) ? prev.filter(id => id !== memberId) : [...prev, memberId]
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Privacy Settings</DialogTitle>
        </DialogHeader>
        <div className="space-y-6">
          <div>
            <Label className="text-sm font-medium mb-3 block">Who can view this recording?</Label>
            <RadioGroup value={visibility} onValueChange={(v) => setVisibility(v as VisibilityLevel)}>
              <div className="flex items-center space-x-2 mb-2">
                <RadioGroupItem value="private" id="private" />
                <Label htmlFor="private" className="cursor-pointer">Private (only me)</Label>
              </div>
              <div className="flex items-center space-x-2 mb-2">
                <RadioGroupItem value="family" id="family" />
                <Label htmlFor="family" className="cursor-pointer">All family members</Label>
              </div>
              <div className="flex items-center space-x-2 mb-2">
                <RadioGroupItem value="specific" id="specific" />
                <Label htmlFor="specific" className="cursor-pointer">Specific members</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="public" id="public" />
                <Label htmlFor="public" className="cursor-pointer">Public (anyone with link)</Label>
              </div>
            </RadioGroup>
          </div>

          {visibility === 'specific' && (
            <div>
              <Label className="text-sm font-medium mb-3 block">Select family members</Label>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {familyMembers.map(member => (
                  <div key={member.id} className="flex items-center space-x-2">
                    <Checkbox 
                      checked={allowedMembers.includes(member.id)}
                      onCheckedChange={() => toggleMember(member.id)}
                    />
                    <Label className="cursor-pointer">{member.name}</Label>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="flex items-center justify-between">
            <Label htmlFor="approval">Require approval before sharing</Label>
            <Switch checked={requiresApproval} onCheckedChange={setRequiresApproval} id="approval" />
          </div>

          <div className="flex gap-2 justify-end">
            <Button variant="outline" onClick={onClose}>Cancel</Button>
            <Button onClick={handleSave}>Save Settings</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
