import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase-client';
import { RecordingWithMember, Milestone, FamilyMember } from '@/types/family';
import { TimelineFilters } from './TimelineFilters';
import { TimelineItem } from './TimelineItem';
import { AddMilestoneModal } from './AddMilestoneModal';
import { PhotoGallery } from './PhotoGallery';
import { Button } from '@/components/ui/button';
import { Plus, Image as ImageIcon, Sparkles, BookOpen } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AIStoryGenerator } from './AIStoryGenerator';
import { AIStoryTimeline } from './AIStoryTimeline';



interface TimelineViewProps {
  familyId: string;
}

export function TimelineView({ familyId }: TimelineViewProps) {
  const [recordings, setRecordings] = useState<RecordingWithMember[]>([]);
  const [milestones, setMilestones] = useState<Milestone[]>([]);
  const [familyMembers, setFamilyMembers] = useState<FamilyMember[]>([]);
  const [photos, setPhotos] = useState<any[]>([]);
  const [selectedMember, setSelectedMember] = useState('all');
  const [selectedYear, setSelectedYear] = useState('all');
  const [selectedEventType, setSelectedEventType] = useState('all');
  const [showAddMilestone, setShowAddMilestone] = useState(false);
  const [showPhotos, setShowPhotos] = useState(false);
  const { toast } = useToast();


  useEffect(() => {
    loadData();
  }, [familyId]);

  const loadData = async () => {
    const { data: recordingsData } = await supabase
      .from('recordings')
      .select('*, family_member:family_members(*)')
      .eq('family_id', familyId)
      .order('created_at', { ascending: false });

    const { data: milestonesData } = await supabase
      .from('milestones')
      .eq('family_id', familyId)
      .order('date', { ascending: false });

    const { data: membersData } = await supabase
      .from('family_members')
      .eq('family_id', familyId);

    const { data: photosData } = await supabase
      .from('photos')
      .select('*')
      .eq('family_id', familyId)
      .order('created_at', { ascending: false });

    if (recordingsData) setRecordings(recordingsData as RecordingWithMember[]);
    if (milestonesData) setMilestones(milestonesData);
    if (membersData) setFamilyMembers(membersData);
    if (photosData) setPhotos(photosData);
  };


  const handleAddMilestone = async (milestone: any) => {
    const { data: { user } } = await supabase.auth.getUser();
    const { error } = await supabase.from('milestones').insert({
      ...milestone,
      family_id: familyId,
      created_by: user?.id
    });

    if (error) {
      toast({ title: 'Error', description: 'Failed to add milestone', variant: 'destructive' });
    } else {
      toast({ title: 'Success', description: 'Milestone added' });
      loadData();
    }
  };

  const filteredItems = [...recordings.map(r => ({ ...r, type: 'recording' as const })), 
    ...milestones.map(m => ({ ...m, type: 'milestone' as const }))]
    .filter(item => {
      if (selectedMember !== 'all' && item.type === 'recording' && item.member_id !== selectedMember) return false;
      if (selectedYear !== 'all') {
        const year = new Date(item.type === 'recording' ? item.created_at : item.date).getFullYear().toString();
        if (year !== selectedYear) return false;
      }
      if (selectedEventType !== 'all') {
        if (selectedEventType === 'recording' && item.type !== 'recording') return false;
        if (selectedEventType !== 'recording' && (item.type !== 'milestone' || item.event_type !== selectedEventType)) return false;
      }
      return true;
    })
    .sort((a, b) => new Date(b.type === 'recording' ? b.created_at : b.date).getTime() - 
      new Date(a.type === 'recording' ? a.created_at : a.date).getTime());

  const years = Array.from(new Set([...recordings.map(r => new Date(r.created_at).getFullYear().toString()),
    ...milestones.map(m => new Date(m.date).getFullYear().toString())])).sort().reverse();

  return (
    <div>
      <Tabs defaultValue="timeline" className="w-full">
        <TabsList className="mb-6">
          <TabsTrigger value="timeline">Timeline</TabsTrigger>
          <TabsTrigger value="ai-story">
            <Sparkles className="w-4 h-4 mr-2" />
            AI Story
          </TabsTrigger>
          <TabsTrigger value="ai-timeline">
            <BookOpen className="w-4 h-4 mr-2" />
            AI Timeline
          </TabsTrigger>
        </TabsList>

        <TabsContent value="timeline">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">Family Timeline</h2>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setShowPhotos(!showPhotos)}>
                <ImageIcon className="w-4 h-4 mr-2" />
                {showPhotos ? 'Hide Photos' : 'Show Photos'}
              </Button>
              <Button onClick={() => setShowAddMilestone(true)}>
                <Plus className="w-4 h-4 mr-2" />Add Milestone
              </Button>
            </div>
          </div>
          
          {showPhotos && photos.length > 0 && (
            <div className="mb-8 bg-white rounded-lg shadow p-6">
              <h3 className="text-xl font-semibold mb-4">Family Photos ({photos.length})</h3>
              <PhotoGallery photos={photos} onDelete={(id) => {
                setPhotos(photos.filter(p => p.id !== id));
              }} editable />
            </div>
          )}

          <TimelineFilters familyMembers={familyMembers} selectedMember={selectedMember} selectedYear={selectedYear}
            selectedEventType={selectedEventType} onMemberChange={setSelectedMember} onYearChange={setSelectedYear}
            onEventTypeChange={setSelectedEventType} years={years} />
          <div className="mt-8">
            {filteredItems.map(item => (
              <TimelineItem key={item.id} item={item} type={item.type} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="ai-story">
          <AIStoryGenerator 
            recordings={recordings.filter(r => r.transcription)} 
            familyName="Family"
          />
        </TabsContent>

        <TabsContent value="ai-timeline">
          <AIStoryTimeline familyId={familyId} />
        </TabsContent>
      </Tabs>

      <AddMilestoneModal open={showAddMilestone} onClose={() => setShowAddMilestone(false)} onAdd={handleAddMilestone} />
    </div>
  );
}
