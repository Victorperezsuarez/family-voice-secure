import { useState } from 'react';
import { supabase } from '@/lib/supabase-client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { VELA_PROFESSIONS } from '@/types/vela';
import { toast } from 'sonner';

interface VelaPersonaCreatorProps {
  onSuccess: () => void;
  onCancel: () => void;
}

export function VelaPersonaCreator({ onSuccess, onCancel }: VelaPersonaCreatorProps) {
  const [name, setName] = useState('');
  const [category, setCategory] = useState<'house' | 'work' | 'custom'>('house');
  const [profession, setProfession] = useState('');
  const [description, setDescription] = useState('');
  const [creating, setCreating] = useState(false);

  const handleCreate = async () => {
    if (!name.trim()) {
      toast.error('Please enter a name');
      return;
    }

    setCreating(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const professionData = profession ? VELA_PROFESSIONS[profession as keyof typeof VELA_PROFESSIONS] : null;
      
      const promptTemplate = generatePromptTemplate(category, profession, professionData);

      const { error } = await supabase
        .from('vela_personas')
        .insert({
          user_id: user.id,
          name,
          category,
          profession: profession || null,
          description: description || `Your ${category === 'house' ? 'home' : 'work'} assistant`,
          personality_traits: professionData ? { tone: professionData.tone } : {},
          expertise_areas: professionData?.expertise || [],
          voice_tone: professionData?.tone || 'friendly',
          prompt_template: promptTemplate,
          is_active: false
        });

      if (error) throw error;

      toast.success('Vela persona created successfully');
      onSuccess();
    } catch (error) {
      console.error('Error creating persona:', error);
      toast.error('Failed to create persona');
    } finally {
      setCreating(false);
    }
  };

  const generatePromptTemplate = (cat: string, prof: string, profData: any) => {
    if (cat === 'house') {
      return 'You are Vela House, a helpful home assistant. Help with family matters, home organization, meal planning, and daily household tasks. Be warm, supportive, and family-focused.';
    }
    if (cat === 'work' && profData) {
      return `You are Vela Work ${profData.name}, a professional ${prof} assistant. Your expertise includes ${profData.expertise.join(', ')}. Provide ${profData.tone} guidance and support.`;
    }
    return 'You are Vela, a helpful AI assistant. Provide clear, accurate, and helpful responses.';
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Create Vela Persona</CardTitle>
        <CardDescription>Configure a new Vela persona for specific contexts</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="name">Persona Name</Label>
          <Input
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g., Vela House, Vela Work Teacher"
          />
        </div>

        <div>
          <Label htmlFor="category">Category</Label>
          <Select value={category} onValueChange={(v: any) => setCategory(v)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="house">🏠 House (Home & Family)</SelectItem>
              <SelectItem value="work">💼 Work (Professional)</SelectItem>
              <SelectItem value="custom">⚙️ Custom</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {category === 'work' && (
          <div>
            <Label htmlFor="profession">Profession</Label>
            <Select value={profession} onValueChange={setProfession}>
              <SelectTrigger>
                <SelectValue placeholder="Select profession" />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(VELA_PROFESSIONS).map(([key, value]) => (
                  <SelectItem key={key} value={key}>
                    {value.icon} {value.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        <div>
          <Label htmlFor="description">Description</Label>
          <Textarea
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe this persona's role and purpose"
            rows={3}
          />
        </div>

        <div className="flex gap-2">
          <Button onClick={handleCreate} disabled={creating} className="flex-1">
            {creating ? 'Creating...' : 'Create Persona'}
          </Button>
          <Button onClick={onCancel} variant="outline">
            Cancel
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
