import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Play, Share2 } from 'lucide-react';

interface Highlight {
  text: string;
  timestamp: number;
  significance: string;
}

interface StoryHighlightsPanelProps {
  highlights: Highlight[];
  onSeekTo: (time: number) => void;
  onShare?: (highlight: Highlight) => void;
}

export function StoryHighlightsPanel({ highlights, onSeekTo, onShare }: StoryHighlightsPanelProps) {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <Card className="p-4">
      <div className="flex items-center gap-2 mb-4">
        <Sparkles className="h-5 w-5 text-yellow-500" />
        <h3 className="text-lg font-semibold">Story Highlights</h3>
      </div>
      <div className="space-y-4">
        {highlights.map((highlight, index) => (
          <div
            key={index}
            className="p-4 rounded-lg bg-gradient-to-br from-yellow-50 to-orange-50 dark:from-yellow-950/20 dark:to-orange-950/20 border border-yellow-200 dark:border-yellow-800"
          >
            <div className="flex items-start gap-3">
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium mb-2 italic">"{highlight.text}"</p>
                <Badge variant="secondary" className="text-xs mb-2">
                  {highlight.significance}
                </Badge>
                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => onSeekTo(highlight.timestamp)}
                    className="text-xs"
                  >
                    <Play className="h-3 w-3 mr-1" />
                    {formatTime(highlight.timestamp)}
                  </Button>
                  {onShare && (
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => onShare(highlight)}
                      className="text-xs"
                    >
                      <Share2 className="h-3 w-3" />
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}