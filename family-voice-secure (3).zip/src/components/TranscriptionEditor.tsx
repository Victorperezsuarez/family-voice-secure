import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Pencil, Loader2, Users, MessageSquare, History, Tag, AlertTriangle } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';
import CollaborativeTranscriptionEditor from './CollaborativeTranscriptionEditor';
import CommentThread from './CommentThread';
import VersionHistoryPanel from './VersionHistoryPanel';
import { ConflictHistoryPanel } from './ConflictHistoryPanel';

interface TranscriptionEditorProps {
  recordingId: string;
  initialTranscription: string | null;
  transcriptionStatus: string;
  onUpdate: (transcription: string) => void;
}

export function TranscriptionEditor({ 
  recordingId, 
  initialTranscription, 
  transcriptionStatus,
  onUpdate 
}: TranscriptionEditorProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [transcription, setTranscription] = useState(initialTranscription || '');
  const [activeTab, setActiveTab] = useState('edit');

  const handleSave = async (content: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      // Get current version number
      const { data: versions } = await supabase
        .from('transcription_versions')
        .select('version_number')
        .eq('recording_id', recordingId)
        .order('version_number', { ascending: false })
        .limit(1);

      const nextVersion = versions && versions.length > 0 ? versions[0].version_number + 1 : 1;

      // Save new version
      await supabase.from('transcription_versions').insert({
        recording_id: recordingId,
        version_number: nextVersion,
        content,
        edited_by: user.id,
        change_summary: 'Manual edit'
      });

      // Update recording
      const { error } = await supabase
        .from('recordings')
        .update({ 
          transcription: content,
          transcription_status: 'completed'
        })
        .eq('id', recordingId);

      if (error) throw error;

      // Generate embedding
      await supabase.functions.invoke('generate-embedding', {
        body: { recordingId, text: content }
      });

      setTranscription(content);
      onUpdate(content);
      toast.success('Transcription updated');
    } catch (error) {
      console.error('Error saving transcription:', error);
      throw error;
    }
  };

  const handleRestore = async (content: string) => {
    await handleSave(content);
    setActiveTab('edit');
  };

  const handlePreview = (content: string) => {
    setTranscription(content);
  };

  if (transcriptionStatus === 'processing') {
    return (
      <div className="bg-blue-50 p-4 rounded-lg">
        <div className="flex items-center gap-2 text-blue-700">
          <Loader2 className="w-4 h-4 animate-spin" />
          <span className="text-sm">Transcribing audio...</span>
        </div>
      </div>
    );
  }

  if (transcriptionStatus === 'failed') {
    return (
      <div className="bg-red-50 p-4 rounded-lg">
        <p className="text-sm text-red-700">Transcription failed</p>
      </div>
    );
  }

  if (!transcription && transcriptionStatus !== 'completed') {
    return (
      <div className="bg-gray-50 p-4 rounded-lg">
        <p className="text-sm text-gray-600">No transcription available</p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <h4 className="font-semibold text-gray-900">Transcription</h4>
        <Button onClick={() => setIsEditing(true)} variant="ghost" size="sm">
          <Users className="w-4 h-4 mr-2" />
          Collaborate
        </Button>
      </div>

      <p className="text-sm text-gray-700 bg-gray-50 p-4 rounded-lg whitespace-pre-wrap max-h-[200px] overflow-y-auto">
        {transcription}
      </p>

      <Dialog open={isEditing} onOpenChange={setIsEditing}>
        <DialogContent className="max-w-4xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle>Collaborative Editing</DialogTitle>
          </DialogHeader>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList>
              <TabsTrigger value="edit">
                <Pencil className="h-4 w-4 mr-2" />
                Edit
              </TabsTrigger>
              <TabsTrigger value="comments">
                <MessageSquare className="h-4 w-4 mr-2" />
                Comments
              </TabsTrigger>
              <TabsTrigger value="history">
                <History className="h-4 w-4 mr-2" />
                History
              </TabsTrigger>
              <TabsTrigger value="conflicts">
                <AlertTriangle className="h-4 w-4 mr-2" />
                Conflicts
              </TabsTrigger>
            </TabsList>

            <TabsContent value="edit" className="mt-4">
              <CollaborativeTranscriptionEditor
                recordingId={recordingId}
                initialTranscription={transcription}
                onSave={handleSave}
                onShowVersionHistory={() => setActiveTab('history')}
                onShowComments={() => setActiveTab('comments')}
                onShowTags={() => {}}
                onShowConflictHistory={() => setActiveTab('conflicts')}
              />
            </TabsContent>
            <TabsContent value="comments" className="mt-4">
              <CommentThread recordingId={recordingId} />
            </TabsContent>
            <TabsContent value="history" className="mt-4">
              <VersionHistoryPanel
                recordingId={recordingId}
                onRestore={handleRestore}
                onPreview={handlePreview}
              />
            </TabsContent>
            <TabsContent value="conflicts" className="mt-4">
              <ConflictHistoryPanel
                recordingId={recordingId}
                onViewConflict={(conflictId) => {
                  // Load and show conflict in resolution dialog
                  console.log('View conflict:', conflictId);
                }}
              />
            </TabsContent>
          </Tabs>

        </DialogContent>
      </Dialog>
    </div>
  );
}

