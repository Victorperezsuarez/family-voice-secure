import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Upload, X, CheckCircle, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { useToast } from '@/hooks/use-toast';

interface UploadItem {
  file: File;
  status: 'pending' | 'uploading' | 'success' | 'error';
  progress: number;
  photoId?: string;
  error?: string;
}

export function BulkPhotoUploader({ familyId, onComplete }: { familyId: string; onComplete: () => void }) {
  const [items, setItems] = useState<UploadItem[]>([]);
  const [uploading, setUploading] = useState(false);
  const { toast } = useToast();

  const handleFiles = (files: FileList) => {
    const newItems = Array.from(files).map(file => ({
      file,
      status: 'pending' as const,
      progress: 0
    }));
    setItems([...items, ...newItems]);
  };

  const uploadAll = async () => {
    setUploading(true);
    for (let i = 0; i < items.length; i++) {
      if (items[i].status !== 'pending') continue;
      
      try {
        setItems(prev => prev.map((item, idx) => 
          idx === i ? { ...item, status: 'uploading', progress: 0 } : item
        ));

        const fileName = `${familyId}/${Date.now()}-${items[i].file.name}`;
        const { data, error } = await supabase.storage
          .from('photos')
          .upload(fileName, items[i].file, {
            onUploadProgress: (progress) => {
              const percent = (progress.loaded / progress.total) * 100;
              setItems(prev => prev.map((item, idx) => 
                idx === i ? { ...item, progress: percent } : item
              ));
            }
          });

        if (error) throw error;

        const { data: { publicUrl } } = supabase.storage.from('photos').getPublicUrl(data.path);
        
        const { data: photo } = await supabase.from('photos').insert({
          family_id: familyId,
          photo_url: publicUrl,
          thumbnail_url: publicUrl
        }).select().single();

        // Extract metadata
        await supabase.functions.invoke('extract-photo-metadata', {
          body: { photoUrl: publicUrl, photoId: photo.id }
        });

        setItems(prev => prev.map((item, idx) => 
          idx === i ? { ...item, status: 'success', progress: 100, photoId: photo.id } : item
        ));
      } catch (error: any) {
        setItems(prev => prev.map((item, idx) => 
          idx === i ? { ...item, status: 'error', error: error.message } : item
        ));
      }
    }
    setUploading(false);
    toast({ title: 'Upload Complete', description: 'All photos uploaded' });
    onComplete();
  };

  const removeItem = (index: number) => {
    setItems(items.filter((_, i) => i !== index));
  };

  return (
    <div className="space-y-4">
      <div className="border-2 border-dashed rounded-lg p-8 text-center">
        <Upload className="h-12 w-12 mx-auto mb-4 text-gray-400" />
        <p className="mb-4">Drag and drop photos or click to browse</p>
        <Button onClick={() => document.getElementById('bulk-input')?.click()}>
          Choose Files
        </Button>
        <input
          id="bulk-input"
          type="file"
          accept="image/*"
          multiple
          className="hidden"
          onChange={(e) => e.target.files && handleFiles(e.target.files)}
        />
      </div>

      {items.length > 0 && (
        <div className="space-y-2">
          {items.map((item, idx) => (
            <div key={idx} className="flex items-center gap-3 p-3 border rounded-lg">
              {item.status === 'success' && <CheckCircle className="h-5 w-5 text-green-500" />}
              {item.status === 'error' && <AlertCircle className="h-5 w-5 text-red-500" />}
              <div className="flex-1">
                <p className="text-sm font-medium">{item.file.name}</p>
                {item.status === 'uploading' && <Progress value={item.progress} className="mt-1" />}
                {item.error && <p className="text-xs text-red-500">{item.error}</p>}
              </div>
              <Button variant="ghost" size="sm" onClick={() => removeItem(idx)}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          ))}
          <Button onClick={uploadAll} disabled={uploading} className="w-full">
            Upload All ({items.filter(i => i.status === 'pending').length})
          </Button>
        </div>
      )}
    </div>
  );
}
