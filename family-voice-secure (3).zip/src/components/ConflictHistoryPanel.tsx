import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { AlertTriangle, Check, Clock, GitMerge, User } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { formatDistanceToNow } from 'date-fns';

interface Conflict {
  id: string;
  conflictType: string;
  conflictRange: { start: number; end: number };
  resolved: boolean;
  resolutionType?: string;
  userA: { name: string; avatar?: string };
  userB: { name: string; avatar?: string };
  resolvedBy?: { name: string };
  createdAt: string;
  resolvedAt?: string;
}

interface ConflictHistoryPanelProps {
  recordingId: string;
  onViewConflict: (conflictId: string) => void;
}

export function ConflictHistoryPanel({ recordingId, onViewConflict }: ConflictHistoryPanelProps) {
  const [conflicts, setConflicts] = useState<Conflict[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'resolved' | 'unresolved'>('all');

  useEffect(() => {
    loadConflicts();

    const channel = supabase
      .channel(`conflicts:${recordingId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'transcription_conflicts',
          filter: `recording_id=eq.${recordingId}`,
        },
        () => {
          loadConflicts();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [recordingId]);

  const loadConflicts = async () => {
    try {
      const { data, error } = await supabase
        .from('transcription_conflicts')
        .select(`
          *,
          userA:user_a_id(full_name, avatar_url),
          userB:user_b_id(full_name, avatar_url),
          resolvedByUser:resolved_by(full_name)
        `)
        .eq('recording_id', recordingId)
        .order('created_at', { ascending: false });

      if (error) throw error;

      setConflicts(data?.map(c => ({
        id: c.id,
        conflictType: c.conflict_type,
        conflictRange: c.conflict_range,
        resolved: c.resolved,
        resolutionType: c.resolution_type,
        userA: { name: c.userA?.full_name || 'Unknown', avatar: c.userA?.avatar_url },
        userB: { name: c.userB?.full_name || 'Unknown', avatar: c.userB?.avatar_url },
        resolvedBy: c.resolvedByUser ? { name: c.resolvedByUser.full_name } : undefined,
        createdAt: c.created_at,
        resolvedAt: c.resolved_at,
      })) || []);
    } catch (error) {
      console.error('Error loading conflicts:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredConflicts = conflicts.filter(c => {
    if (filter === 'resolved') return c.resolved;
    if (filter === 'unresolved') return !c.resolved;
    return true;
  });

  const getResolutionIcon = (type?: string) => {
    switch (type) {
      case 'auto_merge': return <GitMerge className="h-4 w-4" />;
      case 'manual_merge': return <GitMerge className="h-4 w-4" />;
      default: return <Check className="h-4 w-4" />;
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Conflict History
          </span>
          <div className="flex gap-2">
            <Button
              variant={filter === 'all' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter('all')}
            >
              All ({conflicts.length})
            </Button>
            <Button
              variant={filter === 'unresolved' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter('unresolved')}
            >
              Unresolved ({conflicts.filter(c => !c.resolved).length})
            </Button>
            <Button
              variant={filter === 'resolved' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter('resolved')}
            >
              Resolved ({conflicts.filter(c => c.resolved).length})
            </Button>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[400px]">
          {loading ? (
            <p className="text-center text-muted-foreground py-8">Loading conflicts...</p>
          ) : filteredConflicts.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">No conflicts found</p>
          ) : (
            <div className="space-y-3">
              {filteredConflicts.map((conflict) => (
                <div
                  key={conflict.id}
                  className="p-4 border rounded-lg hover:bg-accent transition-colors cursor-pointer"
                  onClick={() => !conflict.resolved && onViewConflict(conflict.id)}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      {conflict.resolved ? (
                        <Check className="h-4 w-4 text-green-500" />
                      ) : (
                        <AlertTriangle className="h-4 w-4 text-amber-500" />
                      )}
                      <Badge variant={conflict.resolved ? 'secondary' : 'destructive'}>
                        {conflict.conflictType.replace('_', ' ')}
                      </Badge>
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {formatDistanceToNow(new Date(conflict.createdAt), { addSuffix: true })}
                    </span>
                  </div>

                  <div className="flex items-center gap-4 mb-2">
                    <div className="flex items-center gap-2">
                      <Avatar className="h-6 w-6">
                        <AvatarImage src={conflict.userA.avatar} />
                        <AvatarFallback><User className="h-3 w-3" /></AvatarFallback>
                      </Avatar>
                      <span className="text-sm">{conflict.userA.name}</span>
                    </div>
                    <span className="text-muted-foreground">vs</span>
                    <div className="flex items-center gap-2">
                      <Avatar className="h-6 w-6">
                        <AvatarImage src={conflict.userB.avatar} />
                        <AvatarFallback><User className="h-3 w-3" /></AvatarFallback>
                      </Avatar>
                      <span className="text-sm">{conflict.userB.name}</span>
                    </div>
                  </div>

                  {conflict.resolved && (
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      {getResolutionIcon(conflict.resolutionType)}
                      <span>
                        Resolved by {conflict.resolvedBy?.name} • {conflict.resolutionType?.replace('_', ' ')}
                      </span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
