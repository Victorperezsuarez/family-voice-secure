import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { RotateCw, Crop, Sparkles, Save, X } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface PhotoEditorProps {
  photoUrl: string;
  onSave: (editedUrl: string, edits: any) => void;
  onCancel: () => void;
}

export function PhotoEditor({ photoUrl, onSave, onCancel }: PhotoEditorProps) {
  const [rotation, setRotation] = useState(0);
  const [brightness, setBrightness] = useState(100);
  const [contrast, setContrast] = useState(100);
  const [saturation, setSaturation] = useState(100);
  const [filter, setFilter] = useState('none');

  const filters = [
    { name: 'none', label: 'Original' },
    { name: 'grayscale', label: 'B&W' },
    { name: 'sepia', label: 'Sepia' },
    { name: 'vintage', label: 'Vintage' },
    { name: 'cool', label: 'Cool' },
    { name: 'warm', label: 'Warm' }
  ];

  const getFilterStyle = () => {
    let filterStr = `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%)`;
    if (filter === 'grayscale') filterStr += ' grayscale(100%)';
    if (filter === 'sepia') filterStr += ' sepia(100%)';
    if (filter === 'vintage') filterStr += ' sepia(50%) contrast(120%)';
    if (filter === 'cool') filterStr += ' hue-rotate(180deg)';
    if (filter === 'warm') filterStr += ' hue-rotate(20deg)';
    return filterStr;
  };

  const handleSave = () => {
    const edits = { rotation, brightness, contrast, saturation, filter };
    onSave(photoUrl, edits);
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between p-4 border-b">
        <h3 className="text-lg font-semibold">Edit Photo</h3>
        <div className="flex gap-2">
          <Button onClick={handleSave} size="sm">
            <Save className="h-4 w-4 mr-2" />
            Save
          </Button>
          <Button onClick={onCancel} variant="ghost" size="sm">
            <X className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="flex-1 flex">
        <div className="flex-1 flex items-center justify-center bg-gray-100 p-8">
          <img
            src={photoUrl}
            alt="Edit"
            style={{
              transform: `rotate(${rotation}deg)`,
              filter: getFilterStyle(),
              maxWidth: '100%',
              maxHeight: '100%'
            }}
          />
        </div>

        <div className="w-80 border-l p-4 overflow-y-auto">
          <Tabs defaultValue="adjust">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="adjust">Adjust</TabsTrigger>
              <TabsTrigger value="filters">Filters</TabsTrigger>
              <TabsTrigger value="rotate">Rotate</TabsTrigger>
            </TabsList>

            <TabsContent value="adjust" className="space-y-6 mt-4">
              <div>
                <label className="text-sm font-medium">Brightness</label>
                <Slider value={[brightness]} onValueChange={([v]) => setBrightness(v)} min={0} max={200} />
              </div>
              <div>
                <label className="text-sm font-medium">Contrast</label>
                <Slider value={[contrast]} onValueChange={([v]) => setContrast(v)} min={0} max={200} />
              </div>
              <div>
                <label className="text-sm font-medium">Saturation</label>
                <Slider value={[saturation]} onValueChange={([v]) => setSaturation(v)} min={0} max={200} />
              </div>
            </TabsContent>

            <TabsContent value="filters" className="space-y-2 mt-4">
              {filters.map((f) => (
                <Button
                  key={f.name}
                  variant={filter === f.name ? 'default' : 'outline'}
                  className="w-full"
                  onClick={() => setFilter(f.name)}
                >
                  {f.label}
                </Button>
              ))}
            </TabsContent>

            <TabsContent value="rotate" className="space-y-4 mt-4">
              <Button className="w-full" onClick={() => setRotation((r) => (r + 90) % 360)}>
                <RotateCw className="h-4 w-4 mr-2" />
                Rotate 90°
              </Button>
              <div>
                <label className="text-sm font-medium">Custom Angle</label>
                <Slider value={[rotation]} onValueChange={([v]) => setRotation(v)} min={0} max={360} />
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
