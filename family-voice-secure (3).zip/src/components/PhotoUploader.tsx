import { useState, useCallback } from 'react';
import { Upload, X, Image as ImageIcon, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/supabase-client';
import { useToast } from '@/hooks/use-toast';

interface PhotoUploaderProps {
  onUploadComplete: (photoUrl: string, thumbnailUrl: string, metadata: any) => void;
  familyId: string;
  maxFiles?: number;
  accept?: string;
}

export function PhotoUploader({ onUploadComplete, familyId, maxFiles = 10, accept = 'image/*' }: PhotoUploaderProps) {
  const [uploading, setUploading] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [previews, setPreviews] = useState<string[]>([]);
  const { toast } = useToast();

  const compressImage = async (file: File): Promise<Blob> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;
          const maxDim = 1920;
          if (width > maxDim || height > maxDim) {
            if (width > height) {
              height = (height / width) * maxDim;
              width = maxDim;
            } else {
              width = (width / height) * maxDim;
              height = maxDim;
            }
          }
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d')!;
          ctx.drawImage(img, 0, 0, width, height);
          canvas.toBlob((blob) => resolve(blob!), 'image/jpeg', 0.85);
        };
        img.src = e.target?.result as string;
      };
      reader.readAsDataURL(file);
    });
  };

  const uploadPhoto = async (file: File) => {
    const compressed = await compressImage(file);
    const fileName = `${familyId}/${Date.now()}-${file.name}`;
    const { data, error } = await supabase.storage.from('photos').upload(fileName, compressed);
    if (error) throw error;
    const { data: { publicUrl } } = supabase.storage.from('photos').getPublicUrl(data.path);
    return { photoUrl: publicUrl, fileName: data.path };
  };

  const handleFiles = async (files: FileList) => {
    if (files.length > maxFiles) {
      toast({ title: 'Error', description: `Maximum ${maxFiles} files allowed`, variant: 'destructive' });
      return;
    }
    setUploading(true);
    try {
      for (const file of Array.from(files)) {
        const { photoUrl } = await uploadPhoto(file);
        const img = new Image();
        img.src = URL.createObjectURL(file);
        await new Promise(resolve => img.onload = resolve);
        onUploadComplete(photoUrl, photoUrl, { width: img.width, height: img.height, size: file.size });
      }
      toast({ title: 'Success', description: 'Photos uploaded successfully' });
    } catch (error: any) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    } finally {
      setUploading(false);
    }
  };

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') setDragActive(true);
    else if (e.type === 'dragleave') setDragActive(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) handleFiles(e.dataTransfer.files);
  }, []);

  return (
    <div
      className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
        dragActive ? 'border-blue-500 bg-blue-50' : 'border-gray-300'
      }`}
      onDragEnter={handleDrag}
      onDragLeave={handleDrag}
      onDragOver={handleDrag}
      onDrop={handleDrop}
    >
      {uploading ? (
        <div className="flex flex-col items-center gap-2">
          <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
          <p className="text-sm text-gray-600">Uploading photos...</p>
        </div>
      ) : (
        <>
          <ImageIcon className="h-12 w-12 mx-auto mb-4 text-gray-400" />
          <p className="text-lg font-medium mb-2">Drag and drop photos here</p>
          <p className="text-sm text-gray-500 mb-4">or</p>
          <Button onClick={() => document.getElementById('photo-input')?.click()}>
            <Upload className="h-4 w-4 mr-2" />
            Choose Files
          </Button>
          <input
            id="photo-input"
            type="file"
            accept={accept}
            multiple
            className="hidden"
            onChange={(e) => e.target.files && handleFiles(e.target.files)}
          />
        </>
      )}
    </div>
  );
}
