import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Sparkles, Loader2, RefreshCw } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { StoryChaptersView } from './StoryChaptersView';
import { StoryHighlightsPanel } from './StoryHighlightsPanel';
import { EmotionalToneAnalysis } from './EmotionalToneAnalysis';
import { StoryEntitiesPanel } from './StoryEntitiesPanel';
import { toast } from 'sonner';

interface AIStoryEnhancementPanelProps {
  recordingId: string;
  transcription: string;
  duration: number;
  currentTime: number;
  onSeekTo: (time: number) => void;
}

export function AIStoryEnhancementPanel({
  recordingId,
  transcription,
  duration,
  currentTime,
  onSeekTo
}: AIStoryEnhancementPanelProps) {
  const [analysis, setAnalysis] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const analyzeStory = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('analyze-story-content', {
        body: { transcription, duration, recordingId }
      });

      if (error) throw error;

      if (data.success) {
        setAnalysis(data.analysis);
        
        // Save analysis to recording
        await supabase
          .from('recordings')
          .update({
            ai_chapters: data.analysis.chapters,
            ai_highlights: data.analysis.highlights,
            ai_emotional_tone: data.analysis.emotionalTone,
            ai_entities: data.analysis.entities,
            ai_themes: data.analysis.themes,
            ai_tags: data.analysis.tags,
            ai_summary: data.analysis.summary
          })
          .eq('id', recordingId);

        toast.success('AI analysis complete!');
      }
    } catch (error: any) {
      toast.error('Failed to analyze story: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    // Load existing analysis
    const loadAnalysis = async () => {
      const { data } = await supabase
        .from('recordings')
        .select('ai_chapters, ai_highlights, ai_emotional_tone, ai_entities, ai_themes, ai_tags, ai_summary')
        .eq('id', recordingId)
        .single();

      if (data?.ai_chapters) {
        setAnalysis({
          chapters: data.ai_chapters,
          highlights: data.ai_highlights,
          emotionalTone: data.ai_emotional_tone,
          entities: data.ai_entities,
          themes: data.ai_themes,
          tags: data.ai_tags,
          summary: data.ai_summary
        });
      }
    };
    loadAnalysis();
  }, [recordingId]);

  if (!analysis && !loading) {
    return (
      <Card className="p-6 text-center">
        <Sparkles className="h-12 w-12 mx-auto mb-4 text-primary" />
        <h3 className="text-lg font-semibold mb-2">AI Story Enhancement</h3>
        <p className="text-sm text-muted-foreground mb-4">
          Unlock chapters, highlights, emotional analysis, and more
        </p>
        <Button onClick={analyzeStory} disabled={loading}>
          <Sparkles className="h-4 w-4 mr-2" />
          Analyze Story
        </Button>
      </Card>
    );
  }

  if (loading) {
    return (
      <Card className="p-6 text-center">
        <Loader2 className="h-8 w-8 mx-auto mb-4 animate-spin text-primary" />
        <p className="text-sm text-muted-foreground">Analyzing your story...</p>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <Card className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div>
            <h3 className="text-lg font-semibold mb-2">AI Story Insights</h3>
            <p className="text-sm text-muted-foreground">{analysis.summary}</p>
          </div>
          <Button size="sm" variant="outline" onClick={analyzeStory}>
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
        <div className="flex flex-wrap gap-2">
          {analysis.themes.map((theme: string, i: number) => (
            <Badge key={i} variant="secondary">{theme}</Badge>
          ))}
        </div>
      </Card>

      <Tabs defaultValue="chapters" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="chapters">Chapters</TabsTrigger>
          <TabsTrigger value="highlights">Highlights</TabsTrigger>
          <TabsTrigger value="emotions">Emotions</TabsTrigger>
          <TabsTrigger value="entities">Elements</TabsTrigger>
        </TabsList>
        <TabsContent value="chapters">
          <StoryChaptersView
            chapters={analysis.chapters}
            onSeekTo={onSeekTo}
            currentTime={currentTime}
          />
        </TabsContent>
        <TabsContent value="highlights">
          <StoryHighlightsPanel
            highlights={analysis.highlights}
            onSeekTo={onSeekTo}
          />
        </TabsContent>
        <TabsContent value="emotions">
          <EmotionalToneAnalysis
            emotionalTone={analysis.emotionalTone}
            onSeekTo={onSeekTo}
          />
        </TabsContent>
        <TabsContent value="entities">
          <StoryEntitiesPanel entities={analysis.entities} />
        </TabsContent>
      </Tabs>
    </div>
  );
}