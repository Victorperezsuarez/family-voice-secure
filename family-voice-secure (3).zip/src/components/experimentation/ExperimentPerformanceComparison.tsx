import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { TrendingUp, Award, AlertCircle } from 'lucide-react';
import { ExperimentResult } from '@/types/featureExperimentation';

interface ExperimentPerformanceComparisonProps {
  experimentId: string;
  results: ExperimentResult[];
  onPromoteConfig: (configId: string) => void;
}

export function ExperimentPerformanceComparison({ 
  experimentId, 
  results, 
  onPromoteConfig 
}: ExperimentPerformanceComparisonProps) {
  const groupedResults = results.reduce((acc, result) => {
    if (!acc[result.config_id]) {
      acc[result.config_id] = [];
    }
    acc[result.config_id].push(result);
    return acc;
  }, {} as Record<string, ExperimentResult[]>);

  const configStats = Object.entries(groupedResults).map(([configId, configResults]) => {
    const avgMetric = configResults.reduce((sum, r) => sum + r.metric_value, 0) / configResults.length;
    const totalSamples = configResults.reduce((sum, r) => sum + r.sample_size, 0);
    const hasSignificance = configResults.some(r => r.statistical_significance);
    
    return {
      configId,
      configName: configResults[0].config_id.includes('control') ? 'Control' : `Treatment ${configId.slice(-1)}`,
      avgMetric,
      totalSamples,
      hasSignificance,
      results: configResults
    };
  });

  const bestConfig = configStats.reduce((best, current) => 
    current.avgMetric > best.avgMetric ? current : best
  , configStats[0]);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {configStats.map((config) => {
          const isBest = config.configId === bestConfig?.configId;
          const isControl = config.configName === 'Control';
          const improvement = isControl ? 0 : ((config.avgMetric - configStats[0].avgMetric) / configStats[0].avgMetric) * 100;
          
          return (
            <Card key={config.configId} className={isBest ? 'border-green-500 border-2' : ''}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">{config.configName}</CardTitle>
                  {isBest && (
                    <Badge className="bg-green-500">
                      <Award className="h-3 w-3 mr-1" />
                      Winner
                    </Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div>
                    <div className="text-3xl font-bold">{config.avgMetric.toFixed(4)}</div>
                    <div className="text-sm text-muted-foreground">Average Metric</div>
                  </div>
                  
                  {!isControl && (
                    <div className="flex items-center gap-2">
                      <TrendingUp className={`h-4 w-4 ${improvement > 0 ? 'text-green-500' : 'text-red-500'}`} />
                      <span className={improvement > 0 ? 'text-green-500' : 'text-red-500'}>
                        {improvement > 0 ? '+' : ''}{improvement.toFixed(2)}%
                      </span>
                      <span className="text-sm text-muted-foreground">vs control</span>
                    </div>
                  )}
                  
                  <div className="text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Sample Size:</span>
                      <span className="font-medium">{config.totalSamples.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between mt-1">
                      <span className="text-muted-foreground">Significance:</span>
                      {config.hasSignificance ? (
                        <Badge variant="outline" className="text-green-600">Yes</Badge>
                      ) : (
                        <Badge variant="outline" className="text-gray-500">No</Badge>
                      )}
                    </div>
                  </div>
                  
                  {isBest && !isControl && config.hasSignificance && (
                    <Button 
                      onClick={() => onPromoteConfig(config.configId)} 
                      className="w-full mt-2"
                      size="sm"
                    >
                      Promote to Production
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
      
      {!bestConfig?.hasSignificance && (
        <Card className="border-yellow-500">
          <CardContent className="flex items-center gap-3 p-4">
            <AlertCircle className="h-5 w-5 text-yellow-500" />
            <div>
              <div className="font-medium">No Statistically Significant Results Yet</div>
              <div className="text-sm text-muted-foreground">
                Continue collecting data to reach statistical significance
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
