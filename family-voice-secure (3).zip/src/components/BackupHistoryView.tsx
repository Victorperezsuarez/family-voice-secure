import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Clock, Cloud, CheckCircle, XCircle, Download, RefreshCw } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { BackupHistory } from '@/types/backup';

interface BackupHistoryViewProps {
  familyId: string;
}

export function BackupHistoryView({ familyId }: BackupHistoryViewProps) {
  const [backups, setBackups] = useState<BackupHistory[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadBackupHistory();
  }, [familyId]);

  const loadBackupHistory = async () => {
    try {
      const { data, error } = await supabase
        .from('backup_history')
        .select('*')
        .eq('family_id', familyId)
        .order('created_at', { ascending: false })
        .limit(20);

      if (error) throw error;
      setBackups(data || []);
    } catch (error) {
      console.error('Error loading backup history:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB';
    if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
    return (bytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'failed': return <XCircle className="h-4 w-4 text-red-500" />;
      case 'in_progress': return <RefreshCw className="h-4 w-4 text-blue-500 animate-spin" />;
      default: return <Clock className="h-4 w-4 text-gray-500" />;
    }
  };

  if (loading) {
    return <div className="text-center py-8">Loading backup history...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Backup History</h3>
        <Button variant="outline" size="sm" onClick={loadBackupHistory}>
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh
        </Button>
      </div>
      {backups.length === 0 ? (
        <Card>
          <CardContent className="py-8 text-center text-muted-foreground">
            No backups yet. Configure automatic backups to get started.
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {backups.map((backup) => (
            <Card key={backup.id}>
              <CardContent className="py-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3 flex-1">
                    {getStatusIcon(backup.status)}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <Cloud className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium capitalize">{backup.provider.replace('_', ' ')}</span>
                        <Badge variant={backup.status === 'completed' ? 'default' : 'secondary'}>
                          {backup.status}
                        </Badge>
                      </div>
                      <div className="text-sm text-muted-foreground space-y-1">
                        <div>{backup.file_count} files • {formatFileSize(backup.file_size_bytes)}</div>
                        <div>{new Date(backup.created_at).toLocaleString()}</div>
                        {backup.backup_path && <div className="truncate">{backup.backup_path}</div>}
                        {backup.error_message && (
                          <div className="text-red-500">{backup.error_message}</div>
                        )}
                      </div>
                    </div>
                  </div>
                  {backup.status === 'completed' && (
                    <Button variant="ghost" size="sm">
                      <Download className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
