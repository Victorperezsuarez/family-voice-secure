import { useState, useRef, useEffect } from 'react';
import { Button } from './ui/button';
import { Video, Square, Pause, Play, X, SwitchCamera, Settings, Edit, Upload, Wifi, WifiOff } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Progress } from './ui/progress';
import { useVideoSync } from '@/hooks/useVideoSync';
import { toast } from 'sonner';

interface VideoRecorderProps {
  onSave: (videoBlob: Blob, metadata: VideoMetadata) => void;
  onEdit?: (videoBlob: Blob) => void;
  onClose: () => void;
}


interface VideoMetadata {
  duration: number;
  quality: string;
  orientation: 'portrait' | 'landscape';
  facingMode: 'user' | 'environment';
}

export function VideoRecorder({ onSave, onEdit, onClose }: VideoRecorderProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [recordedBlob, setRecordedBlob] = useState<Blob | null>(null);
  const [duration, setDuration] = useState(0);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('environment');
  const [quality, setQuality] = useState<'720p' | '1080p' | '4k'>('1080p');
  const [showSettings, setShowSettings] = useState(false);
  const [orientation, setOrientation] = useState<'portrait' | 'landscape'>('portrait');
  const [isUploading, setIsUploading] = useState(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const { uploadVideo, isOnline } = useVideoSync();


  useEffect(() => {
    startCamera();
    detectOrientation();
    window.addEventListener('orientationchange', detectOrientation);
    return () => {
      if (stream) stream.getTracks().forEach(track => track.stop());
      if (intervalRef.current) clearInterval(intervalRef.current);
      window.removeEventListener('orientationchange', detectOrientation);
    };
  }, [facingMode, quality]);

  const detectOrientation = () => {
    const isPortrait = window.innerHeight > window.innerWidth;
    setOrientation(isPortrait ? 'portrait' : 'landscape');
  };

  const getVideoConstraints = () => {
    const constraints: Record<string, any> = {
      '720p': { width: 1280, height: 720 },
      '1080p': { width: 1920, height: 1080 },
      '4k': { width: 3840, height: 2160 }
    };
    return { facingMode, ...constraints[quality] };
  };

  const startCamera = async () => {
    try {
      if (stream) stream.getTracks().forEach(track => track.stop());
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: getVideoConstraints(),
        audio: true
      });
      setStream(mediaStream);
      if (videoRef.current) videoRef.current.srcObject = mediaStream;
    } catch (err) {
      console.error('Camera access error:', err);
    }
  };

  const startRecording = () => {
    if (!stream) return;
    const mediaRecorder = new MediaRecorder(stream, { mimeType: 'video/webm;codecs=vp9' });
    mediaRecorderRef.current = mediaRecorder;
    const chunks: Blob[] = [];
    
    mediaRecorder.ondataavailable = (e) => {
      if (e.data.size > 0) chunks.push(e.data);
    };
    
    mediaRecorder.onstop = () => {
      const blob = new Blob(chunks, { type: 'video/webm' });
      setRecordedBlob(blob);
      saveToLocalStorage(blob);
    };
    
    mediaRecorder.start();
    setIsRecording(true);
    intervalRef.current = setInterval(() => setDuration(d => d + 1), 1000);
  };

  const saveToLocalStorage = async (blob: Blob) => {
    try {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        localStorage.setItem(`vela_video_${Date.now()}`, base64);
      };
      reader.readAsDataURL(blob);
    } catch (err) {
      console.error('Local storage error:', err);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      setIsPaused(false);
      if (intervalRef.current) clearInterval(intervalRef.current);
    }
  };

  const handleSave = async () => {
    if (recordedBlob) {
      const metadata: VideoMetadata = { duration, quality, orientation, facingMode };
      
      if (isOnline) {
        setIsUploading(true);
        try {
          await uploadVideo(recordedBlob, {
            title: `Video ${new Date().toLocaleString()}`,
            duration,
            quality,
            orientation
          });
          toast.success('Video uploaded to cloud');
        } catch (error) {
          toast.error('Upload failed, saved locally');
        } finally {
          setIsUploading(false);
        }
      }
      
      onSave(recordedBlob, metadata);
    }
  };

  const handleEdit = () => {
    if (recordedBlob && onEdit) {
      onEdit(recordedBlob);
    }
  };


  return (
    <div className="fixed inset-0 bg-black z-50 flex flex-col">
      <video ref={videoRef} autoPlay playsInline muted className="flex-1 object-cover" />
      
      <div className="absolute top-4 left-4 right-4 flex justify-between items-start">
        <div className="flex gap-2">
          <Button variant="ghost" size="icon" onClick={onClose} className="bg-black/50 text-white">
            <X className="h-6 w-6" />
          </Button>
          {isOnline ? (
            <div className="bg-green-600/80 text-white px-3 py-1 rounded-full text-sm flex items-center gap-1">
              <Wifi className="h-3 w-3" />
              Online
            </div>
          ) : (
            <div className="bg-orange-600/80 text-white px-3 py-1 rounded-full text-sm flex items-center gap-1">
              <WifiOff className="h-3 w-3" />
              Offline
            </div>
          )}
        </div>
        {isRecording && (
          <div className="bg-red-600 text-white px-4 py-2 rounded-full font-bold animate-pulse">
            REC {Math.floor(duration/60)}:{(duration%60).toString().padStart(2,'0')}
          </div>
        )}
        <div className="flex gap-2">
          <Button variant="ghost" size="icon" onClick={() => setShowSettings(!showSettings)} className="bg-black/50 text-white">
            <Settings className="h-6 w-6" />
          </Button>
          <Button variant="ghost" size="icon" onClick={() => setFacingMode(f => f === 'user' ? 'environment' : 'user')} className="bg-black/50 text-white">
            <SwitchCamera className="h-6 w-6" />
          </Button>
        </div>
      </div>


      {showSettings && !isRecording && (
        <div className="absolute top-20 right-4 bg-black/90 p-4 rounded-lg">
          <Select value={quality} onValueChange={(v: any) => setQuality(v)}>
            <SelectTrigger className="w-32 bg-white/10 text-white border-white/20">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="720p">HD 720p</SelectItem>
              <SelectItem value="1080p">Full HD</SelectItem>
              <SelectItem value="4k">4K UHD</SelectItem>
            </SelectContent>
          </Select>
        </div>
      )}

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-4">
        {!isRecording ? (
          <Button size="icon" onClick={startRecording} className="w-20 h-20 rounded-full bg-red-600 hover:bg-red-700">
            <Video className="h-10 w-10" />
          </Button>
        ) : (
          <>
            <Button size="icon" onClick={isPaused ? () => mediaRecorderRef.current?.resume() : () => mediaRecorderRef.current?.pause()} className="w-16 h-16 rounded-full bg-yellow-600">
              {isPaused ? <Play className="h-8 w-8" /> : <Pause className="h-8 w-8" />}
            </Button>
            <Button size="icon" onClick={stopRecording} className="w-16 h-16 rounded-full bg-white">
              <Square className="h-8 w-8 text-red-600" />
            </Button>
          </>
        )}
      </div>

      {recordedBlob && (
        <div className="absolute inset-0 bg-black/95 flex items-center justify-center p-4">
          <div className="text-center space-y-4">
            <p className="text-white text-xl mb-2">Video Recorded: {Math.floor(duration/60)}:{(duration%60).toString().padStart(2,'0')}</p>
            {isUploading && (
              <div className="space-y-2">
                <div className="flex items-center justify-center gap-2 text-white">
                  <Upload className="h-4 w-4 animate-bounce" />
                  <span>Uploading to cloud...</span>
                </div>
              </div>
            )}
            <div className="flex gap-3 justify-center">
              <Button onClick={() => { setRecordedBlob(null); setDuration(0); }} variant="outline" disabled={isUploading}>Discard</Button>
              {onEdit && <Button onClick={handleEdit} variant="outline" disabled={isUploading}><Edit className="h-4 w-4 mr-2" />Edit</Button>}
              <Button onClick={handleSave} className="bg-amber-600 hover:bg-amber-700" disabled={isUploading}>
                {isUploading ? 'Uploading...' : 'Save Video'}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
