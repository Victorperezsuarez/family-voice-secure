import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { supabase } from '@/lib/supabase-client';
import { UserContext } from '@/types/contextualBandits';
import { Sparkles, Target, Brain } from 'lucide-react';
import { toast } from 'sonner';

interface Props {
  testId: string;
  onSelectionComplete?: (combinationId: string) => void;
}

export function PersonalizedDeliveryManager({ testId, onSelectionComplete }: Props) {
  const [algorithm, setAlgorithm] = useState<'thompson_sampling' | 'ucb' | 'epsilon_greedy'>('thompson_sampling');
  const [explorationRate, setExplorationRate] = useState(0.1);
  const [autoPersonalize, setAutoPersonalize] = useState(true);
  const [selecting, setSelecting] = useState(false);

  const selectVariantForUser = async (userContext: UserContext) => {
    setSelecting(true);
    try {
      // Get all combinations
      const { data: combinations } = await supabase
        .from('notification_mvt_combinations')
        .select('*')
        .eq('test_id', testId);

      if (!combinations || combinations.length === 0) {
        throw new Error('No combinations found');
      }

      // Get contextual stats for user segments
      const segments = extractSegments(userContext);
      const scores = await Promise.all(combinations.map(async (combo) => {
        let totalScore = 0;
        let segmentCount = 0;

        for (const segment of segments) {
          const { data: stats } = await supabase
            .from('notification_contextual_stats')
            .select('*')
            .eq('test_id', testId)
            .eq('combination_id', combo.id)
            .eq('segment_key', segment.key)
            .eq('segment_value', segment.value)
            .single();

          if (stats) {
            const score = calculateScore(algorithm, stats.alpha, stats.beta, explorationRate);
            totalScore += score;
            segmentCount++;
          }
        }

        // Fallback to global stats if no segment data
        if (segmentCount === 0) {
          const { data: globalStats } = await supabase
            .from('notification_bayesian_stats')
            .select('*')
            .eq('test_id', testId)
            .eq('combination_id', combo.id)
            .single();

          if (globalStats) {
            totalScore = calculateScore(algorithm, globalStats.alpha, globalStats.beta, explorationRate);
            segmentCount = 1;
          }
        }

        return {
          combinationId: combo.id,
          score: segmentCount > 0 ? totalScore / segmentCount : Math.random(),
          combination: combo
        };
      }));

      scores.sort((a, b) => b.score - a.score);
      const selected = scores[0];

      // Log selection
      await supabase.from('notification_personalized_selections').insert({
        test_id: testId,
        user_id: userContext.userId,
        combination_id: selected.combinationId,
        user_context: userContext,
        selection_score: selected.score,
        selection_method: algorithm,
        exploration_factor: explorationRate
      });

      toast.success(`Selected variant with score ${selected.score.toFixed(4)}`);
      onSelectionComplete?.(selected.combinationId);
    } catch (error: any) {
      toast.error(`Selection failed: ${error.message}`);
    } finally {
      setSelecting(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="h-5 w-5" />
          Personalized Delivery
        </CardTitle>
        <CardDescription>
          Automatically select best variant for each user based on context
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex items-center justify-between">
          <Label htmlFor="auto-personalize">Enable Auto-Personalization</Label>
          <Switch
            id="auto-personalize"
            checked={autoPersonalize}
            onCheckedChange={setAutoPersonalize}
          />
        </div>

        <div className="space-y-2">
          <Label>Selection Algorithm</Label>
          <Select value={algorithm} onValueChange={(v: any) => setAlgorithm(v)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="thompson_sampling">
                <div className="flex items-center gap-2">
                  <Brain className="h-4 w-4" />
                  Thompson Sampling (Recommended)
                </div>
              </SelectItem>
              <SelectItem value="ucb">
                <div className="flex items-center gap-2">
                  <Target className="h-4 w-4" />
                  Upper Confidence Bound
                </div>
              </SelectItem>
              <SelectItem value="epsilon_greedy">Epsilon Greedy</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>Exploration Rate: {explorationRate.toFixed(2)}</Label>
          <Slider
            value={[explorationRate]}
            onValueChange={([v]) => setExplorationRate(v)}
            min={0}
            max={0.5}
            step={0.01}
          />
          <p className="text-xs text-muted-foreground">
            Higher values explore more variants, lower values exploit best performers
          </p>
        </div>

        <div className="pt-4 border-t">
          <p className="text-sm font-medium mb-2">Status</p>
          <div className="flex items-center gap-2">
            <div className={`h-2 w-2 rounded-full ${autoPersonalize ? 'bg-green-500' : 'bg-gray-400'}`} />
            <span className="text-sm">
              {autoPersonalize ? 'Active - Personalizing for all users' : 'Inactive'}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function extractSegments(context: UserContext) {
  const segments = [];
  if (context.deviceType) segments.push({ key: 'device_type', value: context.deviceType });
  if (context.locationCountry) segments.push({ key: 'location_country', value: context.locationCountry });
  if (context.timeOfDay) segments.push({ key: 'time_of_day', value: context.timeOfDay });
  if (context.dayOfWeek) segments.push({ key: 'day_of_week', value: context.dayOfWeek });
  return segments;
}

function calculateScore(algorithm: string, alpha: number, beta: number, exploration: number): number {
  if (algorithm === 'thompson_sampling') {
    return betaSample(alpha, beta);
  } else if (algorithm === 'ucb') {
    const mean = alpha / (alpha + beta);
    const n = alpha + beta - 2;
    return mean + exploration * Math.sqrt(2 * Math.log(n + 1) / Math.max(n, 1));
  } else {
    return Math.random() < exploration ? Math.random() : alpha / (alpha + beta);
  }
}

function betaSample(alpha: number, beta: number): number {
  const u1 = Math.random();
  const u2 = Math.random();
  return u1 / (u1 + u2);
}
