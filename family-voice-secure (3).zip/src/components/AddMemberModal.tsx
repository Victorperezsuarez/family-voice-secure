import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface AddMemberModalProps {
  open: boolean;
  onClose: () => void;
  onAdd: (member: { name: string; relationship: string; photo_url: string }) => void;
}

const relationships = [
  'Abuelo', 'Abuela', 'Padre', 'Madre', 'Tío', 'Tía',
  'Hermano', 'Hermana', 'Hijo', 'Hija', 'Primo', 'Prima'
];

export function AddMemberModal({ open, onClose, onAdd }: AddMemberModalProps) {
  const [name, setName] = useState('');
  const [relationship, setRelationship] = useState('');
  const [photoUrl, setPhotoUrl] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name && relationship) {
      onAdd({ name, relationship, photo_url: photoUrl });
      setName('');
      setRelationship('');
      setPhotoUrl('');
      onClose();
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-amber-900">
            Agregar Familiar
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="name">Nombre</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ej: María García"
              required
            />
          </div>

          <div>
            <Label htmlFor="relationship">Relación</Label>
            <Select value={relationship} onValueChange={setRelationship} required>
              <SelectTrigger>
                <SelectValue placeholder="Selecciona relación" />
              </SelectTrigger>
              <SelectContent>
                {relationships.map((rel) => (
                  <SelectItem key={rel} value={rel.toLowerCase()}>
                    {rel}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="photo">URL de Foto (opcional)</Label>
            <Input
              id="photo"
              value={photoUrl}
              onChange={(e) => setPhotoUrl(e.target.value)}
              placeholder="https://..."
            />
          </div>

          <div className="flex gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1">
              Cancelar
            </Button>
            <Button 
              type="submit" 
              className="flex-1 bg-gradient-to-r from-amber-500 to-orange-500"
            >
              Agregar
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
