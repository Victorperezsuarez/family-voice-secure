import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Mic, Check, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';

interface VoiceEnrollmentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  familyMemberId: string;
  memberName: string;
}

export function VoiceEnrollmentDialog({
  open,
  onOpenChange,
  familyMemberId,
  memberName
}: VoiceEnrollmentDialogProps) {
  const [enrollmentStatus, setEnrollmentStatus] = useState<'idle' | 'recording' | 'processing' | 'complete'>('idle');
  const [samplesCollected, setSamplesCollected] = useState(0);
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      const chunks: Blob[] = [];

      recorder.ondataavailable = (e) => chunks.push(e.data);
      recorder.onstop = async () => {
        const blob = new Blob(chunks, { type: 'audio/webm' });
        await processVoiceSample(blob);
        stream.getTracks().forEach(track => track.stop());
      };

      recorder.start();
      setMediaRecorder(recorder);
      setEnrollmentStatus('recording');

      setTimeout(() => {
        if (recorder.state === 'recording') {
          recorder.stop();
        }
      }, 5000);
    } catch (error) {
      toast.error('Failed to access microphone');
    }
  };

  const processVoiceSample = async (audioBlob: Blob) => {
    setEnrollmentStatus('processing');

    try {
      const fileName = `voice-sample-${familyMemberId}-${Date.now()}.webm`;
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('recordings')
        .upload(fileName, audioBlob);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('recordings')
        .getPublicUrl(fileName);

      const { data, error } = await supabase.functions.invoke('enroll-voice-profile', {
        body: { familyMemberId, audioUrl: publicUrl, recordingId: uploadData.path }
      });

      if (error) throw error;

      setSamplesCollected(prev => prev + 1);
      
      if (samplesCollected + 1 >= 3) {
        setEnrollmentStatus('complete');
        toast.success('Voice profile enrolled successfully!');
      } else {
        setEnrollmentStatus('idle');
        toast.success(`Sample ${samplesCollected + 1}/3 collected`);
      }
    } catch (error) {
      console.error('Voice enrollment error:', error);
      toast.error('Failed to process voice sample');
      setEnrollmentStatus('idle');
    }
  };

  const progress = (samplesCollected / 3) * 100;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Enroll Voice Profile: {memberName}</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          <div className="text-center space-y-2">
            <p className="text-sm text-muted-foreground">
              Record 3 voice samples (5 seconds each) to create a voice profile
            </p>
            <Progress value={progress} className="h-2" />
            <p className="text-xs text-muted-foreground">
              {samplesCollected} / 3 samples collected
            </p>
          </div>

          {enrollmentStatus === 'complete' ? (
            <div className="text-center space-y-4">
              <Check className="h-16 w-16 text-green-500 mx-auto" />
              <p className="font-medium">Voice profile enrolled!</p>
              <Button onClick={() => onOpenChange(false)}>Done</Button>
            </div>
          ) : (
            <div className="space-y-4">
              <Button
                onClick={startRecording}
                disabled={enrollmentStatus !== 'idle'}
                className="w-full"
                size="lg"
              >
                {enrollmentStatus === 'recording' && <Mic className="mr-2 h-5 w-5 animate-pulse" />}
                {enrollmentStatus === 'processing' && 'Processing...'}
                {enrollmentStatus === 'idle' && 'Record Sample'}
                {enrollmentStatus === 'recording' && 'Recording...'}
              </Button>

              <div className="bg-blue-50 dark:bg-blue-950 p-4 rounded-lg space-y-2">
                <div className="flex items-start gap-2">
                  <AlertCircle className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-blue-900 dark:text-blue-100">
                    <p className="font-medium mb-1">Tips for best results:</p>
                    <ul className="list-disc list-inside space-y-1 text-xs">
                      <li>Speak naturally in a quiet environment</li>
                      <li>Use different phrases for each sample</li>
                      <li>Maintain consistent distance from microphone</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
