import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase-client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { RefreshCw, PlayCircle, CheckCircle, XCircle } from 'lucide-react';
import type { ModelRetrainingTrigger } from '@/types/realtimeFeatures';

export function ModelRetrainingManager() {
  const [triggers, setTriggers] = useState<ModelRetrainingTrigger[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadTriggers();
  }, []);

  async function loadTriggers() {
    const { data } = await supabase
      .from('model_retraining_triggers')
      .select('*')
      .order('triggered_at', { ascending: false })
      .limit(20);
    
    if (data) setTriggers(data);
  }

  async function triggerRetraining(modelName: string, reason: string, affectedFeatures: string[]) {
    setLoading(true);
    
    await supabase.from('model_retraining_triggers').insert({
      model_name: modelName,
      trigger_type: 'distribution_drift',
      trigger_reason: reason,
      affected_features: affectedFeatures,
      trigger_status: 'pending'
    });
    
    await loadTriggers();
    setLoading(false);
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'failed': return <XCircle className="w-4 h-4 text-red-600" />;
      case 'in_progress': return <RefreshCw className="w-4 h-4 text-blue-600 animate-spin" />;
      default: return <PlayCircle className="w-4 h-4 text-gray-600" />;
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center gap-2">
            <RefreshCw className="w-5 h-5" />
            Model Retraining Manager
          </span>
          <Button 
            onClick={() => triggerRetraining('user_segmentation', 'Manual trigger', ['engagement_score'])}
            disabled={loading}
            size="sm"
          >
            Trigger Retraining
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {triggers.map((trigger) => (
            <div key={trigger.id} className="p-4 border rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <div className="font-medium">{trigger.model_name}</div>
                <div className="flex items-center gap-2">
                  {getStatusIcon(trigger.trigger_status)}
                  <Badge variant="outline">{trigger.trigger_status}</Badge>
                </div>
              </div>
              <div className="text-sm space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-muted-foreground">Type:</span>
                  <Badge variant="secondary">{trigger.trigger_type}</Badge>
                </div>
                {trigger.drift_score && (
                  <div className="flex items-center gap-2">
                    <span className="text-muted-foreground">Drift Score:</span>
                    <span className="font-medium">{trigger.drift_score.toFixed(2)}%</span>
                  </div>
                )}
                <div className="text-muted-foreground">
                  Triggered: {new Date(trigger.triggered_at).toLocaleString()}
                </div>
                {trigger.trigger_reason && (
                  <div className="text-muted-foreground mt-2">{trigger.trigger_reason}</div>
                )}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
