import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Filter, Play, CheckCircle2 } from 'lucide-react';
import { SelectionMethod } from '@/types/featureEngineering';

interface FeatureScore {
  name: string;
  score: number;
  selected: boolean;
}

export default function FeatureSelectionPanel() {
  const [method, setMethod] = useState<SelectionMethod>('mutual_info');
  const [topK, setTopK] = useState(10);
  const [isRunning, setIsRunning] = useState(false);

  const demoScores: FeatureScore[] = [
    { name: 'activity_frequency', score: 0.92, selected: true },
    { name: 'engagement_intensity', score: 0.88, selected: true },
    { name: 'engagement_momentum', score: 0.85, selected: true },
    { name: 'sessions_last_7d', score: 0.81, selected: true },
    { name: 'total_duration', score: 0.78, selected: true },
    { name: 'action_count_7d', score: 0.75, selected: true },
    { name: 'unique_actions_7d', score: 0.71, selected: true },
    { name: 'last_active_days_ago', score: 0.68, selected: true },
    { name: 'total_sessions', score: 0.65, selected: true },
    { name: 'avg_value_7d', score: 0.62, selected: true },
    { name: 'signup_source_organic', score: 0.45, selected: false },
    { name: 'device_type_mobile', score: 0.38, selected: false }
  ];

  const runSelection = () => {
    setIsRunning(true);
    setTimeout(() => setIsRunning(false), 1500);
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            <CardTitle>Feature Selection</CardTitle>
          </div>
          <Button onClick={runSelection} disabled={isRunning}>
            <Play className="h-4 w-4 mr-2" />
            {isRunning ? 'Running...' : 'Run Selection'}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Selection Method</label>
              <Select value={method} onValueChange={(v) => setMethod(v as SelectionMethod)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="mutual_info">Mutual Information</SelectItem>
                  <SelectItem value="chi_square">Chi-Square</SelectItem>
                  <SelectItem value="rfe">Recursive Feature Elimination</SelectItem>
                  <SelectItem value="lasso">LASSO Regularization</SelectItem>
                  <SelectItem value="correlation">Correlation-based</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Top K Features</label>
              <Select value={topK.toString()} onValueChange={(v) => setTopK(parseInt(v))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="5">5</SelectItem>
                  <SelectItem value="10">10</SelectItem>
                  <SelectItem value="15">15</SelectItem>
                  <SelectItem value="20">20</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-semibold">Feature Scores</h4>
              <span className="text-xs text-muted-foreground">
                {demoScores.filter(f => f.selected).length} selected
              </span>
            </div>

            <div className="space-y-2">
              {demoScores.map((feature) => (
                <div
                  key={feature.name}
                  className={`flex items-center justify-between p-3 rounded-lg border ${
                    feature.selected ? 'bg-primary/5 border-primary/20' : 'bg-muted/50'
                  }`}
                >
                  <div className="flex items-center gap-3 flex-1">
                    {feature.selected && (
                      <CheckCircle2 className="h-4 w-4 text-primary" />
                    )}
                    <span className="text-sm font-medium">{feature.name}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-32 bg-muted rounded-full h-2">
                      <div
                        className="bg-primary h-2 rounded-full transition-all"
                        style={{ width: `${feature.score * 100}%` }}
                      />
                    </div>
                    <Badge variant={feature.selected ? 'default' : 'outline'}>
                      {feature.score.toFixed(3)}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
