import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Activity } from 'lucide-react';

interface CorrelationHeatmapProps {
  features: string[];
  matrix: number[][];
}

export default function CorrelationHeatmap({ features, matrix }: CorrelationHeatmapProps) {
  const getCorrelationColor = (value: number) => {
    const absValue = Math.abs(value);
    if (absValue > 0.8) return value > 0 ? 'bg-green-600' : 'bg-red-600';
    if (absValue > 0.6) return value > 0 ? 'bg-green-500' : 'bg-red-500';
    if (absValue > 0.4) return value > 0 ? 'bg-green-400' : 'bg-red-400';
    if (absValue > 0.2) return value > 0 ? 'bg-green-300' : 'bg-red-300';
    return 'bg-gray-200';
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Activity className="h-5 w-5" />
          <CardTitle>Feature Correlation Matrix</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <div className="inline-block min-w-full">
            <div className="grid gap-1" style={{ gridTemplateColumns: `120px repeat(${features.length}, 60px)` }}>
              {/* Header row */}
              <div></div>
              {features.map((feature, i) => (
                <div key={i} className="text-xs font-medium text-center transform -rotate-45 origin-left mb-8">
                  {feature.length > 12 ? feature.substring(0, 12) + '...' : feature}
                </div>
              ))}

              {/* Data rows */}
              {features.map((rowFeature, i) => (
                <>
                  <div key={`label-${i}`} className="text-xs font-medium py-2 pr-2 text-right">
                    {rowFeature.length > 15 ? rowFeature.substring(0, 15) + '...' : rowFeature}
                  </div>
                  {matrix[i].map((value, j) => (
                    <div
                      key={`${i}-${j}`}
                      className={`h-12 flex items-center justify-center text-xs font-medium rounded ${getCorrelationColor(value)} ${
                        i === j ? 'border-2 border-primary' : ''
                      }`}
                      title={`${features[i]} vs ${features[j]}: ${value.toFixed(3)}`}
                    >
                      {value.toFixed(2)}
                    </div>
                  ))}
                </>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-6 flex items-center justify-center gap-6 text-sm">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-red-600 rounded"></div>
            <span>Strong Negative</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-gray-200 rounded"></div>
            <span>No Correlation</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-green-600 rounded"></div>
            <span>Strong Positive</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
