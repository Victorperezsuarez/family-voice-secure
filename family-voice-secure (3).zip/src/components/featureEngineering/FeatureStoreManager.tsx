import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, Plus, TrendingUp, Database } from 'lucide-react';
import { Feature, FeatureType } from '@/types/featureEngineering';

const demoFeatures: Feature[] = [
  {
    id: '1',
    feature_name: 'engagement_intensity',
    feature_type: 'derived',
    description: 'Average session duration per user',
    data_type: 'numeric',
    generation_method: 'total_duration / total_sessions',
    source_features: ['total_duration', 'total_sessions'],
    is_active: true,
    importance_score: 0.85,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: '2',
    feature_name: 'activity_frequency',
    feature_type: 'derived',
    description: 'Sessions per day since signup',
    data_type: 'numeric',
    generation_method: 'total_sessions / days_since_signup',
    source_features: ['total_sessions', 'signup_date'],
    is_active: true,
    importance_score: 0.9,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: '3',
    feature_name: 'action_count_7d',
    feature_type: 'time_series',
    description: 'Number of actions in last 7 days',
    data_type: 'numeric',
    generation_method: 'COUNT(actions) WHERE timestamp > NOW() - INTERVAL 7 days',
    is_active: true,
    importance_score: 0.75,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }
];

export default function FeatureStoreManager() {
  const [features] = useState<Feature[]>(demoFeatures);
  const [searchTerm, setSearchTerm] = useState('');

  const filteredFeatures = features.filter(f =>
    f.feature_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    f.description?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getTypeColor = (type: FeatureType) => {
    switch (type) {
      case 'raw': return 'bg-gray-500';
      case 'derived': return 'bg-blue-500';
      case 'aggregated': return 'bg-green-500';
      case 'time_series': return 'bg-purple-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            <CardTitle>Feature Store</CardTitle>
          </div>
          <Button size="sm">
            <Plus className="h-4 w-4 mr-2" />
            Add Feature
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search features..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          <div className="space-y-3">
            {filteredFeatures.map((feature) => (
              <div
                key={feature.id}
                className="border rounded-lg p-4 hover:bg-accent transition-colors"
              >
                <div className="flex items-start justify-between">
                  <div className="space-y-2 flex-1">
                    <div className="flex items-center gap-2">
                      <h4 className="font-semibold">{feature.feature_name}</h4>
                      <Badge className={getTypeColor(feature.feature_type)}>
                        {feature.feature_type}
                      </Badge>
                      {feature.is_active && (
                        <Badge variant="outline" className="text-green-600">
                          Active
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {feature.description}
                    </p>
                    {feature.generation_method && (
                      <code className="text-xs bg-muted px-2 py-1 rounded">
                        {feature.generation_method}
                      </code>
                    )}
                    {feature.source_features && feature.source_features.length > 0 && (
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <span>Sources:</span>
                        {feature.source_features.map((sf) => (
                          <Badge key={sf} variant="outline" className="text-xs">
                            {sf}
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>
                  {feature.importance_score !== undefined && (
                    <div className="flex items-center gap-2 ml-4">
                      <TrendingUp className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm font-medium">
                        {(feature.importance_score * 100).toFixed(0)}%
                      </span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
