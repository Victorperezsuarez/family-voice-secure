import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase-client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Clock, AlertTriangle, CheckCircle } from 'lucide-react';
import type { FeatureFreshness } from '@/types/realtimeFeatures';

export function FeatureFreshnessMonitor() {
  const [freshness, setFreshness] = useState<FeatureFreshness[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadFreshness();
    const interval = setInterval(loadFreshness, 30000);
    return () => clearInterval(interval);
  }, []);

  async function loadFreshness() {
    const { data } = await supabase
      .from('feature_freshness_tracking')
      .select('*')
      .order('freshness_score', { ascending: true });
    
    if (data) setFreshness(data);
    setLoading(false);
  }

  if (loading) return <div>Loading freshness data...</div>;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Clock className="w-5 h-5" />
          Feature Freshness Monitor
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {freshness.map((item) => (
            <div key={item.id} className="flex items-center justify-between p-3 border rounded-lg">
              <div className="flex-1">
                <div className="font-medium">{item.feature_name}</div>
                <div className="text-sm text-muted-foreground">
                  Last updated: {new Date(item.last_updated_at).toLocaleString()}
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <div className="text-sm font-medium">
                    {Math.round(item.freshness_score)}% fresh
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {Math.round(item.staleness_seconds / 60)}m old
                  </div>
                </div>
                {item.is_stale ? (
                  <Badge variant="destructive" className="gap-1">
                    <AlertTriangle className="w-3 h-3" />
                    Stale
                  </Badge>
                ) : (
                  <Badge variant="default" className="gap-1">
                    <CheckCircle className="w-3 h-3" />
                    Fresh
                  </Badge>
                )}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
