import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Plus, Edit, UserCheck, UserX } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { TeamMemberDialog } from './TeamMemberDialog';

export function TeamMembersList() {
  const [members, setMembers] = useState<any[]>([]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedMember, setSelectedMember] = useState<any>(null);

  useEffect(() => {
    loadMembers();
  }, []);

  const loadMembers = async () => {
    const { data } = await supabase
      .from('team_members')
      .select('*, team_member_expertise(*)')
      .order('name');
    setMembers(data || []);
  };

  const toggleAvailability = async (member: any) => {
    const newStatus = member.availability_status === 'available' ? 'unavailable' : 'available';
    await supabase
      .from('team_members')
      .update({ availability_status: newStatus })
      .eq('id', member.id);
    loadMembers();
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available': return 'bg-green-500';
      case 'busy': return 'bg-yellow-500';
      case 'unavailable': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Team Members</CardTitle>
          <Button onClick={() => { setSelectedMember(null); setDialogOpen(true); }}>
            <Plus className="h-4 w-4 mr-2" />
            Add Member
          </Button>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {members.map((member) => (
              <div key={member.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-4">
                  <div className="relative">
                    <Avatar>
                      <AvatarFallback>{member.name.split(' ').map((n: string) => n[0]).join('')}</AvatarFallback>
                    </Avatar>
                    <div className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-white ${getStatusColor(member.availability_status)}`} />
                  </div>
                  <div>
                    <div className="font-medium">{member.name}</div>
                    <div className="text-sm text-muted-foreground">{member.email}</div>
                    <div className="flex gap-1 mt-1">
                      {(member.skills || []).slice(0, 3).map((skill: string) => (
                        <Badge key={skill} variant="secondary" className="text-xs">{skill}</Badge>
                      ))}
                      {(member.skills || []).length > 3 && (
                        <Badge variant="secondary" className="text-xs">+{member.skills.length - 3}</Badge>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="text-right mr-4">
                    <div className="text-sm font-medium">{member.current_alert_count}/{member.max_concurrent_alerts}</div>
                    <div className="text-xs text-muted-foreground">Active alerts</div>
                  </div>
                  <Button variant="outline" size="sm" onClick={() => toggleAvailability(member)}>
                    {member.availability_status === 'available' ? <UserCheck className="h-4 w-4" /> : <UserX className="h-4 w-4" />}
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => { setSelectedMember(member); setDialogOpen(true); }}>
                    <Edit className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      <TeamMemberDialog open={dialogOpen} onOpenChange={setDialogOpen} member={selectedMember} onSave={loadMembers} />
    </>
  );
}
