import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Users, Clock, CheckCircle, AlertTriangle } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { OnCallScheduleManager } from './OnCallScheduleManager';
import { TeamMembersList } from './TeamMembersList';
import { RoutingRulesBuilder } from './RoutingRulesBuilder';
import { WorkloadBalancingPanel } from './WorkloadBalancingPanel';
import { RoutingAnalyticsDashboard } from './RoutingAnalyticsDashboard';
import { PredictiveAnalyticsDashboard } from './PredictiveAnalyticsDashboard';




export function AlertRoutingDashboard() {
  const [stats, setStats] = useState({
    totalMembers: 0,
    availableMembers: 0,
    activeAlerts: 0,
    avgResponseTime: 0
  });

  useEffect(() => {
    loadStats();
    const interval = setInterval(loadStats, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadStats = async () => {
    const { data: members } = await supabase.from('team_members').select('*');
    const { data: assignments } = await supabase
      .from('alert_assignments')
      .select('*')
      .eq('status', 'assigned');

    setStats({
      totalMembers: members?.length || 0,
      availableMembers: members?.filter(m => m.availability_status === 'available').length || 0,
      activeAlerts: assignments?.length || 0,
      avgResponseTime: 12
    });
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Team Members</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalMembers}</div>
            <p className="text-xs text-muted-foreground">{stats.availableMembers} available</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Active Alerts</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.activeAlerts}</div>
            <p className="text-xs text-muted-foreground">Currently assigned</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Avg Response</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.avgResponseTime}m</div>
            <p className="text-xs text-green-600">-15% from last week</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Resolution Rate</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">94%</div>
            <p className="text-xs text-green-600">+2% from last week</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="team" className="space-y-4">
        <TabsList>
          <TabsTrigger value="team">Team Members</TabsTrigger>
          <TabsTrigger value="oncall">On-Call Schedule</TabsTrigger>
          <TabsTrigger value="rules">Routing Rules</TabsTrigger>
          <TabsTrigger value="workload">Workload Balance</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="predictions">ML Predictions</TabsTrigger>
        </TabsList>



        <TabsContent value="team">
          <TeamMembersList />
        </TabsContent>

        <TabsContent value="oncall">
          <OnCallScheduleManager />
        </TabsContent>

        <TabsContent value="rules">
          <RoutingRulesBuilder />
        </TabsContent>

        <TabsContent value="workload">
          <WorkloadBalancingPanel />
        </TabsContent>

        <TabsContent value="analytics">
          <RoutingAnalyticsDashboard />
        </TabsContent>

        <TabsContent value="predictions">
          <PredictiveAnalyticsDashboard />
        </TabsContent>

      </Tabs>
    </div>
  );
}
