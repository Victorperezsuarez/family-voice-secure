import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';

interface EscalationFrequencyPanelProps {
  data: {
    totalEscalations: number;
    escalationRate: number;
    topReasons: Array<{ reason: string; count: number }>;
    byMember: Array<{ name: string; escalations: number; total: number }>;
  };
}

export function EscalationFrequencyPanel({ data }: EscalationFrequencyPanelProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Escalation Analysis</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Total Escalations</p>
            <p className="text-2xl font-bold">{data.totalEscalations}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Escalation Rate</p>
            <p className="text-2xl font-bold">{data.escalationRate}%</p>
          </div>
        </div>

        <div>
          <h4 className="text-sm font-medium mb-3">Top Escalation Reasons</h4>
          <div className="space-y-2">
            {data.topReasons.map((reason, idx) => (
              <div key={idx} className="flex items-center justify-between">
                <span className="text-sm">{reason.reason}</span>
                <Badge variant="secondary">{reason.count}</Badge>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h4 className="text-sm font-medium mb-3">Escalations by Team Member</h4>
          <div className="space-y-3">
            {data.byMember.map((member, idx) => (
              <div key={idx}>
                <div className="flex justify-between text-sm mb-1">
                  <span>{member.name}</span>
                  <span className="text-muted-foreground">
                    {member.escalations}/{member.total}
                  </span>
                </div>
                <Progress value={(member.escalations / member.total) * 100} />
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
