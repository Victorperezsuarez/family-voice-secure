import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Download, TrendingUp, Users, Clock, AlertTriangle } from 'lucide-react';
import { AssignmentSuccessChart } from './AssignmentSuccessChart';
import { ResponseTimeChart } from './ResponseTimeChart';
import { SkillUtilizationChart } from './SkillUtilizationChart';
import { WorkloadDistributionChart } from './WorkloadDistributionChart';
import { EscalationFrequencyPanel } from './EscalationFrequencyPanel';

export function RoutingAnalyticsDashboard() {
  const [dateRange, setDateRange] = useState('7d');

  // Mock data - would come from backend
  const overviewMetrics = {
    totalAssignments: 1247,
    successRate: 94.2,
    avgResponseTime: 180, // seconds
    routingEfficiency: 91.5
  };

  const assignmentData = [
    { date: '2024-01-01', successful: 45, failed: 3, total: 48 },
    { date: '2024-01-02', successful: 52, failed: 2, total: 54 },
    { date: '2024-01-03', successful: 48, failed: 4, total: 52 },
    { date: '2024-01-04', successful: 61, failed: 3, total: 64 },
    { date: '2024-01-05', successful: 55, failed: 2, total: 57 },
    { date: '2024-01-06', successful: 58, failed: 5, total: 63 },
    { date: '2024-01-07', successful: 63, failed: 1, total: 64 }
  ];

  const responseTimeData = [
    { memberName: 'Sarah Chen', avgResponseTime: 120, avgResolutionTime: 900 },
    { memberName: 'Mike Johnson', avgResponseTime: 180, avgResolutionTime: 1200 },
    { memberName: 'Emily Davis', avgResponseTime: 150, avgResolutionTime: 1050 },
    { memberName: 'Alex Kumar', avgResponseTime: 200, avgResolutionTime: 1300 }
  ];

  const skillUtilizationData = [
    { skill: 'Database', requests: 245, fulfilled: 230 },
    { skill: 'Network', requests: 189, fulfilled: 175 },
    { skill: 'Security', requests: 156, fulfilled: 148 },
    { skill: 'Application', requests: 312, fulfilled: 295 },
    { skill: 'Infrastructure', requests: 198, fulfilled: 185 }
  ];

  const workloadData = [
    { date: '2024-01-01', members: { 'Sarah': 12, 'Mike': 15, 'Emily': 11, 'Alex': 10 } },
    { date: '2024-01-02', members: { 'Sarah': 14, 'Mike': 13, 'Emily': 15, 'Alex': 12 } },
    { date: '2024-01-03', members: { 'Sarah': 11, 'Mike': 14, 'Emily': 13, 'Alex': 14 } },
    { date: '2024-01-04', members: { 'Sarah': 16, 'Mike': 15, 'Emily': 17, 'Alex': 16 } },
    { date: '2024-01-05', members: { 'Sarah': 13, 'Mike': 14, 'Emily': 15, 'Alex': 15 } },
    { date: '2024-01-06', members: { 'Sarah': 15, 'Mike': 16, 'Emily': 16, 'Alex': 16 } },
    { date: '2024-01-07', members: { 'Sarah': 16, 'Mike': 15, 'Emily': 17, 'Alex': 16 } }
  ];

  const escalationData = {
    totalEscalations: 73,
    escalationRate: 5.8,
    topReasons: [
      { reason: 'Primary unavailable', count: 28 },
      { reason: 'Skill mismatch', count: 19 },
      { reason: 'Overloaded', count: 15 },
      { reason: 'Timeout', count: 11 }
    ],
    byMember: [
      { name: 'Sarah Chen', escalations: 12, total: 285 },
      { name: 'Mike Johnson', escalations: 23, total: 312 },
      { name: 'Emily Davis', escalations: 18, total: 298 },
      { name: 'Alex Kumar', escalations: 20, total: 352 }
    ]
  };

  const handleExport = () => {
    const data = {
      overview: overviewMetrics,
      assignments: assignmentData,
      responseTimes: responseTimeData,
      skills: skillUtilizationData,
      workload: workloadData,
      escalations: escalationData,
      exportedAt: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `routing-analytics-${Date.now()}.json`;
    a.click();
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold">Routing Analytics</h2>
          <p className="text-muted-foreground">Comprehensive insights into alert routing performance</p>
        </div>
        <Button onClick={handleExport}>
          <Download className="w-4 h-4 mr-2" />
          Export Report
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Assignments</CardTitle>
            <Users className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{overviewMetrics.totalAssignments}</div>
            <p className="text-xs text-muted-foreground">Last 7 days</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
            <TrendingUp className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{overviewMetrics.successRate}%</div>
            <p className="text-xs text-green-600">+2.3% from last week</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Avg Response Time</CardTitle>
            <Clock className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{Math.round(overviewMetrics.avgResponseTime / 60)}m</div>
            <p className="text-xs text-green-600">-15s from last week</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Routing Efficiency</CardTitle>
            <AlertTriangle className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{overviewMetrics.routingEfficiency}%</div>
            <p className="text-xs text-green-600">+1.2% from last week</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="success" className="space-y-4">
        <TabsList>
          <TabsTrigger value="success">Success Rates</TabsTrigger>
          <TabsTrigger value="response">Response Times</TabsTrigger>
          <TabsTrigger value="skills">Skill Utilization</TabsTrigger>
          <TabsTrigger value="workload">Workload</TabsTrigger>
          <TabsTrigger value="escalations">Escalations</TabsTrigger>
        </TabsList>

        <TabsContent value="success" className="space-y-4">
          <AssignmentSuccessChart data={assignmentData} />
        </TabsContent>

        <TabsContent value="response" className="space-y-4">
          <ResponseTimeChart data={responseTimeData} />
        </TabsContent>

        <TabsContent value="skills" className="space-y-4">
          <SkillUtilizationChart data={skillUtilizationData} />
        </TabsContent>

        <TabsContent value="workload" className="space-y-4">
          <WorkloadDistributionChart data={workloadData} />
        </TabsContent>

        <TabsContent value="escalations" className="space-y-4">
          <EscalationFrequencyPanel data={escalationData} />
        </TabsContent>
      </Tabs>
    </div>
  );
}
