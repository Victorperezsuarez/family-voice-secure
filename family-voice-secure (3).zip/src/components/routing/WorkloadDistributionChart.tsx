import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';

interface WorkloadDistributionChartProps {
  data: Array<{
    date: string;
    members: Record<string, number>;
  }>;
}

export function WorkloadDistributionChart({ data }: WorkloadDistributionChartProps) {
  const memberNames = data.length > 0 ? Object.keys(data[0].members) : [];
  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

  return (
    <Card>
      <CardHeader>
        <CardTitle>Workload Distribution Over Time</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis label={{ value: 'Active Alerts', angle: -90, position: 'insideLeft' }} />
            <Tooltip />
            <Legend />
            {memberNames.map((name, idx) => (
              <Line
                key={name}
                type="monotone"
                dataKey={`members.${name}`}
                stroke={COLORS[idx % COLORS.length]}
                name={name}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
