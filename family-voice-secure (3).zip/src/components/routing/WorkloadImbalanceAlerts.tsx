import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { AlertTriangle, TrendingUp, Users } from 'lucide-react';

interface WorkloadPrediction {
  id: string;
  prediction_date: string;
  team_member_id: string;
  team_member_name: string;
  predicted_workload: number;
  imbalance_severity: 'low' | 'medium' | 'high' | 'critical';
  confidence_score: number;
  recommended_actions: string[];
}

interface WorkloadImbalanceAlertsProps {
  predictions: WorkloadPrediction[];
  onTakeAction: (predictionId: string, action: string) => void;
}

export default function WorkloadImbalanceAlerts({ 
  predictions, 
  onTakeAction 
}: WorkloadImbalanceAlertsProps) {
  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'destructive';
      case 'high': return 'destructive';
      case 'medium': return 'secondary';
      default: return 'outline';
    }
  };

  const getSeverityIcon = (severity: string) => {
    if (severity === 'critical' || severity === 'high') {
      return <AlertTriangle className="h-4 w-4" />;
    }
    return <TrendingUp className="h-4 w-4" />;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <AlertTriangle className="h-5 w-5 text-orange-600" />
          Workload Imbalance Alerts
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {predictions.filter(p => p.imbalance_severity !== 'low').map((pred) => (
            <Alert key={pred.id}>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    {getSeverityIcon(pred.imbalance_severity)}
                    <span className="font-medium">{pred.team_member_name}</span>
                    <Badge variant={getSeverityColor(pred.imbalance_severity)}>
                      {pred.imbalance_severity.toUpperCase()}
                    </Badge>
                  </div>
                  <AlertDescription>
                    Predicted workload: {pred.predicted_workload} alerts on{' '}
                    {new Date(pred.prediction_date).toLocaleDateString()}
                    <span className="text-xs text-muted-foreground ml-2">
                      ({(pred.confidence_score * 100).toFixed(0)}% confidence)
                    </span>
                  </AlertDescription>
                  
                  {pred.recommended_actions && pred.recommended_actions.length > 0 && (
                    <div className="mt-2 space-y-1">
                      <div className="text-xs font-medium">Recommended Actions:</div>
                      {pred.recommended_actions.map((action, idx) => (
                        <Button
                          key={idx}
                          variant="outline"
                          size="sm"
                          onClick={() => onTakeAction(pred.id, action)}
                          className="mr-2 mb-1"
                        >
                          {action}
                        </Button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </Alert>
          ))}
          
          {predictions.filter(p => p.imbalance_severity !== 'low').length === 0 && (
            <div className="text-center text-muted-foreground py-4">
              No workload imbalances predicted
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}