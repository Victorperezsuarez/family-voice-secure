import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';
import { RefreshCw, Download } from 'lucide-react';
import AlertVolumeForecastChart from './AlertVolumeForecastChart';
import AvailabilityPredictionsPanel from './AvailabilityPredictionsPanel';
import ScheduleOptimizationPanel from './ScheduleOptimizationPanel';
import WorkloadImbalanceAlerts from './WorkloadImbalanceAlerts';
import ScenarioPlanningPanel from './ScenarioPlanningPanel';

export function PredictiveAnalyticsDashboard() {
  const [forecasts, setForecasts] = useState([]);
  const [availabilityPredictions, setAvailabilityPredictions] = useState([]);
  const [scheduleRecommendations, setScheduleRecommendations] = useState([]);
  const [workloadPredictions, setWorkloadPredictions] = useState([]);
  const [scenarios, setScenarios] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadPredictions();
  }, []);

  const loadPredictions = async () => {
    const { data: forecastData } = await supabase
      .from('alert_volume_forecasts')
      .select('*')
      .order('forecast_date', { ascending: true })
      .limit(7);
    
    const { data: availData } = await supabase
      .from('availability_predictions')
      .select('*')
      .order('prediction_date', { ascending: true });
    
    const { data: schedData } = await supabase
      .from('schedule_recommendations')
      .select('*')
      .order('recommendation_date', { ascending: true });
    
    const { data: workloadData } = await supabase
      .from('workload_predictions')
      .select('*')
      .order('prediction_date', { ascending: true });
    
    const { data: scenarioData } = await supabase
      .from('routing_scenarios')
      .select('*')
      .order('created_at', { ascending: false });

    setForecasts(forecastData || []);
    setAvailabilityPredictions(availData || []);
    setScheduleRecommendations(schedData || []);
    setWorkloadPredictions(workloadData || []);
    setScenarios(scenarioData || []);
  };

  const runForecasting = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('forecast-alert-volumes', {
        body: { days: 7, confidenceLevel: 0.95 }
      });
      if (error) throw error;
      toast.success('Forecasting completed');
      loadPredictions();
    } catch (error: any) {
      toast.error('Forecasting failed: ' + error.message);
    }
    setLoading(false);
  };

  const runAvailabilityPredictions = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('predict-availability-needs', {
        body: { days: 7 }
      });
      if (error) throw error;
      toast.success('Availability predictions completed');
      loadPredictions();
    } catch (error: any) {
      toast.error('Prediction failed: ' + error.message);
    }
    setLoading(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">ML Predictive Analytics</h2>
        <div className="flex gap-2">
          <Button onClick={runForecasting} disabled={loading}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Run Forecasting
          </Button>
          <Button onClick={runAvailabilityPredictions} disabled={loading} variant="outline">
            Predict Availability
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <AlertVolumeForecastChart data={forecasts} />
        <AvailabilityPredictionsPanel predictions={availabilityPredictions} />
      </div>

      <WorkloadImbalanceAlerts 
        predictions={workloadPredictions}
        onTakeAction={(id, action) => toast.info(`Action: ${action}`)}
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ScheduleOptimizationPanel 
          recommendations={scheduleRecommendations}
          onApplySchedule={(id) => toast.success('Schedule applied')}
        />
        <ScenarioPlanningPanel 
          scenarios={scenarios}
          onRunScenario={(id) => toast.info('Running scenario simulation')}
          onCreateScenario={(scenario) => toast.success('Scenario created')}
          onDeleteScenario={(id) => toast.success('Scenario deleted')}
        />
      </div>
    </div>
  );
}