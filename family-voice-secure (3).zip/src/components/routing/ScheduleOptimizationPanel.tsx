import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Calendar, TrendingUp, Users, CheckCircle } from 'lucide-react';
import { Progress } from '@/components/ui/progress';

interface ScheduleRecommendation {
  id: string;
  recommendation_date: string;
  schedule_config: any;
  efficiency_score: number;
  coverage_score: number;
  workload_balance_score: number;
  rationale: string;
}

interface ScheduleOptimizationPanelProps {
  recommendations: ScheduleRecommendation[];
  onApplySchedule: (scheduleId: string) => void;
}

export default function ScheduleOptimizationPanel({ 
  recommendations, 
  onApplySchedule 
}: ScheduleOptimizationPanelProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="h-5 w-5" />
          Optimal Schedule Recommendations
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {recommendations.map((rec) => (
            <div key={rec.id} className="border rounded-lg p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-4 w-4 text-green-600" />
                  <span className="font-medium">
                    Week of {new Date(rec.recommendation_date).toLocaleDateString()}
                  </span>
                </div>
                <Badge variant="outline">
                  Score: {rec.efficiency_score.toFixed(1)}
                </Badge>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <div className="text-sm text-muted-foreground mb-1">Efficiency</div>
                  <Progress value={rec.efficiency_score} className="h-2" />
                  <div className="text-xs mt-1">{rec.efficiency_score.toFixed(0)}%</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground mb-1">Coverage</div>
                  <Progress value={rec.coverage_score * 100} className="h-2" />
                  <div className="text-xs mt-1">{(rec.coverage_score * 100).toFixed(0)}%</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground mb-1">Balance</div>
                  <Progress value={rec.workload_balance_score * 100} className="h-2" />
                  <div className="text-xs mt-1">{(rec.workload_balance_score * 100).toFixed(0)}%</div>
                </div>
              </div>

              <div className="text-sm text-muted-foreground">
                <div className="font-medium mb-1">Rationale:</div>
                <p>{rec.rationale}</p>
              </div>

              <Button 
                onClick={() => onApplySchedule(rec.id)}
                className="w-full"
                variant="outline"
              >
                <CheckCircle className="h-4 w-4 mr-2" />
                Apply This Schedule
              </Button>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}