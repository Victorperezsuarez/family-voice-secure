import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { AlertTriangle, TrendingUp, TrendingDown, RefreshCw } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';

export function WorkloadBalancingPanel() {
  const [members, setMembers] = useState<any[]>([]);
  const [metrics, setMetrics] = useState<any[]>([]);

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadData = async () => {
    const { data: membersData } = await supabase
      .from('team_members')
      .select('*')
      .eq('is_active', true);

    const { data: metricsData } = await supabase
      .from('workload_metrics')
      .select('*')
      .eq('metric_date', new Date().toISOString().split('T')[0]);

    setMembers(membersData || []);
    setMetrics(metricsData || []);
  };

  const getWorkloadPercentage = (member: any) => {
    return (member.current_alert_count / member.max_concurrent_alerts) * 100;
  };

  const getWorkloadStatus = (percentage: number) => {
    if (percentage >= 90) return { label: 'Overloaded', color: 'destructive' };
    if (percentage >= 70) return { label: 'High', color: 'warning' };
    if (percentage >= 40) return { label: 'Moderate', color: 'default' };
    return { label: 'Low', color: 'secondary' };
  };

  const getMemberMetrics = (memberId: string) => {
    return metrics.find(m => m.team_member_id === memberId);
  };

  const rebalanceWorkload = async () => {
    // Trigger workload rebalancing
    console.log('Rebalancing workload...');
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Workload Distribution</CardTitle>
          <Button onClick={rebalanceWorkload}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Rebalance
          </Button>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {members.map((member) => {
              const percentage = getWorkloadPercentage(member);
              const status = getWorkloadStatus(percentage);
              const memberMetrics = getMemberMetrics(member.id);

              return (
                <div key={member.id} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div>
                        <div className="font-medium">{member.name}</div>
                        <div className="text-sm text-muted-foreground">{member.role}</div>
                      </div>
                      <Badge variant={status.color as any}>{status.label}</Badge>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-medium">
                        {member.current_alert_count} / {member.max_concurrent_alerts}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {percentage.toFixed(0)}% capacity
                      </div>
                    </div>
                  </div>

                  <Progress value={percentage} className="h-2" />

                  {memberMetrics && (
                    <div className="flex gap-4 text-xs text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <span>Resolved today:</span>
                        <span className="font-medium text-foreground">{memberMetrics.resolved_today}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <span>Avg response:</span>
                        <span className="font-medium text-foreground">
                          {memberMetrics.avg_response_time_minutes?.toFixed(1)}m
                        </span>
                      </div>
                      {memberMetrics.is_overloaded && (
                        <div className="flex items-center gap-1 text-red-600">
                          <AlertTriangle className="h-3 w-3" />
                          <span>Overloaded</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}

            {members.length === 0 && (
              <div className="text-center py-12 text-muted-foreground">
                <p>No team members available</p>
                <p className="text-sm mt-2">Add team members to track workload</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Avg Workload</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">62%</div>
            <p className="text-xs text-green-600 flex items-center gap-1 mt-1">
              <TrendingDown className="h-3 w-3" />
              -8% from yesterday
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Overloaded Members</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {members.filter(m => getWorkloadPercentage(m) >= 90).length}
            </div>
            <p className="text-xs text-muted-foreground mt-1">Require immediate attention</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Balance Score</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">85/100</div>
            <p className="text-xs text-green-600 flex items-center gap-1 mt-1">
              <TrendingUp className="h-3 w-3" />
              Good distribution
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
