import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Plus, Edit, Trash2, ArrowUp, ArrowDown } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';

export function RoutingRulesBuilder() {
  const [rules, setRules] = useState<any[]>([]);

  useEffect(() => {
    loadRules();
  }, []);

  const loadRules = async () => {
    const { data } = await supabase
      .from('alert_routing_rules')
      .select('*')
      .order('priority', { ascending: false });
    setRules(data || []);
  };

  const deleteRule = async (id: string) => {
    await supabase.from('alert_routing_rules').delete().eq('id', id);
    loadRules();
  };

  const getStrategyLabel = (strategy: string) => {
    const labels: Record<string, string> = {
      round_robin: 'Round Robin',
      least_loaded: 'Least Loaded',
      most_experienced: 'Most Experienced',
      skill_match: 'Skill Match'
    };
    return labels[strategy] || strategy;
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Routing Rules</CardTitle>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Add Rule
        </Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {rules.map((rule, index) => (
            <div key={rule.id} className="border rounded-lg p-4">
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="outline">Priority {rule.priority}</Badge>
                    <Badge variant={rule.is_active ? 'default' : 'secondary'}>
                      {rule.is_active ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>
                  <div className="font-medium text-lg">{rule.name}</div>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    <ArrowUp className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm">
                    <ArrowDown className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm">
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => deleteRule(rule.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <div className="text-muted-foreground mb-1">Strategy</div>
                  <div className="font-medium">{getStrategyLabel(rule.routing_strategy)}</div>
                </div>
                <div>
                  <div className="text-muted-foreground mb-1">Required Skills</div>
                  <div className="flex flex-wrap gap-1">
                    {rule.required_skills?.length > 0 ? (
                      rule.required_skills.map((skill: string) => (
                        <Badge key={skill} variant="secondary" className="text-xs">{skill}</Badge>
                      ))
                    ) : (
                      <span className="text-muted-foreground">None</span>
                    )}
                  </div>
                </div>
              </div>

              <div className="mt-3 grid grid-cols-3 gap-4 text-sm">
                <div>
                  <div className="text-muted-foreground">Workload Weight</div>
                  <div className="font-medium">{(rule.workload_weight * 100).toFixed(0)}%</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Expertise Weight</div>
                  <div className="font-medium">{(rule.expertise_weight * 100).toFixed(0)}%</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Availability Weight</div>
                  <div className="font-medium">{(rule.availability_weight * 100).toFixed(0)}%</div>
                </div>
              </div>
            </div>
          ))}

          {rules.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              <p>No routing rules configured</p>
              <p className="text-sm mt-2">Create rules to automate alert assignment</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
