import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CalendarIcon, Copy, Check } from 'lucide-react';
import { format } from 'date-fns';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onCreateLink: (config: ShareConfig) => Promise<string>;
  recordingId?: string;
  collectionId?: string;
}

export interface ShareConfig {
  password?: string;
  expires_at?: string;
  max_views?: number;
  allow_download: boolean;
}

export default function ShareRecordingModal({ isOpen, onClose, onCreateLink }: Props) {
  const [password, setPassword] = useState('');
  const [usePassword, setUsePassword] = useState(false);
  const [expiresAt, setExpiresAt] = useState<Date>();
  const [maxViews, setMaxViews] = useState<number>();
  const [allowDownload, setAllowDownload] = useState(true);
  const [shareLink, setShareLink] = useState('');
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleCreateLink = async () => {
    setLoading(true);
    try {
      const config: ShareConfig = {
        password: usePassword ? password : undefined,
        expires_at: expiresAt?.toISOString(),
        max_views: maxViews,
        allow_download: allowDownload,
      };
      const link = await onCreateLink(config);
      setShareLink(link);
    } catch (error) {
      console.error('Error creating share link:', error);
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(shareLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Create Secure Share Link</DialogTitle>
        </DialogHeader>
        
        {!shareLink ? (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="password-protect">Password protect</Label>
              <Switch checked={usePassword} onCheckedChange={setUsePassword} id="password-protect" />
            </div>

            {usePassword && (
              <div>
                <Label htmlFor="password">Password</Label>
                <Input 
                  id="password" 
                  type="password" 
                  value={password} 
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter password"
                />
              </div>
            )}

            <div>
              <Label>Expiration date (optional)</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {expiresAt ? format(expiresAt, 'PPP') : 'No expiration'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar mode="single" selected={expiresAt} onSelect={setExpiresAt} />
                </PopoverContent>
              </Popover>
            </div>

            <div>
              <Label htmlFor="max-views">Max views (optional)</Label>
              <Input 
                id="max-views" 
                type="number" 
                value={maxViews || ''} 
                onChange={(e) => setMaxViews(e.target.value ? parseInt(e.target.value) : undefined)}
                placeholder="Unlimited"
              />
            </div>

            <div className="flex items-center justify-between">
              <Label htmlFor="allow-download">Allow downloads</Label>
              <Switch checked={allowDownload} onCheckedChange={setAllowDownload} id="allow-download" />
            </div>

            <Button onClick={handleCreateLink} disabled={loading} className="w-full">
              {loading ? 'Creating...' : 'Create Link'}
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            <div>
              <Label>Share Link</Label>
              <div className="flex gap-2 mt-2">
                <Input value={shareLink} readOnly />
                <Button onClick={copyToClipboard} size="icon">
                  {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
            </div>
            <Button onClick={onClose} className="w-full">Done</Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
