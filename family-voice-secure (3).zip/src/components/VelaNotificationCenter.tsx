import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase-client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Bell, Check, X, Smartphone, Monitor, Tablet } from 'lucide-react';
import { NotificationHistory } from '@/types/deviceSync';
import { toast } from 'sonner';

export function VelaNotificationCenter() {
  const [notifications, setNotifications] = useState<NotificationHistory[]>([]);
  const [filter, setFilter] = useState<'all' | 'unread'>('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadNotifications();
    
    const channel = supabase
      .channel('notification_updates')
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'notification_history' },
        () => loadNotifications()
      )
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [filter]);

  const loadNotifications = async () => {
    try {
      let query = supabase
        .from('notification_history')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(50);

      if (filter === 'unread') {
        query = query.eq('is_read', false);
      }

      const { data, error } = await query;
      if (error) throw error;
      setNotifications(data || []);
    } catch (error: any) {
      toast.error('Failed to load notifications');
    } finally {
      setLoading(false);
    }
  };

  const markAsRead = async (notificationId: string) => {
    try {
      const deviceId = localStorage.getItem('deviceId') || 'default';
      
      await supabase.functions.invoke('sync-notification-status', {
        body: { notificationId, eventType: 'read', deviceId }
      });
      
      toast.success('Notification marked as read across all devices');
    } catch (error: any) {
      toast.error('Failed to mark as read');
    }
  };

  const dismissNotification = async (notificationId: string) => {
    try {
      const deviceId = localStorage.getItem('deviceId') || 'default';
      
      await supabase.functions.invoke('sync-notification-status', {
        body: { notificationId, eventType: 'dismissed', deviceId }
      });
      
      toast.success('Notification dismissed on all devices');
    } catch (error: any) {
      toast.error('Failed to dismiss notification');
    }
  };

  const unreadCount = notifications.filter(n => !n.is_read).length;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell className="h-5 w-5" />
            Notification Center
            {unreadCount > 0 && (
              <Badge variant="destructive">{unreadCount}</Badge>
            )}
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs value={filter} onValueChange={(v) => setFilter(v as any)}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="unread">Unread ({unreadCount})</TabsTrigger>
          </TabsList>
          <TabsContent value={filter}>
            <ScrollArea className="h-[500px]">
              <div className="space-y-3">
                {notifications.map((notification) => (
                  <NotificationItem
                    key={notification.id}
                    notification={notification}
                    onMarkRead={markAsRead}
                    onDismiss={dismissNotification}
                  />
                ))}
                {notifications.length === 0 && (
                  <p className="text-center text-muted-foreground py-8">
                    No notifications
                  </p>
                )}
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}

function NotificationItem({ notification, onMarkRead, onDismiss }: any) {
  return (
    <div className={`p-4 border rounded-lg ${!notification.is_read ? 'bg-blue-50 border-blue-200' : ''}`}>
      <div className="flex justify-between items-start gap-3">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <h4 className="font-semibold">{notification.title}</h4>
            <Badge variant={notification.urgency_level === 'high' ? 'destructive' : 'secondary'}>
              {notification.urgency_level}
            </Badge>
          </div>
          <p className="text-sm text-muted-foreground">{notification.body}</p>
          <p className="text-xs text-muted-foreground mt-2">
            {new Date(notification.created_at).toLocaleString()}
          </p>
        </div>
        <div className="flex gap-2">
          {!notification.is_read && (
            <Button size="sm" variant="ghost" onClick={() => onMarkRead(notification.id)}>
              <Check className="h-4 w-4" />
            </Button>
          )}
          <Button size="sm" variant="ghost" onClick={() => onDismiss(notification.id)}>
            <X className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
