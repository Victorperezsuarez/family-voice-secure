import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useSubscription } from '@/hooks/useSubscription';
import { supabase } from '@/lib/supabase-client';
import { CreditCard, Download, ExternalLink, Loader2, Clock, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import { format, differenceInDays } from 'date-fns';

interface BillingPortalProps {
  userId: string;
}

export const BillingPortal = ({ userId }: BillingPortalProps) => {
  const { subscription, invoices, loading } = useSubscription(userId);
  const [portalLoading, setPortalLoading] = useState(false);

  const handleManageBilling = async () => {
    try {
      setPortalLoading(true);

      if (!subscription?.stripe_customer_id) {
        toast.error('No active subscription found');
        return;
      }

      const { data, error } = await supabase.functions.invoke('create-billing-portal-session', {
        body: { customerId: subscription.stripe_customer_id }
      });

      if (error) throw error;

      if (data.url) {
        window.location.href = data.url;
      }
    } catch (error) {
      console.error('Portal error:', error);
      toast.error('Failed to open billing portal');
    } finally {
      setPortalLoading(false);
    }
  };

  if (loading) {
    return <div className="flex justify-center p-8"><Loader2 className="h-8 w-8 animate-spin" /></div>;
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500';
      case 'trialing': return 'bg-blue-500';
      case 'past_due': return 'bg-yellow-500';
      case 'canceled': return 'bg-gray-500';
      default: return 'bg-red-500';
    }
  };

  const isTrialing = subscription?.status === 'trialing';
  const trialDaysRemaining = subscription?.trial_end 
    ? differenceInDays(new Date(subscription.trial_end), new Date())
    : 0;

  return (
    <div className="space-y-6">
      {isTrialing && subscription?.trial_end && (
        <Alert className="border-blue-500 bg-blue-50">
          <Clock className="h-4 w-4 text-blue-600" />
          <AlertDescription className="text-blue-900">
            <strong>Free Trial Active:</strong> You have {trialDaysRemaining} days remaining in your trial.
            Your subscription will automatically start on {format(new Date(subscription.trial_end), 'MMM d, yyyy')}.
          </AlertDescription>
        </Alert>
      )}

      {subscription?.cancel_at_period_end && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Your subscription is set to cancel on {format(new Date(subscription.current_period_end), 'MMM d, yyyy')}.
            You can reactivate it anytime before then.
          </AlertDescription>
        </Alert>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Current Subscription</CardTitle>
          <CardDescription>Manage your subscription and billing</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {subscription ? (
            <>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-lg font-semibold capitalize">{subscription.plan_name} Plan</p>
                  <Badge className={getStatusColor(subscription.status)}>{subscription.status}</Badge>
                </div>
                <Button onClick={handleManageBilling} disabled={portalLoading}>
                  {portalLoading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <CreditCard className="h-4 w-4 mr-2" />}
                  Manage Billing
                </Button>
              </div>
              <div className="grid grid-cols-2 gap-4 text-sm">
                {isTrialing ? (
                  <div>
                    <p className="text-muted-foreground">Trial Ends</p>
                    <p className="font-medium text-blue-600">
                      {format(new Date(subscription.trial_end!), 'MMM d, yyyy')}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {trialDaysRemaining} days remaining
                    </p>
                  </div>
                ) : (
                  <div>
                    <p className="text-muted-foreground">Current Period</p>
                    <p className="font-medium">
                      {format(new Date(subscription.current_period_start), 'MMM d, yyyy')} - {format(new Date(subscription.current_period_end), 'MMM d, yyyy')}
                    </p>
                  </div>
                )}
                {subscription.cancel_at_period_end && (
                  <div>
                    <p className="text-muted-foreground">Cancels On</p>
                    <p className="font-medium text-red-600">{format(new Date(subscription.current_period_end), 'MMM d, yyyy')}</p>
                  </div>
                )}
              </div>
            </>
          ) : (
            <div className="text-center py-8">
              <p className="text-muted-foreground mb-4">No active subscription</p>
              <Button onClick={() => window.location.href = '/pricing'}>View Plans</Button>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Invoices</CardTitle>
          <CardDescription>Download your payment history</CardDescription>
        </CardHeader>
        <CardContent>
          {invoices.length > 0 ? (
            <div className="space-y-2">
              {invoices.map((invoice) => (
                <div key={invoice.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <p className="font-medium">${(invoice.amount_paid / 100).toFixed(2)}</p>
                    <p className="text-sm text-muted-foreground">{format(new Date(invoice.created_at), 'MMM d, yyyy')}</p>
                  </div>
                  <div className="flex gap-2">
                    {invoice.invoice_pdf && (
                      <Button size="sm" variant="outline" asChild>
                        <a href={invoice.invoice_pdf} target="_blank" rel="noopener noreferrer">
                          <Download className="h-4 w-4 mr-1" /> PDF
                        </a>
                      </Button>
                    )}
                    {invoice.hosted_invoice_url && (
                      <Button size="sm" variant="outline" asChild>
                        <a href={invoice.hosted_invoice_url} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="h-4 w-4 mr-1" /> View
                        </a>
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-center text-muted-foreground py-8">No invoices yet</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

