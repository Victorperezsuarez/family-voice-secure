import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { PerformanceMetric } from '@/types/performance';

interface PerformanceChartProps {
  metrics: PerformanceMetric[];
  metricType: string;
  title: string;
}

export function PerformanceChart({ metrics, metricType, title }: PerformanceChartProps) {
  const data = metrics
    .filter(m => m.metric_type === metricType)
    .map(m => ({
      time: new Date(m.created_at).toLocaleTimeString(),
      value: parseFloat(m.value.toString()),
      date: m.created_at
    }))
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  return (
    <div className="space-y-2">
      <h4 className="font-medium">{title}</h4>
      <ResponsiveContainer width="100%" height={200}>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="time" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Line type="monotone" dataKey="value" stroke="#8884d8" name={metricType} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
