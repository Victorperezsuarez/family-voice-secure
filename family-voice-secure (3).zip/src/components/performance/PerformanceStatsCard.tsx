import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface PerformanceStatsCardProps {
  title: string;
  current: number;
  baseline?: number;
  unit: string;
  trend?: 'up' | 'down' | 'stable';
}

export function PerformanceStatsCard({ title, current, baseline, unit, trend }: PerformanceStatsCardProps) {
  const deviation = baseline ? ((current - baseline) / baseline) * 100 : 0;
  const isRegression = deviation > 10;

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-baseline justify-between">
          <div className="text-2xl font-bold">
            {current.toFixed(2)} {unit}
          </div>
          {baseline && (
            <Badge variant={isRegression ? 'destructive' : 'secondary'}>
              {deviation > 0 ? '+' : ''}{deviation.toFixed(1)}%
            </Badge>
          )}
        </div>
        {baseline && (
          <p className="text-xs text-muted-foreground mt-1">
            Baseline: {baseline.toFixed(2)} {unit}
          </p>
        )}
        {trend && (
          <div className="flex items-center mt-2 text-xs">
            {trend === 'up' && <TrendingUp className="h-3 w-3 mr-1 text-red-500" />}
            {trend === 'down' && <TrendingDown className="h-3 w-3 mr-1 text-green-500" />}
            {trend === 'stable' && <Minus className="h-3 w-3 mr-1 text-gray-500" />}
            <span className="text-muted-foreground">
              {trend === 'up' ? 'Increasing' : trend === 'down' ? 'Improving' : 'Stable'}
            </span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
