import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ShapValue } from '@/types/explainableAI';
import { MessageSquare } from 'lucide-react';

interface Props {
  segment: string;
  confidence: number;
  shapValues: ShapValue[];
}

export function NaturalLanguageExplanation({ segment, confidence, shapValues }: Props) {
  const topPositive = shapValues.filter(sv => sv.contribution > 0).slice(0, 2);
  const topNegative = shapValues.filter(sv => sv.contribution < 0).slice(0, 2);

  const generateExplanation = () => {
    let explanation = `This user was classified as <strong>${segment.replace('_', ' ')}</strong> with <strong>${(confidence * 100).toFixed(0)}%</strong> confidence. `;

    if (topPositive.length > 0) {
      explanation += `The main factors supporting this prediction are `;
      explanation += topPositive.map(sv => `<strong>${sv.displayName.toLowerCase()}</strong> (${sv.value})`).join(' and ');
      explanation += '. ';
    }

    if (topNegative.length > 0) {
      explanation += `However, `;
      explanation += topNegative.map(sv => `${sv.displayName.toLowerCase()}`).join(' and ');
      explanation += ` ${topNegative.length > 1 ? 'are' : 'is'} working against this classification. `;
    }

    if (confidence > 0.8) {
      explanation += `The model is highly confident in this prediction.`;
    } else if (confidence > 0.6) {
      explanation += `The model has moderate confidence in this prediction.`;
    } else {
      explanation += `The model has low confidence - this user may be transitioning between segments.`;
    }

    return explanation;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MessageSquare className="w-5 h-5" />
          Plain English Explanation
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Badge variant="default" className="text-base px-3 py-1">
              {segment.replace('_', ' ')}
            </Badge>
            <Badge variant="outline" className="text-base px-3 py-1">
              {(confidence * 100).toFixed(0)}% confidence
            </Badge>
          </div>
          
          <p 
            className="text-sm leading-relaxed"
            dangerouslySetInnerHTML={{ __html: generateExplanation() }}
          />
        </div>
      </CardContent>
    </Card>
  );
}
