import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ShapValue } from '@/types/explainableAI';
import { ArrowUp, ArrowDown } from 'lucide-react';

interface Props {
  shapValues: ShapValue[];
  baseValue: number;
  finalValue: number;
}

export function FeatureContributionWaterfall({ shapValues, baseValue, finalValue }: Props) {
  let cumulative = baseValue;
  const contributions = shapValues.map(sv => {
    const start = cumulative;
    cumulative += sv.contribution;
    return { ...sv, start, end: cumulative };
  });

  const maxValue = Math.max(Math.abs(baseValue), Math.abs(finalValue), ...contributions.map(c => Math.abs(c.end)));
  const scale = 300 / maxValue;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Feature Contribution Waterfall</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="flex items-center gap-4">
            <div className="w-40 text-sm font-medium">Base Value</div>
            <div className="flex-1 flex items-center gap-2">
              <div className="h-8 bg-gray-300 rounded" style={{ width: `${Math.abs(baseValue) * scale}px` }} />
              <span className="text-sm">{baseValue.toFixed(3)}</span>
            </div>
          </div>

          {contributions.map((contrib, idx) => (
            <div key={idx} className="flex items-center gap-4">
              <div className="w-40 text-sm truncate">{contrib.displayName}</div>
              <div className="flex-1 flex items-center gap-2">
                <div className="relative h-8 flex items-center" style={{ width: '300px' }}>
                  <div
                    className={`h-8 rounded ${contrib.contribution > 0 ? 'bg-green-500' : 'bg-red-500'}`}
                    style={{
                      width: `${Math.abs(contrib.contribution) * scale}px`,
                      marginLeft: `${Math.min(contrib.start, contrib.end) * scale}px`
                    }}
                  />
                </div>
                <div className="flex items-center gap-1">
                  {contrib.contribution > 0 ? (
                    <ArrowUp className="w-4 h-4 text-green-600" />
                  ) : (
                    <ArrowDown className="w-4 h-4 text-red-600" />
                  )}
                  <span className="text-sm">{contrib.contribution > 0 ? '+' : ''}{contrib.contribution.toFixed(3)}</span>
                </div>
              </div>
            </div>
          ))}

          <div className="flex items-center gap-4 pt-2 border-t">
            <div className="w-40 text-sm font-bold">Final Prediction</div>
            <div className="flex-1 flex items-center gap-2">
              <div className="h-8 bg-blue-500 rounded" style={{ width: `${Math.abs(finalValue) * scale}px` }} />
              <span className="text-sm font-bold">{finalValue.toFixed(3)}</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
