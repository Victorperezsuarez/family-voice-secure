import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/lib/supabase-client';
import { useToast } from '@/hooks/use-toast';

interface InviteCollaboratorModalProps {
  isOpen: boolean;
  onClose: () => void;
  collectionId: string;
  collectionName: string;
}

export function InviteCollaboratorModal({ isOpen, onClose, collectionId, collectionName }: InviteCollaboratorModalProps) {
  const [email, setEmail] = useState('');
  const [permission, setPermission] = useState<'view-only' | 'can-add' | 'can-edit'>('can-add');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleInvite = async () => {
    if (!email.trim()) return;

    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { error } = await supabase.from('collection_invitations').insert({
        collection_id: collectionId,
        inviter_id: user.id,
        invitee_email: email,
        permission_level: permission,
        status: 'pending'
      });

      if (error) throw error;

      await supabase.from('collection_activity').insert({
        collection_id: collectionId,
        user_id: user.id,
        action_type: 'invited_contributor',
        details: { email, permission }
      });

      toast({ title: 'Invitation sent!', description: `Invited ${email} to ${collectionName}` });
      setEmail('');
      onClose();
    } catch (error: any) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Invite Collaborator</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label>Email Address</Label>
            <Input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="family@example.com" />
          </div>
          <div>
            <Label>Permission Level</Label>
            <Select value={permission} onValueChange={(v: any) => setPermission(v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="view-only">View Only</SelectItem>
                <SelectItem value="can-add">Can Add Recordings</SelectItem>
                <SelectItem value="can-edit">Can Edit Collection</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button onClick={handleInvite} disabled={loading} className="w-full">Send Invitation</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
