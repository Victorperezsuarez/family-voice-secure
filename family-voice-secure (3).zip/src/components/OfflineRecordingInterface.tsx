import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Mic, Square, Save, Wifi, WifiOff } from 'lucide-react';
import { useAudioRecorder } from '@/hooks/useAudioRecorder';
import { useOfflineSync } from '@/contexts/OfflineSyncContext';
import { indexedDB } from '@/utils/indexedDB';
import { toast } from 'sonner';

export function OfflineRecordingInterface() {
  const { isRecording, startRecording, stopRecording, audioBlob, duration } = useAudioRecorder();
  const { isOnline, addToQueue } = useOfflineSync();
  const [title, setTitle] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    if (!audioBlob) return;
    
    setIsSaving(true);
    try {
      const recordingId = `offline_${Date.now()}`;
      const recording = {
        id: recordingId,
        title: title || 'Untitled Recording',
        audio_url: URL.createObjectURL(audioBlob),
        audioBlob,
        duration,
        family_id: 'current_family',
        member_id: 'current_user',
        created_at: new Date().toISOString(),
        synced: false
      };

      await indexedDB.addRecording(recording);

      if (isOnline) {
        addToQueue('create_recording', {
          ...recording,
          audioBlob: audioBlob
        });
        toast.success('Recording saved and queued for sync');
      } else {
        toast.success('Recording saved offline. Will sync when online.');
      }

      setTitle('');
    } catch (error) {
      toast.error('Failed to save recording');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Card>
      <CardContent className="p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">Record Audio</h3>
          <Badge variant={isOnline ? 'default' : 'secondary'}>
            {isOnline ? <Wifi className="w-3 h-3 mr-1" /> : <WifiOff className="w-3 h-3 mr-1" />}
            {isOnline ? 'Online' : 'Offline'}
          </Badge>
        </div>

        <div className="flex flex-col items-center gap-4">
          <Button
            size="lg"
            variant={isRecording ? 'destructive' : 'default'}
            className="w-20 h-20 rounded-full"
            onClick={isRecording ? stopRecording : startRecording}
          >
            {isRecording ? <Square className="w-8 h-8" /> : <Mic className="w-8 h-8" />}
          </Button>

          {isRecording && (
            <div className="text-2xl font-mono">{Math.floor(duration / 60)}:{(duration % 60).toString().padStart(2, '0')}</div>
          )}

          {audioBlob && !isRecording && (
            <div className="w-full space-y-3">
              <Input
                placeholder="Recording title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
              <Button onClick={handleSave} disabled={isSaving} className="w-full">
                <Save className="w-4 h-4 mr-2" />
                {isSaving ? 'Saving...' : 'Save Recording'}
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
