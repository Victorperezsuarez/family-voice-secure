import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { AuditRetentionPolicy } from '@/types/retention';
import { Archive, Trash2, Edit, Calendar } from 'lucide-react';

interface RetentionPolicyCardProps {
  policy: AuditRetentionPolicy;
  onEdit: (policy: AuditRetentionPolicy) => void;
  onDelete: (id: string) => void;
  onToggleActive: (id: string, active: boolean) => void;
}

export function RetentionPolicyCard({ policy, onEdit, onDelete, onToggleActive }: RetentionPolicyCardProps) {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-lg">{policy.name}</CardTitle>
            {policy.description && (
              <p className="text-sm text-muted-foreground mt-1">{policy.description}</p>
            )}
          </div>
          <Switch
            checked={policy.is_active}
            onCheckedChange={(checked) => onToggleActive(policy.id, checked)}
          />
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-sm">
            <Calendar className="h-4 w-4 text-muted-foreground" />
            <span>Retention: {policy.retention_days} days</span>
          </div>

          <div className="flex flex-wrap gap-2">
            {policy.category && (
              <Badge variant="outline">Category: {policy.category}</Badge>
            )}
            {policy.severity && (
              <Badge variant="outline">Severity: {policy.severity}</Badge>
            )}
            <Badge variant={policy.archive_enabled ? 'default' : 'secondary'}>
              {policy.archive_enabled ? 'Archive Enabled' : 'No Archive'}
            </Badge>
            <Badge variant="outline">Priority: {policy.priority}</Badge>
          </div>

          {policy.archive_enabled && (
            <div className="text-sm text-muted-foreground">
              <Archive className="h-3 w-3 inline mr-1" />
              Location: {policy.archive_location}
              {policy.auto_delete_after_archive && ' (Auto-delete after archive)'}
            </div>
          )}

          <div className="flex gap-2 pt-2">
            <Button size="sm" variant="outline" onClick={() => onEdit(policy)}>
              <Edit className="h-4 w-4 mr-1" />
              Edit
            </Button>
            <Button size="sm" variant="destructive" onClick={() => onDelete(policy.id)}>
              <Trash2 className="h-4 w-4 mr-1" />
              Delete
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
