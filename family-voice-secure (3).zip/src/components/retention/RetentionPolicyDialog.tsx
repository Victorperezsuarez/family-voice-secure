import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { AuditRetentionPolicy } from '@/types/retention';

interface RetentionPolicyDialogProps {
  open: boolean;
  onClose: () => void;
  onSave: (policy: Partial<AuditRetentionPolicy>) => void;
  policy?: AuditRetentionPolicy;
}

export function RetentionPolicyDialog({ open, onClose, onSave, policy }: RetentionPolicyDialogProps) {
  const [formData, setFormData] = useState<Partial<AuditRetentionPolicy>>({
    name: '',
    description: '',
    retention_days: 90,
    archive_enabled: true,
    archive_location: 'supabase_storage',
    auto_delete_after_archive: false,
    is_active: true,
    priority: 0
  });

  useEffect(() => {
    if (policy) {
      setFormData(policy);
    }
  }, [policy]);

  const handleSubmit = () => {
    onSave(formData);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{policy ? 'Edit' : 'Create'} Retention Policy</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <Label>Policy Name</Label>
            <Input
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="e.g., Critical Security Events"
            />
          </div>

          <div>
            <Label>Description</Label>
            <Textarea
              value={formData.description || ''}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Describe this retention policy..."
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Retention Days</Label>
              <Input
                type="number"
                value={formData.retention_days}
                onChange={(e) => setFormData({ ...formData, retention_days: parseInt(e.target.value) })}
              />
            </div>

            <div>
              <Label>Priority</Label>
              <Input
                type="number"
                value={formData.priority}
                onChange={(e) => setFormData({ ...formData, priority: parseInt(e.target.value) })}
              />
            </div>
          </div>

          <div className="flex items-center justify-between">
            <Label>Archive Enabled</Label>
            <Switch
              checked={formData.archive_enabled}
              onCheckedChange={(checked) => setFormData({ ...formData, archive_enabled: checked })}
            />
          </div>

          {formData.archive_enabled && (
            <>
              <div>
                <Label>Archive Location</Label>
                <Select
                  value={formData.archive_location}
                  onValueChange={(value) => setFormData({ ...formData, archive_location: value as any })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="supabase_storage">Supabase Storage</SelectItem>
                    <SelectItem value="external_s3">External S3</SelectItem>
                    <SelectItem value="external_gcs">External GCS</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between">
                <Label>Auto-delete after archive</Label>
                <Switch
                  checked={formData.auto_delete_after_archive}
                  onCheckedChange={(checked) => setFormData({ ...formData, auto_delete_after_archive: checked })}
                />
              </div>
            </>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSubmit}>Save Policy</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
