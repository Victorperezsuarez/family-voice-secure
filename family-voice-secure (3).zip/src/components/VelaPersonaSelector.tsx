import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase-client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Plus, Home, Briefcase, Check } from 'lucide-react';
import { VelaPersona, VELA_PROFESSIONS } from '@/types/vela';
import { toast } from 'sonner';

interface VelaPersonaSelectorProps {
  onPersonaSelect: (persona: VelaPersona) => void;
  onCreateNew: () => void;
}

export function VelaPersonaSelector({ onPersonaSelect, onCreateNew }: VelaPersonaSelectorProps) {
  const [personas, setPersonas] = useState<VelaPersona[]>([]);
  const [activePersona, setActivePersona] = useState<VelaPersona | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPersonas();
  }, []);

  const loadPersonas = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('vela_personas')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;

      setPersonas(data || []);
      const active = data?.find(p => p.is_active);
      if (active) setActivePersona(active);
    } catch (error) {
      console.error('Error loading personas:', error);
      toast.error('Failed to load Vela personas');
    } finally {
      setLoading(false);
    }
  };

  const activatePersona = async (persona: VelaPersona) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      await supabase
        .from('vela_personas')
        .update({ is_active: false })
        .eq('user_id', user.id);

      const { error } = await supabase
        .from('vela_personas')
        .update({ is_active: true })
        .eq('id', persona.id);

      if (error) throw error;

      setActivePersona(persona);
      onPersonaSelect(persona);
      toast.success(`Activated ${persona.name}`);
    } catch (error) {
      console.error('Error activating persona:', error);
      toast.error('Failed to activate persona');
    }
  };

  const getCategoryIcon = (category: string) => {
    if (category === 'house') return <Home className="h-4 w-4" />;
    if (category === 'work') return <Briefcase className="h-4 w-4" />;
    return null;
  };

  const getProfessionIcon = (profession?: string) => {
    if (!profession) return null;
    return VELA_PROFESSIONS[profession as keyof typeof VELA_PROFESSIONS]?.icon || '👤';
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Vela Personas</CardTitle>
        <CardDescription>Select a persona for context-aware assistance</CardDescription>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[400px] pr-4">
          <div className="space-y-3">
            {personas.map((persona) => (
              <Card
                key={persona.id}
                className={`cursor-pointer transition-all hover:shadow-md ${
                  activePersona?.id === persona.id ? 'ring-2 ring-primary' : ''
                }`}
                onClick={() => activatePersona(persona)}
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <div className="text-2xl">
                        {getProfessionIcon(persona.profession)}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-semibold">{persona.name}</h3>
                          {activePersona?.id === persona.id && (
                            <Check className="h-4 w-4 text-primary" />
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">
                          {persona.description}
                        </p>
                        <div className="flex gap-2 mt-2">
                          <Badge variant="outline" className="flex items-center gap-1">
                            {getCategoryIcon(persona.category)}
                            <span className="capitalize">{persona.category}</span>
                          </Badge>
                          {persona.profession && (
                            <Badge variant="secondary">{persona.profession}</Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </ScrollArea>

        <Button onClick={onCreateNew} className="w-full mt-4">
          <Plus className="h-4 w-4 mr-2" />
          Create New Persona
        </Button>
      </CardContent>
    </Card>
  );
}
