import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Mic, Camera, Users, Clock } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { OfflineRecordingInterface } from './OfflineRecordingInterface';
import { OfflineStorageManager } from './OfflineStorageManager';
import { OfflineQueueManager } from './OfflineQueueManager';
import { EnhancedOfflineIndicator } from './EnhancedOfflineIndicator';

export function MobileHome() {
  const navigate = useNavigate();

  const quickActions = [
    { icon: Mic, label: 'Record', path: '/record', color: 'bg-red-500' },
    { icon: Camera, label: 'Photos', path: '/photos', color: 'bg-blue-500' },
    { icon: Users, label: 'Family', path: '/family', color: 'bg-green-500' },
    { icon: Clock, label: 'Timeline', path: '/timeline', color: 'bg-purple-500' },
  ];

  return (
    <div className="p-4 space-y-6 pb-24">
      <EnhancedOfflineIndicator />
      
      <div className="text-center">
        <h1 className="text-3xl font-bold text-amber-900 mb-2">Vela Family Memories</h1>
        <p className="text-gray-600">Capture and preserve your family stories</p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {quickActions.map((action) => (
          <Button
            key={action.label}
            onClick={() => navigate(action.path)}
            variant="outline"
            className={`h-24 flex flex-col items-center justify-center gap-2 ${action.color} text-white border-0 shadow-lg hover:opacity-90`}
          >
            <action.icon className="w-8 h-8" />
            <span className="text-sm font-medium">{action.label}</span>
          </Button>
        ))}
      </div>

      <OfflineRecordingInterface />
      
      <div className="grid gap-4">
        <OfflineStorageManager />
        <OfflineQueueManager />
      </div>
    </div>
  );
}
