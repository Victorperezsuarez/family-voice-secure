import { useState } from 'react';
import { supabase } from '@/lib/supabase-client';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { useToast } from '@/hooks/use-toast';

interface Props {
  familyId: string;
  familyName: string;
  onClose: () => void;
}

export function InviteMemberModal({ familyId, familyName, onClose }: Props) {
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<'admin' | 'contributor' | 'view-only'>('contributor');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleInvite = async () => {
    if (!email) return;

    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Call edge function to send invitation
      const { data, error } = await supabase.functions.invoke('send-family-invitation', {
        body: { 
          familyId, 
          email, 
          role,
          invitedByName: user.email,
          familyName 
        }
      });

      if (error) throw error;

      // Save invitation to database
      await supabase.from('family_invitations').insert({
        family_id: familyId,
        invited_by: user.id,
        email,
        role,
        token: data.token,
        status: 'pending'
      });

      toast({
        title: 'Invitation sent',
        description: `Invitation sent to ${email}`
      });

      onClose();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Invite Family Member</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label htmlFor="email">Email Address</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="member@example.com"
            />
          </div>
          <div>
            <Label htmlFor="role">Role</Label>
            <Select value={role} onValueChange={(v: any) => setRole(v)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="view-only">View Only</SelectItem>
                <SelectItem value="contributor">Contributor</SelectItem>
                <SelectItem value="admin">Admin</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex gap-2">
            <Button onClick={handleInvite} disabled={loading}>
              Send Invitation
            </Button>
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
