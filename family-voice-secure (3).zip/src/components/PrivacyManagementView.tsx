import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Shield, Link as LinkIcon, CheckCircle, Heart } from 'lucide-react';
import ApprovalWorkflowPanel from './ApprovalWorkflowPanel';
import CreateMemorialModal, { MemorialData } from './CreateMemorialModal';
import { FamilyMember } from '@/types/family';
import { supabase } from '@/lib/supabase-client';
import { useToast } from '@/hooks/use-toast';

interface Props {
  familyMembers: FamilyMember[];
}

export default function PrivacyManagementView({ familyMembers }: Props) {
  const [showMemorialModal, setShowMemorialModal] = useState(false);
  const { toast } = useToast();

  const handleCreateMemorial = async (memorial: MemorialData) => {
    const { data: user } = await supabase.auth.getUser();
    if (!user.user) return;

    // Generate slug from title
    const slug = memorial.title.toLowerCase().replace(/[^a-z0-9]+/g, '-');

    const { error } = await supabase.from('memorial_pages').insert({
      ...memorial,
      created_by: user.user.id,
      slug,
      birth_date: memorial.birth_date?.toISOString().split('T')[0],
      death_date: memorial.death_date?.toISOString().split('T')[0],
    });

    if (error) {
      toast({ title: 'Error', description: 'Failed to create memorial page', variant: 'destructive' });
      return;
    }

    toast({ title: 'Success', description: 'Memorial page created successfully' });
    setShowMemorialModal(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold text-amber-900 flex items-center gap-3">
          <Shield className="w-8 h-8" />
          Privacy & Sharing
        </h2>
      </div>

      <Tabs defaultValue="approvals" className="w-full">
        <TabsList className="grid w-full grid-cols-2 max-w-md">
          <TabsTrigger value="approvals">Approvals</TabsTrigger>
          <TabsTrigger value="memorials">Memorial Pages</TabsTrigger>
        </TabsList>

        <TabsContent value="approvals" className="mt-6">
          <ApprovalWorkflowPanel />
        </TabsContent>

        <TabsContent value="memorials" className="mt-6">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <p className="text-muted-foreground">Create beautiful memorial pages for loved ones</p>
              <Button onClick={() => setShowMemorialModal(true)}>
                <Heart className="w-4 h-4 mr-2" />
                Create Memorial
              </Button>
            </div>
          </div>
        </TabsContent>
      </Tabs>

      <CreateMemorialModal
        isOpen={showMemorialModal}
        onClose={() => setShowMemorialModal(false)}
        onSave={handleCreateMemorial}
        familyMembers={familyMembers}
      />
    </div>
  );
}
