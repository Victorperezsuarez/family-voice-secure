import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase-client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Download, TrendingUp, Users, Activity, Radio } from 'lucide-react';
import UsageTrendsChart from '@/components/analytics/UsageTrendsChart';
import FeatureAdoptionChart from '@/components/analytics/FeatureAdoptionChart';
import LicenseDistributionChart from '@/components/analytics/LicenseDistributionChart';
import LiveActivityFeed from '@/components/analytics/LiveActivityFeed';
import { useRealtimeAnalytics } from '@/hooks/useRealtimeAnalytics';
import { toast } from 'sonner';


interface TemplateUsageAnalyticsProps {
  templateId: string;
}

export default function TemplateUsageAnalytics({ templateId }: TemplateUsageAnalyticsProps) {
  const [analytics, setAnalytics] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [dateRange] = useState({
    start: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    end: new Date().toISOString().split('T')[0]
  });
  
  // Real-time analytics hook
  const { analytics: realtimeData, isLive } = useRealtimeAnalytics(templateId);


  useEffect(() => {
    fetchAnalytics();
  }, [templateId]);

  const fetchAnalytics = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('get-usage-analytics', {
        body: { 
          templateId, 
          startDate: dateRange.start, 
          endDate: dateRange.end 
        }
      });

      if (error) throw error;
      setAnalytics(data);
    } catch (error: any) {
      toast.error('Failed to load analytics');
    } finally {
      setLoading(false);
    }
  };

  const exportAnalytics = () => {
    const csv = convertToCSV(analytics);
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `template-analytics-${templateId}-${Date.now()}.csv`;
    a.click();
    toast.success('Analytics exported');
  };

  const convertToCSV = (data: any) => {
    let csv = 'Date,Active Users,New Installations,Total Events\n';
    data.dailyStats?.forEach((stat: any) => {
      csv += `${stat.date},${stat.active_users},${stat.new_installations},${stat.total_events}\n`;
    });
    return csv;
  };

  if (loading) return <div>Loading analytics...</div>;
  if (!analytics) return <div>No analytics data</div>;

  const totalUsers = analytics.dailyStats?.reduce((sum: number, s: any) => sum + s.active_users, 0) || 0;
  const totalInstalls = analytics.dailyStats?.reduce((sum: number, s: any) => sum + s.new_installations, 0) || 0;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Usage Analytics</h2>
        <Button onClick={exportAnalytics}>
          <Download className="w-4 h-4 mr-2" />
          Export Data
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalUsers}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Installations</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalInstalls}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Conversions</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analytics.conversions?.length || 0}</div>
          </CardContent>
        </Card>
        <Card className={isLive ? 'border-green-500' : ''}>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Active Now</CardTitle>
            <Radio className={`h-4 w-4 ${isLive ? 'text-green-500 animate-pulse' : 'text-muted-foreground'}`} />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{realtimeData.activeSessions}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {isLive ? 'Live updates' : 'Connecting...'}
            </p>
          </CardContent>
        </Card>
      </div>

      <LiveActivityFeed events={realtimeData.recentEvents} isLive={isLive} />


      <UsageTrendsChart data={analytics.dailyStats || []} />
      <FeatureAdoptionChart data={analytics.featureUsage || []} />
      <LicenseDistributionChart data={{
        personal: analytics.dailyStats?.[0]?.personal_licenses || 0,
        commercial: analytics.dailyStats?.[0]?.commercial_licenses || 0,
        enterprise: analytics.dailyStats?.[0]?.enterprise_licenses || 0
      }} />
    </div>
  );
}
