import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Home, Mic2, Users, Image, Play } from 'lucide-react';
import { MobileHome } from './MobileHome';
import { MobileRecordingInterface } from './MobileRecordingInterface';
import { FamilyWorkspace } from './FamilyWorkspace';
import { EnhancedPhotoGallery } from './EnhancedPhotoGallery';
import { AudiobookLibrary } from './AudiobookLibrary';
import { useAuth } from '@/contexts/AuthContext';
import { EnhancedOfflineIndicator } from './EnhancedOfflineIndicator';
import { OfflineSyncBanner } from './OfflineSyncBanner';
import { ConflictResolutionManager } from './ConflictResolutionManager';

export default function MobileAppLayout() {
  const [activeTab, setActiveTab] = useState('home');
  const { user } = useAuth();

  const renderContent = () => {
    switch (activeTab) {
      case 'home': return <MobileHome />;
      case 'record': return <MobileRecordingInterface />;
      case 'family': return <FamilyWorkspace />;
      case 'photos': return user ? <EnhancedPhotoGallery familyId={user.id} /> : null;
      case 'audiobooks': return <AudiobookLibrary />;
      default: return <MobileHome />;
    }
  };

  const tabs = [
    { id: 'home', icon: Home, label: 'Home' },
    { id: 'record', icon: Mic2, label: 'Record' },
    { id: 'family', icon: Users, label: 'Family' },
    { id: 'photos', icon: Image, label: 'Photos' },
    { id: 'audiobooks', icon: Play, label: 'Audio' }
  ];

  return (
    <div className="h-screen flex flex-col bg-gradient-to-br from-amber-50 to-orange-50">
      <EnhancedOfflineIndicator />
      <OfflineSyncBanner />
      <ConflictResolutionManager />
      
      <div className="flex-1 overflow-y-auto pb-20">{renderContent()}</div>
      
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg">
        <div className="flex justify-around items-center h-16 px-2">
          {tabs.map(tab => (
            <Button key={tab.id} variant="ghost" onClick={() => setActiveTab(tab.id)}
              className={`flex flex-col items-center gap-1 h-full flex-1 ${activeTab === tab.id ? 'text-amber-600 bg-amber-50' : 'text-gray-600'}`}>
              <tab.icon className="w-6 h-6" />
              <span className="text-xs">{tab.label}</span>
            </Button>
          ))}
        </div>
      </div>
    </div>
  );
}
