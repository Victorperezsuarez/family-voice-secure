import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';

interface CreateCollectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: { name: string; description: string; cover_image_url: string }) => void;
}

const coverImages = [
  'https://d64gsuwffb70l.cloudfront.net/69010a7a5325e92f2828d404_1762356443084_f583ecad.webp',
  'https://d64gsuwffb70l.cloudfront.net/69010a7a5325e92f2828d404_1762356444062_ff23434e.webp',
  'https://d64gsuwffb70l.cloudfront.net/69010a7a5325e92f2828d404_1762356444883_ea063b31.webp',
];

export function CreateCollectionModal({ isOpen, onClose, onSubmit }: CreateCollectionModalProps) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [selectedCover, setSelectedCover] = useState(coverImages[0]);

  const handleSubmit = () => {
    if (name.trim()) {
      onSubmit({ name, description, cover_image_url: selectedCover });
      setName('');
      setDescription('');
      setSelectedCover(coverImages[0]);
      onClose();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Create New Collection</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label htmlFor="name">Collection Name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Grandma's War Stories"
            />
          </div>
          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe this collection..."
              rows={3}
            />
          </div>
          <div>
            <Label>Cover Image</Label>
            <div className="grid grid-cols-3 gap-2 mt-2">
              {coverImages.map((img) => (
                <div
                  key={img}
                  onClick={() => setSelectedCover(img)}
                  className={`cursor-pointer rounded-lg overflow-hidden border-2 ${
                    selectedCover === img ? 'border-blue-500' : 'border-gray-200'
                  }`}
                >
                  <img src={img} alt="Cover" className="w-full h-20 object-cover" />
                </div>
              ))}
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSubmit}>Create</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
