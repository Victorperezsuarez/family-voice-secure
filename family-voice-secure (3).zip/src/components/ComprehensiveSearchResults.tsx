import { useState, useEffect } from 'react';
import { SearchResult } from '@/types/search';
import { SearchResultItem } from './SearchResultItem';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Clock, User, Calendar } from 'lucide-react';

interface ComprehensiveSearchResultsProps {
  results: SearchResult[];
  onPlayFromTimestamp: (recordingId: string, timestamp: number) => void;
  onViewTranscription: (transcriptionId: string, timestamp: number) => void;
}

export const ComprehensiveSearchResults = ({
  results,
  onPlayFromTimestamp,
  onViewTranscription,
}: ComprehensiveSearchResultsProps) => {
  const [filteredResults, setFilteredResults] = useState(results);
  const [selectedSpeaker, setSelectedSpeaker] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'relevance' | 'date' | 'speaker'>('relevance');

  const speakers = Array.from(new Set(results.map((r) => r.speaker).filter(Boolean)));

  useEffect(() => {
    let filtered = [...results];

    if (selectedSpeaker !== 'all') {
      filtered = filtered.filter((r) => r.speaker === selectedSpeaker);
    }

    filtered.sort((a, b) => {
      if (sortBy === 'relevance') return b.matchScore - a.matchScore;
      if (sortBy === 'date') return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      if (sortBy === 'speaker') return (a.speaker || '').localeCompare(b.speaker || '');
      return 0;
    });

    setFilteredResults(filtered);
  }, [results, selectedSpeaker, sortBy]);

  const groupByRecording = () => {
    const grouped: { [key: string]: SearchResult[] } = {};
    filteredResults.forEach((result) => {
      if (!grouped[result.recordingId]) {
        grouped[result.recordingId] = [];
      }
      grouped[result.recordingId].push(result);
    });
    return grouped;
  };

  const groupedByRecording = groupByRecording();

  return (
    <div className="space-y-4">
      <Card className="p-4">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <User className="h-4 w-4 text-muted-foreground" />
              <Select value={selectedSpeaker} onValueChange={setSelectedSpeaker}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="All speakers" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All speakers</SelectItem>
                  {speakers.map((speaker) => (
                    <SelectItem key={speaker} value={speaker!}>
                      {speaker}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-muted-foreground" />
              <Select value={sortBy} onValueChange={(v: any) => setSortBy(v)}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="relevance">Most Relevant</SelectItem>
                  <SelectItem value="date">Most Recent</SelectItem>
                  <SelectItem value="speaker">By Speaker</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Badge variant="secondary">
            {filteredResults.length} {filteredResults.length === 1 ? 'result' : 'results'}
          </Badge>
        </div>
      </Card>

      <Tabs defaultValue="list" className="w-full">
        <TabsList>
          <TabsTrigger value="list">List View</TabsTrigger>
          <TabsTrigger value="grouped">By Recording</TabsTrigger>
        </TabsList>

        <TabsContent value="list" className="space-y-3 mt-4">
          {filteredResults.map((result) => (
            <SearchResultItem
              key={result.id}
              result={result}
              onPlayFromTimestamp={onPlayFromTimestamp}
              onViewTranscription={onViewTranscription}
            />
          ))}
        </TabsContent>

        <TabsContent value="grouped" className="space-y-4 mt-4">
          {Object.entries(groupedByRecording).map(([recordingId, recordingResults]) => (
            <Card key={recordingId} className="p-4">
              <h3 className="font-semibold mb-3">{recordingResults[0].title}</h3>
              <div className="space-y-2">
                {recordingResults.map((result) => (
                  <SearchResultItem
                    key={result.id}
                    result={result}
                    onPlayFromTimestamp={onPlayFromTimestamp}
                    onViewTranscription={onViewTranscription}
                  />
                ))}
              </div>
            </Card>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  );
};
