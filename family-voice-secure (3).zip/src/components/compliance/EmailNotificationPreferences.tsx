import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/lib/supabase-client';
import { useToast } from '@/hooks/use-toast';
import { Bell, Mail, Save } from 'lucide-react';
import type { EmailNotificationPreferences } from '@/types/emailNotifications';

export function EmailNotificationPreferences() {
  const [preferences, setPreferences] = useState<EmailNotificationPreferences | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadPreferences();
  }, []);

  const loadPreferences = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('email_notification_preferences')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') throw error;

      if (data) {
        setPreferences(data);
      } else {
        setPreferences({
          user_id: user.id,
          report_generated: true,
          certificate_expiring: true,
          weekly_digest: true,
          policy_violations: true,
          archival_failures: true,
          digest_frequency: 'weekly',
          digest_day_of_week: 1,
          expiry_warning_days: 30,
          include_attachments: true,
          pdf_format: true
        } as any);
      }
    } catch (error: any) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const savePreferences = async () => {
    if (!preferences) return;
    setSaving(true);
    try {
      const { error } = await supabase
        .from('email_notification_preferences')
        .upsert(preferences);

      if (error) throw error;

      toast({ title: 'Success', description: 'Preferences saved successfully' });
    } catch (error: any) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <div>Loading...</div>;
  if (!preferences) return null;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="w-5 h-5" />
            Notification Types
          </CardTitle>
          <CardDescription>Choose which emails you want to receive</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <Label htmlFor="report-gen">Report Generated</Label>
            <Switch
              id="report-gen"
              checked={preferences.report_generated}
              onCheckedChange={(checked) => 
                setPreferences({ ...preferences, report_generated: checked })
              }
            />
          </div>
          <div className="flex items-center justify-between">
            <Label htmlFor="cert-exp">Certificate Expiring</Label>
            <Switch
              id="cert-exp"
              checked={preferences.certificate_expiring}
              onCheckedChange={(checked) => 
                setPreferences({ ...preferences, certificate_expiring: checked })
              }
            />
          </div>
          <div className="flex items-center justify-between">
            <Label htmlFor="digest">Weekly Digest</Label>
            <Switch
              id="digest"
              checked={preferences.weekly_digest}
              onCheckedChange={(checked) => 
                setPreferences({ ...preferences, weekly_digest: checked })
              }
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mail className="w-5 h-5" />
            Email Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>Email Address (optional override)</Label>
            <Input
              type="email"
              value={preferences.email_address || ''}
              onChange={(e) => setPreferences({ ...preferences, email_address: e.target.value })}
              placeholder="Use account email"
            />
          </div>
          <div>
            <Label>Digest Frequency</Label>
            <Select
              value={preferences.digest_frequency}
              onValueChange={(value: any) => 
                setPreferences({ ...preferences, digest_frequency: value })
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="daily">Daily</SelectItem>
                <SelectItem value="weekly">Weekly</SelectItem>
                <SelectItem value="monthly">Monthly</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Certificate Expiry Warning (days before)</Label>
            <Input
              type="number"
              value={preferences.expiry_warning_days}
              onChange={(e) => 
                setPreferences({ ...preferences, expiry_warning_days: parseInt(e.target.value) })
              }
            />
          </div>
        </CardContent>
      </Card>

      <Button onClick={savePreferences} disabled={saving} className="w-full">
        <Save className="w-4 h-4 mr-2" />
        {saving ? 'Saving...' : 'Save Preferences'}
      </Button>
    </div>
  );
}
