import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';
import { Plus, Trash2 } from 'lucide-react';

interface ABTestCreationDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  templates: any[];
  onTestCreated: () => void;
}

export default function ABTestCreationDialog({ open, onOpenChange, templates, onTestCreated }: ABTestCreationDialogProps) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [variants, setVariants] = useState<{ templateId: string; allocation: number }[]>([
    { templateId: '', allocation: 50 },
    { templateId: '', allocation: 50 }
  ]);
  const [primaryMetric, setPrimaryMetric] = useState('conversion_rate');
  const [targetSampleSize, setTargetSampleSize] = useState(1000);
  const [confidenceLevel, setConfidenceLevel] = useState(95);
  const [autoSelectWinner, setAutoSelectWinner] = useState(true);
  const [loading, setLoading] = useState(false);

  const addVariant = () => {
    const newAllocation = Math.floor(100 / (variants.length + 1));
    const updatedVariants = variants.map(v => ({ ...v, allocation: newAllocation }));
    setVariants([...updatedVariants, { templateId: '', allocation: newAllocation }]);
  };

  const removeVariant = (index: number) => {
    if (variants.length <= 2) return;
    const updated = variants.filter((_, i) => i !== index);
    const equalAllocation = Math.floor(100 / updated.length);
    setVariants(updated.map(v => ({ ...v, allocation: equalAllocation })));
  };

  const updateAllocation = (index: number, value: number) => {
    const updated = [...variants];
    updated[index].allocation = value;
    setVariants(updated);
  };

  const createTest = async () => {
    if (!name || variants.some(v => !v.templateId)) {
      toast.error('Please fill in all fields');
      return;
    }

    const totalAllocation = variants.reduce((sum, v) => sum + v.allocation, 0);
    if (Math.abs(totalAllocation - 100) > 0.1) {
      toast.error('Traffic allocation must sum to 100%');
      return;
    }

    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      const trafficAllocation = variants.reduce((acc, v) => ({ ...acc, [v.templateId]: v.allocation }), {});

      const { error } = await supabase.functions.invoke('create-ab-test', {
        body: {
          name,
          description,
          templateIds: variants.map(v => v.templateId),
          trafficAllocation,
          successMetrics: { primary: primaryMetric },
          targetSampleSize,
          confidenceLevel: confidenceLevel / 100,
          autoSelectWinner,
          userId: user?.id
        }
      });

      if (error) throw error;
      toast.success('A/B test created successfully');
      onTestCreated();
      onOpenChange(false);
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create A/B Test</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label>Test Name</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Holiday notification test" />
          </div>
          <div>
            <Label>Description</Label>
            <Textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Testing different notification styles..." />
          </div>
          <div>
            <Label>Variants</Label>
            {variants.map((variant, index) => (
              <div key={index} className="flex gap-2 mt-2">
                <Select value={variant.templateId} onValueChange={(val) => {
                  const updated = [...variants];
                  updated[index].templateId = val;
                  setVariants(updated);
                }}>
                  <SelectTrigger className="flex-1">
                    <SelectValue placeholder="Select template" />
                  </SelectTrigger>
                  <SelectContent>
                    {templates.map(t => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}
                  </SelectContent>
                </Select>
                <div className="w-32">
                  <Input type="number" value={variant.allocation} onChange={(e) => updateAllocation(index, parseInt(e.target.value))} />
                </div>
                {variants.length > 2 && <Button variant="ghost" size="icon" onClick={() => removeVariant(index)}><Trash2 className="h-4 w-4" /></Button>}
              </div>
            ))}
            <Button variant="outline" size="sm" onClick={addVariant} className="mt-2"><Plus className="h-4 w-4 mr-2" />Add Variant</Button>
          </div>
          <div>
            <Label>Primary Success Metric</Label>
            <Select value={primaryMetric} onValueChange={setPrimaryMetric}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="conversion_rate">Conversion Rate</SelectItem>
                <SelectItem value="click_rate">Click Rate</SelectItem>
                <SelectItem value="action_rate">Action Rate</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Target Sample Size: {targetSampleSize}</Label>
            <Slider value={[targetSampleSize]} onValueChange={([val]) => setTargetSampleSize(val)} min={100} max={10000} step={100} />
          </div>
          <div>
            <Label>Confidence Level: {confidenceLevel}%</Label>
            <Slider value={[confidenceLevel]} onValueChange={([val]) => setConfidenceLevel(val)} min={90} max={99} step={1} />
          </div>
          <div className="flex items-center justify-between">
            <Label>Auto-select winner</Label>
            <Switch checked={autoSelectWinner} onCheckedChange={setAutoSelectWinner} />
          </div>
          <Button onClick={createTest} disabled={loading} className="w-full">{loading ? 'Creating...' : 'Create Test'}</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
