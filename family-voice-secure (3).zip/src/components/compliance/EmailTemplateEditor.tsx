import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';
import { Save, Send, Eye, Code, Type, History, Brain } from 'lucide-react';
import { EmailEngagementPredictor } from './EmailEngagementPredictor';
import { SuggestedVariation } from '@/types/emailEngagement';


interface EmailTemplate {
  id: string;
  name: string;
  subject: string;
  html_content: string;
  text_content: string;
  variables: string[];
}

interface EmailTemplateEditorProps {
  templateId?: string;
  onSave?: () => void;
}

const AVAILABLE_VARIABLES = [
  { key: 'user_name', label: 'User Name' },
  { key: 'organization_name', label: 'Organization Name' },
  { key: 'report_date', label: 'Report Date' },
  { key: 'compliance_score', label: 'Compliance Score' },
  { key: 'certificate_expiry_date', label: 'Certificate Expiry Date' },
  { key: 'report_url', label: 'Report URL' },
  { key: 'total_logs', label: 'Total Logs' },
  { key: 'archived_logs', label: 'Archived Logs' }
];

export function EmailTemplateEditor({ templateId, onSave }: EmailTemplateEditorProps) {
  const [template, setTemplate] = useState<Partial<EmailTemplate>>({
    name: '',
    subject: '',
    html_content: '',
    text_content: '',
    variables: []
  });
  const [testEmail, setTestEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [previewMode, setPreviewMode] = useState(false);

  useEffect(() => {
    if (templateId) loadTemplate();
  }, [templateId]);

  const loadTemplate = async () => {
    const { data, error } = await supabase
      .from('email_templates')
      .select('*')
      .eq('id', templateId)
      .single();

    if (error) {
      toast.error('Failed to load template');
      return;
    }

    setTemplate(data);
  };

  const insertVariable = (variable: string) => {
    const textarea = document.getElementById('html-content') as HTMLTextAreaElement;
    const start = textarea?.selectionStart || 0;
    const end = textarea?.selectionEnd || 0;
    const text = template.html_content || '';
    const before = text.substring(0, start);
    const after = text.substring(end);
    
    setTemplate({
      ...template,
      html_content: `${before}{{${variable}}}${after}`
    });
  };

  const handleSave = async () => {
    setLoading(true);
    try {
      if (templateId) {
        const { error } = await supabase
          .from('email_templates')
          .update(template)
          .eq('id', templateId);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('email_templates')
          .insert([template]);

        if (error) throw error;
      }

      toast.success('Template saved successfully');
      onSave?.();
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleTest = async () => {
    if (!testEmail) {
      toast.error('Please enter a test email address');
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('test-email-template', {
        body: {
          templateId,
          testEmail,
          variables: {
            user_name: 'Test User',
            organization_name: 'Test Org',
            report_date: new Date().toLocaleDateString(),
            compliance_score: '95',
            total_logs: '1000',
            archived_logs: '950'
          }
        }
      });

      if (error) throw error;
      toast.success('Test email sent successfully');
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateABTest = (variation: SuggestedVariation) => {
    toast.success(`Creating A/B test for ${variation.element}`);
    // Integration with A/B testing system
  };

  return (

    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label>Template Name</Label>
          <Input
            value={template.name}
            onChange={(e) => setTemplate({ ...template, name: e.target.value })}
            placeholder="e.g., GDPR Compliance Report"
          />
        </div>
        <div>
          <Label>Email Subject</Label>
          <Input
            value={template.subject}
            onChange={(e) => setTemplate({ ...template, subject: e.target.value })}
            placeholder="e.g., Your {{report_date}} Compliance Report"
          />
        </div>
      </div>

      <Card className="p-4">
        <h3 className="font-semibold mb-3">Available Variables</h3>
        <div className="flex flex-wrap gap-2">
          {AVAILABLE_VARIABLES.map((v) => (
            <Badge
              key={v.key}
              variant="outline"
              className="cursor-pointer hover:bg-primary hover:text-primary-foreground"
              onClick={() => insertVariable(v.key)}
            >
              {v.label}
            </Badge>
          ))}
        </div>
      </Card>

      <Tabs defaultValue="editor">
        <TabsList>
          <TabsTrigger value="editor"><Code className="w-4 h-4 mr-2" />Editor</TabsTrigger>
          <TabsTrigger value="preview"><Eye className="w-4 h-4 mr-2" />Preview</TabsTrigger>
        </TabsList>

        <TabsContent value="editor" className="space-y-4">
          <div>
            <Label>HTML Content</Label>
            <Textarea
              id="html-content"
              value={template.html_content}
              onChange={(e) => setTemplate({ ...template, html_content: e.target.value })}
              rows={15}
              className="font-mono text-sm"
              placeholder="Enter HTML content with {{variables}}"
            />
          </div>
          <div>
            <Label>Plain Text Content (Fallback)</Label>
            <Textarea
              value={template.text_content}
              onChange={(e) => setTemplate({ ...template, text_content: e.target.value })}
              rows={8}
              placeholder="Plain text version"
            />
          </div>
        </TabsContent>

        <TabsContent value="preview">
          <Card className="p-6">
            <div dangerouslySetInnerHTML={{ __html: template.html_content || '' }} />
          </Card>
        </TabsContent>
      </Tabs>

      {templateId && (
        <EmailEngagementPredictor
          templateId={templateId}
          subject={template.subject || ''}
          htmlContent={template.html_content || ''}
          plainTextContent={template.text_content || ''}
          onCreateABTest={handleCreateABTest}
        />
      )}


      <div className="flex items-center gap-4">
        <Button onClick={handleSave} disabled={loading}>
          <Save className="w-4 h-4 mr-2" />
          Save Template
        </Button>
        
        {templateId && (
          <>
            <Input
              type="email"
              placeholder="test@example.com"
              value={testEmail}
              onChange={(e) => setTestEmail(e.target.value)}
              className="max-w-xs"
            />
            <Button onClick={handleTest} variant="outline" disabled={loading}>
              <Send className="w-4 h-4 mr-2" />
              Send Test
            </Button>
          </>
        )}
      </div>
    </div>
  );
}
