import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase-client';
import { Mail, CheckCircle, XCircle, Clock, Eye } from 'lucide-react';
import type { EmailDeliveryTracking } from '@/types/emailNotifications';

export function EmailDeliveryDashboard() {
  const [emails, setEmails] = useState<EmailDeliveryTracking[]>([]);
  const [stats, setStats] = useState({
    total: 0,
    sent: 0,
    delivered: 0,
    opened: 0,
    failed: 0
  });

  useEffect(() => {
    loadEmails();
  }, []);

  const loadEmails = async () => {
    const { data } = await supabase
      .from('email_delivery_tracking')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(50);

    if (data) {
      setEmails(data);
      setStats({
        total: data.length,
        sent: data.filter(e => e.status === 'sent' || e.status === 'delivered' || e.status === 'opened').length,
        delivered: data.filter(e => e.status === 'delivered' || e.status === 'opened').length,
        opened: data.filter(e => e.status === 'opened').length,
        failed: data.filter(e => e.status === 'failed').length
      });
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, any> = {
      sent: { variant: 'default', icon: Mail },
      delivered: { variant: 'default', icon: CheckCircle },
      opened: { variant: 'default', icon: Eye },
      failed: { variant: 'destructive', icon: XCircle },
      pending: { variant: 'secondary', icon: Clock }
    };
    const config = variants[status] || variants.pending;
    const Icon = config.icon;
    return (
      <Badge variant={config.variant}>
        <Icon className="w-3 h-3 mr-1" />
        {status}
      </Badge>
    );
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-5 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Total</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Sent</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{stats.sent}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Delivered</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.delivered}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Opened</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">{stats.opened}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Failed</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{stats.failed}</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Emails</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {emails.map(email => (
              <div key={email.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex-1">
                  <div className="font-medium">{email.subject}</div>
                  <div className="text-sm text-muted-foreground">{email.recipient_email}</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    {new Date(email.created_at).toLocaleString()}
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <Badge variant="outline">{email.email_type}</Badge>
                  {getStatusBadge(email.status)}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
