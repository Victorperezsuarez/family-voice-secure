import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';
import { Loader2, Brain, Calendar, Clock } from 'lucide-react';
import { EmailEngagementScoreCard } from './EmailEngagementScoreCard';
import { PredictedMetricsPanel } from './PredictedMetricsPanel';
import { EmailAnalysisRecommendations } from './EmailAnalysisRecommendations';
import { EmailEngagementPrediction, SuggestedVariation } from '@/types/emailEngagement';

interface EmailEngagementPredictorProps {
  templateId: string;
  subject: string;
  htmlContent: string;
  plainTextContent: string;
  onCreateABTest?: (variation: SuggestedVariation) => void;
}

export function EmailEngagementPredictor({
  templateId,
  subject,
  htmlContent,
  plainTextContent,
  onCreateABTest
}: EmailEngagementPredictorProps) {
  const [loading, setLoading] = useState(false);
  const [prediction, setPrediction] = useState<EmailEngagementPrediction | null>(null);

  const analyzePrediction = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('predict-email-engagement', {
        body: { templateId, subject, htmlContent, plainTextContent }
      });

      if (error) throw error;

      // Save prediction to database
      const { data: saved, error: saveError } = await supabase
        .from('email_engagement_predictions')
        .insert([{ template_id: templateId, ...data }])
        .select()
        .single();

      if (saveError) throw saveError;

      setPrediction(saved);
      toast.success('Email analysis complete!');
    } catch (error: any) {
      toast.error(error.message || 'Failed to analyze email');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5 text-purple-600" />
            AI-Powered Engagement Prediction
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Button onClick={analyzePrediction} disabled={loading}>
            {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Analyze Email Performance
          </Button>
        </CardContent>
      </Card>

      {prediction && (
        <Tabs defaultValue="scores" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="scores">Scores</TabsTrigger>
            <TabsTrigger value="metrics">Metrics</TabsTrigger>
            <TabsTrigger value="timing">Timing</TabsTrigger>
            <TabsTrigger value="recommendations">Tips</TabsTrigger>
          </TabsList>

          <TabsContent value="scores" className="space-y-4">
            <EmailEngagementScoreCard
              overallScore={prediction.overall_score}
              subjectLineScore={prediction.subject_line_score}
              contentScore={prediction.content_score}
              ctaScore={prediction.cta_score}
              timingScore={prediction.timing_score}
            />
          </TabsContent>

          <TabsContent value="metrics">
            <PredictedMetricsPanel
              predictedOpenRate={prediction.predicted_open_rate}
              predictedClickRate={prediction.predicted_click_rate}
              predictedConversionRate={prediction.predicted_conversion_rate}
              predictedBounceRate={prediction.predicted_bounce_rate}
            />
          </TabsContent>

          <TabsContent value="timing">
            <Card>
              <CardHeader>
                <CardTitle>Optimal Send Time</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-4">
                  <Calendar className="h-8 w-8 text-blue-600" />
                  <div>
                    <div className="font-semibold">{prediction.optimal_send_day}</div>
                    <div className="text-sm text-muted-foreground">Best day to send</div>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <Clock className="h-8 w-8 text-green-600" />
                  <div>
                    <div className="font-semibold">{prediction.optimal_send_hour}:00</div>
                    <div className="text-sm text-muted-foreground">
                      {prediction.optimal_send_timezone}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="recommendations">
            <EmailAnalysisRecommendations
              recommendations={prediction.recommendations}
              suggestedVariations={prediction.suggested_variations}
              onCreateABTest={onCreateABTest}
            />
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}
