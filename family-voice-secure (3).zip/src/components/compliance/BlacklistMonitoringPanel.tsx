import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, CheckCircle, Shield } from 'lucide-react';
import { EmailBlacklistMonitoring } from '@/types/emailDeliverability';

interface BlacklistMonitoringPanelProps {
  blacklists: EmailBlacklistMonitoring[];
  blacklistScore: number;
}

export function BlacklistMonitoringPanel({ blacklists, blacklistScore }: BlacklistMonitoringPanelProps) {
  const listedCount = blacklists.filter(b => b.isListed).length;
  const totalCount = blacklists.length;

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            <CardTitle>Blacklist Monitoring</CardTitle>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold">{blacklistScore}</p>
            <p className="text-sm text-muted-foreground">Score</p>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="mb-4 p-3 bg-muted rounded-lg">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Status Overview</span>
            <Badge variant={listedCount === 0 ? 'default' : 'destructive'}>
              {listedCount === 0 ? 'Clean' : `${listedCount} Listings`}
            </Badge>
          </div>
          <p className="text-sm text-muted-foreground mt-1">
            Checked against {totalCount} blacklists
          </p>
        </div>

        <div className="space-y-2">
          {blacklists.map((blacklist) => (
            <div
              key={blacklist.id}
              className="flex items-center justify-between p-2 border rounded-lg"
            >
              <div className="flex items-center gap-2">
                {blacklist.isListed ? (
                  <AlertTriangle className="h-4 w-4 text-red-500" />
                ) : (
                  <CheckCircle className="h-4 w-4 text-green-500" />
                )}
                <span className="text-sm font-medium">{blacklist.blacklistName}</span>
              </div>
              <Badge variant={blacklist.isListed ? 'destructive' : 'secondary'}>
                {blacklist.isListed ? 'Listed' : 'Clear'}
              </Badge>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
