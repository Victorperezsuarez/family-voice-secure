import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { EmailDeliverabilityHealth } from '@/types/emailDeliverability';

interface HealthTrendsChartProps {
  data: EmailDeliverabilityHealth[];
}

export function HealthTrendsChart({ data }: HealthTrendsChartProps) {
  const chartData = data.map(item => ({
    date: new Date(item.snapshotDate).toLocaleDateString(),
    health: item.healthScore,
    reputation: item.reputationScore,
    authentication: item.authenticationScore,
    blacklist: item.blacklistScore,
    delivery: item.deliveryRateScore
  }));

  return (
    <Card>
      <CardHeader>
        <CardTitle>Health Trends</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis domain={[0, 100]} />
            <Tooltip />
            <Area type="monotone" dataKey="health" stackId="1" stroke="#8884d8" fill="#8884d8" name="Overall Health" />
            <Area type="monotone" dataKey="reputation" stackId="2" stroke="#82ca9d" fill="#82ca9d" name="Reputation" />
            <Area type="monotone" dataKey="authentication" stackId="3" stroke="#ffc658" fill="#ffc658" name="Authentication" />
          </AreaChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
