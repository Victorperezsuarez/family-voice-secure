import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Lightbulb, Zap, ArrowRight } from 'lucide-react';
import { SuggestedVariation } from '@/types/emailEngagement';

interface EmailAnalysisRecommendationsProps {
  recommendations: string[];
  suggestedVariations: SuggestedVariation[];
  onCreateABTest?: (variation: SuggestedVariation) => void;
}

export function EmailAnalysisRecommendations({
  recommendations,
  suggestedVariations,
  onCreateABTest
}: EmailAnalysisRecommendationsProps) {
  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lightbulb className="h-5 w-5 text-yellow-600" />
            Recommendations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {recommendations.map((rec, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <span className="text-blue-600 mt-1">•</span>
                <span className="text-sm">{rec}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      {suggestedVariations && suggestedVariations.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-purple-600" />
              Suggested A/B Test Variations
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {suggestedVariations.map((variation, idx) => (
              <div key={idx} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <Badge>{variation.element}</Badge>
                  <Badge variant="outline" className="bg-green-50">
                    {variation.expected_improvement}
                  </Badge>
                </div>
                <div className="flex items-center gap-2 text-sm mb-2">
                  <span className="text-muted-foreground">Current:</span>
                  <span className="font-medium">{variation.current}</span>
                </div>
                <div className="flex items-center gap-2 text-sm mb-3">
                  <ArrowRight className="h-4 w-4 text-blue-600" />
                  <span className="text-muted-foreground">Suggested:</span>
                  <span className="font-medium text-blue-600">{variation.suggested}</span>
                </div>
                {onCreateABTest && (
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => onCreateABTest(variation)}
                  >
                    Create A/B Test
                  </Button>
                )}
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
