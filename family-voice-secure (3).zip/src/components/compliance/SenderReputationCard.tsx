import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { EmailSenderReputation } from '@/types/emailDeliverability';

interface SenderReputationCardProps {
  reputation: EmailSenderReputation | null;
}

export function SenderReputationCard({ reputation }: SenderReputationCardProps) {
  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-500';
    if (score >= 60) return 'text-yellow-500';
    return 'text-red-500';
  };

  const getTrendIcon = (rate: number, threshold: number) => {
    if (rate > threshold) return <TrendingUp className="h-4 w-4 text-red-500" />;
    if (rate < threshold * 0.5) return <TrendingDown className="h-4 w-4 text-green-500" />;
    return <Minus className="h-4 w-4 text-yellow-500" />;
  };

  if (!reputation) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Sender Reputation</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-center text-muted-foreground py-4">No reputation data available</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Sender Reputation</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-center">
          <p className={`text-4xl font-bold ${getScoreColor(reputation.reputationScore)}`}>
            {reputation.reputationScore}
          </p>
          <p className="text-sm text-muted-foreground">Overall Score</p>
        </div>

        <div className="space-y-3">
          <div>
            <div className="flex justify-between text-sm mb-1">
              <span>Complaint Rate</span>
              <div className="flex items-center gap-1">
                {getTrendIcon(reputation.complaintRate, 0.001)}
                <span>{(reputation.complaintRate * 100).toFixed(3)}%</span>
              </div>
            </div>
            <Progress value={Math.min(reputation.complaintRate * 10000, 100)} />
          </div>

          <div>
            <div className="flex justify-between text-sm mb-1">
              <span>Bounce Rate</span>
              <div className="flex items-center gap-1">
                {getTrendIcon(reputation.bounceRate, 0.05)}
                <span>{(reputation.bounceRate * 100).toFixed(2)}%</span>
              </div>
            </div>
            <Progress value={Math.min(reputation.bounceRate * 200, 100)} />
          </div>

          <div className="pt-2 border-t">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-muted-foreground">Sent</p>
                <p className="font-semibold">{reputation.volumeSent.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Delivered</p>
                <p className="font-semibold">{reputation.volumeDelivered.toLocaleString()}</p>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
