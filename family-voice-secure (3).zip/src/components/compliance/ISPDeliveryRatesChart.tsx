import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { EmailISPDeliveryRate } from '@/types/emailDeliverability';

interface ISPDeliveryRatesChartProps {
  data: EmailISPDeliveryRate[];
}

export function ISPDeliveryRatesChart({ data }: ISPDeliveryRatesChartProps) {
  const chartData = data.reduce((acc: any[], item) => {
    const existing = acc.find(d => d.date === item.date);
    if (existing) {
      existing[item.ispName] = (item.emailsDelivered / item.emailsSent) * 100;
    } else {
      acc.push({
        date: item.date,
        [item.ispName]: (item.emailsDelivered / item.emailsSent) * 100
      });
    }
    return acc;
  }, []);

  const ispNames = [...new Set(data.map(d => d.ispName))];
  const colors = ['#8884d8', '#82ca9d', '#ffc658', '#ff7c7c', '#a78bfa'];

  return (
    <Card>
      <CardHeader>
        <CardTitle>ISP Delivery Rates</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />
            <Legend />
            {ispNames.map((isp, index) => (
              <Line
                key={isp}
                type="monotone"
                dataKey={isp}
                stroke={colors[index % colors.length]}
                name={isp}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
