import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface EmailEngagementScoreCardProps {
  overallScore: number;
  subjectLineScore: number;
  contentScore: number;
  ctaScore: number;
  timingScore: number;
}

export function EmailEngagementScoreCard({
  overallScore,
  subjectLineScore,
  contentScore,
  ctaScore,
  timingScore
}: EmailEngagementScoreCardProps) {
  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreBadge = (score: number) => {
    if (score >= 80) return <Badge className="bg-green-600">Excellent</Badge>;
    if (score >= 60) return <Badge className="bg-yellow-600">Good</Badge>;
    return <Badge className="bg-red-600">Needs Work</Badge>;
  };

  const scores = [
    { label: 'Subject Line', value: subjectLineScore },
    { label: 'Content', value: contentScore },
    { label: 'Call-to-Action', value: ctaScore },
    { label: 'Timing', value: timingScore }
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle>Engagement Score</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="text-center">
          <div className={`text-6xl font-bold ${getScoreColor(overallScore)}`}>
            {overallScore}
          </div>
          <div className="mt-2">{getScoreBadge(overallScore)}</div>
          <p className="text-sm text-muted-foreground mt-2">Overall Score</p>
        </div>

        <div className="space-y-4">
          {scores.map((item) => (
            <div key={item.label}>
              <div className="flex justify-between mb-2">
                <span className="text-sm font-medium">{item.label}</span>
                <span className={`text-sm font-bold ${getScoreColor(item.value)}`}>
                  {item.value}
                </span>
              </div>
              <Progress value={item.value} className="h-2" />
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
