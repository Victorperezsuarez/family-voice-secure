import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertTriangle, CheckCircle, Info } from 'lucide-react';
import { EmailDeliverabilityAlert } from '@/types/emailDeliverability';

interface DeliverabilityAlertsPanelProps {
  alerts: EmailDeliverabilityAlert[];
  onResolve: (alertId: string) => void;
}

export function DeliverabilityAlertsPanel({ alerts, onResolve }: DeliverabilityAlertsPanelProps) {
  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'destructive';
      case 'high': return 'destructive';
      case 'medium': return 'default';
      default: return 'secondary';
    }
  };

  const getSeverityIcon = (severity: string) => {
    if (severity === 'critical' || severity === 'high') {
      return <AlertTriangle className="h-5 w-5 text-red-500" />;
    }
    return <Info className="h-5 w-5 text-yellow-500" />;
  };

  if (alerts.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Active Alerts</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <CheckCircle className="h-12 w-12 text-green-500 mb-4" />
            <p className="text-lg font-medium">No Active Alerts</p>
            <p className="text-sm text-muted-foreground">Your email deliverability is healthy</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Active Alerts ({alerts.length})</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {alerts.map((alert) => (
          <Alert key={alert.id} className="border-l-4">
            <div className="flex items-start gap-3">
              {getSeverityIcon(alert.severity)}
              <div className="flex-1">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-semibold">{alert.title}</h4>
                  <Badge variant={getSeverityColor(alert.severity)}>
                    {alert.severity.toUpperCase()}
                  </Badge>
                </div>
                <AlertDescription className="mb-3">
                  {alert.description}
                </AlertDescription>
                {alert.remediationSteps && alert.remediationSteps.length > 0 && (
                  <div className="bg-muted p-3 rounded-md mb-3">
                    <p className="text-sm font-medium mb-2">Remediation Steps:</p>
                    <ol className="text-sm space-y-1 list-decimal list-inside">
                      {alert.remediationSteps.map((step, idx) => (
                        <li key={idx}>{step}</li>
                      ))}
                    </ol>
                  </div>
                )}
                <Button size="sm" onClick={() => onResolve(alert.id)}>
                  Mark as Resolved
                </Button>
              </div>
            </div>
          </Alert>
        ))}
      </CardContent>
    </Card>
  );
}
