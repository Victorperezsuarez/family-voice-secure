import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { supabase } from '@/lib/supabase-client';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Play, Pause, Trophy, TrendingUp } from 'lucide-react';
import { toast } from 'sonner';
import ABTestCreationDialog from './ABTestCreationDialog';
import ABTestRecommendationsPanel from '../notifications/ABTestRecommendationsPanel';

export default function ABTestAnalyticsDashboard() {
  const [tests, setTests] = useState<any[]>([]);
  const [selectedTest, setSelectedTest] = useState<any>(null);
  const [results, setResults] = useState<any[]>([]);
  const [templates, setTemplates] = useState<any[]>([]);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadData = async () => {
    try {
      const [testsRes, templatesRes] = await Promise.all([
        supabase.from('notification_ab_tests').select('*').order('created_at', { ascending: false }),
        supabase.from('notification_templates').select('id, name')
      ]);

      if (testsRes.data) setTests(testsRes.data);
      if (templatesRes.data) setTemplates(templatesRes.data);

      if (selectedTest) {
        const { data: resultsData } = await supabase
          .from('notification_ab_test_results')
          .select('*')
          .eq('test_id', selectedTest.id);
        if (resultsData) setResults(resultsData);
      }
    } catch (error: any) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const startTest = async (testId: string) => {
    const { error } = await supabase
      .from('notification_ab_tests')
      .update({ status: 'running', start_date: new Date().toISOString() })
      .eq('id', testId);
    if (error) toast.error(error.message);
    else { toast.success('Test started'); loadData(); }
  };

  const pauseTest = async (testId: string) => {
    const { error } = await supabase.from('notification_ab_tests').update({ status: 'paused' }).eq('id', testId);
    if (error) toast.error(error.message);
    else { toast.success('Test paused'); loadData(); }
  };

  const analyzeTest = async (testId: string) => {
    setLoading(true);
    try {
      const { error } = await supabase.functions.invoke('analyze-ab-test', { body: { testId } });
      if (error) throw error;
      toast.success('Analysis complete');
      loadData();
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      draft: 'bg-gray-500',
      running: 'bg-green-500',
      paused: 'bg-yellow-500',
      completed: 'bg-blue-500',
      winner_selected: 'bg-purple-500'
    };
    return colors[status] || 'bg-gray-500';
  };

  const formatPercent = (val: number) => `${(val * 100).toFixed(2)}%`;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">A/B Testing Dashboard</h2>
        <Button onClick={() => setShowCreateDialog(true)}>Create New Test</Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-1">
          <CardHeader><CardTitle>Active Tests</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {tests.map(test => (
              <div key={test.id} className={`p-3 border rounded cursor-pointer hover:bg-gray-50 ${selectedTest?.id === test.id ? 'border-blue-500 bg-blue-50' : ''}`} onClick={() => { setSelectedTest(test); loadData(); }}>
                <div className="flex justify-between items-start mb-2">
                  <span className="font-medium">{test.name}</span>
                  <Badge className={getStatusColor(test.status)}>{test.status}</Badge>
                </div>
                <div className="text-sm text-gray-600">{test.template_ids.length} variants</div>
                <div className="flex gap-2 mt-2">
                  {test.status === 'draft' && <Button size="sm" onClick={(e) => { e.stopPropagation(); startTest(test.id); }}><Play className="h-3 w-3" /></Button>}
                  {test.status === 'running' && <Button size="sm" variant="outline" onClick={(e) => { e.stopPropagation(); pauseTest(test.id); }}><Pause className="h-3 w-3" /></Button>}
                  {test.status === 'running' && <Button size="sm" variant="outline" onClick={(e) => { e.stopPropagation(); analyzeTest(test.id); }}>Analyze</Button>}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {selectedTest && (
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>{selectedTest.name}</CardTitle>
              <p className="text-sm text-gray-600">{selectedTest.description}</p>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div>
                  <div className="text-sm text-gray-600">Target Sample Size</div>
                  <div className="text-2xl font-bold">{selectedTest.target_sample_size}</div>
                </div>
                <div>
                  <div className="text-sm text-gray-600">Confidence Level</div>
                  <div className="text-2xl font-bold">{(selectedTest.confidence_level * 100).toFixed(0)}%</div>
                </div>
              </div>

              {results.length > 0 && (
                <>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={results.map(r => ({ name: templates.find(t => t.id === r.template_id)?.name || 'Unknown', conversionRate: r.conversion_rate * 100, clickRate: r.click_rate * 100, actionRate: r.action_rate * 100 }))}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="conversionRate" fill="#8b5cf6" name="Conversion %" />
                      <Bar dataKey="clickRate" fill="#3b82f6" name="Click %" />
                      <Bar dataKey="actionRate" fill="#10b981" name="Action %" />
                    </BarChart>
                  </ResponsiveContainer>

                  <div className="mt-6 space-y-4">
                    {results.map(result => {
                      const template = templates.find(t => t.id === result.template_id);
                      const progress = (result.deliveries / selectedTest.target_sample_size) * 100;
                      return (
                        <div key={result.id} className="border rounded p-4">
                          <div className="flex justify-between items-start mb-2">
                            <div className="font-medium">{template?.name}</div>
                            {result.is_winner && <Badge className="bg-yellow-500"><Trophy className="h-3 w-3 mr-1" />Winner</Badge>}
                          </div>
                          <Progress value={progress} className="mb-2" />
                          <div className="grid grid-cols-4 gap-2 text-sm">
                            <div><span className="text-gray-600">Deliveries:</span> {result.deliveries}</div>
                            <div><span className="text-gray-600">Clicks:</span> {formatPercent(result.click_rate)}</div>
                            <div><span className="text-gray-600">Actions:</span> {formatPercent(result.action_rate)}</div>
                            <div><span className="text-gray-600">Conversions:</span> {formatPercent(result.conversion_rate)}</div>
                          </div>
                          {result.statistical_significance && (
                            <div className="mt-2 text-sm">
                              <span className="text-gray-600">Statistical Significance:</span> {formatPercent(result.statistical_significance)}
                              {result.statistical_significance >= selectedTest.confidence_level && <TrendingUp className="inline h-4 w-4 text-green-500 ml-1" />}
                            </div>
                          )}
                          {result.confidence_interval_lower && (
                            <div className="text-sm text-gray-600">
                              95% CI: [{formatPercent(result.confidence_interval_lower)}, {formatPercent(result.confidence_interval_upper)}]
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        )}
      </div>

      {selectedTest && results.length > 0 && (
        <ABTestRecommendationsPanel testResults={results} test={selectedTest} />
      )}

      <ABTestCreationDialog open={showCreateDialog} onOpenChange={setShowCreateDialog} templates={templates} onTestCreated={loadData} />
    </div>
  );
}

