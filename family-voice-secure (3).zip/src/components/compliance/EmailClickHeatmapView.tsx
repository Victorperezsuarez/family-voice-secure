import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/lib/supabase-client';
import { Badge } from '@/components/ui/badge';

interface EmailClickHeatmapViewProps {
  testId: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function EmailClickHeatmapView({ testId, open, onOpenChange }: EmailClickHeatmapViewProps) {
  const [clicksA, setClicksA] = useState<any[]>([]);
  const [clicksB, setClicksB] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (open) loadHeatmapData();
  }, [open, testId]);

  const loadHeatmapData = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('email_click_heatmap')
      .select('*')
      .eq('ab_test_id', testId);

    setClicksA(data?.filter(c => c.variant === 'a') || []);
    setClicksB(data?.filter(c => c.variant === 'b') || []);
    setLoading(false);
  };

  const renderHeatmap = (clicks: any[]) => {
    const linkStats = clicks.reduce((acc, click) => {
      const url = click.link_url || 'Unknown';
      if (!acc[url]) {
        acc[url] = { count: 0, positions: [] };
      }
      acc[url].count++;
      acc[url].positions.push({ x: click.click_x, y: click.click_y });
      return acc;
    }, {} as Record<string, { count: number; positions: { x: number; y: number }[] }>);

    const sortedLinks = Object.entries(linkStats).sort((a, b) => b[1].count - a[1].count);

    return (
      <div className="space-y-4">
        <div className="grid gap-2">
          {sortedLinks.map(([url, stats], idx) => (
            <Card key={idx}>
              <CardContent className="pt-4">
                <div className="flex justify-between items-start">
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{url}</p>
                    <p className="text-sm text-muted-foreground">
                      Average position: X:{Math.round(stats.positions.reduce((sum, p) => sum + p.x, 0) / stats.count)}%, 
                      Y:{Math.round(stats.positions.reduce((sum, p) => sum + p.y, 0) / stats.count)}%
                    </p>
                  </div>
                  <Badge variant="secondary">{stats.count} clicks</Badge>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {clicks.length === 0 && (
          <p className="text-center text-muted-foreground py-8">No click data available yet</p>
        )}
      </div>
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Email Click Heatmap</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="a" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="a">Variant A ({clicksA.length} clicks)</TabsTrigger>
            <TabsTrigger value="b">Variant B ({clicksB.length} clicks)</TabsTrigger>
          </TabsList>
          <TabsContent value="a" className="space-y-4">
            {renderHeatmap(clicksA)}
          </TabsContent>
          <TabsContent value="b" className="space-y-4">
            {renderHeatmap(clicksB)}
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
