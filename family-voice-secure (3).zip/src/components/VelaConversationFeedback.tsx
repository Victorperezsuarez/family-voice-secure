import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { Star, ThumbsUp, ThumbsDown } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { toast } from '@/components/ui/use-toast';

interface VelaConversationFeedbackProps {
  conversationId: string;
  onFeedbackSubmitted?: () => void;
}

export function VelaConversationFeedback({ 
  conversationId, 
  onFeedbackSubmitted 
}: VelaConversationFeedbackProps) {
  const [rating, setRating] = useState<number>(0);
  const [helpful, setHelpful] = useState<boolean | null>(null);
  const [feedback, setFeedback] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async () => {
    try {
      await supabase
        .from('vela_conversations')
        .update({
          user_rating: rating || null,
          response_helpful: helpful,
          user_feedback: feedback || null
        })
        .eq('id', conversationId);

      setSubmitted(true);
      toast({
        title: 'Feedback submitted',
        description: 'Thank you for helping Vela learn!'
      });
      
      if (onFeedbackSubmitted) {
        onFeedbackSubmitted();
      }
    } catch (error) {
      console.error('Error submitting feedback:', error);
      toast({
        title: 'Error',
        description: 'Failed to submit feedback',
        variant: 'destructive'
      });
    }
  };

  if (submitted) {
    return (
      <Card className="p-4 bg-green-50 border-green-200">
        <p className="text-sm text-green-800">Thank you for your feedback!</p>
      </Card>
    );
  }

  return (
    <Card className="p-4 space-y-4">
      <div>
        <p className="text-sm font-medium mb-2">Was this response helpful?</p>
        <div className="flex gap-2">
          <Button
            variant={helpful === true ? 'default' : 'outline'}
            size="sm"
            onClick={() => setHelpful(true)}
          >
            <ThumbsUp className="h-4 w-4 mr-1" />
            Yes
          </Button>
          <Button
            variant={helpful === false ? 'default' : 'outline'}
            size="sm"
            onClick={() => setHelpful(false)}
          >
            <ThumbsDown className="h-4 w-4 mr-1" />
            No
          </Button>
        </div>
      </div>

      <div>
        <p className="text-sm font-medium mb-2">Rate this response</p>
        <div className="flex gap-1">
          {[1, 2, 3, 4, 5].map((star) => (
            <button
              key={star}
              onClick={() => setRating(star)}
              className="focus:outline-none"
            >
              <Star
                className={`h-6 w-6 ${
                  star <= rating
                    ? 'fill-yellow-400 text-yellow-400'
                    : 'text-gray-300'
                }`}
              />
            </button>
          ))}
        </div>
      </div>

      <div>
        <p className="text-sm font-medium mb-2">Additional feedback (optional)</p>
        <Textarea
          placeholder="Tell us how we can improve..."
          value={feedback}
          onChange={(e) => setFeedback(e.target.value)}
          rows={3}
        />
      </div>

      <Button onClick={handleSubmit} className="w-full">
        Submit Feedback
      </Button>
    </Card>
  );
}