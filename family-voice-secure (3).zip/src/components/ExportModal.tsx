import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Checkbox } from '@/components/ui/checkbox';
import { CalendarIcon, Download, FileArchive, FileText } from 'lucide-react';
import { format } from 'date-fns';
import { supabase } from '@/lib/supabase-client';
import { useToast } from '@/hooks/use-toast';
import type { ExportFormat, ExportFilters } from '@/types/export';

interface ExportModalProps {
  open: boolean;
  onClose: () => void;
  familyId: string;
  members: any[];
  collections: any[];
}

export function ExportModal({ open, onClose, familyId, members, collections }: ExportModalProps) {
  const [format, setFormat] = useState<ExportFormat>('pdf');
  const [filters, setFilters] = useState<ExportFilters>({});
  const [startDate, setStartDate] = useState<Date>();
  const [endDate, setEndDate] = useState<Date>();
  const [includePhotos, setIncludePhotos] = useState(true);
  const [includeTranscriptions, setIncludeTranscriptions] = useState(true);
  const [includeAudio, setIncludeAudio] = useState(true);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleExport = async () => {
    setLoading(true);
    try {
      const exportFilters: ExportFilters = {
        ...filters,
        startDate: startDate?.toISOString(),
        endDate: endDate?.toISOString()
      };

      const { data, error } = await supabase.functions.invoke('export-family-archive', {
        body: {
          familyId,
          format,
          filters: exportFilters,
          includePhotos,
          includeTranscriptions,
          includeAudio
        }
      });

      if (error) throw error;

      // Trigger download
      const blob = new Blob([JSON.stringify(data.data)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = data.filename;
      a.click();
      URL.revokeObjectURL(url);

      toast({
        title: 'Export successful',
        description: `Your family archive has been downloaded as ${data.filename}`
      });
      onClose();
    } catch (error: any) {
      toast({
        title: 'Export failed',
        description: error.message,
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Export Family Archive</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          <div>
            <Label>Export Format</Label>
            <div className="grid grid-cols-2 gap-4 mt-2">
              <Button
                variant={format === 'pdf' ? 'default' : 'outline'}
                onClick={() => setFormat('pdf')}
                className="h-20 flex-col"
              >
                <FileText className="h-8 w-8 mb-2" />
                PDF Book
              </Button>
              <Button
                variant={format === 'zip' ? 'default' : 'outline'}
                onClick={() => setFormat('zip')}
                className="h-20 flex-col"
              >
                <FileArchive className="h-8 w-8 mb-2" />
                ZIP Archive
              </Button>
            </div>
          </div>

          <div>
            <Label>Filter by Family Member</Label>
            <Select onValueChange={(value) => setFilters({ ...filters, memberId: value })}>
              <SelectTrigger>
                <SelectValue placeholder="All members" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All members</SelectItem>
                {members.map(member => (
                  <SelectItem key={member.id} value={member.id}>
                    {member.full_name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Filter by Collection</Label>
            <Select onValueChange={(value) => setFilters({ ...filters, collectionId: value })}>
              <SelectTrigger>
                <SelectValue placeholder="All collections" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All collections</SelectItem>
                {collections.map(collection => (
                  <SelectItem key={collection.id} value={collection.id}>
                    {collection.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Start Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {startDate ? format(startDate, 'PPP') : 'Pick a date'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar mode="single" selected={startDate} onSelect={setStartDate} />
                </PopoverContent>
              </Popover>
            </div>
            <div>
              <Label>End Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {endDate ? format(endDate, 'PPP') : 'Pick a date'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar mode="single" selected={endDate} onSelect={setEndDate} />
                </PopoverContent>
              </Popover>
            </div>
          </div>

          <div className="space-y-3">
            <Label>Include in Export</Label>
            <div className="flex items-center space-x-2">
              <Checkbox checked={includeAudio} onCheckedChange={(c) => setIncludeAudio(!!c)} />
              <Label>Audio recordings</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox checked={includeTranscriptions} onCheckedChange={(c) => setIncludeTranscriptions(!!c)} />
              <Label>Transcriptions</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox checked={includePhotos} onCheckedChange={(c) => setIncludePhotos(!!c)} />
              <Label>Photos</Label>
            </div>
          </div>

          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={onClose}>Cancel</Button>
            <Button onClick={handleExport} disabled={loading}>
              <Download className="mr-2 h-4 w-4" />
              {loading ? 'Exporting...' : 'Export'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
