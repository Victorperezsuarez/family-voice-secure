import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Users, MapPin, Calendar, Clock } from 'lucide-react';

interface Person {
  name: string;
  relationship: string;
}

interface Entities {
  people: Person[];
  places: string[];
  events: string[];
  timePeriods: string[];
}

interface StoryEntitiesPanelProps {
  entities: Entities;
  onEntityClick?: (type: string, value: string) => void;
}

export function StoryEntitiesPanel({ entities, onEntityClick }: StoryEntitiesPanelProps) {
  return (
    <Card className="p-4">
      <h3 className="text-lg font-semibold mb-4">Story Elements</h3>
      
      {entities.people.length > 0 && (
        <div className="mb-4">
          <div className="flex items-center gap-2 mb-2">
            <Users className="h-4 w-4 text-muted-foreground" />
            <p className="text-sm font-medium">People</p>
          </div>
          <div className="flex flex-wrap gap-2">
            {entities.people.map((person, index) => (
              <Badge
                key={index}
                variant="secondary"
                className="cursor-pointer hover:bg-secondary/80"
                onClick={() => onEntityClick?.('person', person.name)}
              >
                {person.name}
                {person.relationship && (
                  <span className="ml-1 text-xs opacity-70">
                    ({person.relationship})
                  </span>
                )}
              </Badge>
            ))}
          </div>
        </div>
      )}

      {entities.places.length > 0 && (
        <div className="mb-4">
          <div className="flex items-center gap-2 mb-2">
            <MapPin className="h-4 w-4 text-muted-foreground" />
            <p className="text-sm font-medium">Places</p>
          </div>
          <div className="flex flex-wrap gap-2">
            {entities.places.map((place, index) => (
              <Badge
                key={index}
                variant="outline"
                className="cursor-pointer hover:bg-accent"
                onClick={() => onEntityClick?.('place', place)}
              >
                {place}
              </Badge>
            ))}
          </div>
        </div>
      )}

      {entities.events.length > 0 && (
        <div className="mb-4">
          <div className="flex items-center gap-2 mb-2">
            <Calendar className="h-4 w-4 text-muted-foreground" />
            <p className="text-sm font-medium">Events</p>
          </div>
          <div className="flex flex-wrap gap-2">
            {entities.events.map((event, index) => (
              <Badge
                key={index}
                variant="outline"
                className="cursor-pointer hover:bg-accent"
                onClick={() => onEntityClick?.('event', event)}
              >
                {event}
              </Badge>
            ))}
          </div>
        </div>
      )}

      {entities.timePeriods.length > 0 && (
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Clock className="h-4 w-4 text-muted-foreground" />
            <p className="text-sm font-medium">Time Periods</p>
          </div>
          <div className="flex flex-wrap gap-2">
            {entities.timePeriods.map((period, index) => (
              <Badge
                key={index}
                variant="outline"
                className="cursor-pointer hover:bg-accent"
                onClick={() => onEntityClick?.('time', period)}
              >
                {period}
              </Badge>
            ))}
          </div>
        </div>
      )}
    </Card>
  );
}