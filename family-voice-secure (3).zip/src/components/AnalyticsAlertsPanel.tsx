import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { AlertRuleCard } from '@/components/analytics/AlertRuleCard';
import { CreateAlertRuleDialog } from '@/components/analytics/CreateAlertRuleDialog';
import { AlertsList } from '@/components/analytics/AlertsList';
import { AlertScheduleEditor } from '@/components/analytics/AlertScheduleEditor';
import { RecurringScheduleDialog } from '@/components/analytics/RecurringScheduleDialog';
import { AlertSuspensionDialog } from '@/components/analytics/AlertSuspensionDialog';
import { ScheduleCalendarView } from '@/components/analytics/ScheduleCalendarView';
import { AlertCorrelationPanel } from '@/components/analytics/AlertCorrelationPanel';
import AnomalyDetectionPanel from '@/components/analytics/AnomalyDetectionPanel';
import { AnomalyVisualizationDashboard } from '@/components/analytics/AnomalyVisualizationDashboard';
import NotificationChannelsManager from '@/components/notifications/NotificationChannelsManager';
import { AlertRoutingDashboard } from '@/components/routing/AlertRoutingDashboard';



import { supabase } from '@/lib/supabase-client';
import { useToast } from '@/hooks/use-toast';
import { Bell, History, Calendar, Network, Brain, BarChart3, MessageSquare } from 'lucide-react';


import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';




interface AnalyticsAlertsPanelProps {
  templateId: string;
}

export function AnalyticsAlertsPanel({ templateId }: AnalyticsAlertsPanelProps) {
  const [alertRules, setAlertRules] = useState<any[]>([]);
  const [triggeredAlerts, setTriggeredAlerts] = useState<any[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [selectedRuleId, setSelectedRuleId] = useState<string | null>(null);
  const [scheduleDialogOpen, setScheduleDialogOpen] = useState(false);
  const [recurringDialogOpen, setRecurringDialogOpen] = useState(false);
  const [suspensionDialogOpen, setSuspensionDialogOpen] = useState(false);
  const [familyId, setFamilyId] = useState<string>('');
  const { toast } = useToast();



  useEffect(() => {
    loadFamilyId();
    loadAlertRules();
    loadTriggeredAlerts();
    
    // Subscribe to real-time updates
    const subscription = supabase
      .channel('alerts_updates')
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'triggered_alerts',
        filter: `template_id=eq.${templateId}`
      }, (payload) => {
        setTriggeredAlerts(prev => [payload.new, ...prev]);
        setUnreadCount(prev => prev + 1);
        toast({
          title: 'New Alert',
          description: payload.new.message
        });
      })
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [templateId]);

  const loadFamilyId = async () => {
    const { data: user } = await supabase.auth.getUser();
    if (user.user) {
      const { data } = await supabase.from('family_users').select('family_id').eq('user_id', user.user.id).single();
      if (data) setFamilyId(data.family_id);
    }
  };


  const loadAlertRules = async () => {
    const { data } = await supabase
      .from('alert_rules')
      .select('*')
      .eq('template_id', templateId)
      .order('created_at', { ascending: false });
    
    if (data) setAlertRules(data);
  };

  const loadTriggeredAlerts = async () => {
    const { data } = await supabase
      .from('triggered_alerts')
      .select('*')
      .eq('template_id', templateId)
      .order('triggered_at', { ascending: false });
    
    if (data) {
      setTriggeredAlerts(data);
      setUnreadCount(data.filter(a => !a.is_read).length);
    }
  };

  const handleCreateRule = async (rule: any) => {
    const { data: user } = await supabase.auth.getUser();
    const { error } = await supabase
      .from('alert_rules')
      .insert({ ...rule, creator_id: user.user?.id });
    
    if (!error) {
      toast({ title: 'Alert rule created successfully' });
      loadAlertRules();
    }
  };

  const handleToggleRule = async (id: string, active: boolean) => {
    await supabase
      .from('alert_rules')
      .update({ is_active: active })
      .eq('id', id);
    loadAlertRules();
  };

  const handleDeleteRule = async (id: string) => {
    await supabase.from('alert_rules').delete().eq('id', id);
    loadAlertRules();
  };

  const handleMarkAsRead = async (id: string) => {
    await supabase
      .from('triggered_alerts')
      .update({ is_read: true })
      .eq('id', id);
    loadTriggeredAlerts();
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Analytics Alerts</CardTitle>
        <CardDescription>Configure alerts and view notification history</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="rules">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="rules">
              <Bell className="w-4 h-4 mr-2" />
              Alert Rules
            </TabsTrigger>
            <TabsTrigger value="history">
              <History className="w-4 h-4 mr-2" />
              History
              {unreadCount > 0 && (
                <Badge variant="destructive" className="ml-2">{unreadCount}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="notifications">
              <MessageSquare className="w-4 h-4 mr-2" />
              Channels
            </TabsTrigger>
            <TabsTrigger value="correlation">
              <Network className="w-4 h-4 mr-2" />
              Correlation
            </TabsTrigger>
            <TabsTrigger value="anomaly">
              <Brain className="w-4 h-4 mr-2" />
              ML Detection
            </TabsTrigger>
            <TabsTrigger value="visualization">
              <BarChart3 className="w-4 h-4 mr-2" />
              Visualizations
            </TabsTrigger>
          </TabsList>
          <TabsContent value="rules" className="space-y-4">
            <CreateAlertRuleDialog templateId={templateId} onCreateRule={handleCreateRule} />
            <div className="space-y-3">
              {alertRules.map(rule => (
                <AlertRuleCard
                  key={rule.id}
                  rule={rule}
                  onToggle={handleToggleRule}
                  onDelete={handleDeleteRule}
                />
              ))}
            </div>
          </TabsContent>
          <TabsContent value="history">
            <AlertsList alerts={triggeredAlerts} onMarkAsRead={handleMarkAsRead} />
          </TabsContent>
          <TabsContent value="notifications">
            {familyId && <NotificationChannelsManager familyId={familyId} />}
          </TabsContent>
          <TabsContent value="correlation">
            <AlertCorrelationPanel />
          </TabsContent>
          <TabsContent value="anomaly">
            <AnomalyDetectionPanel templateId={templateId} />
          </TabsContent>
          <TabsContent value="visualization">
            <AnomalyVisualizationDashboard />
          </TabsContent>
        </Tabs>




      </CardContent>
    </Card>
  );
}