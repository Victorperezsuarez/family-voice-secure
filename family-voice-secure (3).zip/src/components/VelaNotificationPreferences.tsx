import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Bell, BellOff, Volume2, VolumeX, Smartphone } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

interface NotificationPreference {
  suggestion_type: string;
  urgency_level: 'low' | 'medium' | 'high' | 'critical';
  enabled: boolean;
  sound_enabled: boolean;
  vibration_enabled: boolean;
}

export function VelaNotificationPreferences() {
  const { user } = useAuth();
  const [preferences, setPreferences] = useState<NotificationPreference[]>([]);
  const [permission, setPermission] = useState<NotificationPermission>('default');
  const [loading, setLoading] = useState(true);

  const suggestionTypes = ['recording_reminder', 'story_idea', 'family_update', 'milestone_suggestion'];
  const urgencyLevels: Array<'low' | 'medium' | 'high' | 'critical'> = ['low', 'medium', 'high', 'critical'];

  useEffect(() => {
    if (user) {
      loadPreferences();
      setPermission(Notification.permission);
    }
  }, [user]);

  const loadPreferences = async () => {
    try {
      const { data, error } = await supabase
        .from('vela_notification_preferences')
        .select('*')
        .eq('user_id', user!.id);

      if (error) throw error;

      const prefMap = new Map(data?.map(p => [`${p.suggestion_type}-${p.urgency_level}`, p]) || []);
      
      const allPrefs = suggestionTypes.flatMap(type =>
        urgencyLevels.map(urgency => ({
          suggestion_type: type,
          urgency_level: urgency,
          enabled: prefMap.get(`${type}-${urgency}`)?.enabled ?? true,
          sound_enabled: prefMap.get(`${type}-${urgency}`)?.sound_enabled ?? true,
          vibration_enabled: prefMap.get(`${type}-${urgency}`)?.vibration_enabled ?? true
        }))
      );

      setPreferences(allPrefs);
    } catch (error) {
      console.error('Error loading preferences:', error);
    } finally {
      setLoading(false);
    }
  };

  const requestPermission = async () => {
    try {
      const result = await Notification.requestPermission();
      setPermission(result);
      
      if (result === 'granted') {
        await subscribeToNotifications();
        toast.success('Notifications enabled');
      }
    } catch (error) {
      toast.error('Failed to enable notifications');
    }
  };

  const subscribeToNotifications = async () => {
    try {
      const registration = await navigator.serviceWorker.ready;
      const subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(import.meta.env.VITE_VAPID_PUBLIC_KEY || '')
      });

      await supabase.functions.invoke('subscribe-push-notifications', {
        body: { subscription, userId: user!.id }
      });
    } catch (error) {
      console.error('Subscription error:', error);
    }
  };

  const updatePreference = async (type: string, urgency: string, field: string, value: boolean) => {
    try {
      await supabase.from('vela_notification_preferences').upsert({
        user_id: user!.id,
        suggestion_type: type,
        urgency_level: urgency,
        [field]: value
      });

      setPreferences(prev => prev.map(p =>
        p.suggestion_type === type && p.urgency_level === urgency
          ? { ...p, [field]: value }
          : p
      ));
    } catch (error) {
      toast.error('Failed to update preference');
    }
  };

  const urlBase64ToUint8Array = (base64String: string) => {
    const padding = '='.repeat((4 - base64String.length % 4) % 4);
    const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
    const rawData = window.atob(base64);
    return new Uint8Array([...rawData].map(char => char.charCodeAt(0)));
  };

  if (loading) return <div>Loading...</div>;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bell className="h-5 w-5" />
          Notification Preferences
        </CardTitle>
        <CardDescription>
          Control how and when you receive Vela suggestions
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {permission !== 'granted' && (
          <div className="p-4 bg-blue-50 rounded-lg">
            <p className="text-sm mb-2">Enable browser notifications to receive Vela suggestions</p>
            <Button onClick={requestPermission}>
              <Bell className="h-4 w-4 mr-2" />
              Enable Notifications
            </Button>
          </div>
        )}

        {suggestionTypes.map(type => (
          <div key={type} className="space-y-3">
            <h3 className="font-medium capitalize">{type.replace(/_/g, ' ')}</h3>
            {urgencyLevels.map(urgency => {
              const pref = preferences.find(p => p.suggestion_type === type && p.urgency_level === urgency);
              if (!pref) return null;

              return (
                <div key={`${type}-${urgency}`} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                  <div className="flex items-center gap-4">
                    <Label className="capitalize text-sm">{urgency}</Label>
                    <div className="flex gap-2">
                      <Switch
                        checked={pref.enabled}
                        onCheckedChange={(checked) => updatePreference(type, urgency, 'enabled', checked)}
                      />
                      <Switch
                        checked={pref.sound_enabled}
                        onCheckedChange={(checked) => updatePreference(type, urgency, 'sound_enabled', checked)}
                        disabled={!pref.enabled}
                      />
                      <Switch
                        checked={pref.vibration_enabled}
                        onCheckedChange={(checked) => updatePreference(type, urgency, 'vibration_enabled', checked)}
                        disabled={!pref.enabled}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
