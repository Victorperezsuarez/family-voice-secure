import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase-client';
import type { FamilyActivity } from '@/types/family';
import { Clock, User, FileAudio, UserPlus } from 'lucide-react';

interface Props {
  familyId: string;
}

export function ActivityFeed({ familyId }: Props) {
  const [activities, setActivities] = useState<FamilyActivity[]>([]);

  useEffect(() => {
    loadActivities();
    
    const channel = supabase
      .channel('family-activity')
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'family_activity', filter: `family_id=eq.${familyId}` },
        () => loadActivities()
      )
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [familyId]);

  const loadActivities = async () => {
    const { data } = await supabase
      .from('family_activity')
      .select('*')
      .eq('family_id', familyId)
      .order('created_at', { ascending: false })
      .limit(20);

    if (data) setActivities(data);
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'recording_added': return <FileAudio className="w-4 h-4" />;
      case 'member_added': return <UserPlus className="w-4 h-4" />;
      case 'member_joined': return <User className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-3">
      {activities.length === 0 && (
        <p className="text-center text-muted-foreground py-8">No activity yet</p>
      )}
      {activities.map((activity) => (
        <div key={activity.id} className="flex gap-3 p-3 border rounded-lg">
          <div className="mt-1">{getIcon(activity.action_type)}</div>
          <div className="flex-1">
            <p className="text-sm">{activity.description}</p>
            <p className="text-xs text-muted-foreground mt-1">
              {new Date(activity.created_at).toLocaleString()}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
}
