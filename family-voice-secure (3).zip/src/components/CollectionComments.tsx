import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase-client';
import { CollectionComment } from '@/types/family';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/hooks/use-toast';
import { formatDistanceToNow } from 'date-fns';

interface CollectionCommentsProps {
  collectionId: string;
}

export function CollectionComments({ collectionId }: CollectionCommentsProps) {
  const [comments, setComments] = useState<CollectionComment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadComments();
  }, [collectionId]);

  const loadComments = async () => {
    try {
      const { data, error } = await supabase
        .from('collection_comments')
        .select(`*, profiles!collection_comments_user_id_fkey(email, full_name)`)
        .eq('collection_id', collectionId)
        .order('created_at', { ascending: false });

      if (error) throw error;

      const formatted = data?.map(c => ({
        ...c,
        user_email: c.profiles?.email,
        user_name: c.profiles?.full_name
      })) || [];

      setComments(formatted);
    } catch (error) {
      console.error('Error loading comments:', error);
    }
  };

  const handleAddComment = async () => {
    if (!newComment.trim()) return;

    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { error } = await supabase.from('collection_comments').insert({
        collection_id: collectionId,
        user_id: user.id,
        comment_text: newComment
      });

      if (error) throw error;

      await supabase.from('collection_activity').insert({
        collection_id: collectionId,
        user_id: user.id,
        action_type: 'added_comment'
      });

      setNewComment('');
      loadComments();
      toast({ title: 'Comment added!' });
    } catch (error: any) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <Textarea value={newComment} onChange={(e) => setNewComment(e.target.value)} placeholder="Add a comment..." rows={3} />
        <Button onClick={handleAddComment} disabled={loading} className="mt-2">Post Comment</Button>
      </div>
      <ScrollArea className="h-[300px]">
        <div className="space-y-3">
          {comments.map(comment => (
            <Card key={comment.id} className="p-4">
              <div className="flex justify-between items-start">
                <p className="font-medium text-sm">{comment.user_name || comment.user_email}</p>
                <p className="text-xs text-gray-500">{formatDistanceToNow(new Date(comment.created_at), { addSuffix: true })}</p>
              </div>
              <p className="text-sm mt-2">{comment.comment_text}</p>
            </Card>
          ))}
          {comments.length === 0 && <p className="text-sm text-gray-500">No comments yet</p>}
        </div>
      </ScrollArea>
    </div>
  );
}
