import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { CheckCircle2, Rocket, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export function VelaDeploymentBanner() {
  const [isVisible, setIsVisible] = useState(true);
  const navigate = useNavigate();

  if (!isVisible) return null;

  return (
    <Card className="bg-gradient-to-r from-amber-500 to-orange-500 text-white border-0 mb-6 relative">
      <div className="p-6 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="bg-white/20 p-3 rounded-full">
            <Rocket className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <h3 className="text-xl font-bold">Vela AI Desplegado</h3>
              <Badge className="bg-green-500 text-white border-0">
                <CheckCircle2 className="w-3 h-3 mr-1" />
                Activo
              </Badge>
            </div>
            <p className="text-amber-50">
              Sistema de preservación de memorias familiares completamente operativo
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Button 
            onClick={() => navigate('/vela-deployment')}
            variant="secondary"
            className="bg-white text-amber-600 hover:bg-amber-50"
          >
            Ver Estado del Sistema
          </Button>
          <Button
            onClick={() => setIsVisible(false)}
            variant="ghost"
            size="icon"
            className="text-white hover:bg-white/20"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </Card>
  );
}
