import { useOfflineSync } from '@/contexts/OfflineSyncContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { RefreshCw, Trash2, Clock, AlertCircle, CheckCircle2 } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export function EnhancedSyncStatusPanel() {
  const { isOnline, isSyncing, syncStats, queueItems, retrySync, clearQueue } = useOfflineSync();

  const totalItems = syncStats.pending + syncStats.syncing + syncStats.failed;
  const progress = totalItems > 0 ? ((totalItems - syncStats.pending) / totalItems) * 100 : 100;

  const getItemIcon = (status: string) => {
    switch (status) {
      case 'syncing': return <RefreshCw className="h-4 w-4 animate-spin text-blue-500" />;
      case 'error': return <AlertCircle className="h-4 w-4 text-destructive" />;
      case 'conflict': return <AlertCircle className="h-4 w-4 text-amber-500" />;
      case 'success': return <CheckCircle2 className="h-4 w-4 text-green-500" />;
      default: return <Clock className="h-4 w-4 text-muted-foreground" />;
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Sync Status</span>
          <Badge variant={isOnline ? 'default' : 'secondary'}>
            {isOnline ? 'Online' : 'Offline'}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {totalItems > 0 && (
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Progress</span>
              <span>{Math.round(progress)}%</span>
            </div>
            <Progress value={progress} />
          </div>
        )}

        <div className="grid grid-cols-3 gap-4 text-center">
          <div className="space-y-1">
            <div className="text-2xl font-bold text-yellow-500">{syncStats.pending}</div>
            <div className="text-xs text-muted-foreground">Pending</div>
          </div>
          <div className="space-y-1">
            <div className="text-2xl font-bold text-blue-500">{syncStats.syncing}</div>
            <div className="text-xs text-muted-foreground">Syncing</div>
          </div>
          <div className="space-y-1">
            <div className="text-2xl font-bold text-destructive">{syncStats.failed}</div>
            <div className="text-xs text-muted-foreground">Failed</div>
          </div>
        </div>

        {queueItems.length > 0 && (
          <ScrollArea className="h-64">
            <div className="space-y-2">
              {queueItems.map(item => (
                <div key={item.id} className="p-3 border rounded-lg space-y-1">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {getItemIcon(item.status)}
                      <span className="text-sm font-medium">{item.type.replace(/_/g, ' ')}</span>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {formatDistanceToNow(item.timestamp, { addSuffix: true })}
                    </Badge>
                  </div>
                  {item.error && (
                    <p className="text-xs text-destructive">{item.error}</p>
                  )}
                </div>
              ))}
            </div>
          </ScrollArea>
        )}

        <div className="flex gap-2">
          <Button onClick={retrySync} disabled={!isOnline || isSyncing} className="flex-1">
            <RefreshCw className="h-4 w-4 mr-2" />
            Retry Sync
          </Button>
          <Button onClick={clearQueue} variant="outline" disabled={queueItems.length === 0}>
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
