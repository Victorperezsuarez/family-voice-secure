import { useState } from 'react';
import { supabase } from '@/lib/supabase-client';
import { useAuth } from '@/contexts/AuthContext';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';

interface CreateFamilyModalProps {
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export function CreateFamilyModal({ open, onClose, onSuccess }: CreateFamilyModalProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !name.trim()) return;

    setLoading(true);
    try {
      const { data: family, error: familyError } = await supabase
        .from('families')
        .insert([{
          name: name.trim(),
          description: description.trim() || null,
          created_by: user.id
        }])
        .select()
        .single();

      if (familyError) throw familyError;

      await supabase
        .from('family_users')
        .insert([{
          family_id: family.id,
          user_id: user.id,
          role: 'admin'
        }]);

      await supabase
        .from('profiles')
        .update({ current_family_id: family.id })
        .eq('id', user.id);

      toast({ title: 'Family created successfully!' });
      setName('');
      setDescription('');
      onSuccess();
      onClose();
    } catch (error: any) {
      toast({ 
        title: 'Failed to create family', 
        description: error.message,
        variant: 'destructive' 
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Create New Family</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="name">Family Name *</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="The Smith Family"
              required
            />
          </div>
          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="A brief description of your family..."
              rows={3}
            />
          </div>
          <div className="flex gap-2 justify-end">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading || !name.trim()}>
              {loading ? 'Creating...' : 'Create Family'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
