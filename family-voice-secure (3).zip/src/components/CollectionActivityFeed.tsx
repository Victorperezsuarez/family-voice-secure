import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase-client';
import { CollectionActivity } from '@/types/family';
import { Card } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { formatDistanceToNow } from 'date-fns';

interface CollectionActivityFeedProps {
  collectionId: string;
}

export function CollectionActivityFeed({ collectionId }: CollectionActivityFeedProps) {
  const [activities, setActivities] = useState<CollectionActivity[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadActivities();
  }, [collectionId]);

  const loadActivities = async () => {
    try {
      const { data, error } = await supabase
        .from('collection_activity')
        .select(`
          *,
          profiles!collection_activity_user_id_fkey(email, full_name),
          recordings(title)
        `)
        .eq('collection_id', collectionId)
        .order('created_at', { ascending: false })
        .limit(20);

      if (error) throw error;

      const formatted = data?.map(item => ({
        ...item,
        user_email: item.profiles?.email,
        user_name: item.profiles?.full_name,
        recording_title: item.recordings?.title
      })) || [];

      setActivities(formatted);
    } catch (error) {
      console.error('Error loading activities:', error);
    } finally {
      setLoading(false);
    }
  };

  const getActivityText = (activity: CollectionActivity) => {
    const name = activity.user_name || activity.user_email || 'Someone';
    switch (activity.action_type) {
      case 'created': return `${name} created this collection`;
      case 'added_recording': return `${name} added "${activity.recording_title}"`;
      case 'removed_recording': return `${name} removed a recording`;
      case 'updated': return `${name} updated the collection`;
      case 'added_comment': return `${name} added a comment`;
      case 'invited_contributor': return `${name} invited a collaborator`;
      default: return `${name} performed an action`;
    }
  };

  if (loading) return <div className="text-sm text-gray-500">Loading activity...</div>;

  return (
    <ScrollArea className="h-[300px]">
      <div className="space-y-2">
        {activities.map(activity => (
          <Card key={activity.id} className="p-3">
            <p className="text-sm">{getActivityText(activity)}</p>
            <p className="text-xs text-gray-500 mt-1">
              {formatDistanceToNow(new Date(activity.created_at), { addSuffix: true })}
            </p>
          </Card>
        ))}
        {activities.length === 0 && <p className="text-sm text-gray-500">No activity yet</p>}
      </div>
    </ScrollArea>
  );
}
