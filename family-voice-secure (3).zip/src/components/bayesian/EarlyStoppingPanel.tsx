import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { AlertCircle, CheckCircle, StopCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';

interface EarlyStoppingEval {
  id: string;
  evaluated_at: string;
  should_stop: boolean;
  winning_combination_id: string | null;
  confidence_level: number;
  reason: string;
}

export function EarlyStoppingPanel({ testId }: { testId: string }) {
  const [enabled, setEnabled] = useState(false);
  const [confidenceThreshold, setConfidenceThreshold] = useState(0.95);
  const [minSampleSize, setMinSampleSize] = useState(100);
  const [evaluations, setEvaluations] = useState<EarlyStoppingEval[]>([]);
  const [loading, setLoading] = useState(false);
  const [testStopped, setTestStopped] = useState(false);

  useEffect(() => {
    loadEvaluations();
    checkTestStatus();
    const interval = setInterval(() => {
      loadEvaluations();
      checkTestStatus();
    }, 30000);
    return () => clearInterval(interval);
  }, [testId]);

  const loadEvaluations = async () => {
    const { data } = await supabase
      .from('notification_early_stopping_evaluations')
      .select('*')
      .eq('test_id', testId)
      .order('evaluated_at', { ascending: false })
      .limit(5);
    
    if (data) setEvaluations(data as any);
  };

  const checkTestStatus = async () => {
    const { data } = await supabase
      .from('notification_ab_tests')
      .select('stopped_early, winning_combination_id')
      .eq('id', testId)
      .single();
    
    if (data?.stopped_early) setTestStopped(true);
  };

  const checkEarlyStopping = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('analyze-ab-test', {
        body: { testId, action: 'check_early_stopping' }
      });
      if (error) throw error;
      await loadEvaluations();
      await checkTestStatus();
    } catch (error) {
      console.error('Early stopping check failed:', error);
    } finally {
      setLoading(false);
    }
  };

  const saveSettings = async () => {
    await supabase
      .from('notification_ab_tests')
      .update({
        early_stopping_enabled: enabled,
        confidence_threshold: confidenceThreshold,
        minimum_sample_size: minSampleSize
      })
      .eq('id', testId);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <StopCircle className="h-5 w-5 text-orange-500" />
            Early Stopping Configuration
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {testStopped && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-start gap-3">
              <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
              <div>
                <p className="font-medium text-green-900">Test Stopped Early</p>
                <p className="text-sm text-green-700">Winner identified with high confidence</p>
              </div>
            </div>
          )}

          <div className="flex items-center justify-between">
            <Label>Enable Early Stopping</Label>
            <Switch checked={enabled} onCheckedChange={setEnabled} disabled={testStopped} />
          </div>

          <div className="space-y-2">
            <Label>Confidence Threshold</Label>
            <Input
              type="number"
              value={confidenceThreshold}
              onChange={(e) => setConfidenceThreshold(parseFloat(e.target.value))}
              min={0.8}
              max={0.99}
              step={0.01}
              disabled={testStopped}
            />
            <p className="text-xs text-muted-foreground">
              Stop when winner probability exceeds this threshold
            </p>
          </div>

          <div className="space-y-2">
            <Label>Minimum Sample Size</Label>
            <Input
              type="number"
              value={minSampleSize}
              onChange={(e) => setMinSampleSize(parseInt(e.target.value))}
              min={50}
              step={50}
              disabled={testStopped}
            />
            <p className="text-xs text-muted-foreground">
              Minimum impressions before considering early stopping
            </p>
          </div>

          <div className="flex gap-2">
            <Button onClick={saveSettings} variant="outline" disabled={testStopped} className="flex-1">
              Save Settings
            </Button>
            <Button onClick={checkEarlyStopping} disabled={loading || testStopped} className="flex-1">
              {loading ? 'Checking...' : 'Check Now'}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Evaluation History</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {evaluations.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">
                No evaluations yet
              </p>
            ) : (
              evaluations.map((evaluation) => (
                <div key={evaluation.id} className="border rounded-lg p-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">
                      {new Date(evaluation.evaluated_at).toLocaleString()}
                    </span>
                    <Badge variant={evaluation.should_stop ? 'default' : 'secondary'}>
                      {evaluation.should_stop ? 'Stop Recommended' : 'Continue'}
                    </Badge>
                  </div>
                  <p className="text-sm">{evaluation.reason}</p>
                  {evaluation.confidence_level && (
                    <div className="flex items-center gap-2 text-sm">
                      <span className="text-muted-foreground">Confidence:</span>
                      <span className="font-medium">{(evaluation.confidence_level * 100).toFixed(1)}%</span>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}