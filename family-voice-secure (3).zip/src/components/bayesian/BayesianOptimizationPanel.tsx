import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Activity, TrendingUp, Target, Zap } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';

interface BayesianStats {
  combination_id: string;
  combination_name: string;
  alpha: number;
  beta: number;
  expected_value: number;
  probability_best: number;
  total_impressions: number;
  total_conversions: number;
  current_allocation?: number;
}

export function BayesianOptimizationPanel({ testId }: { testId: string }) {
  const [stats, setStats] = useState<BayesianStats[]>([]);
  const [loading, setLoading] = useState(false);
  const [optimizationEnabled, setOptimizationEnabled] = useState(false);
  const [explorationRate, setExplorationRate] = useState(0.10);
  const [autoRefresh, setAutoRefresh] = useState(true);

  useEffect(() => {
    loadBayesianStats();
    if (autoRefresh) {
      const interval = setInterval(loadBayesianStats, 30000);
      return () => clearInterval(interval);
    }
  }, [testId, autoRefresh]);

  const loadBayesianStats = async () => {
    const { data } = await supabase
      .from('notification_bayesian_stats')
      .select('*')
      .eq('test_id', testId)
      .order('probability_best', { ascending: false });
    
    if (data) setStats(data as any);
  };

  const runThompsonSampling = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('analyze-ab-test', {
        body: { testId, action: 'thompson_sampling' }
      });
      if (error) throw error;
      await loadBayesianStats();
    } catch (error) {
      console.error('Thompson sampling failed:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5 text-yellow-500" />
            Bayesian Optimization Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <Label>Enable Dynamic Allocation</Label>
            <Switch checked={optimizationEnabled} onCheckedChange={setOptimizationEnabled} />
          </div>
          
          <div className="space-y-2">
            <Label>Exploration Rate: {(explorationRate * 100).toFixed(0)}%</Label>
            <Slider value={[explorationRate * 100]} onValueChange={([v]) => setExplorationRate(v / 100)} max={50} step={5} />
            <p className="text-xs text-muted-foreground">
              Higher = more exploration, Lower = more exploitation
            </p>
          </div>

          <div className="flex items-center justify-between">
            <Label>Auto-refresh (30s)</Label>
            <Switch checked={autoRefresh} onCheckedChange={setAutoRefresh} />
          </div>

          <Button onClick={runThompsonSampling} disabled={loading} className="w-full">
            <Activity className="h-4 w-4 mr-2" />
            {loading ? 'Running...' : 'Run Thompson Sampling'}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Combination Performance</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {stats.map((stat, idx) => (
              <div key={stat.combination_id} className="border rounded-lg p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Badge variant={idx === 0 ? 'default' : 'outline'}>
                      #{idx + 1}
                    </Badge>
                    <span className="font-medium">{stat.combination_name}</span>
                  </div>
                  <Badge variant="secondary">
                    {(stat.probability_best * 100).toFixed(1)}% prob. best
                  </Badge>
                </div>

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-muted-foreground">Expected Value</p>
                    <p className="font-semibold">{(stat.expected_value * 100).toFixed(2)}%</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Samples</p>
                    <p className="font-semibold">{stat.total_impressions}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Conversions</p>
                    <p className="font-semibold">{stat.total_conversions}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Beta Params</p>
                    <p className="font-semibold text-xs">α={stat.alpha.toFixed(1)} β={stat.beta.toFixed(1)}</p>
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span>Confidence</span>
                    <span>{(stat.probability_best * 100).toFixed(1)}%</span>
                  </div>
                  <div className="h-2 bg-secondary rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-primary transition-all"
                      style={{ width: `${stat.probability_best * 100}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}