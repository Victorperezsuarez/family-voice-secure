import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Clock, Calendar, Play, Pause, CheckCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';

interface BackupConfig {
  id: string;
  provider: string;
  schedule: string;
  enabled: boolean;
  next_backup_at: string;
  created_at: string;
}

interface SchedulerStatusPanelProps {
  familyId: string;
  onRefresh: () => void;
}

export function SchedulerStatusPanel({ familyId, onRefresh }: SchedulerStatusPanelProps) {
  const [configs, setConfigs] = useState<BackupConfig[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadConfigs();
  }, [familyId]);

  const loadConfigs = async () => {
    try {
      const { data, error } = await supabase
        .from('backup_configs')
        .select('*')
        .eq('family_id', familyId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setConfigs(data || []);
    } catch (error) {
      console.error('Error loading configs:', error);
    } finally {
      setLoading(false);
    }
  };

  const toggleEnabled = async (configId: string, currentEnabled: boolean) => {
    try {
      const { error } = await supabase
        .from('backup_configs')
        .update({ enabled: !currentEnabled })
        .eq('id', configId);

      if (error) throw error;
      loadConfigs();
      onRefresh();
    } catch (error) {
      console.error('Error toggling config:', error);
    }
  };

  const getTimeUntilNext = (nextBackupAt: string) => {
    const next = new Date(nextBackupAt);
    const now = new Date();
    const diff = next.getTime() - now.getTime();
    
    if (diff < 0) return 'Overdue';
    
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(hours / 24);
    
    if (days > 0) return `in ${days} day${days > 1 ? 's' : ''}`;
    if (hours > 0) return `in ${hours} hour${hours > 1 ? 's' : ''}`;
    return 'Soon';
  };

  if (loading) {
    return <div className="text-center py-4">Loading...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Scheduled Backups</h3>
      </div>
      {configs.length === 0 ? (
        <Card>
          <CardContent className="py-8 text-center text-muted-foreground">
            No backup schedules configured yet.
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {configs.map((config) => (
            <Card key={config.id}>
              <CardContent className="py-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {config.enabled ? (
                      <CheckCircle className="h-5 w-5 text-green-500" />
                    ) : (
                      <Pause className="h-5 w-5 text-gray-400" />
                    )}
                    <div>
                      <div className="font-medium capitalize">
                        {config.provider.replace('_', ' ')} • {config.schedule}
                      </div>
                      {config.enabled && config.next_backup_at && (
                        <div className="text-sm text-muted-foreground flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          Next backup {getTimeUntilNext(config.next_backup_at)}
                        </div>
                      )}
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => toggleEnabled(config.id, config.enabled)}
                  >
                    {config.enabled ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
