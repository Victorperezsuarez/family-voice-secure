import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Play, Trash2, Volume2 } from 'lucide-react';
import { useState } from 'react';

interface VoiceSampleCardProps {
  sample: {
    id: string;
    audio_url: string;
    duration_seconds: number;
    emotion_type: string;
    speaking_style: string;
    quality_score: number;
    clarity_score: number;
    noise_level: string;
    prompt_text: string;
    created_at: string;
  };
  onDelete: (id: string) => void;
}

export function VoiceSampleCard({ sample, onDelete }: VoiceSampleCardProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [audio] = useState(new Audio(sample.audio_url));

  const handlePlay = () => {
    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
    } else {
      audio.play();
      setIsPlaying(true);
      audio.onended = () => setIsPlaying(false);
    }
  };

  const getQualityColor = (score: number) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 70) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <Card className="p-4">
      <div className="space-y-3">
        <div className="flex items-start justify-between">
          <div className="flex gap-2">
            <Badge variant="outline">{sample.emotion_type}</Badge>
            <Badge variant="outline">{sample.speaking_style}</Badge>
          </div>
          <Button variant="ghost" size="sm" onClick={() => onDelete(sample.id)}>
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>

        <p className="text-sm text-muted-foreground line-clamp-2">{sample.prompt_text}</p>

        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span>Quality Score</span>
            <span className={getQualityColor(sample.quality_score)}>{sample.quality_score}%</span>
          </div>
          <Progress value={sample.quality_score} className="h-2" />

          <div className="flex items-center justify-between text-sm">
            <span>Clarity</span>
            <span className={getQualityColor(sample.clarity_score)}>{sample.clarity_score}%</span>
          </div>
          <Progress value={sample.clarity_score} className="h-2" />

          <div className="flex items-center justify-between text-sm">
            <span>Noise Level</span>
            <Badge variant={sample.noise_level === 'low' ? 'default' : 'destructive'}>
              {sample.noise_level}
            </Badge>
          </div>
        </div>

        <Button onClick={handlePlay} className="w-full" variant="outline">
          {isPlaying ? <Volume2 className="mr-2 h-4 w-4" /> : <Play className="mr-2 h-4 w-4" />}
          {isPlaying ? 'Playing...' : 'Play Sample'}
        </Button>
      </div>
    </Card>
  );
}