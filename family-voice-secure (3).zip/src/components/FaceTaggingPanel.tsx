import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { User, Check, X } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { useToast } from '@/hooks/use-toast';

interface FaceTaggingPanelProps {
  photoId: string;
  photoUrl: string;
  familyId: string;
}

interface FaceTag {
  id?: string;
  x: number;
  y: number;
  width: number;
  height: number;
  confidence: number;
  family_member_id?: string;
  member_name?: string;
}

export function FaceTaggingPanel({ photoId, photoUrl, familyId }: FaceTaggingPanelProps) {
  const [faces, setFaces] = useState<FaceTag[]>([]);
  const [members, setMembers] = useState<any[]>([]);
  const [detecting, setDetecting] = useState(false);
  const [selectedFace, setSelectedFace] = useState<number | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    loadFamilyMembers();
    loadExistingTags();
  }, [photoId]);

  const loadFamilyMembers = async () => {
    const { data } = await supabase
      .from('family_members')
      .select('id, name')
      .eq('family_id', familyId);
    if (data) setMembers(data);
  };

  const loadExistingTags = async () => {
    const { data } = await supabase
      .from('photo_face_tags')
      .select('*, family_members(name)')
      .eq('photo_id', photoId);
    
    if (data) {
      setFaces(data.map(tag => ({
        id: tag.id,
        x: tag.bounding_box.x,
        y: tag.bounding_box.y,
        width: tag.bounding_box.width,
        height: tag.bounding_box.height,
        confidence: tag.confidence,
        family_member_id: tag.family_member_id,
        member_name: tag.family_members?.name
      })));
    }
  };

  const detectFaces = async () => {
    setDetecting(true);
    try {
      const { data, error } = await supabase.functions.invoke('detect-faces', {
        body: { photoUrl, photoId }
      });
      
      if (error) throw error;
      setFaces(data.faces || []);
      toast({ title: 'Success', description: `Detected ${data.detectedCount} faces` });
    } catch (error: any) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    } finally {
      setDetecting(false);
    }
  };

  const tagFace = async (faceIndex: number, memberId: string) => {
    const face = faces[faceIndex];
    try {
      const { error } = await supabase.from('photo_face_tags').insert({
        photo_id: photoId,
        family_member_id: memberId,
        bounding_box: { x: face.x, y: face.y, width: face.width, height: face.height },
        confidence: face.confidence,
        verified: true
      });
      
      if (error) throw error;
      await loadExistingTags();
      toast({ title: 'Success', description: 'Face tagged' });
    } catch (error: any) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h4 className="font-medium">Face Tagging</h4>
        <Button onClick={detectFaces} disabled={detecting} size="sm">
          <User className="h-4 w-4 mr-2" />
          {detecting ? 'Detecting...' : 'Detect Faces'}
        </Button>
      </div>

      <div className="relative">
        <img src={photoUrl} alt="Photo" className="w-full rounded-lg" />
        {faces.map((face, idx) => (
          <div
            key={idx}
            className="absolute border-2 border-blue-500 cursor-pointer hover:bg-blue-500/20"
            style={{
              left: `${face.x * 100}%`,
              top: `${face.y * 100}%`,
              width: `${face.width * 100}%`,
              height: `${face.height * 100}%`
            }}
            onClick={() => setSelectedFace(idx)}
          >
            {face.member_name && (
              <Badge className="absolute -top-6 left-0">{face.member_name}</Badge>
            )}
          </div>
        ))}
      </div>

      {selectedFace !== null && !faces[selectedFace].member_name && (
        <div className="flex gap-2">
          <Select onValueChange={(v) => tagFace(selectedFace, v)}>
            <SelectTrigger>
              <SelectValue placeholder="Tag person" />
            </SelectTrigger>
            <SelectContent>
              {members.map((m) => (
                <SelectItem key={m.id} value={m.id}>{m.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}
    </div>
  );
}
