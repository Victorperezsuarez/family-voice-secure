import { useState, useEffect } from 'react';
import { SearchResultItem } from './SearchResultItem';
import { SearchResult } from '@/types/search';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';

interface SemanticSearchResultsProps {
  results: SearchResult[];
  onPlayFromTimestamp: (recordingId: string, timestamp: number) => void;
  onViewTranscription: (transcriptionId: string, timestamp: number) => void;
  isLoading?: boolean;
}

export const SemanticSearchResults = ({
  results,
  onPlayFromTimestamp,
  onViewTranscription,
  isLoading,
}: SemanticSearchResultsProps) => {
  const [groupedResults, setGroupedResults] = useState<{
    high: SearchResult[];
    medium: SearchResult[];
    low: SearchResult[];
  }>({ high: [], medium: [], low: [] });

  useEffect(() => {
    const high = results.filter((r) => r.matchScore >= 0.7);
    const medium = results.filter((r) => r.matchScore >= 0.4 && r.matchScore < 0.7);
    const low = results.filter((r) => r.matchScore < 0.4);
    setGroupedResults({ high, medium, low });
  }, [results]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (results.length === 0) {
    return (
      <div className="text-center py-12 text-muted-foreground">
        No results found. Try a different search query.
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold">
          {results.length} {results.length === 1 ? 'Result' : 'Results'} Found
        </h2>
      </div>

      <Tabs defaultValue="all" className="w-full">
        <TabsList>
          <TabsTrigger value="all">
            All <Badge className="ml-2">{results.length}</Badge>
          </TabsTrigger>
          <TabsTrigger value="high">
            High Relevance <Badge className="ml-2">{groupedResults.high.length}</Badge>
          </TabsTrigger>
          <TabsTrigger value="medium">
            Medium <Badge className="ml-2">{groupedResults.medium.length}</Badge>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-3 mt-4">
          <ScrollArea className="h-[600px]">
            {results.map((result) => (
              <div key={result.id} className="mb-3">
                <SearchResultItem
                  result={result}
                  onPlayFromTimestamp={onPlayFromTimestamp}
                  onViewTranscription={onViewTranscription}
                />
              </div>
            ))}
          </ScrollArea>
        </TabsContent>

        <TabsContent value="high" className="space-y-3 mt-4">
          <ScrollArea className="h-[600px]">
            {groupedResults.high.map((result) => (
              <div key={result.id} className="mb-3">
                <SearchResultItem
                  result={result}
                  onPlayFromTimestamp={onPlayFromTimestamp}
                  onViewTranscription={onViewTranscription}
                />
              </div>
            ))}
          </ScrollArea>
        </TabsContent>

        <TabsContent value="medium" className="space-y-3 mt-4">
          <ScrollArea className="h-[600px]">
            {groupedResults.medium.map((result) => (
              <div key={result.id} className="mb-3">
                <SearchResultItem
                  result={result}
                  onPlayFromTimestamp={onPlayFromTimestamp}
                  onViewTranscription={onViewTranscription}
                />
              </div>
            ))}
          </ScrollArea>
        </TabsContent>
      </Tabs>
    </div>
  );
};
