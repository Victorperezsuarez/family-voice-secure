import { useState } from 'react';
import { ArrowUp, CreditCard, Loader2 } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase-client';
import { useToast } from '@/hooks/use-toast';

interface LicenseUpgradeDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  purchaseId: string;
  currentLicense: string;
  newLicense: string;
  templateName: string;
  onSuccess?: () => void;
}

export function LicenseUpgradeDialog({
  open,
  onOpenChange,
  purchaseId,
  currentLicense,
  newLicense,
  templateName,
  onSuccess
}: LicenseUpgradeDialogProps) {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleUpgrade = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('upgrade-license', {
        body: { purchaseId, newLicenseType: newLicense }
      });

      if (error) throw error;

      // In production, integrate Stripe Elements here
      toast({
        title: 'Upgrade initiated',
        description: `Upgrading to ${newLicense} license for $${data.upgradeCost.toFixed(2)}`
      });

      onSuccess?.();
      onOpenChange(false);
    } catch (error: any) {
      toast({
        title: 'Upgrade failed',
        description: error.message,
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ArrowUp className="h-5 w-5" />
            Upgrade License
          </DialogTitle>
          <DialogDescription>{templateName}</DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
            <div>
              <p className="text-sm font-medium">Current License</p>
              <Badge variant="secondary" className="mt-1">{currentLicense}</Badge>
            </div>
            <ArrowUp className="h-5 w-5 text-muted-foreground" />
            <div>
              <p className="text-sm font-medium">New License</p>
              <Badge className="mt-1">{newLicense}</Badge>
            </div>
          </div>

          <div className="space-y-2">
            <h4 className="font-medium">Upgrade Benefits</h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• Commercial use allowed</li>
              <li>• Use in client projects</li>
              <li>• Priority support</li>
              <li>• Lifetime updates</li>
            </ul>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={loading}>
            Cancel
          </Button>
          <Button onClick={handleUpgrade} disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Processing...
              </>
            ) : (
              <>
                <CreditCard className="mr-2 h-4 w-4" />
                Upgrade License
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}