import { useState, useEffect } from 'react';
import { ThumbsUp, ThumbsDown, BadgeCheck, Flag } from 'lucide-react';
import { ReportContentModal } from './ReportContentModal';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { StarRating } from '@/components/StarRating';
import { supabase } from '@/lib/supabase-client';
import { useToast } from '@/hooks/use-toast';

interface Review {
  id: string;
  rating: number;
  review_text: string;
  is_verified: boolean;
  usage_days: number;
  created_at: string;
  family_id: string;
  helpful_votes: number;
  unhelpful_votes: number;
  user_vote?: string;
}

interface TemplateReviewsListProps {
  templateId: string;
  currentFamilyId?: string;
}

export function TemplateReviewsList({ templateId, currentFamilyId }: TemplateReviewsListProps) {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [reportModalOpen, setReportModalOpen] = useState(false);
  const [reportReviewId, setReportReviewId] = useState<string>('');
  const { toast } = useToast();

  useEffect(() => {
    loadReviews();
  }, [templateId]);

  const loadReviews = async () => {
    try {
      const { data, error } = await supabase
        .from('template_reviews')
        .select(`
          *,
          helpful_votes:review_votes!review_id(count),
          unhelpful_votes:review_votes!review_id(count)
        `)
        .eq('template_id', templateId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setReviews(data || []);
    } catch (error) {
      toast({ title: 'Failed to load reviews', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const handleVote = async (reviewId: string, voteType: string) => {
    if (!currentFamilyId) {
      toast({ title: 'Please sign in to vote', variant: 'destructive' });
      return;
    }

    try {
      const { error } = await supabase.functions.invoke('vote-on-review', {
        body: { reviewId, familyId: currentFamilyId, voteType }
      });

      if (error) throw error;
      loadReviews();
    } catch (error) {
      toast({ title: 'Failed to submit vote', variant: 'destructive' });
    }
  };

  if (loading) return <div>Loading reviews...</div>;

  return (
    <div className="space-y-4">
      {reviews.map((review) => (
        <Card key={review.id} className="p-4">
          <div className="flex items-start justify-between mb-2">
            <div className="flex items-center gap-2">
              <StarRating rating={review.rating} size={16} />
              {review.is_verified && (
                <BadgeCheck className="w-4 h-4 text-blue-500" title="Verified User (30+ days)" />
              )}
            </div>
            <span className="text-sm text-muted-foreground">
              {new Date(review.created_at).toLocaleDateString()}
            </span>
          </div>
          
          {review.review_text && (
            <p className="text-sm mb-3">{review.review_text}</p>
          )}
          
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleVote(review.id, 'helpful')}
            >
              <ThumbsUp className="w-4 h-4 mr-1" />
              {review.helpful_votes || 0}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleVote(review.id, 'unhelpful')}
            >
              <ThumbsDown className="w-4 h-4 mr-1" />
              {review.unhelpful_votes || 0}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                setReportReviewId(review.id);
                setReportModalOpen(true);
              }}
            >
              <Flag className="w-4 h-4" />
            </Button>
          </div>
        </Card>
      ))}
      
      <ReportContentModal
        open={reportModalOpen}
        onOpenChange={setReportModalOpen}
        contentType="review"
        contentId={reportReviewId}
      />
    </div>
  );
}
