import { Progress } from '@/components/ui/progress';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AlertCircle, TrendingUp } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface UsageMeterCardProps {
  title: string;
  current: number;
  max: number;
  unit: string;
  icon: React.ReactNode;
  onUpgrade?: () => void;
}

export function UsageMeterCard({ title, current, max, unit, icon, onUpgrade }: UsageMeterCardProps) {
  const isUnlimited = max === -1;
  const percentage = isUnlimited ? 0 : (current / max) * 100;
  const isNearLimit = percentage > 80;
  const isAtLimit = percentage >= 100;

  const formatValue = (value: number) => {
    if (unit === 'GB') {
      return (value / (1024 * 1024 * 1024)).toFixed(2);
    }
    return value.toString();
  };

  return (
    <Card className={isAtLimit ? 'border-red-500' : isNearLimit ? 'border-yellow-500' : ''}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold">{formatValue(current)}</span>
            <span className="text-sm text-muted-foreground">
              {isUnlimited ? 'Unlimited' : `/ ${formatValue(max)} ${unit}`}
            </span>
          </div>
          
          {!isUnlimited && (
            <Progress 
              value={Math.min(percentage, 100)} 
              className={isAtLimit ? 'bg-red-100' : isNearLimit ? 'bg-yellow-100' : ''}
            />
          )}

          {isAtLimit && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                Limit reached. Upgrade to continue.
              </AlertDescription>
            </Alert>
          )}

          {isNearLimit && !isAtLimit && (
            <Alert>
              <TrendingUp className="h-4 w-4" />
              <AlertDescription>
                You're using {percentage.toFixed(0)}% of your limit.
              </AlertDescription>
            </Alert>
          )}

          {(isNearLimit || isAtLimit) && onUpgrade && (
            <Button onClick={onUpgrade} className="w-full" variant={isAtLimit ? 'default' : 'outline'}>
              Upgrade Plan
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}