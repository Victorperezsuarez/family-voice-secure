import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Plus, RefreshCw } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';
import { CorrelationRuleCard } from './CorrelationRuleCard';
import { CreateCorrelationRuleDialog } from './CreateCorrelationRuleDialog';
import { AlertGroupsList } from './AlertGroupsList';

export function AlertCorrelationPanel() {
  const [rules, setRules] = useState<any[]>([]);
  const [groups, setGroups] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingRule, setEditingRule] = useState<any>(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [rulesRes, groupsRes] = await Promise.all([
        supabase.from('alert_correlation_rules').select('*').order('created_at', { ascending: false }),
        supabase.from('alert_groups').select('*, alert_group_members(count)').eq('status', 'active').order('first_alert_at', { ascending: false })
      ]);

      if (rulesRes.error) throw rulesRes.error;
      if (groupsRes.error) throw groupsRes.error;

      setRules(rulesRes.data || []);
      setGroups(groupsRes.data || []);
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleToggleRule = async (ruleId: string, enabled: boolean) => {
    try {
      const { error } = await supabase
        .from('alert_correlation_rules')
        .update({ enabled })
        .eq('id', ruleId);
      if (error) throw error;
      toast.success(`Rule ${enabled ? 'enabled' : 'disabled'}`);
      loadData();
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  const handleDeleteRule = async (ruleId: string) => {
    if (!confirm('Delete this correlation rule?')) return;
    try {
      const { error } = await supabase
        .from('alert_correlation_rules')
        .delete()
        .eq('id', ruleId);
      if (error) throw error;
      toast.success('Rule deleted');
      loadData();
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  const runCorrelation = async () => {
    try {
      const { error } = await supabase.functions.invoke('correlate-alerts');
      if (error) throw error;
      toast.success('Alert correlation completed');
      loadData();
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Alert Correlation</CardTitle>
            <div className="flex gap-2">
              <Button onClick={runCorrelation} variant="outline" size="sm">
                <RefreshCw className="h-4 w-4 mr-2" />
                Run Correlation
              </Button>
              <Button onClick={() => { setEditingRule(null); setDialogOpen(true); }} size="sm">
                <Plus className="h-4 w-4 mr-2" />
                New Rule
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="rules">
            <TabsList>
              <TabsTrigger value="rules">Correlation Rules</TabsTrigger>
              <TabsTrigger value="groups">Alert Groups ({groups.length})</TabsTrigger>
            </TabsList>

            <TabsContent value="rules" className="space-y-4">
              {loading ? (
                <p className="text-muted-foreground">Loading...</p>
              ) : rules.length === 0 ? (
                <p className="text-muted-foreground">No correlation rules configured</p>
              ) : (
                <div className="grid gap-4">
                  {rules.map(rule => (
                    <CorrelationRuleCard
                      key={rule.id}
                      rule={rule}
                      onEdit={(r) => { setEditingRule(r); setDialogOpen(true); }}
                      onDelete={handleDeleteRule}
                      onToggle={handleToggleRule}
                    />
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="groups">
              <AlertGroupsList groups={groups} onUpdate={loadData} />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <CreateCorrelationRuleDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        rule={editingRule}
        onSuccess={loadData}
      />
    </div>
  );
}