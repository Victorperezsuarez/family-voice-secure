import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { supabase } from '@/lib/supabase-client';
import { Badge } from '@/components/ui/badge';

export function TemplateComparisonTable() {
  const [templates, setTemplates] = useState<any[]>([]);

  useEffect(() => {
    loadTemplatePerformance();
  }, []);

  const loadTemplatePerformance = async () => {
    try {
      const { data: analytics } = await supabase
        .from('notification_analytics')
        .select('*, notification_templates(name)');

      if (analytics) {
        const templateStats: Record<string, any> = {};

        analytics.forEach((item: any) => {
          const templateId = item.template_id;
          if (!templateStats[templateId]) {
            templateStats[templateId] = {
              id: templateId,
              name: item.notification_templates?.name || 'Unknown',
              sent: 0,
              delivered: 0,
              clicked: 0,
              actions: 0,
              conversions: 0
            };
          }
          templateStats[templateId].sent++;
          if (item.delivered_at) templateStats[templateId].delivered++;
          if (item.clicked_at) templateStats[templateId].clicked++;
          if (item.action_taken) templateStats[templateId].actions++;
          if (item.conversion_completed) templateStats[templateId].conversions++;
        });

        const formattedTemplates = Object.values(templateStats).map((t: any) => ({
          ...t,
          deliveryRate: t.sent > 0 ? (t.delivered / t.sent) * 100 : 0,
          clickRate: t.delivered > 0 ? (t.clicked / t.delivered) * 100 : 0,
          actionRate: t.clicked > 0 ? (t.actions / t.clicked) * 100 : 0,
          conversionRate: t.actions > 0 ? (t.conversions / t.actions) * 100 : 0
        })).sort((a, b) => b.conversionRate - a.conversionRate);

        setTemplates(formattedTemplates);
      }
    } catch (error) {
      console.error('Error loading template performance:', error);
    }
  };

  const getRatingBadge = (rate: number) => {
    if (rate >= 50) return <Badge className="bg-green-500">Excellent</Badge>;
    if (rate >= 30) return <Badge className="bg-blue-500">Good</Badge>;
    if (rate >= 15) return <Badge className="bg-yellow-500">Average</Badge>;
    return <Badge variant="destructive">Poor</Badge>;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Template Performance Comparison</CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Template Name</TableHead>
              <TableHead className="text-right">Sent</TableHead>
              <TableHead className="text-right">Delivery Rate</TableHead>
              <TableHead className="text-right">Click Rate</TableHead>
              <TableHead className="text-right">Action Rate</TableHead>
              <TableHead className="text-right">Conversion Rate</TableHead>
              <TableHead>Rating</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {templates.map((template) => (
              <TableRow key={template.id}>
                <TableCell className="font-medium">{template.name}</TableCell>
                <TableCell className="text-right">{template.sent}</TableCell>
                <TableCell className="text-right">{template.deliveryRate.toFixed(1)}%</TableCell>
                <TableCell className="text-right">{template.clickRate.toFixed(1)}%</TableCell>
                <TableCell className="text-right">{template.actionRate.toFixed(1)}%</TableCell>
                <TableCell className="text-right font-bold">{template.conversionRate.toFixed(1)}%</TableCell>
                <TableCell>{getRatingBadge(template.conversionRate)}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
