import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Users } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';

interface TopFamiliesTableProps {
  families: Array<{ familyId: string; count: number }>;
}

export function TopFamiliesTable({ families }: TopFamiliesTableProps) {
  const [familyNames, setFamilyNames] = useState<Record<string, string>>({});

  useEffect(() => {
    loadFamilyNames();
  }, [families]);

  const loadFamilyNames = async () => {
    if (families.length === 0) return;

    const familyIds = families.map(f => f.familyId);
    const { data } = await supabase
      .from('families')
      .select('id, name')
      .in('id', familyIds);

    if (data) {
      const names: Record<string, string> = {};
      data.forEach(family => {
        names[family.id] = family.name;
      });
      setFamilyNames(names);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users className="h-5 w-5" />
          Most Active Families
        </CardTitle>
        <CardDescription>Families with the highest template usage</CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Rank</TableHead>
              <TableHead>Family</TableHead>
              <TableHead className="text-right">Usage Count</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {families.map((family, index) => (
              <TableRow key={family.familyId}>
                <TableCell>
                  <Badge variant={index < 3 ? 'default' : 'secondary'}>
                    #{index + 1}
                  </Badge>
                </TableCell>
                <TableCell className="font-medium">
                  {familyNames[family.familyId] || 'Loading...'}
                </TableCell>
                <TableCell className="text-right">{family.count}</TableCell>
              </TableRow>
            ))}
            {families.length === 0 && (
              <TableRow>
                <TableCell colSpan={3} className="text-center text-muted-foreground">
                  No usage data available yet
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}