import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { X } from 'lucide-react';

interface AnomalyDetails {
  id: string;
  timestamp: string;
  metricName: string;
  actualValue: number;
  baselineValue: number;
  anomalyScore: number;
  type: string;
  deviationPercent: number;
  isNovel: boolean;
  alertTriggered: boolean;
}

interface Props {
  anomaly: AnomalyDetails | null;
  onClose: () => void;
}

export const AnomalyDetailsPanel: React.FC<Props> = ({ anomaly, onClose }) => {
  if (!anomaly) return null;

  const getSeverityColor = (score: number) => {
    if (score >= 80) return 'destructive';
    if (score >= 60) return 'default';
    return 'secondary';
  };

  return (
    <Card className="border-2">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Anomaly Details</CardTitle>
        <Button variant="ghost" size="icon" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <div className="text-sm text-muted-foreground">Metric</div>
          <div className="font-semibold">{anomaly.metricName}</div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <div className="text-sm text-muted-foreground">Actual Value</div>
            <div className="text-lg font-bold text-red-600">{anomaly.actualValue.toFixed(2)}</div>
          </div>
          <div>
            <div className="text-sm text-muted-foreground">Baseline</div>
            <div className="text-lg font-bold text-blue-600">{anomaly.baselineValue.toFixed(2)}</div>
          </div>
        </div>
        <div>
          <div className="text-sm text-muted-foreground">Anomaly Score</div>
          <Badge variant={getSeverityColor(anomaly.anomalyScore)}>{anomaly.anomalyScore.toFixed(1)}</Badge>
        </div>
        <div>
          <div className="text-sm text-muted-foreground">Deviation</div>
          <div className="font-semibold">{anomaly.deviationPercent.toFixed(1)}%</div>
        </div>
        <div className="flex gap-2">
          <Badge variant="outline">{anomaly.type}</Badge>
          {anomaly.isNovel && <Badge variant="secondary">Novel Pattern</Badge>}
          {anomaly.alertTriggered && <Badge>Alert Triggered</Badge>}
        </div>
        <div className="text-xs text-muted-foreground">{new Date(anomaly.timestamp).toLocaleString()}</div>
      </CardContent>
    </Card>
  );
};
