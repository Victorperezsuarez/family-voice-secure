import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Edit, Trash2, Clock, Link as LinkIcon } from 'lucide-react';

interface CorrelationRuleCardProps {
  rule: any;
  onEdit: (rule: any) => void;
  onDelete: (ruleId: string) => void;
  onToggle: (ruleId: string, enabled: boolean) => void;
}

export function CorrelationRuleCard({ rule, onEdit, onDelete, onToggle }: CorrelationRuleCardProps) {
  const typeColors = {
    time_based: 'bg-blue-500',
    cascading: 'bg-orange-500',
    pattern: 'bg-purple-500',
    dependency: 'bg-green-500'
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-2">
        <div className="space-y-1">
          <CardTitle className="text-base font-medium">{rule.name}</CardTitle>
          <p className="text-sm text-muted-foreground">{rule.description}</p>
        </div>
        <Switch
          checked={rule.enabled}
          onCheckedChange={(checked) => onToggle(rule.id, checked)}
        />
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="flex flex-wrap gap-2">
            <Badge className={typeColors[rule.correlation_type as keyof typeof typeColors]}>
              {rule.correlation_type.replace('_', ' ')}
            </Badge>
            {rule.detect_cascading && (
              <Badge variant="outline">Cascading Detection</Badge>
            )}
            {rule.enable_root_cause_analysis && (
              <Badge variant="outline">Root Cause Analysis</Badge>
            )}
          </div>

          <div className="grid grid-cols-2 gap-2 text-sm">
            <div className="flex items-center gap-1 text-muted-foreground">
              <Clock className="h-3 w-3" />
              <span>{rule.time_window_minutes}m window</span>
            </div>
            <div className="flex items-center gap-1 text-muted-foreground">
              <LinkIcon className="h-3 w-3" />
              <span>Min {rule.min_alerts_for_group} alerts</span>
            </div>
          </div>

          <div className="flex gap-2">
            <Button size="sm" variant="outline" onClick={() => onEdit(rule)}>
              <Edit className="h-3 w-3 mr-1" />
              Edit
            </Button>
            <Button size="sm" variant="outline" onClick={() => onDelete(rule.id)}>
              <Trash2 className="h-3 w-3 mr-1" />
              Delete
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}