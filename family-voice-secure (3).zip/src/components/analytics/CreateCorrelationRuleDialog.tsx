import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';

interface CreateCorrelationRuleDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  rule?: any;
  onSuccess: () => void;
}

export function CreateCorrelationRuleDialog({ open, onOpenChange, rule, onSuccess }: CreateCorrelationRuleDialogProps) {
  const [formData, setFormData] = useState({
    name: rule?.name || '',
    description: rule?.description || '',
    correlation_type: rule?.correlation_type || 'time_based',
    time_window_minutes: rule?.time_window_minutes || 5,
    min_alerts_for_group: rule?.min_alerts_for_group || 2,
    template_scope: rule?.template_scope || 'any',
    detect_cascading: rule?.detect_cascading ?? true,
    cascading_delay_seconds: rule?.cascading_delay_seconds || 30,
    enable_root_cause_analysis: rule?.enable_root_cause_analysis ?? true,
    similarity_threshold: rule?.similarity_threshold || 0.7,
    enabled: rule?.enabled ?? true
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      if (rule) {
        const { error } = await supabase
          .from('alert_correlation_rules')
          .update(formData)
          .eq('id', rule.id);
        if (error) throw error;
        toast.success('Correlation rule updated');
      } else {
        const { error } = await supabase
          .from('alert_correlation_rules')
          .insert([formData]);
        if (error) throw error;
        toast.success('Correlation rule created');
      }
      onSuccess();
      onOpenChange(false);
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{rule ? 'Edit' : 'Create'} Correlation Rule</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label>Name</Label>
            <Input
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
            />
          </div>

          <div className="space-y-2">
            <Label>Description</Label>
            <Textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={2}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Correlation Type</Label>
              <Select
                value={formData.correlation_type}
                onValueChange={(value) => setFormData({ ...formData, correlation_type: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="time_based">Time-Based</SelectItem>
                  <SelectItem value="cascading">Cascading</SelectItem>
                  <SelectItem value="pattern">Pattern</SelectItem>
                  <SelectItem value="dependency">Dependency</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Template Scope</Label>
              <Select
                value={formData.template_scope}
                onValueChange={(value) => setFormData({ ...formData, template_scope: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="same_template">Same Template</SelectItem>
                  <SelectItem value="same_family">Same Family</SelectItem>
                  <SelectItem value="any">Any</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Time Window (minutes)</Label>
              <Input
                type="number"
                value={formData.time_window_minutes}
                onChange={(e) => setFormData({ ...formData, time_window_minutes: parseInt(e.target.value) })}
                min={1}
              />
            </div>

            <div className="space-y-2">
              <Label>Min Alerts for Group</Label>
              <Input
                type="number"
                value={formData.min_alerts_for_group}
                onChange={(e) => setFormData({ ...formData, min_alerts_for_group: parseInt(e.target.value) })}
                min={2}
              />
            </div>
          </div>

          <div className="flex items-center justify-between">
            <Label>Detect Cascading Failures</Label>
            <Switch
              checked={formData.detect_cascading}
              onCheckedChange={(checked) => setFormData({ ...formData, detect_cascading: checked })}
            />
          </div>

          {formData.detect_cascading && (
            <div className="space-y-2">
              <Label>Cascading Delay (seconds)</Label>
              <Input
                type="number"
                value={formData.cascading_delay_seconds}
                onChange={(e) => setFormData({ ...formData, cascading_delay_seconds: parseInt(e.target.value) })}
                min={1}
              />
            </div>
          )}

          <div className="flex items-center justify-between">
            <Label>Enable Root Cause Analysis</Label>
            <Switch
              checked={formData.enable_root_cause_analysis}
              onCheckedChange={(checked) => setFormData({ ...formData, enable_root_cause_analysis: checked })}
            />
          </div>

          <div className="flex gap-2 justify-end">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit">
              {rule ? 'Update' : 'Create'} Rule
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}