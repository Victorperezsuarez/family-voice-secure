import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Scatter, ScatterChart, ZAxis } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface AnomalyDataPoint {
  timestamp: string;
  value: number;
  baseline: number;
  anomalyScore: number;
  type: string;
}

interface Props {
  data: AnomalyDataPoint[];
  onPointClick?: (point: AnomalyDataPoint) => void;
}

export const AnomalyTimeSeriesChart: React.FC<Props> = ({ data, onPointClick }) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Anomaly Time Series</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="timestamp" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="value" stroke="#ef4444" name="Actual Value" />
            <Line type="monotone" dataKey="baseline" stroke="#3b82f6" name="Baseline" strokeDasharray="5 5" />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
};
