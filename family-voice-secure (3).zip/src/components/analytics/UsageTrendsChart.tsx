import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface UsageTrendsChartProps {
  data: Array<{
    date: string;
    active_users: number;
    new_installations: number;
    total_events: number;
  }>;
}

export default function UsageTrendsChart({ data }: UsageTrendsChartProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Usage Trends</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="active_users" stroke="#8b5cf6" name="Active Users" />
            <Line type="monotone" dataKey="new_installations" stroke="#3b82f6" name="New Installs" />
            <Line type="monotone" dataKey="total_events" stroke="#10b981" name="Total Events" />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
