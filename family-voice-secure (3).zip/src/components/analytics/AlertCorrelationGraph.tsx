import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase-client';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, ArrowRight, Target } from 'lucide-react';

interface AlertCorrelationGraphProps {
  groupId: string;
}

export function AlertCorrelationGraph({ groupId }: AlertCorrelationGraphProps) {
  const [alerts, setAlerts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAlerts();
  }, [groupId]);

  const loadAlerts = async () => {
    try {
      const { data, error } = await supabase
        .from('alert_group_members')
        .select(`
          *,
          triggered_alerts (
            id,
            metric_name,
            metric_value,
            threshold_value,
            severity,
            triggered_at,
            alert_rules (rule_name)
          )
        `)
        .eq('alert_group_id', groupId)
        .order('added_at', { ascending: true });

      if (error) throw error;
      setAlerts(data || []);
    } catch (error) {
      console.error('Error loading alerts:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="text-sm text-muted-foreground">Loading correlation graph...</div>;
  }

  if (alerts.length === 0) {
    return <div className="text-sm text-muted-foreground">No alerts in this group</div>;
  }

  return (
    <div className="space-y-3">
      <h4 className="text-sm font-medium">Alert Correlation Graph</h4>
      <div className="space-y-2">
        {alerts.map((member, index) => {
          const alert = member.triggered_alerts;
          if (!alert) return null;

          return (
            <div key={member.id}>
              <Card className={`p-3 ${member.is_root_cause ? 'border-red-500 border-2' : ''}`}>
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0">
                    {member.is_root_cause ? (
                      <Target className="h-5 w-5 text-red-500" />
                    ) : (
                      <AlertTriangle className={`h-5 w-5 ${
                        alert.severity === 'critical' ? 'text-red-500' : 
                        alert.severity === 'warning' ? 'text-yellow-500' : 
                        'text-blue-500'
                      }`} />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="text-sm font-medium truncate">
                        {alert.alert_rules?.rule_name || 'Alert'}
                      </p>
                      {member.is_root_cause && (
                        <Badge variant="destructive" className="text-xs">Root Cause</Badge>
                      )}
                      {member.is_cascading_effect && (
                        <Badge variant="outline" className="text-xs">Cascading</Badge>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground truncate">
                      {alert.metric_name}
                    </p>
                    <div className="flex items-center gap-4 mt-1 text-xs text-muted-foreground">
                      <span>Value: {alert.metric_value}</span>
                      <span>Threshold: {alert.threshold_value}</span>
                      <span>{new Date(alert.triggered_at).toLocaleTimeString()}</span>
                    </div>
                    {member.correlation_score && (
                      <div className="mt-1">
                        <div className="flex items-center gap-2">
                          <div className="flex-1 bg-muted rounded-full h-1.5">
                            <div 
                              className="bg-primary h-1.5 rounded-full"
                              style={{ width: `${member.correlation_score * 100}%` }}
                            />
                          </div>
                          <span className="text-xs text-muted-foreground">
                            {(member.correlation_score * 100).toFixed(0)}%
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </Card>
              {index < alerts.length - 1 && (
                <div className="flex justify-center py-1">
                  <ArrowRight className="h-4 w-4 text-muted-foreground" />
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}