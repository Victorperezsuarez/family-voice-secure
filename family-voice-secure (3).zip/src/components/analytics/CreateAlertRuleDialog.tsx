import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Switch } from '@/components/ui/switch';
import { Plus } from 'lucide-react';
import { useState } from 'react';
import AdvancedConditionBuilder from './AdvancedConditionBuilder';

interface CreateAlertRuleDialogProps {
  templateId: string;
  onCreateRule: (rule: any) => void;
}

export function CreateAlertRuleDialog({ templateId, onCreateRule }: CreateAlertRuleDialogProps) {
  const [open, setOpen] = useState(false);
  const [ruleType, setRuleType] = useState('install_threshold');
  const [conditionType, setConditionType] = useState('simple');
  const [threshold, setThreshold] = useState('100');
  const [channels, setChannels] = useState(['in_app', 'email']);
  const [cooldownMinutes, setCooldownMinutes] = useState(60);
  const [smartThresholdEnabled, setSmartThresholdEnabled] = useState(false);
  const [advancedConfig, setAdvancedConfig] = useState<any>({});

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onCreateRule({
      template_id: templateId,
      rule_type: ruleType,
      metric: ruleType === 'install_threshold' ? 'installs' : 'violations',
      threshold_value: parseInt(threshold),
      notification_channels: channels,
      condition_type: conditionType,
      cooldown_minutes: cooldownMinutes,
      smart_threshold_enabled: smartThresholdEnabled,
      ...advancedConfig
    });
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button><Plus className="w-4 h-4 mr-2" />Create Alert Rule</Button>
      </DialogTrigger>
      <DialogContent className="max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create Advanced Alert Rule</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label>Alert Type</Label>
            <Select value={ruleType} onValueChange={setRuleType}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="install_threshold">Install Threshold</SelectItem>
                <SelectItem value="license_violation">License Violation</SelectItem>
                <SelectItem value="usage_spike">Usage Spike</SelectItem>
                <SelectItem value="conversion_milestone">Conversion Milestone</SelectItem>
                <SelectItem value="feature_adoption">Feature Adoption</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Condition Type</Label>
            <Select value={conditionType} onValueChange={setConditionType}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="simple">Simple Threshold</SelectItem>
                <SelectItem value="percentage">Percentage Change</SelectItem>
                <SelectItem value="comparison">Time Period Comparison</SelectItem>
                <SelectItem value="combined">Combined Conditions</SelectItem>
                <SelectItem value="formula">Custom Formula</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {conditionType === 'simple' && (
            <div>
              <Label>Threshold Value</Label>
              <Input type="number" value={threshold} onChange={(e) => setThreshold(e.target.value)} />
            </div>
          )}

          <AdvancedConditionBuilder 
            conditionType={conditionType}
            onConditionChange={setAdvancedConfig}
          />

          <div>
            <Label>Cooldown Period (minutes)</Label>
            <Input 
              type="number" 
              value={cooldownMinutes} 
              onChange={(e) => setCooldownMinutes(Number(e.target.value))}
              min={1}
            />
            <p className="text-xs text-muted-foreground mt-1">
              Prevent duplicate alerts for this duration
            </p>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label>Smart Threshold Auto-Adjustment</Label>
              <p className="text-xs text-muted-foreground">
                Automatically adjust thresholds based on historical patterns
              </p>
            </div>
            <Switch checked={smartThresholdEnabled} onCheckedChange={setSmartThresholdEnabled} />
          </div>

          <div className="space-y-2">
            <Label>Notification Channels</Label>
            <div className="flex items-center gap-4">
              <label className="flex items-center gap-2">
                <Checkbox checked={channels.includes('in_app')} onCheckedChange={(checked) => {
                  setChannels(checked ? [...channels, 'in_app'] : channels.filter(c => c !== 'in_app'));
                }} />
                <span className="text-sm">In-App</span>
              </label>
              <label className="flex items-center gap-2">
                <Checkbox checked={channels.includes('email')} onCheckedChange={(checked) => {
                  setChannels(checked ? [...channels, 'email'] : channels.filter(c => c !== 'email'));
                }} />
                <span className="text-sm">Email</span>
              </label>
            </div>
          </div>
          <Button type="submit" className="w-full">Create Advanced Rule</Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
