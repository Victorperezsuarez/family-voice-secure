import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface FeatureAdoptionChartProps {
  data: Array<{
    feature_name: string;
    usage_count: number;
    unique_users: number;
  }>;
}

export default function FeatureAdoptionChart({ data }: FeatureAdoptionChartProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Feature Adoption</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="feature_name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="usage_count" fill="#8b5cf6" name="Total Uses" />
            <Bar dataKey="unique_users" fill="#3b82f6" name="Unique Users" />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
