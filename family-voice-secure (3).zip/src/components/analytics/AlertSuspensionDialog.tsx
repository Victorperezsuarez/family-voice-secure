import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';
import { PauseCircle } from 'lucide-react';

interface AlertSuspensionDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  ruleId: string;
  onSuspensionCreated: () => void;
}

export function AlertSuspensionDialog({ open, onOpenChange, ruleId, onSuspensionCreated }: AlertSuspensionDialogProps) {
  const [reason, setReason] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const [loading, setLoading] = useState(false);

  const handleCreate = async () => {
    if (!startTime || !endTime) {
      toast.error('Please select start and end times');
      return;
    }

    if (new Date(startTime) >= new Date(endTime)) {
      toast.error('End time must be after start time');
      return;
    }

    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      const { error } = await supabase.from('alert_suspensions').insert({
        alert_rule_id: ruleId,
        suspension_reason: reason,
        start_time: startTime,
        end_time: endTime,
        created_by: user?.id
      });

      if (error) throw error;

      toast.success('Alert suspended successfully');
      onSuspensionCreated();
      onOpenChange(false);
      resetForm();
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setReason('');
    setStartTime('');
    setEndTime('');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <PauseCircle className="h-5 w-5 text-orange-500" />
            Suspend Alert
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Reason (Optional)</Label>
            <Textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g., Scheduled maintenance, System upgrade"
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label>Start Time</Label>
            <Input
              type="datetime-local"
              value={startTime}
              onChange={(e) => setStartTime(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label>End Time</Label>
            <Input
              type="datetime-local"
              value={endTime}
              onChange={(e) => setEndTime(e.target.value)}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleCreate} disabled={loading}>
            {loading ? 'Suspending...' : 'Suspend Alert'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}