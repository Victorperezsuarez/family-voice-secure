import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { AnomalyTimeSeriesChart } from './AnomalyTimeSeriesChart';
import { BaselineTrendsChart } from './BaselineTrendsChart';
import { AnomalyScoreDistribution } from './AnomalyScoreDistribution';
import { AnomalyDetailsPanel } from './AnomalyDetailsPanel';
import { supabase } from '@/lib/supabase-client';
import { useAuth } from '@/contexts/AuthContext';
import { RefreshCw } from 'lucide-react';

export const AnomalyVisualizationDashboard: React.FC = () => {
  const { user } = useAuth();
  const [timeRange, setTimeRange] = useState('24h');
  const [anomalyType, setAnomalyType] = useState('all');
  const [severity, setSeverity] = useState('all');
  const [selectedAnomaly, setSelectedAnomaly] = useState<any>(null);
  const [timeSeriesData, setTimeSeriesData] = useState<any[]>([]);
  const [baselineData, setBaselineData] = useState<any[]>([]);
  const [distributionData, setDistributionData] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const loadData = async () => {
    if (!user) return;
    setLoading(true);

    try {
      const hoursMap: Record<string, number> = { '24h': 24, '7d': 168, '30d': 720 };
      const hours = hoursMap[timeRange];
      const since = new Date(Date.now() - hours * 60 * 60 * 1000).toISOString();

      let query = supabase
        .from('alert_anomalies')
        .select('*, alert_baselines(*)')
        .gte('detected_at', since)
        .order('detected_at', { ascending: true });

      if (anomalyType !== 'all') query = query.eq('anomaly_type', anomalyType);
      if (severity !== 'all') {
        const scoreMap: Record<string, [number, number]> = {
          low: [0, 40], medium: [40, 60], high: [60, 80], critical: [80, 100]
        };
        const [min, max] = scoreMap[severity];
        query = query.gte('anomaly_score', min).lt('anomaly_score', max);
      }

      const { data: anomalies } = await query;

      if (anomalies) {
        const tsData = anomalies.map(a => ({
          timestamp: new Date(a.detected_at).toLocaleTimeString(),
          value: a.actual_value,
          baseline: a.expected_value,
          anomalyScore: a.anomaly_score,
          type: a.anomaly_type
        }));
        setTimeSeriesData(tsData);

        const dist = [
          { range: '0-40', count: anomalies.filter(a => a.anomaly_score < 40).length, severity: 'low' as const },
          { range: '40-60', count: anomalies.filter(a => a.anomaly_score >= 40 && a.anomaly_score < 60).length, severity: 'medium' as const },
          { range: '60-80', count: anomalies.filter(a => a.anomaly_score >= 60 && a.anomaly_score < 80).length, severity: 'high' as const },
          { range: '80-100', count: anomalies.filter(a => a.anomaly_score >= 80).length, severity: 'critical' as const }
        ];
        setDistributionData(dist);
      }

      const { data: baselines } = await supabase
        .from('alert_baselines')
        .select('*')
        .order('last_updated', { ascending: true })
        .limit(30);

      if (baselines) {
        const blData = baselines.map(b => ({
          date: new Date(b.last_updated).toLocaleDateString(),
          mean: b.baseline_mean,
          upperBound: b.baseline_mean + 2 * b.baseline_std_dev,
          lowerBound: Math.max(0, b.baseline_mean - 2 * b.baseline_std_dev),
          confidence: b.confidence_score
        }));
        setBaselineData(blData);
      }
    } catch (error) {
      console.error('Error loading anomaly data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [timeRange, anomalyType, severity, user]);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Anomaly Visualization Dashboard</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 flex-wrap">
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-[150px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="24h">Last 24 Hours</SelectItem>
                <SelectItem value="7d">Last 7 Days</SelectItem>
                <SelectItem value="30d">Last 30 Days</SelectItem>
              </SelectContent>
            </Select>

            <Select value={anomalyType} onValueChange={setAnomalyType}>
              <SelectTrigger className="w-[150px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="spike">Spike</SelectItem>
                <SelectItem value="drop">Drop</SelectItem>
                <SelectItem value="outlier">Outlier</SelectItem>
                <SelectItem value="unusual_pattern">Unusual Pattern</SelectItem>
              </SelectContent>
            </Select>

            <Select value={severity} onValueChange={setSeverity}>
              <SelectTrigger className="w-[150px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Severities</SelectItem>
                <SelectItem value="low">Low (0-40)</SelectItem>
                <SelectItem value="medium">Medium (40-60)</SelectItem>
                <SelectItem value="high">High (60-80)</SelectItem>
                <SelectItem value="critical">Critical (80+)</SelectItem>
              </SelectContent>
            </Select>

            <Button onClick={loadData} disabled={loading} variant="outline">
              <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <AnomalyTimeSeriesChart data={timeSeriesData} onPointClick={setSelectedAnomaly} />
        <BaselineTrendsChart data={baselineData} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <AnomalyScoreDistribution data={distributionData} />
        </div>
        <AnomalyDetailsPanel anomaly={selectedAnomaly} onClose={() => setSelectedAnomaly(null)} />
      </div>
    </div>
  );
};
