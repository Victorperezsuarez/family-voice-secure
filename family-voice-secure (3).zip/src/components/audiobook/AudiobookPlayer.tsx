import { useState, useRef, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Play, Pause, SkipBack, SkipForward, Volume2 } from 'lucide-react';
import { AudiobookChapter } from '@/types/audiobook';

interface AudiobookPlayerProps {
  chapters: AudiobookChapter[];
  currentChapter: number;
  onChapterChange: (chapter: number) => void;
}

export function AudiobookPlayer({ chapters, currentChapter, onChapterChange }: AudiobookPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [volume, setVolume] = useState(1);
  const audioRef = useRef<HTMLAudioElement>(null);

  const chapter = chapters[currentChapter];

  useEffect(() => {
    if (audioRef.current && chapter?.audio_url) {
      audioRef.current.src = chapter.audio_url;
      audioRef.current.load();
    }
  }, [chapter]);

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handlePrevious = () => {
    if (currentChapter > 0) onChapterChange(currentChapter - 1);
  };

  const handleNext = () => {
    if (currentChapter < chapters.length - 1) onChapterChange(currentChapter + 1);
  };

  return (
    <Card className="p-6">
      <audio ref={audioRef} onTimeUpdate={(e) => setProgress((e.currentTarget.currentTime / e.currentTarget.duration) * 100)} />
      <div className="space-y-4">
        <div>
          <h3 className="font-semibold">{chapter?.title}</h3>
          <p className="text-sm text-muted-foreground">Chapter {currentChapter + 1} of {chapters.length}</p>
        </div>
        <Slider value={[progress]} onValueChange={([v]) => { if (audioRef.current) audioRef.current.currentTime = (v / 100) * audioRef.current.duration; }} />
        <div className="flex items-center justify-center gap-4">
          <Button variant="ghost" size="icon" onClick={handlePrevious}><SkipBack /></Button>
          <Button size="icon" onClick={togglePlay}>{isPlaying ? <Pause /> : <Play />}</Button>
          <Button variant="ghost" size="icon" onClick={handleNext}><SkipForward /></Button>
        </div>
        <div className="flex items-center gap-2">
          <Volume2 className="w-4 h-4" />
          <Slider value={[volume * 100]} onValueChange={([v]) => { setVolume(v / 100); if (audioRef.current) audioRef.current.volume = v / 100; }} className="w-24" />
        </div>
      </div>
    </Card>
  );
}
