import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Music, Play, Pause } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { BackgroundMusic } from '@/types/audiobook';
import { Slider } from '@/components/ui/slider';

interface BackgroundMusicSelectorProps {
  onSelect: (musicId: string) => void;
}

export function BackgroundMusicSelector({ onSelect }: BackgroundMusicSelectorProps) {
  const [music, setMusic] = useState<BackgroundMusic[]>([]);
  const [selected, setSelected] = useState<string>('');
  const [playing, setPlaying] = useState<string | null>(null);
  const [volume, setVolume] = useState(30);

  useEffect(() => {
    loadMusic();
  }, []);

  const loadMusic = async () => {
    const { data } = await supabase
      .from('background_music')
      .select('*')
      .eq('is_public', true);
    if (data) setMusic(data);
  };

  const handleSelect = (musicId: string) => {
    setSelected(musicId);
    onSelect(musicId);
  };

  const togglePreview = (track: BackgroundMusic) => {
    if (playing === track.id) {
      setPlaying(null);
    } else {
      setPlaying(track.id);
      const audio = new Audio(track.audio_url);
      audio.volume = volume / 100;
      audio.play();
    }
  };

  return (
    <Card className="p-6">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <Label className="text-lg">Background Music</Label>
          <div className="flex items-center gap-2">
            <Label className="text-sm">Volume</Label>
            <Slider value={[volume]} onValueChange={([v]) => setVolume(v)} className="w-24" />
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {music.map((track) => (
            <div
              key={track.id}
              className={`p-4 border rounded-lg cursor-pointer transition ${
                selected === track.id ? 'border-primary bg-primary/5' : 'hover:border-primary/50'
              }`}
              onClick={() => handleSelect(track.id)}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Music className="w-4 h-4" />
                  <div>
                    <p className="font-medium text-sm">{track.name}</p>
                    <p className="text-xs text-muted-foreground">{track.mood}</p>
                  </div>
                </div>
                <Button variant="ghost" size="sm" onClick={(e) => { e.stopPropagation(); togglePreview(track); }}>
                  {playing === track.id ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Card>
  );
}
