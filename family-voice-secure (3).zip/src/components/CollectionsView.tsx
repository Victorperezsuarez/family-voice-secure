import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase-client';
import { Collection, RecordingWithMember, CollectionContributor } from '@/types/family';
import { CollectionCard } from './CollectionCard';
import { CreateCollectionModal } from './CreateCollectionModal';
import { EditCollectionModal } from './EditCollectionModal';
import { InviteCollaboratorModal } from './InviteCollaboratorModal';
import { CollectionActivityFeed } from './CollectionActivityFeed';
import { CollectionComments } from './CollectionComments';
import { RecordingCard } from './RecordingCard';
import { PhotoGallery } from './PhotoGallery';
import { PhotoUploader } from './PhotoUploader';
import BatchAudioEnhancement from './BatchAudioEnhancement';
import { ThemeBasedCollections } from './ThemeBasedCollections';

import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Plus, ArrowLeft, Users, Share2, Image as ImageIcon, Wand2 } from 'lucide-react';

import { useAuth } from '@/contexts/AuthContext';


interface CollectionsViewProps {
  familyId: string;
}

export function CollectionsView({ familyId }: CollectionsViewProps) {
  const { user } = useAuth();
  const [collections, setCollections] = useState<Collection[]>([]);
  const [selectedCollection, setSelectedCollection] = useState<Collection | null>(null);
  const [recordings, setRecordings] = useState<RecordingWithMember[]>([]);
  const [contributors, setContributors] = useState<CollectionContributor[]>([]);
  const [photos, setPhotos] = useState<any[]>([]);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isInviteOpen, setIsInviteOpen] = useState(false);
  const [editingCollection, setEditingCollection] = useState<Collection | null>(null);



  useEffect(() => {
    loadCollections();
  }, [familyId]);

  const loadCollections = async () => {
    const { data } = await supabase
      .from('collections')
      .select(`
        *,
        recording_collections(count)
      `)
      .eq('family_id', familyId)
      .order('created_at', { ascending: false });
    
    if (data) {
      const collectionsWithCount = data.map(c => ({
        ...c,
        recording_count: c.recording_collections?.[0]?.count || 0
      }));
      setCollections(collectionsWithCount);
    }
  };

  const loadCollectionRecordings = async (collectionId: string) => {
    const { data } = await supabase
      .from('recording_collections')
      .select(`
        recording_id,
        recordings!inner(*, family_members(*))
      `)
      .eq('collection_id', collectionId);
    
    if (data) {
      const recs = data.map(rc => ({
        ...rc.recordings,
        family_member: rc.recordings.family_members
      }));
      setRecordings(recs as any);
    }
  };

  const handleCreate = async (data: any) => {
    const { error } = await supabase.from('collections').insert({
      ...data,
      family_id: familyId,
      created_by: user?.id
    });
    if (!error) loadCollections();
  };

  const handleEdit = async (id: string, data: any) => {
    const { error } = await supabase
      .from('collections')
      .update({ ...data, updated_at: new Date().toISOString() })
      .eq('id', id);
    if (!error) loadCollections();
  };

  const handleDelete = async (id: string) => {
    if (confirm('Delete this collection?')) {
      await supabase.from('collections').delete().eq('id', id);
      loadCollections();
    }
  };

  const handleOpenCollection = (collection: Collection) => {
    setSelectedCollection(collection);
    loadCollectionRecordings(collection.id);
    loadContributors(collection.id);
  };

  const loadContributors = async (collectionId: string) => {
    const { data } = await supabase
      .from('collection_contributors')
      .select(`*, profiles!collection_contributors_user_id_fkey(email, full_name)`)
      .eq('collection_id', collectionId);
    
    if (data) {
      const formatted = data.map(c => ({
        ...c,
        user_email: c.profiles?.email,
        user_name: c.profiles?.full_name
      }));
      setContributors(formatted as any);
    }
  };


  if (selectedCollection) {
    const isOwner = selectedCollection.owner_id === user?.id || selectedCollection.created_by === user?.id;
    
    return (
      <div>
        <div className="flex justify-between items-center mb-4">
          <Button variant="ghost" onClick={() => setSelectedCollection(null)}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Collections
          </Button>
          {isOwner && (
            <Button onClick={() => setIsInviteOpen(true)}>
              <Share2 className="h-4 w-4 mr-2" />
              Invite Collaborators
            </Button>
          )}
        </div>

        <div className="flex items-center gap-3 mb-4">
          <h2 className="text-2xl font-bold">{selectedCollection.name}</h2>
          {selectedCollection.is_shared && <Badge variant="secondary"><Users className="h-3 w-3 mr-1" />Shared</Badge>}
        </div>
        <p className="text-gray-600 mb-6">{selectedCollection.description}</p>

        <Tabs defaultValue="recordings" className="mb-6">
          <TabsList>
            <TabsTrigger value="recordings">Recordings</TabsTrigger>
            <TabsTrigger value="enhance">Batch Enhancement</TabsTrigger>
            <TabsTrigger value="contributors">Contributors ({contributors.length})</TabsTrigger>
            <TabsTrigger value="activity">Activity</TabsTrigger>
            <TabsTrigger value="comments">Comments</TabsTrigger>
          </TabsList>
          
          <TabsContent value="recordings">
            <div className="space-y-4">
              {recordings.map((recording) => (
                <RecordingCard 
                  key={recording.id} 
                  recording={recording} 
                  onPlay={() => {}}
                />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="enhance">
            <BatchAudioEnhancement 
              collectionId={selectedCollection.id}
              recordings={recordings}
              onComplete={() => loadCollectionRecordings(selectedCollection.id)}
            />
          </TabsContent>

          <TabsContent value="contributors">
            <div className="space-y-3">
              {contributors.map(c => (
                <div key={c.id} className="flex justify-between items-center p-3 border rounded">
                  <div>
                    <p className="font-medium">{c.user_name || c.user_email}</p>
                    <p className="text-sm text-gray-500">{c.permission_level}</p>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="activity">
            <CollectionActivityFeed collectionId={selectedCollection.id} />
          </TabsContent>

          <TabsContent value="comments">
            <CollectionComments collectionId={selectedCollection.id} />
          </TabsContent>
        </Tabs>

        <InviteCollaboratorModal
          isOpen={isInviteOpen}
          onClose={() => setIsInviteOpen(false)}
          collectionId={selectedCollection.id}
          collectionName={selectedCollection.name}
        />
      </div>
    );
  }


  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Collections</h2>
        <Button onClick={() => setIsCreateOpen(true)}>
          <Plus className="h-4 w-4 mr-2" />
          New Collection
        </Button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {collections.map((collection) => (
          <CollectionCard
            key={collection.id}
            collection={collection}
            onEdit={(c) => {
              setEditingCollection(c);
              setIsEditOpen(true);
            }}
            onDelete={handleDelete}
            onOpen={handleOpenCollection}
            isOwner={collection.created_by === user?.id}
          />
        ))}
      </div>
      <CreateCollectionModal
        isOpen={isCreateOpen}
        onClose={() => setIsCreateOpen(false)}
        onSubmit={handleCreate}
      />
      <EditCollectionModal
        isOpen={isEditOpen}
        onClose={() => setIsEditOpen(false)}
        onSubmit={handleEdit}
        collection={editingCollection}
      />
    </div>
  );
}
