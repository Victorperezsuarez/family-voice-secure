import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CheckCircle2, XCircle, AlertCircle, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';

interface ValidationReport {
  passed: boolean;
  gates: {
    allTestsPassed: boolean;
    coverageMet: boolean;
    unitTestsPassed: boolean;
    integrationTestsPassed: boolean;
    e2eTestsPassed: boolean;
    noBlockingIssues: boolean;
  };
  testResults: any;
  requirements: {
    minCoverage: number;
  };
  blockers: string[];
}

export function PublishValidationDialog({ 
  open, 
  onOpenChange, 
  templateId,
  onPublish 
}: { 
  open: boolean; 
  onOpenChange: (open: boolean) => void;
  templateId: string;
  onPublish: () => void;
}) {
  const [validating, setValidating] = useState(false);
  const [report, setReport] = useState<ValidationReport | null>(null);

  useEffect(() => {
    if (open && templateId) {
      runValidation();
    }
  }, [open, templateId]);

  const runValidation = async () => {
    setValidating(true);
    try {
      const { data, error } = await supabase.functions.invoke('validate-template-publish', {
        body: { templateId, minCoverage: 80 }
      });
      if (error) throw error;
      setReport(data);
    } catch (error) {
      console.error('Validation failed:', error);
    } finally {
      setValidating(false);
    }
  };

  const GateStatus = ({ passed, label }: { passed: boolean; label: string }) => (
    <div className="flex items-center justify-between py-2">
      <span className="text-sm">{label}</span>
      {passed ? (
        <CheckCircle2 className="w-5 h-5 text-green-600" />
      ) : (
        <XCircle className="w-5 h-5 text-red-600" />
      )}
    </div>
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Pre-Publish Validation</DialogTitle>
        </DialogHeader>

        {validating && (
          <div className="flex flex-col items-center justify-center py-8">
            <Loader2 className="w-8 h-8 animate-spin text-blue-600 mb-4" />
            <p className="text-sm text-gray-600">Running quality gates...</p>
          </div>
        )}

        {report && (
          <div className="space-y-4">
            {report.passed ? (
              <Alert className="border-green-200 bg-green-50">
                <CheckCircle2 className="w-4 h-4 text-green-600" />
                <AlertDescription className="text-green-800">
                  All quality gates passed! Template is ready to publish.
                </AlertDescription>
              </Alert>
            ) : (
              <Alert className="border-red-200 bg-red-50">
                <XCircle className="w-4 h-4 text-red-600" />
                <AlertDescription className="text-red-800">
                  Validation failed. Fix the issues below before publishing.
                </AlertDescription>
              </Alert>
            )}

            <div className="border rounded-lg p-4">
              <h3 className="font-semibold mb-3">Quality Gates</h3>
              <GateStatus passed={report.gates.allTestsPassed} label="All Tests Passed" />
              <GateStatus passed={report.gates.coverageMet} label={`Coverage ≥ ${report.requirements.minCoverage}%`} />
              <GateStatus passed={report.gates.unitTestsPassed} label="Unit Tests" />
              <GateStatus passed={report.gates.integrationTestsPassed} label="Integration Tests" />
              <GateStatus passed={report.gates.e2eTestsPassed} label="E2E Tests" />
            </div>

            {report.blockers.length > 0 && (
              <div className="border border-red-200 rounded-lg p-4 bg-red-50">
                <h3 className="font-semibold text-red-800 mb-2 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4" />
                  Blocking Issues
                </h3>
                <ul className="list-disc list-inside space-y-1">
                  {report.blockers.map((blocker, i) => (
                    <li key={i} className="text-sm text-red-700">{blocker}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button 
            onClick={onPublish}
            disabled={!report || !report.passed}
          >
            Publish Template
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
