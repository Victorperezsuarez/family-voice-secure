import { useState } from 'react';
import { supabase } from '@/lib/supabase-client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { toast } from 'sonner';
import { AlertTriangle } from 'lucide-react';

interface DangerZoneSectionProps {
  familyId: string;
  onDeleted: () => void;
}

export function DangerZoneSection({ familyId, onDeleted }: DangerZoneSectionProps) {
  const [confirmText, setConfirmText] = useState('');
  const [familyName, setFamilyName] = useState('');
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);

  const loadFamilyName = async () => {
    const { data } = await supabase
      .from('families')
      .select('name')
      .eq('id', familyId)
      .single();
    
    if (data) setFamilyName(data.name);
  };

  const handleDelete = async () => {
    if (confirmText !== 'DELETE') {
      toast.error('Please type DELETE to confirm');
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase
        .from('families')
        .delete()
        .eq('id', familyId);

      if (error) throw error;

      toast.success('Family deleted successfully');
      onDeleted();
    } catch (error) {
      toast.error('Failed to delete family');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="border-red-200 bg-red-50">
      <CardHeader>
        <CardTitle className="text-red-600 flex items-center gap-2">
          <AlertTriangle className="w-5 h-5" />
          Danger Zone
        </CardTitle>
        <CardDescription>Irreversible and destructive actions</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <h3 className="font-semibold text-red-600 mb-2">Delete Family</h3>
            <p className="text-sm text-gray-600 mb-4">
              Permanently delete this family and all associated recordings, collections, and data. 
              This action cannot be undone.
            </p>
          </div>
          
          <AlertDialog open={open} onOpenChange={setOpen}>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" onClick={loadFamilyName}>
                Delete Family
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Delete Family: {familyName}?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will permanently delete all recordings, collections, members, and settings.
                  This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <div className="my-4">
                <Label htmlFor="confirm">Type DELETE to confirm</Label>
                <Input
                  id="confirm"
                  value={confirmText}
                  onChange={(e) => setConfirmText(e.target.value)}
                  placeholder="DELETE"
                />
              </div>
              <AlertDialogFooter>
                <AlertDialogCancel onClick={() => setConfirmText('')}>Cancel</AlertDialogCancel>
                <AlertDialogAction
                  onClick={handleDelete}
                  disabled={confirmText !== 'DELETE' || loading}
                  className="bg-red-600 hover:bg-red-700"
                >
                  {loading ? 'Deleting...' : 'Delete Family'}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </CardContent>
    </Card>
  );
}
