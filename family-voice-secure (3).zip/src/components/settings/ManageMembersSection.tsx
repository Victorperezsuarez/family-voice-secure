import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase-client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { UserX } from 'lucide-react';

interface Member {
  id: string;
  user_id: string;
  role: string;
  role_id: string;
  joined_at: string;
  profiles?: { full_name: string; email: string };
  custom_roles?: { id: string; name: string };
}


export function ManageMembersSection({ familyId }: { familyId: string }) {
  const [members, setMembers] = useState<Member[]>([]);
  const [roles, setRoles] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadMembers();
    loadRoles();
  }, [familyId]);

  const loadRoles = async () => {
    const { data } = await supabase
      .from('custom_roles')
      .select('*')
      .eq('family_id', familyId)
      .order('name');
    
    if (data) setRoles(data);
  };

  const loadMembers = async () => {
    const { data } = await supabase
      .from('family_users')
      .select('*, profiles(full_name, email), custom_roles(id, name)')
      .eq('family_id', familyId)
      .order('joined_at', { ascending: true });

    if (data) setMembers(data);
  };


  const handleRoleChange = async (memberId: string, newRoleId: string) => {
    setLoading(true);
    try {
      const selectedRole = roles.find(r => r.id === newRoleId);
      
      const { error } = await supabase
        .from('family_users')
        .update({ role_id: newRoleId, role: selectedRole?.name.toLowerCase() || 'viewer' })
        .eq('id', memberId);

      if (error) throw error;

      await supabase.from('family_activity_logs').insert({
        family_id: familyId,
        user_id: (await supabase.auth.getUser()).data.user?.id,
        action_type: 'member_role_changed',
        action_description: `Changed member role to ${selectedRole?.name}`,
        metadata: { member_id: memberId, new_role: selectedRole?.name }
      });

      toast.success('Member role updated');
      loadMembers();
    } catch (error) {
      toast.error('Failed to update role');
    } finally {
      setLoading(false);
    }
  };


  const handleRemoveMember = async (memberId: string, memberName: string) => {
    setLoading(true);
    try {
      const { error } = await supabase
        .from('family_users')
        .delete()
        .eq('id', memberId);

      if (error) throw error;

      await supabase.from('family_activity_logs').insert({
        family_id: familyId,
        user_id: (await supabase.auth.getUser()).data.user?.id,
        action_type: 'member_removed',
        action_description: `Removed ${memberName} from family`,
        metadata: { member_id: memberId }
      });

      toast.success('Member removed');
      loadMembers();
    } catch (error) {
      toast.error('Failed to remove member');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Manage Members</CardTitle>
        <CardDescription>View and manage family member roles and access</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {members.map((member) => (
            <div key={member.id} className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <p className="font-medium">{member.profiles?.full_name || 'Unknown'}</p>
                  <Badge variant="outline">{member.custom_roles?.name || member.role}</Badge>
                </div>
                <p className="text-sm text-gray-500">{member.profiles?.email}</p>
                <p className="text-xs text-gray-400">Joined {new Date(member.joined_at).toLocaleDateString()}</p>
              </div>
              <div className="flex items-center gap-3">
                <Select value={member.role_id} onValueChange={(value) => handleRoleChange(member.id, value)} disabled={loading}>
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {roles.map(role => (
                      <SelectItem key={role.id} value={role.id}>
                        {role.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="destructive" size="sm" disabled={loading}>
                      <UserX className="w-4 h-4" />
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Remove Member?</AlertDialogTitle>
                      <AlertDialogDescription>
                        Remove {member.profiles?.full_name} from this family? They will lose access to all recordings.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={() => handleRemoveMember(member.id, member.profiles?.full_name || 'member')}>
                        Remove
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
