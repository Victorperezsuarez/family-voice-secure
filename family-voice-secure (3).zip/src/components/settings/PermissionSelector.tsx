import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';

interface Permission {
  name: string;
  description: string;
  category: string;
}

interface PermissionSelectorProps {
  permissions: Permission[];
  selectedPermissions: Set<string>;
  onPermissionToggle: (permission: string) => void;
}

export function PermissionSelector({
  permissions,
  selectedPermissions,
  onPermissionToggle
}: PermissionSelectorProps) {
  const categories = Array.from(new Set(permissions.map(p => p.category)));

  return (
    <div className="space-y-4">
      {categories.map(category => (
        <Card key={category} className="p-4">
          <h4 className="font-semibold capitalize mb-3 text-sm">
            {category}
          </h4>
          <div className="space-y-3">
            {permissions
              .filter(p => p.category === category)
              .map(permission => (
                <div key={permission.name} className="flex items-start space-x-3">
                  <Checkbox
                    id={permission.name}
                    checked={selectedPermissions.has(permission.name)}
                    onCheckedChange={() => onPermissionToggle(permission.name)}
                  />
                  <div className="flex-1">
                    <Label
                      htmlFor={permission.name}
                      className="text-sm font-medium cursor-pointer"
                    >
                      {permission.description}
                    </Label>
                  </div>
                </div>
              ))}
          </div>
        </Card>
      ))}
    </div>
  );
}
