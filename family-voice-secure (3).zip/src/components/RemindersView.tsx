import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase-client';
import { Button } from '@/components/ui/button';
import { Plus, Calendar } from 'lucide-react';
import { ReminderCard } from './ReminderCard';
import { CreateReminderModal } from './CreateReminderModal';
import { Reminder } from '@/types/reminder';
import { FamilyMember } from '@/types/family';
import { useToast } from '@/hooks/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface RemindersViewProps {
  familyId: string;
  familyMembers: FamilyMember[];
}

export function RemindersView({ familyId, familyMembers }: RemindersViewProps) {
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadReminders();
  }, [familyId]);

  const loadReminders = async () => {
    const { data, error } = await supabase
      .from('reminders')
      .select('*')
      .eq('family_id', familyId)
      .order('occasion_date', { ascending: true });

    if (!error && data) setReminders(data);
    setLoading(false);
  };

  const handleCreate = async (data: any) => {
    const { error } = await supabase.from('reminders').insert({
      ...data,
      family_id: familyId,
      created_by: (await supabase.auth.getUser()).data.user?.id
    });

    if (error) {
      toast({ title: 'Error creating reminder', variant: 'destructive' });
    } else {
      toast({ title: 'Reminder created successfully' });
      loadReminders();
    }
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('reminders').delete().eq('id', id);
    if (!error) {
      toast({ title: 'Reminder deleted' });
      loadReminders();
    }
  };

  const handleSendNow = async (reminder: Reminder) => {
    const member = familyMembers.find(m => m.id === reminder.family_member_id);
    
    const { error } = await supabase.functions.invoke('send-reminder', {
      body: {
        reminderId: reminder.id,
        familyMemberId: reminder.family_member_id,
        email: member?.email,
        phone: member?.phone,
        occasion: reminder.occasion,
        topics: reminder.suggested_topics,
        sendEmail: reminder.send_email,
        sendSms: reminder.send_sms
      }
    });

    if (error) {
      toast({ title: 'Error sending reminder', variant: 'destructive' });
    } else {
      toast({ title: 'Reminder sent successfully' });
    }
  };

  const activeReminders = reminders.filter(r => r.is_active);
  const inactiveReminders = reminders.filter(r => !r.is_active);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Calendar className="h-6 w-6" />
          <h2 className="text-2xl font-bold">Reminders</h2>
        </div>
        <Button onClick={() => setIsCreateOpen(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Create Reminder
        </Button>
      </div>

      <Tabs defaultValue="active">
        <TabsList>
          <TabsTrigger value="active">Active ({activeReminders.length})</TabsTrigger>
          <TabsTrigger value="inactive">Inactive ({inactiveReminders.length})</TabsTrigger>
        </TabsList>
        <TabsContent value="active" className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
          {activeReminders.map(reminder => (
            <ReminderCard
              key={reminder.id}
              reminder={reminder}
              onEdit={() => {}}
              onDelete={handleDelete}
              onSendNow={handleSendNow}
            />
          ))}
        </TabsContent>
        <TabsContent value="inactive" className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
          {inactiveReminders.map(reminder => (
            <ReminderCard
              key={reminder.id}
              reminder={reminder}
              onEdit={() => {}}
              onDelete={handleDelete}
              onSendNow={handleSendNow}
            />
          ))}
        </TabsContent>
      </Tabs>

      <CreateReminderModal
        isOpen={isCreateOpen}
        onClose={() => setIsCreateOpen(false)}
        onSubmit={handleCreate}
        familyMembers={familyMembers}
      />
    </div>
  );
}
