import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ShoppingCart, Printer } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase-client';

interface PrintSize {
  id: string;
  name: string;
  dimensions: string;
  price: number;
}

export function PhotoPrintingService({ photoIds, familyId }: { photoIds: string[]; familyId: string }) {
  const [selectedSizes, setSelectedSizes] = useState<Record<string, string>>({});
  const [quantities, setQuantities] = useState<Record<string, number>>({});
  const [address, setAddress] = useState({ street: '', city: '', state: '', zip: '' });
  const { toast } = useToast();

  const printSizes: PrintSize[] = [
    { id: '4x6', name: '4x6"', dimensions: '4" × 6"', price: 0.29 },
    { id: '5x7', name: '5x7"', dimensions: '5" × 7"', price: 1.99 },
    { id: '8x10', name: '8x10"', dimensions: '8" × 10"', price: 3.99 },
    { id: '11x14', name: '11x14"', dimensions: '11" × 14"', price: 9.99 },
    { id: '16x20', name: '16x20"', dimensions: '16" × 20"', price: 19.99 }
  ];

  const calculateTotal = () => {
    return Object.entries(selectedSizes).reduce((total, [photoId, sizeId]) => {
      const size = printSizes.find(s => s.id === sizeId);
      const qty = quantities[photoId] || 1;
      return total + (size?.price || 0) * qty;
    }, 0);
  };

  const placeOrder = async () => {
    try {
      const total = calculateTotal();
      const orderNumber = `ORD-${Date.now()}`;
      
      const { error } = await supabase.from('photo_print_orders').insert({
        family_id: familyId,
        photo_ids: photoIds,
        print_sizes: selectedSizes,
        quantities,
        shipping_address: address,
        total_price: total,
        order_number: orderNumber,
        status: 'pending'
      });

      if (error) throw error;
      toast({ 
        title: 'Order Placed', 
        description: `Order ${orderNumber} placed successfully. Total: $${total.toFixed(2)}` 
      });
    } catch (error: any) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold flex items-center gap-2">
          <Printer className="h-5 w-5" />
          Print Photos
        </h3>
        <Badge variant="secondary">{photoIds.length} photos</Badge>
      </div>

      <div className="grid gap-4">
        <Card className="p-4">
          <h4 className="font-medium mb-3">Select Print Sizes</h4>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {printSizes.map((size) => (
              <Button
                key={size.id}
                variant="outline"
                className="flex flex-col h-auto p-4"
                onClick={() => {
                  const newSizes = { ...selectedSizes };
                  photoIds.forEach(id => newSizes[id] = size.id);
                  setSelectedSizes(newSizes);
                }}
              >
                <span className="font-semibold">{size.name}</span>
                <span className="text-xs text-gray-500">{size.dimensions}</span>
                <span className="text-sm font-medium mt-1">${size.price}</span>
              </Button>
            ))}
          </div>
        </Card>

        <Card className="p-4">
          <h4 className="font-medium mb-3">Shipping Address</h4>
          <div className="grid gap-3">
            <Input placeholder="Street Address" value={address.street} 
              onChange={(e) => setAddress({...address, street: e.target.value})} />
            <div className="grid grid-cols-3 gap-3">
              <Input placeholder="City" value={address.city}
                onChange={(e) => setAddress({...address, city: e.target.value})} />
              <Input placeholder="State" value={address.state}
                onChange={(e) => setAddress({...address, state: e.target.value})} />
              <Input placeholder="ZIP" value={address.zip}
                onChange={(e) => setAddress({...address, zip: e.target.value})} />
            </div>
          </div>
        </Card>

        <Card className="p-4 bg-blue-50">
          <div className="flex items-center justify-between mb-2">
            <span className="font-medium">Total</span>
            <span className="text-2xl font-bold">${calculateTotal().toFixed(2)}</span>
          </div>
          <Button onClick={placeOrder} className="w-full" size="lg">
            <ShoppingCart className="h-4 w-4 mr-2" />
            Place Order
          </Button>
        </Card>
      </div>
    </div>
  );
}
