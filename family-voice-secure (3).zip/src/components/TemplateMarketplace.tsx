import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase-client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Download, Star, TrendingUp, Search, BarChart3, MessageSquare, Flag, Award, History, TestTube, Activity, DollarSign, ShieldCheck } from 'lucide-react';





import { ReportContentModal } from './ReportContentModal';
import { TemplateVersionHistory } from './TemplateVersionHistory';
import { TemplateVersionComparison } from './TemplateVersionComparison';
import { TemplateTestingDashboard } from './TemplateTestingDashboard';
import { PerformanceMonitoringDashboard } from './PerformanceMonitoringDashboard';
import { CreatorEarningsDashboard } from './monetization/CreatorEarningsDashboard';
import { LicenseVerificationDialog } from './LicenseVerificationDialog';
import { LicenseUpgradeDialog } from './LicenseUpgradeDialog';






import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TemplateAnalyticsDashboard } from './TemplateAnalyticsDashboard';
import { TemplateReviewForm } from './TemplateReviewForm';
import { TemplateReviewsList } from './TemplateReviewsList';
import { StarRating } from './StarRating';
import { toast } from 'sonner';


interface TemplateWithReviews extends CommunityTemplate {
  review_count?: number;
  avg_rating?: number;
}


interface CommunityTemplate {
  id: string;
  name: string;
  description: string;
  permissions: Record<string, boolean>;
  author_name: string;
  author_family_id: string;
  category: string;
  tags: string[];
  downloads_count: number;
  rating: number;
  is_featured: boolean;
  current_version: number;
}


interface TemplateMarketplaceProps {
  familyId: string;
  onImport: (template: CommunityTemplate) => void;
}

export function TemplateMarketplace({ familyId, onImport }: TemplateMarketplaceProps) {
  const [templates, setTemplates] = useState<TemplateWithReviews[]>([]);
  const [featuredTemplates, setFeaturedTemplates] = useState<TemplateWithReviews[]>([]);
  const [filteredTemplates, setFilteredTemplates] = useState<TemplateWithReviews[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [sortBy, setSortBy] = useState('downloads');
  const [loading, setLoading] = useState(true);
  const [showDialog, setShowDialog] = useState(false);
  const [dialogMode, setDialogMode] = useState<'analytics' | 'reviews' | 'versions' | 'testing' | 'performance' | 'earnings'>('analytics');



  const [selectedTemplate, setSelectedTemplate] = useState<TemplateWithReviews | null>(null);
  const [reportModalOpen, setReportModalOpen] = useState(false);
  const [reportContentId, setReportContentId] = useState<string>('');
  const [comparisonOpen, setComparisonOpen] = useState(false);
  const [compareVersions, setCompareVersions] = useState<[number, number]>([1, 2]);
  const [verificationDialogOpen, setVerificationDialogOpen] = useState(false);
  const [verificationResult, setVerificationResult] = useState<any>(null);
  const [upgradeDialogOpen, setUpgradeDialogOpen] = useState(false);
  const [upgradePurchaseId, setUpgradePurchaseId] = useState<string>('');




  useEffect(() => {
    loadTemplates();
  }, []);

  useEffect(() => {
    filterAndSortTemplates();
  }, [templates, searchQuery, categoryFilter, sortBy]);

  const loadTemplates = async () => {
    try {
      // Get featured templates
      const { data: featuredData, error: featuredError } = await supabase
        .from('community_templates')
        .select('*')
        .eq('is_active', true)
        .eq('is_featured', true)
        .order('featured_order', { ascending: true, nullsLast: true });

      // Get all templates with review stats
      const { data: templatesData, error: templatesError } = await supabase
        .from('community_templates')
        .select('*')
        .eq('is_active', true)
        .eq('is_featured', false);

      if (templatesError) throw templatesError;

      // Get review stats for featured templates
      const featuredWithReviews = await Promise.all(
        (featuredData || []).map(async (template) => {
          const { data: reviews } = await supabase
            .from('template_reviews')
            .select('rating')
            .eq('template_id', template.id);

          const reviewCount = reviews?.length || 0;
          const avgRating = reviewCount > 0
            ? reviews.reduce((sum, r) => sum + r.rating, 0) / reviewCount
            : 0;

          return { ...template, review_count: reviewCount, avg_rating: avgRating };
        })
      );

      // Get review stats for regular templates
      const templatesWithReviews = await Promise.all(
        (templatesData || []).map(async (template) => {
          const { data: reviews } = await supabase
            .from('template_reviews')
            .select('rating')
            .eq('template_id', template.id);

          const reviewCount = reviews?.length || 0;
          const avgRating = reviewCount > 0
            ? reviews.reduce((sum, r) => sum + r.rating, 0) / reviewCount
            : 0;

          return { ...template, review_count: reviewCount, avg_rating: avgRating };
        })
      );

      setFeaturedTemplates(featuredWithReviews);
      setTemplates(templatesWithReviews);
    } catch (error) {
      console.error('Error loading templates:', error);
      toast.error('Failed to load templates');
    } finally {
      setLoading(false);
    }
  };



  const filterAndSortTemplates = () => {
    let filtered = [...templates];

    if (searchQuery) {
      filtered = filtered.filter(t =>
        t.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        t.description?.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    if (categoryFilter !== 'all') {
      filtered = filtered.filter(t => t.category === categoryFilter);
    }

    filtered.sort((a, b) => {
      if (sortBy === 'downloads') return b.downloads_count - a.downloads_count;
      if (sortBy === 'rating') return b.rating - a.rating;
      return 0;
    });

    setFilteredTemplates(filtered);
  };

  const handleImport = async (template: CommunityTemplate) => {
    try {
      await supabase.from('community_templates')
        .update({ downloads_count: template.downloads_count + 1 })
        .eq('id', template.id);
      
      onImport(template);
      toast.success('Template imported successfully');
    } catch (error) {
      console.error('Error importing template:', error);
      toast.error('Failed to import template');
    }
  };

  const categories = ['all', ...new Set(templates.map(t => t.category))];

  return (
    <div className="space-y-6">
      <div className="flex gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search templates..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {categories.map(cat => (
              <SelectItem key={cat} value={cat}>{cat}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={sortBy} onValueChange={setSortBy}>
          <SelectTrigger className="w-[180px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="downloads">Most Downloaded</SelectItem>
            <SelectItem value="rating">Highest Rated</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {featuredTemplates.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Award className="h-6 w-6 text-amber-500" />
            <h2 className="text-2xl font-bold">Featured Templates</h2>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            {featuredTemplates.map(template => (
              <Card key={template.id} className="border-2 border-amber-500/20 bg-gradient-to-br from-amber-50/50 to-transparent dark:from-amber-950/20">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="flex items-center gap-2">
                        {template.name}
                        <Badge className="bg-amber-500 hover:bg-amber-600">
                          <Star className="h-3 w-3 mr-1" />
                          Featured
                        </Badge>
                      </CardTitle>
                      <CardDescription>{template.description}</CardDescription>
                      <div className="flex items-center gap-2 mt-2">
                        <StarRating rating={template.avg_rating || 0} size={16} />
                        <span className="text-sm text-muted-foreground">
                          {template.avg_rating?.toFixed(1) || '0.0'} ({template.review_count || 0})
                        </span>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span>By {template.author_name}</span>
                      <span className="flex items-center gap-1">
                        <TrendingUp className="h-4 w-4" />
                        {template.downloads_count}
                      </span>
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => {
                          setSelectedTemplate(template);
                          setDialogMode('reviews');
                          setShowDialog(true);
                        }}
                      >
                        <MessageSquare className="h-4 w-4 mr-2" />
                        Reviews
                      </Button>
                      <Button onClick={() => handleImport(template)} size="sm">
                        <Download className="h-4 w-4 mr-2" />
                        Import
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      <div className="space-y-4">
        <h2 className="text-xl font-semibold">All Templates</h2>

      <div className="grid gap-4">
        {filteredTemplates.map(template => (
          <Card key={template.id}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="flex items-center gap-2">
                    {template.name}
                    {template.is_featured && <Badge variant="secondary">Featured</Badge>}
                  </CardTitle>
                  <CardDescription>{template.description}</CardDescription>
                  <div className="flex items-center gap-2 mt-2">
                    <StarRating rating={template.avg_rating || 0} size={16} />
                    <span className="text-sm text-muted-foreground">
                      {template.avg_rating?.toFixed(1) || '0.0'} ({template.review_count || 0} reviews)
                    </span>
                  </div>
                </div>
                <div className="flex gap-2">
                  {template.author_family_id === familyId && (
                    <>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => {
                          setSelectedTemplate(template);
                          setDialogMode('analytics');
                          setShowDialog(true);
                        }}
                      >
                        <BarChart3 className="h-4 w-4 mr-2" />
                        Analytics
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => {
                          setSelectedTemplate(template);
                          setDialogMode('testing');
                          setShowDialog(true);
                        }}
                      >
                        <TestTube className="h-4 w-4 mr-2" />
                        Tests
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => {
                          setSelectedTemplate(template);
                          setDialogMode('performance');
                          setShowDialog(true);
                         }}
                       >
                         <Activity className="h-4 w-4 mr-2" />
                         Performance
                       </Button>

                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => {
                          setSelectedTemplate(template);
                          setDialogMode('earnings');
                          setShowDialog(true);
                        }}
                      >
                        <DollarSign className="h-4 w-4 mr-2" />
                        Earnings
                      </Button>
                    </>

                  )}

                   <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => {
                      setSelectedTemplate(template);
                      setDialogMode('versions');
                      setShowDialog(true);
                     }}
                  >
                    <History className="h-4 w-4 mr-2" />
                    Versions
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => {
                      setSelectedTemplate(template);
                      setDialogMode('reviews');
                      setShowDialog(true);
                     }}
                  >
                    <MessageSquare className="h-4 w-4 mr-2" />
                    Reviews
                  </Button>

                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => {
                      setReportContentId(template.id);
                      setReportModalOpen(true);
                    }}
                  >
                    <Flag className="h-4 w-4" />
                  </Button>
                  <Button onClick={() => handleImport(template)} size="sm">
                    <Download className="h-4 w-4 mr-2" />
                    Import
                  </Button>
                </div>
              </div>
            </CardHeader>

            <CardContent>
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <span>By {template.author_name}</span>
                <span className="flex items-center gap-1">
                  <TrendingUp className="h-4 w-4" />
                  {template.downloads_count} downloads
                </span>
                <Badge variant="outline">{template.category}</Badge>
                <span>v{template.current_version}</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      </div>



      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
          {selectedTemplate && (
            <>
              <DialogHeader>
                <DialogTitle>{selectedTemplate.name}</DialogTitle>
              </DialogHeader>
              
              <Tabs value={dialogMode} onValueChange={(v) => setDialogMode(v as any)}>
                <TabsList>
                  {selectedTemplate.author_family_id === familyId && (
                    <>
                      <TabsTrigger value="analytics">Analytics</TabsTrigger>
                      <TabsTrigger value="testing">Testing</TabsTrigger>
                      <TabsTrigger value="performance">Performance</TabsTrigger>
                      <TabsTrigger value="earnings">Earnings</TabsTrigger>
                    </>
                  )}
                  <TabsTrigger value="versions">Version History</TabsTrigger>
                  <TabsTrigger value="reviews">Reviews</TabsTrigger>
                </TabsList>


                {selectedTemplate.author_family_id === familyId && (
                  <>
                    <TabsContent value="analytics">
                      <TemplateAnalyticsDashboard 
                        templateId={selectedTemplate.id}
                        templateName={selectedTemplate.name}
                      />
                    </TabsContent>
                    
                    <TabsContent value="testing">
                      <TemplateTestingDashboard 
                        templateId={selectedTemplate.id}
                      />
                    </TabsContent>

                    <TabsContent value="performance">
                      <PerformanceMonitoringDashboard 
                        templateId={selectedTemplate.id}
                      />
                    </TabsContent>

                    <TabsContent value="earnings">
                      <CreatorEarningsDashboard />
                    </TabsContent>
                  </>

                )}

                <TabsContent value="versions">
                  <TemplateVersionHistory
                    templateId={selectedTemplate.id}
                    currentVersion={selectedTemplate.current_version}
                    onCompare={(v1, v2) => {
                      setCompareVersions([v1, v2]);
                      setComparisonOpen(true);
                    }}
                  />
                </TabsContent>
                
                <TabsContent value="reviews" className="space-y-6">
                  <div>
                    <h3 className="text-lg font-semibold mb-4">Write a Review</h3>
                    <TemplateReviewForm
                      templateId={selectedTemplate.id}
                      familyId={familyId}
                      onSuccess={() => {
                        loadTemplates();
                        setShowDialog(false);
                      }}
                    />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold mb-4">All Reviews</h3>
                    <TemplateReviewsList
                      templateId={selectedTemplate.id}
                      currentFamilyId={familyId}
                    />
                  </div>
                </TabsContent>
               </Tabs>
            </>
          )}

        </DialogContent>
      </Dialog>


      {selectedTemplate && (
        <TemplateVersionComparison
          templateId={selectedTemplate.id}
          version1={compareVersions[0]}
          version2={compareVersions[1]}
          open={comparisonOpen}
          onClose={() => setComparisonOpen(false)}
        />
      )}

      <ReportContentModal
        open={reportModalOpen}
        onOpenChange={setReportModalOpen}
        contentType="template"
        contentId={reportContentId}
      />

      {selectedTemplate && (
        <>
          <LicenseVerificationDialog
            open={verificationDialogOpen}
            onOpenChange={setVerificationDialogOpen}
            verification={verificationResult}
            templateName={selectedTemplate.name}
            onPurchase={() => {
              toast.info('Redirecting to purchase page...');
            }}
            onUpgrade={() => {
              setUpgradeDialogOpen(true);
              setVerificationDialogOpen(false);
            }}
          />

          <LicenseUpgradeDialog
            open={upgradeDialogOpen}
            onOpenChange={setUpgradeDialogOpen}
            purchaseId={upgradePurchaseId}
            currentLicense="personal"
            newLicense="commercial"
            templateName={selectedTemplate.name}
            onSuccess={() => {
              toast.success('License upgraded successfully!');
              loadTemplates();
            }}
          />
        </>
      )}

    </div>
  );
}
