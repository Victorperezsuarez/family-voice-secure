import { useState, useRef, useEffect } from 'react';
import { Button } from './ui/button';
import { Slider } from './ui/slider';
import { Input } from './ui/input';
import { X, Scissors, Sparkles, Type, Save, Play, Pause } from 'lucide-react';
import { Card } from './ui/card';

interface VideoEditorProps {
  videoBlob: Blob;
  onSave: (editedBlob: Blob) => void;
  onClose: () => void;
}

const FILTERS = [
  { name: 'None', filter: '' },
  { name: 'Vintage', filter: 'sepia(0.5) contrast(1.2)' },
  { name: 'B&W', filter: 'grayscale(1)' },
  { name: 'Bright', filter: 'brightness(1.3) contrast(1.1)' },
  { name: 'Cool', filter: 'hue-rotate(180deg) saturate(1.5)' },
  { name: 'Warm', filter: 'sepia(0.3) saturate(1.4)' }
];

export function VideoEditor({ videoBlob, onSave, onClose }: VideoEditorProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [videoUrl, setVideoUrl] = useState('');
  const [duration, setDuration] = useState(0);
  const [trimStart, setTrimStart] = useState(0);
  const [trimEnd, setTrimEnd] = useState(100);
  const [selectedFilter, setSelectedFilter] = useState(0);
  const [textOverlay, setTextOverlay] = useState('');
  const [textPosition, setTextPosition] = useState({ x: 50, y: 10 });
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);

  useEffect(() => {
    const url = URL.createObjectURL(videoBlob);
    setVideoUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [videoBlob]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handleLoadedMetadata = () => {
      setDuration(video.duration);
      setTrimEnd(video.duration);
    };

    const handleTimeUpdate = () => {
      setCurrentTime(video.currentTime);
      const trimEndTime = (trimEnd / 100) * duration;
      if (video.currentTime >= trimEndTime) {
        video.pause();
        setIsPlaying(false);
      }
    };

    video.addEventListener('loadedmetadata', handleLoadedMetadata);
    video.addEventListener('timeupdate', handleTimeUpdate);

    return () => {
      video.removeEventListener('loadedmetadata', handleLoadedMetadata);
      video.removeEventListener('timeupdate', handleTimeUpdate);
    };
  }, [duration, trimEnd]);

  const togglePlayPause = () => {
    const video = videoRef.current;
    if (!video) return;

    if (isPlaying) {
      video.pause();
    } else {
      const startTime = (trimStart / 100) * duration;
      if (video.currentTime < startTime || video.currentTime >= (trimEnd / 100) * duration) {
        video.currentTime = startTime;
      }
      video.play();
    }
    setIsPlaying(!isPlaying);
  };

  const handleSave = async () => {
    // In a real implementation, this would use FFmpeg.js or a backend service
    // For now, we'll save the original with metadata about edits
    const metadata = {
      trimStart: (trimStart / 100) * duration,
      trimEnd: (trimEnd / 100) * duration,
      filter: FILTERS[selectedFilter].name,
      textOverlay,
      textPosition
    };
    
    console.log('Video edits:', metadata);
    onSave(videoBlob);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 bg-black z-50 flex flex-col">
      <div className="flex-1 relative overflow-hidden">
        <video
          ref={videoRef}
          src={videoUrl}
          className="w-full h-full object-contain"
          style={{ filter: FILTERS[selectedFilter].filter }}
        />
        {textOverlay && (
          <div
            className="absolute text-white font-bold text-2xl drop-shadow-lg"
            style={{
              left: `${textPosition.x}%`,
              top: `${textPosition.y}%`,
              transform: 'translate(-50%, -50%)'
            }}
          >
            {textOverlay}
          </div>
        )}
        <canvas ref={canvasRef} className="hidden" />
      </div>

      <div className="bg-gray-900 p-4 space-y-4 max-h-[50vh] overflow-y-auto">
        <div className="flex justify-between items-center">
          <h3 className="text-white font-semibold">Video Editor</h3>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-5 w-5 text-white" />
          </Button>
        </div>

        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <Button size="sm" onClick={togglePlayPause} variant="outline">
              {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            </Button>
            <span className="text-white text-sm">{formatTime(currentTime)} / {formatTime(duration)}</span>
          </div>
        </div>

        <Card className="p-3 bg-gray-800 border-gray-700">
          <div className="flex items-center gap-2 mb-2">
            <Scissors className="h-4 w-4 text-amber-500" />
            <span className="text-white text-sm font-medium">Trim</span>
          </div>
          <div className="space-y-2">
            <div>
              <label className="text-xs text-gray-400">Start: {formatTime((trimStart / 100) * duration)}</label>
              <Slider value={[trimStart]} onValueChange={([v]) => setTrimStart(v)} max={100} step={1} />
            </div>
            <div>
              <label className="text-xs text-gray-400">End: {formatTime((trimEnd / 100) * duration)}</label>
              <Slider value={[trimEnd]} onValueChange={([v]) => setTrimEnd(v)} max={100} step={1} />
            </div>
          </div>
        </Card>

        <Card className="p-3 bg-gray-800 border-gray-700">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="h-4 w-4 text-purple-500" />
            <span className="text-white text-sm font-medium">Filters</span>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {FILTERS.map((filter, idx) => (
              <Button
                key={idx}
                size="sm"
                variant={selectedFilter === idx ? 'default' : 'outline'}
                onClick={() => setSelectedFilter(idx)}
                className="text-xs"
              >
                {filter.name}
              </Button>
            ))}
          </div>
        </Card>

        <Card className="p-3 bg-gray-800 border-gray-700">
          <div className="flex items-center gap-2 mb-2">
            <Type className="h-4 w-4 text-blue-500" />
            <span className="text-white text-sm font-medium">Text Overlay</span>
          </div>
          <Input
            value={textOverlay}
            onChange={(e) => setTextOverlay(e.target.value)}
            placeholder="Add text..."
            className="bg-gray-700 border-gray-600 text-white"
          />
        </Card>

        <Button onClick={handleSave} className="w-full bg-amber-600 hover:bg-amber-700">
          <Save className="h-4 w-4 mr-2" />
          Save Edited Video
        </Button>
      </div>
    </div>
  );
}
