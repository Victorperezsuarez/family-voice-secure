import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase-client';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { History, RotateCcw, Eye } from 'lucide-react';
import { TranscriptionVersion } from '@/types/collaboration';
import { formatDistanceToNow } from 'date-fns';
import { useToast } from '@/hooks/use-toast';

interface Props {
  recordingId: string;
  onRestore: (content: string) => void;
  onPreview: (content: string) => void;
}

export default function VersionHistoryPanel({ recordingId, onRestore, onPreview }: Props) {
  const [versions, setVersions] = useState<TranscriptionVersion[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadVersions();
  }, [recordingId]);

  const loadVersions = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('transcription_versions')
      .select(`*, user:profiles(id, full_name)`)
      .eq('recording_id', recordingId)
      .order('version_number', { ascending: false });

    if (data) setVersions(data as any);
    setLoading(false);
  };

  const handleRestore = async (version: TranscriptionVersion) => {
    try {
      await onRestore(version.content);
      toast({ title: 'Restored', description: `Restored to version ${version.version_number}` });
    } catch (error) {
      toast({ title: 'Error', description: 'Failed to restore version', variant: 'destructive' });
    }
  };

  if (loading) {
    return <div className="text-center py-8">Loading version history...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <History className="h-5 w-5" />
        <h3 className="text-lg font-semibold">Version History</h3>
        <Badge variant="secondary">{versions.length} versions</Badge>
      </div>

      <ScrollArea className="h-[500px]">
        <div className="space-y-3">
          {versions.map((version, index) => (
            <Card key={version.id} className="p-4">
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Badge variant={index === 0 ? 'default' : 'outline'}>
                      Version {version.version_number}
                    </Badge>
                    {index === 0 && <Badge variant="secondary">Current</Badge>}
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Edited by {version.user?.full_name}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {formatDistanceToNow(new Date(version.edited_at), { addSuffix: true })}
                  </p>
                  {version.change_summary && (
                    <p className="text-sm mt-2">{version.change_summary}</p>
                  )}
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onPreview(version.content)}
                  >
                    <Eye className="h-4 w-4" />
                  </Button>
                  {index !== 0 && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleRestore(version)}
                    >
                      <RotateCcw className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}
