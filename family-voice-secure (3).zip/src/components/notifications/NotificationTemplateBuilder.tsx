import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Plus, X, Save, Eye } from 'lucide-react';
import { NotificationTemplate, NotificationAction } from '@/types/notificationTemplates';
import { supabase } from '@/lib/supabase-client';
import { toast } from '@/hooks/use-toast';

interface NotificationTemplateBuilderProps {
  template?: NotificationTemplate;
  onSave?: (template: NotificationTemplate) => void;
}

export function NotificationTemplateBuilder({ template, onSave }: NotificationTemplateBuilderProps) {
  const [name, setName] = useState(template?.name || '');
  const [description, setDescription] = useState(template?.description || '');
  const [suggestionType, setSuggestionType] = useState(template?.suggestion_type || 'recording');
  const [urgencyLevel, setUrgencyLevel] = useState(template?.urgency_level || 'medium');
  const [titleTemplate, setTitleTemplate] = useState(template?.title_template || '');
  const [bodyTemplate, setBodyTemplate] = useState(template?.body_template || '');
  const [iconUrl, setIconUrl] = useState(template?.icon_url || '');
  const [imageUrl, setImageUrl] = useState(template?.image_url || '');
  const [badgeUrl, setBadgeUrl] = useState(template?.badge_url || '');
  const [actions, setActions] = useState<NotificationAction[]>(template?.actions || []);
  const [showProgress, setShowProgress] = useState(template?.show_progress || false);
  const [progressMax, setProgressMax] = useState(template?.progress_max || 100);
  const [soundUrl, setSoundUrl] = useState(template?.sound_url || '');
  const [requireInteraction, setRequireInteraction] = useState(template?.require_interaction || false);
  const [autoCloseDelay, setAutoCloseDelay] = useState(template?.auto_close_delay || 0);
  const [isDefault, setIsDefault] = useState(template?.is_default || false);
  const [saving, setSaving] = useState(false);

  const addAction = () => {
    setActions([...actions, { action: '', title: '', icon: '' }]);
  };

  const removeAction = (index: number) => {
    setActions(actions.filter((_, i) => i !== index));
  };

  const updateAction = (index: number, field: keyof NotificationAction, value: string) => {
    const newActions = [...actions];
    newActions[index] = { ...newActions[index], [field]: value };
    setActions(newActions);
  };

  const handleSave = async () => {
    if (!name || !titleTemplate || !bodyTemplate) {
      toast({ title: 'Error', description: 'Please fill in required fields', variant: 'destructive' });
      return;
    }

    setSaving(true);
    try {
      const templateData = {
        name,
        description,
        suggestion_type: suggestionType,
        urgency_level: urgencyLevel,
        title_template: titleTemplate,
        body_template: bodyTemplate,
        icon_url: iconUrl || null,
        image_url: imageUrl || null,
        badge_url: badgeUrl || null,
        actions,
        show_progress: showProgress,
        progress_max: progressMax,
        sound_url: soundUrl || null,
        require_interaction: requireInteraction,
        auto_close_delay: autoCloseDelay || null,
        is_default: isDefault,
        is_active: true
      };

      let result;
      if (template?.id) {
        result = await supabase
          .from('notification_templates')
          .update(templateData)
          .eq('id', template.id)
          .select()
          .single();
      } else {
        result = await supabase
          .from('notification_templates')
          .insert(templateData)
          .select()
          .single();
      }

      if (result.error) throw result.error;

      toast({ title: 'Success', description: 'Template saved successfully' });
      onSave?.(result.data);
    } catch (error: any) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Template Details</CardTitle>
          <CardDescription>Configure the notification template</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="name">Template Name *</Label>
            <Input id="name" value={name} onChange={(e) => setName(e.target.value)} />
          </div>
          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea id="description" value={description} onChange={(e) => setDescription(e.target.value)} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="type">Suggestion Type *</Label>
              <Select value={suggestionType} onValueChange={setSuggestionType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="recording">Recording</SelectItem>
                  <SelectItem value="milestone">Milestone</SelectItem>
                  <SelectItem value="collection">Collection</SelectItem>
                  <SelectItem value="reminder">Reminder</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="urgency">Urgency Level *</Label>
              <Select value={urgencyLevel} onValueChange={setUrgencyLevel}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Content Templates</CardTitle>
          <CardDescription>Use variables like {'{name}'}, {'{date}'}, {'{count}'}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="title">Title Template *</Label>
            <Input id="title" value={titleTemplate} onChange={(e) => setTitleTemplate(e.target.value)} />
          </div>
          <div>
            <Label htmlFor="body">Body Template *</Label>
            <Textarea id="body" value={bodyTemplate} onChange={(e) => setBodyTemplate(e.target.value)} />
          </div>
          <div>
            <Label htmlFor="icon">Icon URL</Label>
            <Input id="icon" value={iconUrl} onChange={(e) => setIconUrl(e.target.value)} placeholder="/icon.png" />
          </div>
          <div>
            <Label htmlFor="image">Image URL</Label>
            <Input id="image" value={imageUrl} onChange={(e) => setImageUrl(e.target.value)} placeholder="/image.jpg" />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Action Buttons</CardTitle>
          <CardDescription>Add interactive buttons to the notification</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {actions.map((action, index) => (
            <div key={index} className="flex gap-2 items-end">
              <div className="flex-1">
                <Label>Action ID</Label>
                <Input value={action.action} onChange={(e) => updateAction(index, 'action', e.target.value)} placeholder="accept" />
              </div>
              <div className="flex-1">
                <Label>Button Text</Label>
                <Input value={action.title} onChange={(e) => updateAction(index, 'title', e.target.value)} placeholder="Accept" />
              </div>
              <Button variant="ghost" size="icon" onClick={() => removeAction(index)}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          ))}
          <Button variant="outline" onClick={addAction}>
            <Plus className="h-4 w-4 mr-2" />
            Add Action
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Behavior Settings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <Label htmlFor="progress">Show Progress Bar</Label>
            <Switch id="progress" checked={showProgress} onCheckedChange={setShowProgress} />
          </div>
          {showProgress && (
            <div>
              <Label htmlFor="progressMax">Progress Max Value</Label>
              <Input id="progressMax" type="number" value={progressMax} onChange={(e) => setProgressMax(Number(e.target.value))} />
            </div>
          )}
          <div className="flex items-center justify-between">
            <Label htmlFor="interaction">Require Interaction</Label>
            <Switch id="interaction" checked={requireInteraction} onCheckedChange={setRequireInteraction} />
          </div>
          <div>
            <Label htmlFor="autoClose">Auto Close Delay (ms, 0 = never)</Label>
            <Input id="autoClose" type="number" value={autoCloseDelay} onChange={(e) => setAutoCloseDelay(Number(e.target.value))} />
          </div>
          <div>
            <Label htmlFor="sound">Sound URL</Label>
            <Input id="sound" value={soundUrl} onChange={(e) => setSoundUrl(e.target.value)} placeholder="/notification.mp3" />
          </div>
          <div className="flex items-center justify-between">
            <Label htmlFor="default">Set as Default Template</Label>
            <Switch id="default" checked={isDefault} onCheckedChange={setIsDefault} />
          </div>
        </CardContent>
      </Card>

      <div className="flex gap-2">
        <Button onClick={handleSave} disabled={saving}>
          <Save className="h-4 w-4 mr-2" />
          {saving ? 'Saving...' : 'Save Template'}
        </Button>
      </div>
    </div>
  );
}
