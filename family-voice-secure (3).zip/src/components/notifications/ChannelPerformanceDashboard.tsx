import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/lib/supabase-client';
import { ChannelHealthCard } from './ChannelHealthCard';
import { FailureAnalysisPanel } from './FailureAnalysisPanel';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Button } from '@/components/ui/button';
import { RefreshCw } from 'lucide-react';
import { toast } from 'sonner';

export function ChannelPerformanceDashboard() {
  const [channels, setChannels] = useState<any[]>([]);
  const [metrics, setMetrics] = useState<any[]>([]);
  const [failures, setFailures] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const loadData = async () => {
    setLoading(true);
    try {
      const { data: channelsData } = await supabase
        .from('notification_channels')
        .select('*, channel_health_status(*)');
      
      const { data: metricsData } = await supabase
        .from('channel_health_metrics')
        .select('*')
        .order('recorded_at', { ascending: false })
        .limit(100);

      const { data: logsData } = await supabase
        .from('notification_delivery_log')
        .select('*, notification_channels(name)')
        .eq('status', 'failed')
        .order('delivered_at', { ascending: false })
        .limit(50);

      // Aggregate failures by channel and error
      const failureMap = new Map();
      logsData?.forEach(log => {
        const key = `${log.channel_id}-${log.error_message}`;
        if (failureMap.has(key)) {
          const existing = failureMap.get(key);
          existing.count++;
          existing.last_occurred = log.delivered_at;
        } else {
          failureMap.set(key, {
            channel_name: log.notification_channels?.name || 'Unknown',
            error_message: log.error_message || 'Unknown error',
            count: 1,
            last_occurred: log.delivered_at
          });
        }
      });

      setChannels(channelsData || []);
      setMetrics(metricsData || []);
      setFailures(Array.from(failureMap.values()).sort((a, b) => b.count - a.count));
    } catch (error) {
      toast.error('Failed to load channel data');
    } finally {
      setLoading(false);
    }
  };


  useEffect(() => {
    loadData();
  }, []);

  const handleRunHealthCheck = async (channelId: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('check-channel-health', {
        body: { channelId }
      });

      if (error) throw error;
      toast.success('Health check completed');
      loadData();
    } catch (error) {
      toast.error('Health check failed');
    }
  };

  const successRateData = channels.map(ch => ({
    name: ch.name,
    rate: ch.channel_health_status?.success_rate || 0
  }));

  const latencyData = metrics.slice(0, 20).reverse().map((m, i) => ({
    time: i,
    latency: Number(m.value)
  }));

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Channel Performance</h2>
        <Button onClick={loadData} disabled={loading}>
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh
        </Button>
      </div>

      <Tabs defaultValue="overview">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="metrics">Metrics</TabsTrigger>
          <TabsTrigger value="health">Health Status</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Success Rates</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart data={successRateData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="rate" fill="#10b981" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Latency Trends</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <LineChart data={latencyData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis />
                    <Tooltip />
                    <Line type="monotone" dataKey="latency" stroke="#3b82f6" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
          <FailureAnalysisPanel failures={failures} />
        </TabsContent>


        <TabsContent value="health" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {channels.map(channel => (
              <ChannelHealthCard
                key={channel.id}
                channel={channel}
                onRunHealthCheck={handleRunHealthCheck}
              />
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
