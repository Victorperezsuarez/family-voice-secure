import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Activity, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';

interface ChannelHealthCardProps {
  channel: {
    id: string;
    name: string;
    channel_type: string;
    health_status?: {
      status: string;
      success_rate: number;
      avg_latency_ms: number;
      health_score: number;
      consecutive_failures: number;
      last_check_at: string;
    };
  };
  onRunHealthCheck: (channelId: string) => void;
}

export function ChannelHealthCard({ channel, onRunHealthCheck }: ChannelHealthCardProps) {
  const status = channel.health_status?.status || 'unknown';
  const successRate = channel.health_status?.success_rate || 0;
  const avgLatency = channel.health_status?.avg_latency_ms || 0;
  const healthScore = channel.health_status?.health_score || 0;

  const getStatusColor = () => {
    switch (status) {
      case 'healthy': return 'bg-green-500';
      case 'degraded': return 'bg-yellow-500';
      case 'failing': return 'bg-orange-500';
      case 'offline': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusIcon = () => {
    switch (status) {
      case 'healthy': return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'degraded': return <AlertTriangle className="h-5 w-5 text-yellow-600" />;
      case 'failing': return <XCircle className="h-5 w-5 text-orange-600" />;
      case 'offline': return <XCircle className="h-5 w-5 text-red-600" />;
      default: return <Activity className="h-5 w-5 text-gray-600" />;
    }
  };

  return (
    <Card className="p-4">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          {getStatusIcon()}
          <div>
            <h3 className="font-semibold">{channel.name}</h3>
            <p className="text-sm text-muted-foreground capitalize">{channel.channel_type}</p>
          </div>
        </div>
        <Badge className={getStatusColor()}>{status}</Badge>
      </div>

      <div className="grid grid-cols-3 gap-4 mb-4">
        <div>
          <p className="text-xs text-muted-foreground">Success Rate</p>
          <p className="text-lg font-bold">{successRate.toFixed(1)}%</p>
        </div>
        <div>
          <p className="text-xs text-muted-foreground">Avg Latency</p>
          <p className="text-lg font-bold">{avgLatency.toFixed(0)}ms</p>
        </div>
        <div>
          <p className="text-xs text-muted-foreground">Health Score</p>
          <p className="text-lg font-bold">{healthScore.toFixed(0)}</p>
        </div>
      </div>

      <Button 
        size="sm" 
        variant="outline" 
        className="w-full"
        onClick={() => onRunHealthCheck(channel.id)}
      >
        Run Health Check
      </Button>
    </Card>
  );
}
