import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Settings, TrendingUp, CheckCircle2 } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';

export function ThresholdOptimizationPanel() {
  const [optimizations, setOptimizations] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadOptimizations();
  }, []);

  const loadOptimizations = async () => {
    const { data } = await supabase
      .from('alert_threshold_optimizations')
      .select('*, alert_rules(name)')
      .order('created_at', { ascending: false })
      .limit(20);
    
    setOptimizations(data || []);
  };

  const applyOptimization = async (optId: string) => {
    setLoading(true);
    await supabase
      .from('alert_threshold_optimizations')
      .update({ applied: true, applied_at: new Date().toISOString() })
      .eq('id', optId);
    
    await loadOptimizations();
    setLoading(false);
  };

  const getConfidenceBadge = (confidence: number) => {
    if (confidence >= 80) return { variant: 'default' as const, label: 'High Confidence' };
    if (confidence >= 60) return { variant: 'secondary' as const, label: 'Medium Confidence' };
    return { variant: 'outline' as const, label: 'Low Confidence' };
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Threshold Optimization Suggestions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {optimizations.map((opt) => {
              const badge = getConfidenceBadge(opt.confidence_score);
              return (
                <Card key={opt.id} className={opt.applied ? 'opacity-60' : ''}>
                  <CardContent className="pt-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h4 className="font-semibold">{opt.alert_rules?.name || 'Unknown Rule'}</h4>
                          <Badge variant={badge.variant}>{badge.label}</Badge>
                          {opt.applied && (
                            <Badge variant="outline">
                              <CheckCircle2 className="h-3 w-3 mr-1" />
                              Applied
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground mb-3">{opt.optimization_reason}</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">Current Threshold</p>
                        <p className="text-lg font-semibold">{opt.old_threshold}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">Suggested Threshold</p>
                        <p className="text-lg font-semibold text-blue-600">{opt.new_threshold}</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-muted-foreground">False Positive Reduction</p>
                        <p className="font-semibold text-green-600">
                          <TrendingUp className="h-3 w-3 inline mr-1" />
                          {opt.false_positive_reduction?.toFixed(1)}%
                        </p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">True Positive Retention</p>
                        <p className="font-semibold">{opt.true_positive_retention?.toFixed(1)}%</p>
                      </div>
                    </div>

                    {!opt.applied && (
                      <Button
                        variant="default"
                        size="sm"
                        className="w-full mt-4"
                        onClick={() => applyOptimization(opt.id)}
                        disabled={loading}
                      >
                        Apply Optimization
                      </Button>
                    )}
                  </CardContent>
                </Card>
              );
            })}

            {optimizations.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                <p>No optimization suggestions available</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}