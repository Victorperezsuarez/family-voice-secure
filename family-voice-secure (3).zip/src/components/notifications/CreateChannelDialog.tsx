import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';

interface CreateChannelDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (channel: any) => void;
}

export function CreateChannelDialog({ open, onOpenChange, onSave }: CreateChannelDialogProps) {

  const [name, setName] = useState('');
  const [type, setType] = useState<'email' | 'sms' | 'slack' | 'webhook'>('email');
  const [config, setConfig] = useState<any>({});

  const handleSave = () => {
    onSave({ name, type, config, is_active: true });
    setName('');
    setType('email');
    setConfig({});
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Create Notification Channel</DialogTitle>
          <DialogDescription>Configure a new delivery method for alerts</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label>Channel Name</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g., Team Email" />
          </div>
          <div>
            <Label>Channel Type</Label>
            <Select value={type} onValueChange={(v: any) => setType(v)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="email">Email</SelectItem>
                <SelectItem value="sms">SMS</SelectItem>
                <SelectItem value="slack">Slack</SelectItem>
                <SelectItem value="webhook">Webhook</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {type === 'email' && (
            <>
              <div>
                <Label>To Email</Label>
                <Input value={config.to_email || ''} onChange={(e) => setConfig({ ...config, to_email: e.target.value })} placeholder="alerts@example.com" />
              </div>
              <div>
                <Label>From Email</Label>
                <Input value={config.from_email || ''} onChange={(e) => setConfig({ ...config, from_email: e.target.value })} placeholder="noreply@vela.app" />
              </div>
            </>
          )}
          {type === 'sms' && (
            <>
              <div>
                <Label>To Number</Label>
                <Input value={config.to_number || ''} onChange={(e) => setConfig({ ...config, to_number: e.target.value })} placeholder="+1234567890" />
              </div>
              <div>
                <Label>From Number</Label>
                <Input value={config.from_number || ''} onChange={(e) => setConfig({ ...config, from_number: e.target.value })} placeholder="+1234567890" />
              </div>
            </>
          )}
          {type === 'slack' && (
            <div>
              <Label>Webhook URL</Label>
              <Textarea value={config.webhook_url || ''} onChange={(e) => setConfig({ ...config, webhook_url: e.target.value })} placeholder="https://hooks.slack.com/..." />
            </div>
          )}
          {type === 'webhook' && (
            <>
              <div>
                <Label>URL</Label>
                <Input value={config.url || ''} onChange={(e) => setConfig({ ...config, url: e.target.value })} placeholder="https://api.example.com/alerts" />
              </div>
              <div>
                <Label>Method</Label>
                <Select value={config.method || 'POST'} onValueChange={(v) => setConfig({ ...config, method: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="POST">POST</SelectItem>
                    <SelectItem value="PUT">PUT</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </>
          )}
          <Button onClick={handleSave} className="w-full">Create Channel</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}