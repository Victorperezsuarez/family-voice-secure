import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Lightbulb, TrendingUp, AlertTriangle, CheckCircle } from 'lucide-react';

interface Recommendation {
  type: 'success' | 'warning' | 'info';
  title: string;
  description: string;
  impact: 'high' | 'medium' | 'low';
  action?: string;
}

interface ABTestRecommendationsPanelProps {
  testResults: any[];
  test: any;
}

export default function ABTestRecommendationsPanel({ testResults, test }: ABTestRecommendationsPanelProps) {
  const generateRecommendations = (): Recommendation[] => {
    const recommendations: Recommendation[] = [];
    
    if (testResults.length < 2) return recommendations;

    const sorted = [...testResults].sort((a, b) => b.conversion_rate - a.conversion_rate);
    const best = sorted[0];
    const worst = sorted[sorted.length - 1];

    // Check if winner is clear
    if (best.statistical_significance && best.statistical_significance >= test.confidence_level) {
      recommendations.push({
        type: 'success',
        title: 'Clear Winner Identified',
        description: `Template "${best.template_id}" shows ${((best.conversion_rate - worst.conversion_rate) * 100).toFixed(1)}% higher conversion rate with ${(best.statistical_significance * 100).toFixed(1)}% confidence.`,
        impact: 'high',
        action: 'Deploy this template to all users'
      });
    } else {
      recommendations.push({
        type: 'warning',
        title: 'Insufficient Data',
        description: `Need ${test.target_sample_size - best.deliveries} more samples to reach statistical significance.`,
        impact: 'high',
        action: 'Continue test'
      });
    }

    // Check click-through rates
    const avgClickRate = testResults.reduce((sum, r) => sum + r.click_rate, 0) / testResults.length;
    if (avgClickRate < 0.1) {
      recommendations.push({
        type: 'warning',
        title: 'Low Click-Through Rate',
        description: 'All variants have CTR below 10%. Consider testing more engaging copy or imagery.',
        impact: 'high',
        action: 'Create new variants with stronger CTAs'
      });
    }

    // Check action rates
    testResults.forEach(result => {
      if (result.click_rate > 0.2 && result.action_rate < 0.5) {
        recommendations.push({
          type: 'info',
          title: 'High Clicks, Low Actions',
          description: `Template "${result.template_id}" gets clicks but users don't take action. Simplify the action flow.`,
          impact: 'medium',
          action: 'Reduce friction in action buttons'
        });
      }
    });

    // Check time metrics
    const fastResponders = testResults.filter(r => r.avg_time_to_action && r.avg_time_to_action < 5000);
    if (fastResponders.length > 0) {
      recommendations.push({
        type: 'success',
        title: 'Quick User Response',
        description: `Some templates get responses in under 5 seconds. Users are highly engaged.`,
        impact: 'medium',
        action: 'Analyze what makes these templates effective'
      });
    }

    // Sample size recommendations
    if (best.deliveries < 100) {
      recommendations.push({
        type: 'warning',
        title: 'Small Sample Size',
        description: 'Results may not be reliable with fewer than 100 deliveries per variant.',
        impact: 'high',
        action: 'Increase traffic or extend test duration'
      });
    }

    return recommendations;
  };

  const recommendations = generateRecommendations();

  const getIcon = (type: string) => {
    switch (type) {
      case 'success': return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'warning': return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      default: return <Lightbulb className="h-5 w-5 text-blue-500" />;
    }
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high': return 'bg-red-500';
      case 'medium': return 'bg-yellow-500';
      default: return 'bg-blue-500';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="h-5 w-5" />
          Recommendations
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {recommendations.length === 0 ? (
          <p className="text-gray-500 text-center py-4">No recommendations yet. Start the test to get insights.</p>
        ) : (
          recommendations.map((rec, index) => (
            <div key={index} className="border rounded-lg p-4 space-y-2">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2">
                  {getIcon(rec.type)}
                  <h4 className="font-semibold">{rec.title}</h4>
                </div>
                <Badge className={getImpactColor(rec.impact)}>
                  {rec.impact} impact
                </Badge>
              </div>
              <p className="text-sm text-gray-600">{rec.description}</p>
              {rec.action && (
                <Button size="sm" variant="outline" className="mt-2">
                  {rec.action}
                </Button>
              )}
            </div>
          ))
        )}
      </CardContent>
    </Card>
  );
}
