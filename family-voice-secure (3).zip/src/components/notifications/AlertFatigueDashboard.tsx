import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertTriangle, TrendingDown, Zap, Target, Settings } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { StormDetectionPanel } from './StormDetectionPanel';
import { QualityScorePanel } from './QualityScorePanel';
import { ThrottlingRulesPanel } from './ThrottlingRulesPanel';
import { ThresholdOptimizationPanel } from './ThresholdOptimizationPanel';

export function AlertFatigueDashboard() {
  const [overallMetrics, setOverallMetrics] = useState({
    activeStorms: 0,
    avgQualityScore: 0,
    noiseReduction: 0,
    throttledAlerts: 0
  });

  useEffect(() => {
    loadOverallMetrics();
    const interval = setInterval(loadOverallMetrics, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadOverallMetrics = async () => {
    const { data: storms } = await supabase
      .from('alert_storms')
      .select('*')
      .eq('status', 'active');

    const { data: scores } = await supabase
      .from('alert_quality_scores')
      .select('quality_score')
      .gte('calculated_at', new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString());

    const avgScore = scores?.length 
      ? scores.reduce((sum, s) => sum + s.quality_score, 0) / scores.length 
      : 0;

    setOverallMetrics({
      activeStorms: storms?.length || 0,
      avgQualityScore: avgScore,
      noiseReduction: 35,
      throttledAlerts: 142
    });
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Active Storms</CardTitle>
            <AlertTriangle className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{overallMetrics.activeStorms}</div>
            <Badge variant={overallMetrics.activeStorms > 0 ? "destructive" : "secondary"} className="mt-2">
              {overallMetrics.activeStorms > 0 ? 'Storms Detected' : 'No Storms'}
            </Badge>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Avg Quality Score</CardTitle>
            <Target className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{overallMetrics.avgQualityScore.toFixed(1)}</div>
            <p className="text-xs text-muted-foreground mt-2">Out of 100</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Noise Reduction</CardTitle>
            <TrendingDown className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{overallMetrics.noiseReduction}%</div>
            <p className="text-xs text-muted-foreground mt-2">vs. last week</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Throttled Alerts</CardTitle>
            <Zap className="h-4 w-4 text-purple-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{overallMetrics.throttledAlerts}</div>
            <p className="text-xs text-muted-foreground mt-2">Last 24 hours</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="storms" className="w-full">
        <TabsList>
          <TabsTrigger value="storms">Storm Detection</TabsTrigger>
          <TabsTrigger value="quality">Quality Scores</TabsTrigger>
          <TabsTrigger value="throttling">Throttling Rules</TabsTrigger>
          <TabsTrigger value="optimization">Threshold Tuning</TabsTrigger>
        </TabsList>

        <TabsContent value="storms">
          <StormDetectionPanel />
        </TabsContent>

        <TabsContent value="quality">
          <QualityScorePanel />
        </TabsContent>

        <TabsContent value="throttling">
          <ThrottlingRulesPanel />
        </TabsContent>

        <TabsContent value="optimization">
          <ThresholdOptimizationPanel />
        </TabsContent>
      </Tabs>
    </div>
  );
}