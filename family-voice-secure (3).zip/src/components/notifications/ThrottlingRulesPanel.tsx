import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Zap, Plus } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';

export function ThrottlingRulesPanel() {
  const [rules, setRules] = useState<any[]>([]);

  useEffect(() => {
    loadRules();
  }, []);

  const loadRules = async () => {
    const { data } = await supabase
      .from('alert_throttling_rules')
      .select('*, alert_rules(name)')
      .order('created_at', { ascending: false });
    
    setRules(data || []);
  };

  const toggleRule = async (ruleId: string, enabled: boolean) => {
    await supabase
      .from('alert_throttling_rules')
      .update({ enabled })
      .eq('id', ruleId);
    
    await loadRules();
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'rate_limit': return 'Rate Limit';
      case 'burst_protection': return 'Burst Protection';
      case 'duplicate_suppression': return 'Duplicate Suppression';
      case 'storm_protection': return 'Storm Protection';
      default: return type;
    }
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5" />
              Throttling Rules
            </CardTitle>
            <Button size="sm">
              <Plus className="h-4 w-4 mr-2" />
              Add Rule
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {rules.map((rule) => (
              <Card key={rule.id}>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h4 className="font-semibold">{rule.alert_rules?.name || 'Unknown Rule'}</h4>
                        <Badge variant="outline">{getTypeLabel(rule.throttle_type)}</Badge>
                        {rule.auto_enabled && (
                          <Badge variant="secondary">Auto-enabled</Badge>
                        )}
                      </div>
                      
                      <div className="text-sm text-muted-foreground">
                        Max {rule.max_alerts_per_window} alerts per {rule.time_window_minutes} minutes
                        {rule.cooldown_period_minutes && ` • ${rule.cooldown_period_minutes}m cooldown`}
                      </div>
                    </div>

                    <Switch
                      checked={rule.enabled}
                      onCheckedChange={(checked) => toggleRule(rule.id, checked)}
                    />
                  </div>
                </CardContent>
              </Card>
            ))}

            {rules.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                <p>No throttling rules configured</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}