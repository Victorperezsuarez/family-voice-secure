import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, XCircle, User } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';

interface ApprovalChainDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  workflow: any;
}

export function ApprovalChainDialog({ open, onOpenChange, workflow }: ApprovalChainDialogProps) {
  const [comment, setComment] = useState('');
  const [loading, setLoading] = useState(false);

  const handleApprove = async () => {
    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      await supabase
        .from('alert_acknowledgment_workflows')
        .update({
          approval_status: 'approved',
          approved_by: user?.id,
          approved_at: new Date().toISOString(),
          approval_comment: comment
        })
        .eq('id', workflow.id);

      toast.success('Acknowledgment approved');
      onOpenChange(false);
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleReject = async () => {
    setLoading(true);
    try {
      await supabase
        .from('alert_acknowledgment_workflows')
        .update({ approval_status: 'rejected', approval_comment: comment })
        .eq('id', workflow.id);

      toast.success('Acknowledgment rejected');
      onOpenChange(false);
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Approval Required</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="p-4 bg-gray-50 rounded-lg space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Acknowledged By</span>
              <Badge variant="outline">
                <User className="h-3 w-3 mr-1" />
                {workflow.acknowledged_by}
              </Badge>
            </div>
            <div>
              <span className="text-sm font-medium">Comment</span>
              <p className="text-sm text-gray-600 mt-1">{workflow.acknowledgment_comment}</p>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Approval Comment</label>
            <Textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Add approval notes..."
              rows={3}
            />
          </div>

          <div className="flex gap-2">
            <Button onClick={handleApprove} disabled={loading} className="flex-1">
              <CheckCircle className="h-4 w-4 mr-2" />
              Approve
            </Button>
            <Button onClick={handleReject} disabled={loading} variant="destructive" className="flex-1">
              <XCircle className="h-4 w-4 mr-2" />
              Reject
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
