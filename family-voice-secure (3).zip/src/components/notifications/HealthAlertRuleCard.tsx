import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { AlertTriangle, Clock, TrendingDown, Zap } from 'lucide-react';

interface HealthAlertRuleCardProps {
  rule: {
    id: string;
    rule_name: string;
    rule_type: string;
    condition_config: any;
    severity: string;
    enabled: boolean;
    escalation_policy?: any;
    suppression_windows?: any[];
  };
  onToggle: (id: string, enabled: boolean) => void;
  onEdit: (rule: any) => void;
  onDelete: (id: string) => void;
}

const ruleTypeIcons = {
  success_rate: TrendingDown,
  consecutive_failures: AlertTriangle,
  latency_spike: Clock,
  error_rate: Zap
};

const severityColors = {
  low: 'bg-blue-100 text-blue-800',
  medium: 'bg-yellow-100 text-yellow-800',
  high: 'bg-orange-100 text-orange-800',
  critical: 'bg-red-100 text-red-800'
};

export function HealthAlertRuleCard({ rule, onToggle, onEdit, onDelete }: HealthAlertRuleCardProps) {
  const Icon = ruleTypeIcons[rule.rule_type as keyof typeof ruleTypeIcons] || AlertTriangle;

  return (
    <Card className="p-4">
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-purple-100 rounded-lg">
            <Icon className="w-5 h-5 text-purple-600" />
          </div>
          <div>
            <h3 className="font-semibold">{rule.rule_name}</h3>
            <p className="text-sm text-muted-foreground capitalize">{rule.rule_type.replace('_', ' ')}</p>
          </div>
        </div>
        <Switch checked={rule.enabled} onCheckedChange={(checked) => onToggle(rule.id, checked)} />
      </div>

      <div className="space-y-2 mb-3">
        <div className="flex items-center gap-2 text-sm">
          <Badge className={severityColors[rule.severity as keyof typeof severityColors]}>
            {rule.severity.toUpperCase()}
          </Badge>
          {rule.escalation_policy && (
            <Badge variant="outline">
              {rule.escalation_policy.levels?.length || 0} Escalation Levels
            </Badge>
          )}
        </div>

        <div className="text-sm text-muted-foreground">
          {rule.rule_type === 'success_rate' && `Threshold: ${rule.condition_config.threshold}%`}
          {rule.rule_type === 'consecutive_failures' && `Max failures: ${rule.condition_config.max_failures}`}
          {rule.rule_type === 'latency_spike' && `Threshold: ${rule.condition_config.threshold_ms}ms`}
          {rule.rule_type === 'error_rate' && `Threshold: ${rule.condition_config.threshold}%`}
        </div>

        {rule.suppression_windows && rule.suppression_windows.length > 0 && (
          <Badge variant="secondary" className="text-xs">
            {rule.suppression_windows.length} Maintenance Window(s)
          </Badge>
        )}
      </div>

      <div className="flex gap-2">
        <Button variant="outline" size="sm" onClick={() => onEdit(rule)} className="flex-1">
          Edit
        </Button>
        <Button variant="outline" size="sm" onClick={() => onDelete(rule.id)} className="text-red-600">
          Delete
        </Button>
      </div>
    </Card>
  );
}
