import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { supabase } from '@/lib/supabase-client';
import { AlertCircle, CheckCircle, Clock, XCircle, MessageSquare } from 'lucide-react';
import { toast } from 'sonner';
import { AcknowledgmentWorkflowPanel } from './AcknowledgmentWorkflowPanel';
import { ApprovalChainDialog } from './ApprovalChainDialog';

interface TriggeredAlertsPanelProps {
  familyId: string;
}


export function TriggeredAlertsPanel({ familyId }: TriggeredAlertsPanelProps) {
  const [alerts, setAlerts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedAlert, setSelectedAlert] = useState<any>(null);
  const [workflowDialogOpen, setWorkflowDialogOpen] = useState(false);
  const [approvalDialogOpen, setApprovalDialogOpen] = useState(false);
  const [selectedWorkflow, setSelectedWorkflow] = useState<any>(null);


  useEffect(() => {
    loadAlerts();
    const interval = setInterval(loadAlerts, 30000);
    return () => clearInterval(interval);
  }, [familyId]);

  const loadAlerts = async () => {
    try {
      const { data, error } = await supabase
        .from('triggered_health_alerts')
        .select('*, notification_channels(name, type)')
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      setAlerts(data || []);
    } catch (error: any) {
      console.error('Error loading alerts:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAcknowledge = async (alertId: string) => {
    try {
      const { error } = await supabase
        .from('triggered_health_alerts')
        .update({ status: 'acknowledged', acknowledged_at: new Date().toISOString() })
        .eq('id', alertId);

      if (error) throw error;
      toast.success('Alert acknowledged');
      loadAlerts();
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  const handleResolve = async (alertId: string) => {
    try {
      const { error } = await supabase
        .from('triggered_health_alerts')
        .update({ status: 'resolved', resolved_at: new Date().toISOString() })
        .eq('id', alertId);

      if (error) throw error;
      toast.success('Alert resolved');
      loadAlerts();
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  const statusIcons = {
    active: AlertCircle,
    acknowledged: Clock,
    resolved: CheckCircle,
    suppressed: XCircle
  };

  const statusColors = {
    active: 'bg-red-100 text-red-800',
    acknowledged: 'bg-yellow-100 text-yellow-800',
    resolved: 'bg-green-100 text-green-800',
    suppressed: 'bg-gray-100 text-gray-800'
  };

  const severityColors = {
    low: 'border-blue-500',
    medium: 'border-yellow-500',
    high: 'border-orange-500',
    critical: 'border-red-500'
  };

  if (loading) return <div className="text-center py-8">Loading alerts...</div>;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Triggered Alerts</h3>
        <Badge variant="outline">{alerts.filter(a => a.status === 'active').length} Active</Badge>
      </div>

      {alerts.length === 0 ? (
        <Card className="p-8 text-center">
          <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-3" />
          <p className="text-muted-foreground">No alerts triggered</p>
        </Card>
      ) : (
        <div className="space-y-3">
          {alerts.map((alert) => {
            const StatusIcon = statusIcons[alert.status as keyof typeof statusIcons];
            return (
              <Card key={alert.id} className={`p-4 border-l-4 ${severityColors[alert.severity as keyof typeof severityColors]}`}>
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <StatusIcon className="w-5 h-5" />
                    <div>
                      <h4 className="font-semibold">{alert.alert_message}</h4>
                      <p className="text-sm text-muted-foreground">
                        {alert.notification_channels?.name} ({alert.notification_channels?.type})
                      </p>
                    </div>
                  </div>
                  <Badge className={statusColors[alert.status as keyof typeof statusColors]}>
                    {alert.status}
                  </Badge>
                </div>

                <div className="flex items-center gap-4 text-sm text-muted-foreground mb-3">
                  <span>Severity: {alert.severity}</span>
                  {alert.escalation_level > 0 && <span>Escalation Level: {alert.escalation_level}</span>}
                  <span>{new Date(alert.created_at).toLocaleString()}</span>
                </div>

                {alert.status === 'active' && (
                  <div className="flex gap-2">
                    <Button 
                      size="sm" 
                      variant="outline" 
                      onClick={() => {
                        setSelectedAlert(alert);
                        setWorkflowDialogOpen(true);
                      }}
                    >
                      <MessageSquare className="h-4 w-4 mr-1" />
                      Acknowledge with Workflow
                    </Button>
                    <Button size="sm" onClick={() => handleResolve(alert.id)}>
                      Quick Resolve
                    </Button>
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      )}

      <Dialog open={workflowDialogOpen} onOpenChange={setWorkflowDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Alert Acknowledgment Workflow</DialogTitle>
          </DialogHeader>
          {selectedAlert && <AcknowledgmentWorkflowPanel alert={selectedAlert} />}
        </DialogContent>
      </Dialog>

      {selectedWorkflow && (
        <ApprovalChainDialog
          open={approvalDialogOpen}
          onOpenChange={setApprovalDialogOpen}
          workflow={selectedWorkflow}
        />
      )}
    </div>
  );
}

