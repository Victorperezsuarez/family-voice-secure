import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { AlertTriangle, Zap, Shield } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';

export function StormDetectionPanel() {
  const [storms, setStorms] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadStorms();
    const interval = setInterval(loadStorms, 10000);
    return () => clearInterval(interval);
  }, []);

  const loadStorms = async () => {
    const { data } = await supabase
      .from('alert_storms')
      .select('*, alert_rules(name)')
      .eq('status', 'active')
      .order('created_at', { ascending: false });
    
    setStorms(data || []);
  };

  const suppressStorm = async (stormId: string) => {
    setLoading(true);
    await supabase
      .from('alert_storms')
      .update({ status: 'suppressed', throttling_applied: true })
      .eq('id', stormId);
    
    await loadStorms();
    setLoading(false);
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'destructive';
      case 'high': return 'destructive';
      case 'medium': return 'default';
      case 'low': return 'secondary';
      default: return 'secondary';
    }
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5" />
            Active Alert Storms
          </CardTitle>
        </CardHeader>
        <CardContent>
          {storms.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Shield className="h-12 w-12 mx-auto mb-2 opacity-50" />
              <p>No active alert storms detected</p>
            </div>
          ) : (
            <div className="space-y-4">
              {storms.map((storm) => (
                <Card key={storm.id}>
                  <CardContent className="pt-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h4 className="font-semibold">{storm.alert_rules?.name || 'Unknown Rule'}</h4>
                          <Badge variant={getSeverityColor(storm.storm_severity)}>
                            {storm.storm_severity?.toUpperCase()}
                          </Badge>
                        </div>
                        
                        <div className="grid grid-cols-3 gap-4 text-sm">
                          <div>
                            <p className="text-muted-foreground">Alert Count</p>
                            <p className="font-semibold">{storm.alert_count}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Rate</p>
                            <p className="font-semibold">{storm.alerts_per_minute?.toFixed(1)} /min</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Duration</p>
                            <p className="font-semibold">
                              {Math.round((Date.now() - new Date(storm.start_time).getTime()) / 60000)} min
                            </p>
                          </div>
                        </div>

                        {storm.throttling_applied && (
                          <Badge variant="outline" className="mt-2">
                            <Zap className="h-3 w-3 mr-1" />
                            Throttling Active
                          </Badge>
                        )}
                      </div>

                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => suppressStorm(storm.id)}
                        disabled={loading}
                      >
                        Suppress Storm
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}