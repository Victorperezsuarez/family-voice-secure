import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, XCircle, Clock, AlertTriangle } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';

export function AcknowledgmentWorkflowPanel({ alert }: { alert: any }) {
  const [comment, setComment] = useState('');
  const [loading, setLoading] = useState(false);

  const handleAcknowledge = async () => {
    if (!comment.trim()) {
      toast.error('Comment is required for acknowledgment');
      return;
    }

    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      const { error } = await supabase.functions.invoke('intelligent-alert-acknowledgment', {
        body: { alertId: alert.id, action: 'acknowledge', userId: user?.id, comment }
      });

      if (error) throw error;
      toast.success('Alert acknowledged successfully');
      setComment('');
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Clock className="h-5 w-5" />
          Acknowledgment Workflow
        </CardTitle>
        <CardDescription>Acknowledge and manage alert resolution</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium">Status</span>
          <Badge variant={alert.status === 'triggered' ? 'destructive' : 'secondary'}>
            {alert.status}
          </Badge>
        </div>

        {alert.severity === 'critical' && (
          <div className="flex items-center gap-2 p-3 bg-amber-50 border border-amber-200 rounded-lg">
            <AlertTriangle className="h-4 w-4 text-amber-600" />
            <span className="text-sm text-amber-800">Requires approval for acknowledgment</span>
          </div>
        )}

        <div className="space-y-2">
          <label className="text-sm font-medium">Acknowledgment Comment *</label>
          <Textarea
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder="Describe the action taken or investigation status..."
            rows={4}
          />
        </div>

        <Button onClick={handleAcknowledge} disabled={loading} className="w-full">
          <CheckCircle className="h-4 w-4 mr-2" />
          Acknowledge Alert
        </Button>
      </CardContent>
    </Card>
  );
}
