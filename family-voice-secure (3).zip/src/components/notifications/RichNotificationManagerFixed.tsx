import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase-client';
import { Plus, BarChart3, Bell, Eye, Send } from 'lucide-react';
import { NotificationTemplateBuilder } from './NotificationTemplateBuilder';
import { RichNotificationPreview } from './RichNotificationPreview';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { NotificationAnalyticsDashboard } from '../analytics/NotificationAnalyticsDashboard';
import { useToast } from '@/hooks/use-toast';

export function RichNotificationManager() {
  const [templates, setTemplates] = useState<any[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<any>(null);
  const [showBuilder, setShowBuilder] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [showAnalytics, setShowAnalytics] = useState(false);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadTemplates();
  }, []);

  const loadTemplates = async () => {
    try {
      const { data, error } = await supabase
        .from('notification_templates')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setTemplates(data || []);
    } catch (error: any) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const handleTestNotification = async (template: any) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { error } = await supabase.functions.invoke('send-rich-notification', {
        body: {
          userId: user.id,
          templateId: template.id,
          variables: {
            name: user.email?.split('@')[0] || 'User',
            date: new Date().toLocaleDateString(),
            count: '3'
          },
          progress: 50,
          progressMax: 100,
          progressLabel: 'Test Progress'
        }
      });

      if (error) throw error;
      toast({ title: 'Success', description: 'Test notification sent!' });
    } catch (error: any) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    }
  };

  const urgencyColors: Record<string, string> = {
    low: 'bg-blue-500',
    medium: 'bg-yellow-500',
    high: 'bg-orange-500',
    critical: 'bg-red-500'
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Rich Notification Templates</h2>
          <p className="text-muted-foreground">Manage notification layouts with images, progress bars, and actions</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setShowAnalytics(!showAnalytics)}>
            <BarChart3 className="h-4 w-4 mr-2" />
            Analytics
          </Button>
          <Button onClick={() => { setSelectedTemplate(null); setShowBuilder(true); }}>
            <Plus className="h-4 w-4 mr-2" />
            New Template
          </Button>
        </div>
      </div>

      {showAnalytics && (
        <Card>
          <CardHeader>
            <CardTitle>Notification Analytics</CardTitle>
          </CardHeader>
          <CardContent>
            <NotificationAnalyticsDashboard />
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="templates">
        <TabsList>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="builder">Template Builder</TabsTrigger>
        </TabsList>

        <TabsContent value="templates" className="space-y-4">
          {loading ? (
            <p>Loading templates...</p>
          ) : templates.length === 0 ? (
            <Card>
              <CardContent className="py-8 text-center">
                <Bell className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <p className="text-muted-foreground">No templates yet. Create your first one!</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4 md:grid-cols-2">
              {templates.map((template) => (
                <Card key={template.id}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle>{template.name}</CardTitle>
                        <CardDescription>{template.description}</CardDescription>
                      </div>
                      {template.is_default && (
                        <Badge variant="secondary">Default</Badge>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex gap-2">
                      <Badge variant="outline">{template.suggestion_type}</Badge>
                      <Badge className={urgencyColors[template.urgency_level]}>
                        {template.urgency_level}
                      </Badge>
                    </div>
                    
                    <div className="text-sm space-y-1">
                      <p><strong>Title:</strong> {template.title_template}</p>
                      <p><strong>Body:</strong> {template.body_template.substring(0, 60)}...</p>
                    </div>

                    {template.actions?.length > 0 && (
                      <div className="flex gap-2 flex-wrap">
                        {template.actions.map((action: any, idx: number) => (
                          <Badge key={idx} variant="outline">{action.title}</Badge>
                        ))}
                      </div>
                    )}

                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => { setSelectedTemplate(template); setShowPreview(true); }}
                      >
                        <Eye className="h-4 w-4 mr-2" />
                        Preview
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => { setSelectedTemplate(template); setShowBuilder(true); }}
                      >
                        Edit
                      </Button>
                      <Button 
                        size="sm"
                        onClick={() => handleTestNotification(template)}
                      >
                        <Send className="h-4 w-4 mr-2" />
                        Test
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="builder">
          <NotificationTemplateBuilder 
            template={selectedTemplate || undefined}
            onSave={() => {
              loadTemplates();
              setShowBuilder(false);
              toast({ title: 'Success', description: 'Template saved!' });
            }}
          />
        </TabsContent>
      </Tabs>

      <Dialog open={showPreview} onOpenChange={setShowPreview}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Notification Preview</DialogTitle>
          </DialogHeader>
          {selectedTemplate && (
            <RichNotificationPreview 
              options={{
                title: selectedTemplate.title_template,
                body: selectedTemplate.body_template,
                icon: selectedTemplate.icon_url,
                image: selectedTemplate.image_url,
                badge: selectedTemplate.badge_url,
                actions: selectedTemplate.actions,
                progress: selectedTemplate.show_progress ? 50 : undefined,
                progressMax: selectedTemplate.progress_max,
                progressLabel: 'Progress'
              }}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
