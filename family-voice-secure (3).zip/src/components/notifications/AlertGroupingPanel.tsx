import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Layers, TrendingUp, Clock } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';

export function AlertGroupingPanel() {
  const [patterns, setPatterns] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPatterns();
  }, []);

  const loadPatterns = async () => {
    try {
      const { data } = await supabase
        .from('alert_patterns')
        .select('*')
        .order('occurrence_count', { ascending: false })
        .limit(10);

      setPatterns(data || []);
    } catch (error) {
      console.error('Error loading patterns:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Layers className="h-5 w-5" />
          Alert Grouping & Patterns
        </CardTitle>
        <CardDescription>ML-based alert pattern detection and grouping</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {patterns.map((pattern) => (
            <div key={pattern.id} className="p-4 border rounded-lg space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-medium text-sm">{pattern.pattern_type}</span>
                <Badge variant="secondary">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  {pattern.occurrence_count} occurrences
                </Badge>
              </div>
              <p className="text-xs text-gray-600">{pattern.pattern_signature}</p>
              <div className="flex items-center gap-4 text-xs text-gray-500">
                <span className="flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  First: {new Date(pattern.first_seen).toLocaleString()}
                </span>
                <span>Last: {new Date(pattern.last_seen).toLocaleString()}</span>
              </div>
            </div>
          ))}

          {patterns.length === 0 && !loading && (
            <p className="text-center text-gray-500 py-8">No alert patterns detected yet</p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
