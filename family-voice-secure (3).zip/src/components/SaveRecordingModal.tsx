import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Loader2, Image as ImageIcon, Wand2, UserCheck } from 'lucide-react';
import { PhotoUploader } from './PhotoUploader';
import { AudioEditor } from './AudioEditor';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';


interface SaveRecordingModalProps {
  open: boolean;
  onClose: () => void;
  onSave: (title: string, tags: string[], photos?: string[]) => Promise<void>;
  duration: number;
  familyId: string;
  audioUrl?: string;
}



export function SaveRecordingModal({ open, onClose, onSave, duration, familyId, audioUrl }: SaveRecordingModalProps) {
  const [title, setTitle] = useState('');
  const [tags, setTags] = useState('');
  const [photos, setPhotos] = useState<string[]>([]);
  const [showPhotoUploader, setShowPhotoUploader] = useState(false);
  const [showAudioEditor, setShowAudioEditor] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [identifiedSpeakers, setIdentifiedSpeakers] = useState<any[]>([]);
  const [isIdentifying, setIsIdentifying] = useState(false);

  useEffect(() => {
    if (audioUrl && familyId) {
      identifySpeakers();
    }
  }, [audioUrl, familyId]);

  const identifySpeakers = async () => {
    if (!audioUrl) return;
    
    setIsIdentifying(true);
    try {
      const { data, error } = await supabase.functions.invoke('identify-speaker', {
        body: { audioUrl, familyId, recordingId: 'temp-' + Date.now() }
      });

      if (error) throw error;
      
      if (data?.identifications?.length > 0) {
        setIdentifiedSpeakers(data.identifications);
        
        // Fetch member names
        const memberIds = data.identifications.map((i: any) => i.family_member_id);
        const { data: members } = await supabase
          .from('family_members')
          .select('id, name')
          .in('id', memberIds);
        
        if (members) {
          const enriched = data.identifications.map((id: any) => ({
            ...id,
            memberName: members.find(m => m.id === id.family_member_id)?.name
          }));
          setIdentifiedSpeakers(enriched);
        }
      }
    } catch (error) {
      console.error('Speaker identification error:', error);
    } finally {
      setIsIdentifying(false);
    }
  };


  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handlePhotoUpload = (photoUrl: string) => {
    setPhotos(prev => [...prev, photoUrl]);
  };

  const handleAutoEnhance = async () => {
    if (!audioUrl) return;
    
    setIsEnhancing(true);
    try {
      const { data, error } = await supabase.functions.invoke('enhance-audio', {
        body: {
          audioUrl,
          enhancements: {
            noiseReduction: true,
            volumeNormalization: true,
            voiceEnhancement: true,
            restoration: false,
          },
        },
      });

      if (error) throw error;
      toast.success('Audio enhanced successfully');
    } catch (error: any) {
      toast.error('Enhancement failed: ' + error.message);
    } finally {
      setIsEnhancing(false);
    }
  };

  const handleAudioEditorSave = (editedAudioUrl: string) => {
    setShowAudioEditor(false);
    toast.success('Audio edits saved');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title) return;

    setIsSaving(true);
    try {
      const tagArray = tags.split(',').map(t => t.trim()).filter(Boolean);
      await onSave(title, tagArray, photos);
      setTitle('');
      setTags('');
      setPhotos([]);
      setShowPhotoUploader(false);
      setShowAudioEditor(false);
      onClose();
    } catch (error) {
      console.error('Error saving recording:', error);
    } finally {
      setIsSaving(false);
    }
  };



  if (showAudioEditor && audioUrl) {
    return (
      <Dialog open={open} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-4xl">
          <DialogHeader>
            <DialogTitle>Edit Audio Recording</DialogTitle>
          </DialogHeader>
          <AudioEditor
            audioUrl={audioUrl}
            onSave={handleAudioEditorSave}
            onCancel={() => setShowAudioEditor(false)}
          />
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto">

        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-amber-900">
            Guardar Grabación
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="bg-amber-50 p-3 rounded-lg">
            <p className="text-sm text-amber-800">
              Duración: <span className="font-semibold">{formatDuration(duration)}</span>
            </p>
          </div>

          <div>
            <Label htmlFor="title">Título de la Historia</Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Ej: Recuerdos de la infancia"
              required
            />
          </div>
          <div>
            <Label htmlFor="tags">Etiquetas (separadas por coma)</Label>
            <Input
              id="tags"
              value={tags}
              onChange={(e) => setTags(e.target.value)}
              placeholder="Ej: infancia, familia, tradiciones"
            />
          </div>


          {identifiedSpeakers.length > 0 && (
            <div className="bg-blue-50 dark:bg-blue-950 p-3 rounded-lg space-y-2">
              <div className="flex items-center gap-2 mb-2">
                <UserCheck className="h-4 w-4 text-blue-600" />
                <Label className="text-sm font-medium">Identified Speakers</Label>
              </div>
              <div className="flex flex-wrap gap-2">
                {identifiedSpeakers.map((speaker, idx) => (
                  <Badge key={idx} variant="secondary" className="text-xs">
                    {speaker.memberName} ({Math.round(speaker.confidence_score * 100)}%)
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {isIdentifying && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" />
              Identifying speakers...
            </div>
          )}

          <div>
            <div className="flex items-center justify-between mb-2">
              <Label>Fotos ({photos.length})</Label>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setShowPhotoUploader(!showPhotoUploader)}
              >
                <ImageIcon className="h-4 w-4 mr-2" />
                {showPhotoUploader ? 'Ocultar' : 'Agregar Fotos'}
              </Button>
            </div>
            {showPhotoUploader && (
              <PhotoUploader
                familyId={familyId}
                onUploadComplete={handlePhotoUpload}
                maxFiles={5}
              />
            )}
          </div>

          {audioUrl && (
            <div className="flex gap-2">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleAutoEnhance}
                disabled={isEnhancing}
                className="flex-1"
              >
                {isEnhancing ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Enhancing...
                  </>
                ) : (
                  <>
                    <Wand2 className="h-4 w-4 mr-2" />
                    Auto Enhance
                  </>
                )}
              </Button>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setShowAudioEditor(true)}
                className="flex-1"
              >
                Edit Audio
              </Button>
            </div>
          )}


          <div className="flex gap-3 pt-4">
            <Button 
              type="button" 
              variant="outline" 
              onClick={onClose} 
              className="flex-1"
              disabled={isSaving}
            >
              Cancelar
            </Button>
            <Button 
              type="submit" 
              className="flex-1 bg-gradient-to-r from-amber-500 to-orange-500"
              disabled={isSaving}
            >
              {isSaving ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Guardando...
                </>
              ) : (
                'Guardar'
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
