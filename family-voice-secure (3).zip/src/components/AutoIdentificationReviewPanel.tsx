import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Check, X, User, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';

interface SpeakerSegment {
  id: string;
  speaker_label: string;
  start_time: number;
  end_time: number;
  identified_member_id?: string;
  identified_member_name?: string;
  identification_confidence?: number;
  identification_status: string;
  text_content: string;
}

interface Props {
  segments: SpeakerSegment[];
  onReviewComplete: () => void;
}

export function AutoIdentificationReviewPanel({ segments, onReviewComplete }: Props) {
  const [reviewing, setReviewing] = useState<Set<string>>(new Set());
  
  const pendingSegments = segments.filter(s => 
    s.identification_status === 'pending' && s.identified_member_id
  );

  const handleConfirm = async (segmentId: string) => {
    setReviewing(prev => new Set(prev).add(segmentId));
    
    try {
      const { error } = await supabase
        .from('speaker_segments')
        .update({ identification_status: 'confirmed' })
        .eq('id', segmentId);

      if (error) throw error;
      
      toast.success('Speaker identification confirmed');
      onReviewComplete();
    } catch (error) {
      console.error('Error confirming:', error);
      toast.error('Failed to confirm identification');
    } finally {
      setReviewing(prev => {
        const next = new Set(prev);
        next.delete(segmentId);
        return next;
      });
    }
  };

  const handleReject = async (segmentId: string) => {
    setReviewing(prev => new Set(prev).add(segmentId));
    
    try {
      const { error } = await supabase
        .from('speaker_segments')
        .update({ 
          identification_status: 'rejected',
          identified_member_id: null,
          identification_confidence: null
        })
        .eq('id', segmentId);

      if (error) throw error;
      
      toast.success('Identification rejected');
      onReviewComplete();
    } catch (error) {
      console.error('Error rejecting:', error);
      toast.error('Failed to reject identification');
    } finally {
      setReviewing(prev => {
        const next = new Set(prev);
        next.delete(segmentId);
        return next;
      });
    }
  };

  if (pendingSegments.length === 0) {
    return null;
  }

  return (
    <Card className="p-4 bg-blue-50 border-blue-200">
      <div className="flex items-start gap-3 mb-4">
        <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
        <div>
          <h3 className="font-semibold text-blue-900">Review Automatic Identifications</h3>
          <p className="text-sm text-blue-700">
            {pendingSegments.length} speaker{pendingSegments.length !== 1 ? 's' : ''} automatically identified
          </p>
        </div>
      </div>

      <div className="space-y-3">
        {pendingSegments.map(segment => (
          <Card key={segment.id} className="p-3 bg-white">
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <User className="w-4 h-4 text-gray-400" />
                  <span className="font-medium">{segment.identified_member_name}</span>
                  <Badge variant="secondary" className="text-xs">
                    {segment.identification_confidence}% confident
                  </Badge>
                </div>
                <p className="text-sm text-gray-600 truncate">{segment.text_content}</p>
                <p className="text-xs text-gray-400 mt-1">
                  {Math.floor(segment.start_time)}s - {Math.floor(segment.end_time)}s
                </p>
              </div>
              
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleConfirm(segment.id)}
                  disabled={reviewing.has(segment.id)}
                  className="text-green-600 hover:text-green-700 hover:bg-green-50"
                >
                  <Check className="w-4 h-4" />
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleReject(segment.id)}
                  disabled={reviewing.has(segment.id)}
                  className="text-red-600 hover:text-red-700 hover:bg-red-50"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </Card>
  );
}
