import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { VoiceSampleCard } from './VoiceSampleCard';
import { VoiceEnrollmentWizard } from './VoiceEnrollmentWizard';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';
import { Mic, TrendingUp, AlertCircle, CheckCircle2 } from 'lucide-react';

interface VoiceProfileManagerProps {
  familyMemberId: string;
}

export function VoiceProfileManager({ familyMemberId }: VoiceProfileManagerProps) {
  const [voiceProfile, setVoiceProfile] = useState<any>(null);
  const [voiceSamples, setVoiceSamples] = useState<any[]>([]);
  const [showEnrollment, setShowEnrollment] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadVoiceProfile();
    loadVoiceSamples();
  }, [familyMemberId]);

  const loadVoiceProfile = async () => {
    const { data, error } = await supabase
      .from('voice_profiles')
      .select('*')
      .eq('family_member_id', familyMemberId)
      .single();

    if (data) setVoiceProfile(data);
    setLoading(false);
  };

  const loadVoiceSamples = async () => {
    const { data } = await supabase
      .from('voice_samples')
      .select('*')
      .eq('family_member_id', familyMemberId)
      .order('created_at', { ascending: false });

    if (data) setVoiceSamples(data);
  };

  const handleDeleteSample = async (sampleId: string) => {
    const { error } = await supabase
      .from('voice_samples')
      .delete()
      .eq('id', sampleId);

    if (error) {
      toast.error('Failed to delete sample');
    } else {
      toast.success('Sample deleted');
      loadVoiceSamples();
      loadVoiceProfile();
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, any> = {
      excellent: { variant: 'default', icon: CheckCircle2, color: 'text-green-600' },
      good: { variant: 'secondary', icon: TrendingUp, color: 'text-blue-600' },
      basic: { variant: 'outline', icon: AlertCircle, color: 'text-yellow-600' },
      incomplete: { variant: 'destructive', icon: AlertCircle, color: 'text-red-600' }
    };
    const config = variants[status] || variants.incomplete;
    const Icon = config.icon;
    return (
      <Badge variant={config.variant}>
        <Icon className="mr-1 h-3 w-3" />
        {status}
      </Badge>
    );
  };

  if (loading) return <div>Loading...</div>;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Voice Profile Overview</span>
            {getStatusBadge(voiceProfile?.enrollment_status || 'incomplete')}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-3xl font-bold">{voiceProfile?.total_samples || 0}</div>
              <div className="text-sm text-muted-foreground">Total Samples</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold">{voiceProfile?.average_quality_score?.toFixed(0) || 0}%</div>
              <div className="text-sm text-muted-foreground">Avg Quality</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold">{voiceProfile?.confidence_score?.toFixed(0) || 0}%</div>
              <div className="text-sm text-muted-foreground">ID Confidence</div>
            </div>
          </div>

          <div>
            <div className="flex justify-between text-sm mb-2">
              <span>Enrollment Progress</span>
              <span>{Math.min(100, (voiceProfile?.total_samples || 0) * 10)}%</span>
            </div>
            <Progress value={Math.min(100, (voiceProfile?.total_samples || 0) * 10)} />
          </div>

          <Button onClick={() => setShowEnrollment(true)} className="w-full">
            <Mic className="mr-2 h-4 w-4" />
            Add Voice Samples
          </Button>
        </CardContent>
      </Card>

      {voiceProfile?.recommended_improvements && voiceProfile.recommended_improvements.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Recommendations</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {voiceProfile.recommended_improvements.map((rec: string, idx: number) => (
                <li key={idx} className="flex items-start gap-2">
                  <AlertCircle className="h-4 w-4 mt-0.5 text-blue-600" />
                  <span className="text-sm">{rec}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="samples">
        <TabsList className="w-full">
          <TabsTrigger value="samples" className="flex-1">Voice Samples ({voiceSamples.length})</TabsTrigger>
          <TabsTrigger value="metrics" className="flex-1">Detailed Metrics</TabsTrigger>
        </TabsList>

        <TabsContent value="samples" className="space-y-4">
          {voiceSamples.length === 0 ? (
            <Card className="p-8 text-center">
              <p className="text-muted-foreground">No voice samples yet. Start recording to improve accuracy!</p>
            </Card>
          ) : (
            <div className="grid gap-4 md:grid-cols-2">
              {voiceSamples.map(sample => (
                <VoiceSampleCard key={sample.id} sample={sample} onDelete={handleDeleteSample} />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="metrics">
          <Card>
            <CardContent className="pt-6 space-y-4">
              <div className="space-y-2">
                <h4 className="font-semibold">Emotion Coverage</h4>
                {['neutral', 'happy', 'sad', 'excited', 'calm'].map(emotion => {
                  const count = voiceSamples.filter(s => s.emotion_type === emotion).length;
                  return (
                    <div key={emotion} className="flex items-center justify-between">
                      <span className="capitalize">{emotion}</span>
                      <Badge variant={count > 0 ? 'default' : 'outline'}>{count} samples</Badge>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {voiceProfile && (
        <VoiceEnrollmentWizard
          open={showEnrollment}
          onClose={() => setShowEnrollment(false)}
          familyMemberId={familyMemberId}
          voiceProfileId={voiceProfile.id}
          onComplete={() => {
            loadVoiceProfile();
            loadVoiceSamples();
          }}
        />
      )}
    </div>
  );
}