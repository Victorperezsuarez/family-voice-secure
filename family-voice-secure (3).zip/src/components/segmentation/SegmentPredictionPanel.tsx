import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Brain, TrendingUp, Users, AlertCircle } from 'lucide-react';
import { SegmentPrediction, SegmentDefinition } from '@/types/segmentPrediction';

interface SegmentPredictionPanelProps {
  prediction: SegmentPrediction;
}

const segmentDefinitions: Record<string, SegmentDefinition> = {
  power_user: {
    id: 'power_user',
    name: 'Power User',
    description: 'Highly engaged with excellent retention',
    color: 'bg-purple-500',
    icon: '⚡',
    characteristics: ['Daily active', 'Creates content', 'High feature adoption']
  },
  high_engagement: {
    id: 'high_engagement',
    name: 'High Engagement',
    description: 'Very active and engaged user',
    color: 'bg-green-500',
    icon: '🔥',
    characteristics: ['Regular usage', 'Good retention', 'Active contributor']
  },
  moderate_engagement: {
    id: 'moderate_engagement',
    name: 'Moderate Engagement',
    description: 'Casual user with steady activity',
    color: 'bg-blue-500',
    icon: '📊',
    characteristics: ['Weekly active', 'Occasional content', 'Stable usage']
  },
  low_engagement: {
    id: 'low_engagement',
    name: 'Low Engagement',
    description: 'Infrequent user needing activation',
    color: 'bg-yellow-500',
    icon: '⚠️',
    characteristics: ['Rare activity', 'Low retention', 'Needs nurturing']
  },
  new_user: {
    id: 'new_user',
    name: 'New User',
    description: 'Recently signed up, still onboarding',
    color: 'bg-cyan-500',
    icon: '🌟',
    characteristics: ['< 7 days old', 'Exploring features', 'High potential']
  },
  at_risk: {
    id: 'at_risk',
    name: 'At Risk',
    description: 'Declining activity, may churn',
    color: 'bg-red-500',
    icon: '🚨',
    characteristics: ['Inactive', 'Poor retention', 'Needs intervention']
  }
};

export function SegmentPredictionPanel({ prediction }: SegmentPredictionPanelProps) {
  const segment = segmentDefinitions[prediction.predictedSegment];
  const sortedProbs = Object.entries(prediction.segmentProbabilities)
    .sort(([, a], [, b]) => b - a);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            Predicted Segment
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className={`w-12 h-12 ${segment.color} rounded-lg flex items-center justify-center text-2xl`}>
                {segment.icon}
              </div>
              <div>
                <h3 className="font-semibold text-lg">{segment.name}</h3>
                <p className="text-sm text-muted-foreground">{segment.description}</p>
              </div>
            </div>
            <Badge variant="secondary" className="text-lg px-4 py-2">
              {Math.round(prediction.confidenceScore * 100)}% confident
            </Badge>
          </div>
          
          <div className="space-y-2">
            <h4 className="text-sm font-medium">Key Characteristics:</h4>
            <div className="flex flex-wrap gap-2">
              {segment.characteristics.map((char, idx) => (
                <Badge key={idx} variant="outline">{char}</Badge>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Segment Probability Distribution
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {sortedProbs.map(([seg, prob]) => {
            const segDef = segmentDefinitions[seg];
            return (
              <div key={seg} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xl">{segDef.icon}</span>
                    <span className="font-medium">{segDef.name}</span>
                  </div>
                  <span className="text-sm text-muted-foreground">
                    {Math.round(prob * 100)}%
                  </span>
                </div>
                <Progress value={prob * 100} className="h-2" />
              </div>
            );
          })}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Model Information
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex justify-between">
            <span className="text-sm text-muted-foreground">Model Version:</span>
            <span className="text-sm font-medium">{prediction.modelVersion}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-sm text-muted-foreground">Prediction Method:</span>
            <Badge variant="outline">{prediction.predictionMethod}</Badge>
          </div>
          <div className="flex justify-between">
            <span className="text-sm text-muted-foreground">Engagement Score:</span>
            <span className="text-sm font-medium">
              {Math.round(prediction.featuresUsed.engagementScore || 0)}/100
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-sm text-muted-foreground">Retention Score:</span>
            <span className="text-sm font-medium">
              {Math.round(prediction.featuresUsed.retentionScore || 0)}/100
            </span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
