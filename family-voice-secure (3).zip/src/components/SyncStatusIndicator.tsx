import { useState, useEffect } from 'react';
import { syncQueue } from '@/utils/syncQueue';
import { SyncQueueItem, SyncStats } from '@/types/sync';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { Cloud, CloudOff, RefreshCw, AlertCircle, CheckCircle2, Clock } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';

export function SyncStatusIndicator() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [queue, setQueue] = useState<SyncQueueItem[]>([]);
  const [stats, setStats] = useState<SyncStats>({ pending: 0, syncing: 0, failed: 0 });

  useEffect(() => {
    const updateQueue = () => {
      const items = syncQueue.getQueue();
      setQueue(items);
      
      setStats({
        pending: items.filter(i => i.status === 'pending').length,
        syncing: items.filter(i => i.status === 'syncing').length,
        failed: items.filter(i => i.status === 'error' || i.status === 'conflict').length,
        lastSyncTime: items.length > 0 ? Math.max(...items.map(i => i.timestamp)) : undefined
      });
    };

    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    const unsubscribe = syncQueue.subscribe(updateQueue);
    updateQueue();

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      unsubscribe();
    };
  }, []);

  const getStatusIcon = () => {
    if (!isOnline) return <CloudOff className="h-4 w-4 text-muted-foreground" />;
    if (stats.syncing > 0) return <RefreshCw className="h-4 w-4 animate-spin text-blue-500" />;
    if (stats.failed > 0) return <AlertCircle className="h-4 w-4 text-destructive" />;
    if (stats.pending > 0) return <Clock className="h-4 w-4 text-yellow-500" />;
    return <CheckCircle2 className="h-4 w-4 text-green-500" />;
  };

  const totalItems = stats.pending + stats.syncing + stats.failed;
  const progress = totalItems > 0 ? ((stats.syncing / totalItems) * 100) : 0;

  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="ghost" size="sm" className="relative">
          {getStatusIcon()}
          {totalItems > 0 && (
            <Badge variant="destructive" className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center text-xs">
              {totalItems}
            </Badge>
          )}
        </Button>
      </SheetTrigger>
      <SheetContent>
        <SheetHeader>
          <SheetTitle>Sync Status</SheetTitle>
        </SheetHeader>
        
        <div className="mt-6 space-y-4">
          <Alert>
            <Cloud className="h-4 w-4" />
            <AlertDescription>
              {isOnline ? 'Connected' : 'Offline - Changes will sync when online'}
            </AlertDescription>
          </Alert>

          {stats.syncing > 0 && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Syncing...</span>
                <span>{stats.syncing} items</span>
              </div>
              <Progress value={progress} />
            </div>
          )}

          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-yellow-500">{stats.pending}</div>
              <div className="text-xs text-muted-foreground">Pending</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-blue-500">{stats.syncing}</div>
              <div className="text-xs text-muted-foreground">Syncing</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-destructive">{stats.failed}</div>
              <div className="text-xs text-muted-foreground">Failed</div>
            </div>
          </div>

          {queue.length > 0 && (
            <div className="space-y-2">
              <h4 className="font-semibold text-sm">Queue Items</h4>
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {queue.map(item => (
                  <div key={item.id} className="p-3 border rounded-lg">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">{item.type}</span>
                      <Badge variant={
                        item.status === 'success' ? 'default' :
                        item.status === 'error' ? 'destructive' :
                        item.status === 'conflict' ? 'destructive' : 'secondary'
                      }>
                        {item.status}
                      </Badge>
                    </div>
                    {item.error && (
                      <p className="text-xs text-destructive mt-1">{item.error}</p>
                    )}
                    {item.retryCount > 0 && (
                      <p className="text-xs text-muted-foreground mt-1">
                        Retry {item.retryCount}/{5}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {isOnline && totalItems > 0 && (
            <Button 
              onClick={() => syncQueue.processQueue()} 
              className="w-full"
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Retry Sync
            </Button>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}
