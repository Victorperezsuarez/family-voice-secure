import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Switch } from '@/components/ui/switch';
import { supabase } from '@/lib/supabase-client';
import { Loader2, CheckCircle, XCircle, ExternalLink } from 'lucide-react';
import { Separator } from '@/components/ui/separator';

interface StripeConfig {
  plan_name: string;
  monthly_price_id: string;
  annual_price_id: string;
}

interface TrialConfig {
  trial_days: number;
  reminder_days_before: number;
  auto_cancel_on_trial_end: boolean;
}

export function StripeConfigPanel() {
  const [configs, setConfigs] = useState<StripeConfig[]>([]);
  const [trialConfig, setTrialConfig] = useState<TrialConfig>({ trial_days: 14, reminder_days_before: 3, auto_cancel_on_trial_end: false });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [formData, setFormData] = useState({
    family_monthly: '',
    family_annual: '',
    premium_monthly: '',
    premium_annual: ''
  });

  useEffect(() => {
    loadConfig();
  }, []);

  const loadConfig = async () => {
    try {
      const [priceRes, trialRes] = await Promise.all([
        supabase.from('stripe_config').select('*').in('plan_name', ['family', 'premium']),
        supabase.from('trial_config').select('*').limit(1).single()
      ]);

      if (priceRes.error) throw priceRes.error;

      if (priceRes.data) {
        setConfigs(priceRes.data);
        const familyConfig = priceRes.data.find(c => c.plan_name === 'family');
        const premiumConfig = priceRes.data.find(c => c.plan_name === 'premium');

        setFormData({
          family_monthly: familyConfig?.monthly_price_id || '',
          family_annual: familyConfig?.annual_price_id || '',
          premium_monthly: premiumConfig?.monthly_price_id || '',
          premium_annual: premiumConfig?.annual_price_id || ''
        });
      }

      if (trialRes.data) {
        setTrialConfig(trialRes.data);
      }
    } catch (error) {
      console.error('Error loading config:', error);
      setMessage({ type: 'error', text: 'Failed to load configuration' });
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    setMessage(null);

    try {
      await Promise.all([
        supabase.from('stripe_config').upsert({
          plan_name: 'family',
          monthly_price_id: formData.family_monthly,
          annual_price_id: formData.family_annual,
          updated_at: new Date().toISOString()
        }),
        supabase.from('stripe_config').upsert({
          plan_name: 'premium',
          monthly_price_id: formData.premium_monthly,
          annual_price_id: formData.premium_annual,
          updated_at: new Date().toISOString()
        }),
        supabase.from('trial_config').update(trialConfig).eq('id', (await supabase.from('trial_config').select('id').limit(1).single()).data?.id || '')
      ]);

      setMessage({ type: 'success', text: 'Configuration saved successfully!' });
      loadConfig();
    } catch (error) {
      console.error('Error saving config:', error);
      setMessage({ type: 'error', text: 'Failed to save configuration' });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <Card><CardContent className="flex items-center justify-center py-8"><Loader2 className="h-6 w-6 animate-spin" /></CardContent></Card>;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Stripe & Trial Configuration</CardTitle>
        <CardDescription>Configure Stripe Price IDs and trial settings</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {message && (
          <Alert variant={message.type === 'error' ? 'destructive' : 'default'}>
            {message.type === 'success' ? <CheckCircle className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}
            <AlertDescription>{message.text}</AlertDescription>
          </Alert>
        )}

        <div className="space-y-4">
          <h3 className="font-semibold">Trial Settings</h3>
          <div className="grid gap-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="trial_days">Trial Duration (days)</Label>
              <Input id="trial_days" type="number" className="w-24" value={trialConfig.trial_days} onChange={(e) => setTrialConfig({ ...trialConfig, trial_days: parseInt(e.target.value) })} />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="reminder_days">Reminder Days Before End</Label>
              <Input id="reminder_days" type="number" className="w-24" value={trialConfig.reminder_days_before} onChange={(e) => setTrialConfig({ ...trialConfig, reminder_days_before: parseInt(e.target.value) })} />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="auto_cancel">Auto-cancel on trial end</Label>
              <Switch id="auto_cancel" checked={trialConfig.auto_cancel_on_trial_end} onCheckedChange={(checked) => setTrialConfig({ ...trialConfig, auto_cancel_on_trial_end: checked })} />
            </div>
          </div>
        </div>

        <Separator />

        <div className="space-y-4">
          <h3 className="font-semibold">Family Plan Price IDs</h3>
          <div className="grid gap-4">
            <div>
              <Label htmlFor="family_monthly">Monthly Price ID</Label>
              <Input id="family_monthly" placeholder="price_xxxxxxxxxxxxx" value={formData.family_monthly} onChange={(e) => setFormData({ ...formData, family_monthly: e.target.value })} />
            </div>
            <div>
              <Label htmlFor="family_annual">Annual Price ID</Label>
              <Input id="family_annual" placeholder="price_xxxxxxxxxxxxx" value={formData.family_annual} onChange={(e) => setFormData({ ...formData, family_annual: e.target.value })} />
            </div>
          </div>
        </div>

        <Separator />

        <div className="space-y-4">
          <h3 className="font-semibold">Premium Plan Price IDs</h3>
          <div className="grid gap-4">
            <div>
              <Label htmlFor="premium_monthly">Monthly Price ID</Label>
              <Input id="premium_monthly" placeholder="price_xxxxxxxxxxxxx" value={formData.premium_monthly} onChange={(e) => setFormData({ ...formData, premium_monthly: e.target.value })} />
            </div>
            <div>
              <Label htmlFor="premium_annual">Annual Price ID</Label>
              <Input id="premium_annual" placeholder="price_xxxxxxxxxxxxx" value={formData.premium_annual} onChange={(e) => setFormData({ ...formData, premium_annual: e.target.value })} />
            </div>
          </div>
        </div>

        <div className="flex gap-3">
          <Button onClick={handleSave} disabled={saving}>
            {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Save All Configuration
          </Button>
          <Button variant="outline" asChild>
            <a href="https://dashboard.stripe.com/test/products" target="_blank" rel="noopener noreferrer">
              Stripe Dashboard <ExternalLink className="ml-2 h-4 w-4" />
            </a>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

