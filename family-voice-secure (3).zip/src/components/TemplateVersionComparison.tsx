import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase-client';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { ArrowRight, Plus, Minus, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';
import { MigrationAssistant } from './MigrationAssistant';


interface Props {
  templateId: string;
  version1: number;
  version2: number;
  open: boolean;
  onClose: () => void;
}

interface Diff {
  added: string[];
  removed: string[];
  changed: string[];
}

export function TemplateVersionComparison({ templateId, version1, version2, open, onClose }: Props) {
  const [oldVersion, setOldVersion] = useState<any>(null);
  const [newVersion, setNewVersion] = useState<any>(null);
  const [diff, setDiff] = useState<Diff>({ added: [], removed: [], changed: [] });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (open) {
      loadComparison();
    }
  }, [open, templateId, version1, version2]);

  const loadComparison = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('compare-versions', {
        body: { templateId, version1, version2 }
      });

      if (error) throw error;
      setOldVersion(data.oldVersion);
      setNewVersion(data.newVersion);
      setDiff(data.diff);
    } catch (error) {
      toast.error('Failed to compare versions');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            Version Comparison
            <Badge variant="outline">v{version1}</Badge>
            <ArrowRight className="w-4 h-4" />
            <Badge variant="outline">v{version2}</Badge>
          </DialogTitle>
        </DialogHeader>

        {loading ? (
          <div>Loading comparison...</div>
        ) : (
          <ScrollArea className="h-[500px]">
            <div className="space-y-6">
              {/* Changelog Comparison */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold mb-2">v{version1}</h4>
                  <p className="text-sm text-muted-foreground">{oldVersion?.changelog}</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">v{version2}</h4>
                  <p className="text-sm text-muted-foreground">{newVersion?.changelog}</p>
                </div>
              </div>

              {/* Permission Changes */}
              <div>
                <h4 className="font-semibold mb-3">Permission Changes</h4>
                
                {diff.added.length > 0 && (
                  <div className="mb-3">
                    <div className="flex items-center gap-2 mb-2">
                      <Plus className="w-4 h-4 text-green-600" />
                      <span className="text-sm font-medium text-green-600">Added Permissions</span>
                    </div>
                    <div className="space-y-1 ml-6">
                      {diff.added.map(perm => (
                        <div key={perm} className="text-sm bg-green-50 p-2 rounded">
                          {perm}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {diff.removed.length > 0 && (
                  <div className="mb-3">
                    <div className="flex items-center gap-2 mb-2">
                      <Minus className="w-4 h-4 text-red-600" />
                      <span className="text-sm font-medium text-red-600">Removed Permissions</span>
                    </div>
                    <div className="space-y-1 ml-6">
                      {diff.removed.map(perm => (
                        <div key={perm} className="text-sm bg-red-50 p-2 rounded">
                          {perm}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {diff.changed.length > 0 && (
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <RefreshCw className="w-4 h-4 text-blue-600" />
                      <span className="text-sm font-medium text-blue-600">Modified Permissions</span>
                    </div>
                    <div className="space-y-1 ml-6">
                      {diff.changed.map(perm => (
                        <div key={perm} className="text-sm bg-blue-50 p-2 rounded">
                          {perm}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {diff.added.length === 0 && diff.removed.length === 0 && diff.changed.length === 0 && (
                  <p className="text-sm text-muted-foreground">No permission changes</p>
                )}
              </div>

              {/* Breaking Changes Warning */}
              {newVersion?.breaking_changes && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <h4 className="font-semibold text-red-900 mb-2">Breaking Changes</h4>
                  <p className="text-sm text-red-800 mb-2">{newVersion.migration_notes}</p>
                </div>
              )}

              {/* AI Migration Assistant */}
              {(diff.added.length > 0 || diff.removed.length > 0 || diff.changed.length > 0 || newVersion?.breaking_changes) && (
                <>
                  <Separator />
                  <MigrationAssistant
                    fromVersion={version1.toString()}
                    toVersion={version2.toString()}
                    templateName={newVersion?.template_name || 'Template'}
                    permissionChanges={diff}
                  />
                </>
              )}
            </div>

          </ScrollArea>
        )}
      </DialogContent>
    </Dialog>
  );
}