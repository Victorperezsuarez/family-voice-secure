import { useState, useEffect } from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Wifi, WifiOff, Upload, AlertCircle, CheckCircle } from 'lucide-react';
import { useOfflineSync } from '@/contexts/OfflineSyncContext';
import { Progress } from '@/components/ui/progress';

export function EnhancedOfflineIndicator() {
  const { isOnline, isSyncing, syncStats, queueItems, retrySync } = useOfflineSync();
  const [showDetails, setShowDetails] = useState(false);

  const totalItems = queueItems.length;
  const syncProgress = totalItems > 0 ? ((totalItems - syncStats.pending) / totalItems) * 100 : 100;

  return (
    <Popover open={showDetails} onOpenChange={setShowDetails}>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
          className="fixed top-4 right-4 z-50 shadow-lg"
        >
          <Badge
            variant={isOnline ? 'default' : 'secondary'}
            className="flex items-center gap-2"
          >
            {isOnline ? (
              <Wifi className="w-4 h-4" />
            ) : (
              <WifiOff className="w-4 h-4" />
            )}
            {isOnline ? 'Online' : 'Offline'}
            {totalItems > 0 && (
              <span className="ml-1 bg-white text-black rounded-full px-2 py-0.5 text-xs">
                {totalItems}
              </span>
            )}
          </Badge>
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80">
        <div className="space-y-4">
          <div>
            <h4 className="font-semibold mb-2">Connection Status</h4>
            <div className="flex items-center gap-2">
              {isOnline ? (
                <CheckCircle className="w-5 h-5 text-green-500" />
              ) : (
                <AlertCircle className="w-5 h-5 text-orange-500" />
              )}
              <span className="text-sm">
                {isOnline ? 'Connected to internet' : 'Working offline'}
              </span>
            </div>
          </div>

          {totalItems > 0 && (
            <div>
              <h4 className="font-semibold mb-2">Sync Status</h4>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Pending: {syncStats.pending}</span>
                  <span>Failed: {syncStats.failed}</span>
                </div>
                <Progress value={syncProgress} />
                {isSyncing && (
                  <p className="text-xs text-blue-600">Syncing in progress...</p>
                )}
              </div>
            </div>
          )}

          {isOnline && totalItems > 0 && (
            <Button onClick={retrySync} size="sm" className="w-full">
              <Upload className="w-4 h-4 mr-2" />
              Sync Now
            </Button>
          )}

          {!isOnline && (
            <p className="text-xs text-gray-600">
              Your data is saved locally and will sync automatically when you're back online.
            </p>
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}
