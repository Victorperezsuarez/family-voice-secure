import { RecordingWithMember, Milestone } from '@/types/family';
import { AudioPlayer } from './AudioPlayer';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Calendar, User, Flag } from 'lucide-react';

interface TimelineItemProps {
  item: RecordingWithMember | Milestone;
  type: 'recording' | 'milestone';
}

export function TimelineItem({ item, type }: TimelineItemProps) {
  const date = new Date(type === 'recording' ? item.created_at : (item as Milestone).date);
  const formattedDate = date.toLocaleDateString('en-US', { 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });

  return (
    <div className="flex gap-4 mb-8">
      <div className="flex flex-col items-center">
        <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
          type === 'milestone' ? 'bg-purple-500' : 'bg-blue-500'
        }`}>
          {type === 'milestone' ? <Flag className="w-6 h-6 text-white" /> : <User className="w-6 h-6 text-white" />}
        </div>
        <div className="w-0.5 h-full bg-gray-300 mt-2"></div>
      </div>
      <Card className="flex-1 p-4">
        <div className="flex items-start justify-between mb-2">
          <div>
            <h3 className="font-semibold text-lg">{type === 'recording' ? item.title : (item as Milestone).title}</h3>
            <div className="flex items-center gap-2 text-sm text-gray-600 mt-1">
              <Calendar className="w-4 h-4" />
              <span>{formattedDate}</span>
            </div>
          </div>
          <Badge variant={type === 'milestone' ? 'default' : 'secondary'}>
            {type === 'milestone' ? (item as Milestone).event_type : 'recording'}
          </Badge>
        </div>
        {type === 'recording' && (
          <>
            <p className="text-sm text-gray-600 mb-2">
              Family Member: {(item as RecordingWithMember).family_member.name}
            </p>
            {(item as RecordingWithMember).summary && (
              <p className="text-sm mb-3">{(item as RecordingWithMember).summary}</p>
            )}
            <AudioPlayer audioUrl={(item as RecordingWithMember).audio_url} />
          </>
        )}
        {type === 'milestone' && (item as Milestone).description && (
          <p className="text-sm text-gray-700">{(item as Milestone).description}</p>
        )}
      </Card>
    </div>
  );
}
