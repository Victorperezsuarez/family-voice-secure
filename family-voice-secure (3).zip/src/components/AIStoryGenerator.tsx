import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2, Sparkles, Download, Copy } from 'lucide-react';
import { supabase } from '@/lib/supabase-client';
import { toast } from 'sonner';

interface Recording {
  id: string;
  title: string;
  transcription: string;
}

interface AIStoryGeneratorProps {
  recordings: Recording[];
  familyName?: string;
}

export function AIStoryGenerator({ recordings, familyName }: AIStoryGeneratorProps) {
  const [theme, setTheme] = useState('');
  const [story, setStory] = useState('');
  const [loading, setLoading] = useState(false);

  const generateStory = async () => {
    if (recordings.length === 0) {
      toast.error('Please select at least one recording');
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('generate-story-from-recordings', {
        body: { recordings, theme, familyName }
      });

      if (error) throw error;
      setStory(data.story);
      toast.success(`Story generated! (${data.wordCount} words)`);
    } catch (error: any) {
      toast.error(error.message || 'Failed to generate story');
    } finally {
      setLoading(false);
    }
  };

  const copyStory = () => {
    navigator.clipboard.writeText(story);
    toast.success('Story copied to clipboard');
  };

  const downloadStory = () => {
    const blob = new Blob([story], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `family-story-${Date.now()}.txt`;
    a.click();
    toast.success('Story downloaded');
  };

  return (
    <div className="space-y-4">
      <Card className="p-6">
        <div className="space-y-4">
          <div>
            <Label>Story Theme (Optional)</Label>
            <Input
              placeholder="e.g., Childhood Adventures, Family Traditions..."
              value={theme}
              onChange={(e) => setTheme(e.target.value)}
            />
          </div>
          <Button onClick={generateStory} disabled={loading} className="w-full">
            {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Sparkles className="w-4 h-4 mr-2" />}
            Generate Story from {recordings.length} Recording{recordings.length !== 1 ? 's' : ''}
          </Button>
        </div>
      </Card>

      {story && (
        <Card className="p-6">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold">Generated Story</h3>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={copyStory}>
                  <Copy className="w-4 h-4 mr-2" />
                  Copy
                </Button>
                <Button variant="outline" size="sm" onClick={downloadStory}>
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </Button>
              </div>
            </div>
            <Textarea
              value={story}
              readOnly
              className="min-h-[400px] font-serif text-base leading-relaxed"
            />
          </div>
        </Card>
      )}
    </div>
  );
}