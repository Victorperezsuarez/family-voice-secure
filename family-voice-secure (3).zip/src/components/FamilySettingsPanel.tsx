import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase-client';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Settings, Users, Activity, Shield, AlertTriangle, KeyRound, UserCheck, ShieldCheck } from 'lucide-react';

import { EditFamilyDetailsSection } from './settings/EditFamilyDetailsSection';
import { ManageMembersSection } from './settings/ManageMembersSection';
import { ActivityLogsSection } from './settings/ActivityLogsSection';
import { FamilyWideSettingsSection } from './settings/FamilyWideSettingsSection';
import { DangerZoneSection } from './settings/DangerZoneSection';
import { CustomRolesManager } from './settings/CustomRolesManager';
import { VoiceProfilesManager } from './VoiceProfilesManager';
import { RoleManagementSection } from './settings/RoleManagementSection';
import { useRoleCheck } from '@/hooks/useRoleCheck';


interface FamilySettingsPanelProps {
  familyId: string;
  onClose: () => void;
}

export function FamilySettingsPanel({ familyId, onClose }: FamilySettingsPanelProps) {
  const { user } = useAuth();
  const { hasRole: isSystemAdmin } = useRoleCheck('admin');
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);


  useEffect(() => {
    checkAdminStatus();
  }, [familyId, user]);

  const checkAdminStatus = async () => {
    if (!user) return;
    
    const { data } = await supabase
      .from('family_users')
      .select('role')
      .eq('family_id', familyId)
      .eq('user_id', user.id)
      .single();

    setIsAdmin(data?.role === 'admin');
    setLoading(false);
  };

  if (loading) return <div className="p-8">Loading...</div>;

  if (!isAdmin) {
    return (
      <div className="p-8 text-center">
        <AlertTriangle className="w-16 h-16 mx-auto text-yellow-500 mb-4" />
        <h2 className="text-2xl font-bold mb-2">Admin Access Required</h2>
        <p className="text-gray-600 mb-4">Only family administrators can access settings.</p>
        <Button onClick={onClose}>Go Back</Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-6xl mx-auto">
        <Button variant="ghost" onClick={onClose} className="mb-4">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Family
        </Button>

        <h1 className="text-3xl font-bold mb-6">Family Settings</h1>

        <Tabs defaultValue="details" className="space-y-6">
          <TabsList className="grid w-full grid-cols-8">
            <TabsTrigger value="details"><Settings className="w-4 h-4 mr-2" />Details</TabsTrigger>
            <TabsTrigger value="members"><Users className="w-4 h-4 mr-2" />Members</TabsTrigger>
            <TabsTrigger value="roles"><KeyRound className="w-4 h-4 mr-2" />Roles</TabsTrigger>
            <TabsTrigger value="voice"><UserCheck className="w-4 h-4 mr-2" />Voice</TabsTrigger>
            <TabsTrigger value="settings"><Shield className="w-4 h-4 mr-2" />Settings</TabsTrigger>
            <TabsTrigger value="activity"><Activity className="w-4 h-4 mr-2" />Activity</TabsTrigger>
            {isSystemAdmin && <TabsTrigger value="admin"><ShieldCheck className="w-4 h-4 mr-2" />Admin</TabsTrigger>}
            <TabsTrigger value="danger"><AlertTriangle className="w-4 h-4 mr-2" />Danger</TabsTrigger>
          </TabsList>

          <TabsContent value="details">
            <EditFamilyDetailsSection familyId={familyId} />
          </TabsContent>

          <TabsContent value="members">
            <ManageMembersSection familyId={familyId} />
          </TabsContent>

          <TabsContent value="roles">
            <Card className="p-6">
              <h2 className="text-xl font-semibold mb-4">Custom Roles & Permissions</h2>
              <CustomRolesManager familyId={familyId} />
            </Card>
          </TabsContent>

          <TabsContent value="voice">
            <VoiceProfilesManager familyId={familyId} />
          </TabsContent>

          <TabsContent value="settings">
            <FamilyWideSettingsSection familyId={familyId} />
          </TabsContent>

          <TabsContent value="activity">
            <ActivityLogsSection familyId={familyId} />
          </TabsContent>

          {isSystemAdmin && (
            <TabsContent value="admin">
              <RoleManagementSection />
            </TabsContent>
          )}

          <TabsContent value="danger">
            <DangerZoneSection familyId={familyId} onDeleted={onClose} />
          </TabsContent>
        </Tabs>

      </div>
    </div>
  );
}
