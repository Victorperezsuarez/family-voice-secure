import { useEffect, useState } from 'react';
import { UsageMeterCard } from './UsageMeterCard';
import { supabase } from '@/lib/supabase-client';
import { useNavigate } from 'react-router-dom';
import { Database, HardDrive, Users, Image, FolderTree, Mic } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';

interface UsageData {
  recordings_count: number;
  storage_used_bytes: number;
  family_trees_count: number;
  family_members_count: number;
  photos_count: number;
  collections_count: number;
}

interface PlanLimits {
  max_recordings: number;
  max_storage_gb: number;
  max_family_trees: number;
  max_family_members: number;
  max_photos: number;
  max_collections: number;
}

export function UsageDashboard() {
  const [usage, setUsage] = useState<UsageData | null>(null);
  const [limits, setLimits] = useState<PlanLimits | null>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    loadUsageData();
  }, []);

  const loadUsageData = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Get subscription
      const { data: subs } = await supabase
        .from('subscriptions')
        .select('plan_name')
        .eq('user_id', user.id)
        .eq('status', 'active')
        .single();

      const planName = subs?.plan_name || 'free';

      // Get limits
      const { data: limitsData } = await supabase
        .from('plan_limits')
        .select('*')
        .eq('plan_name', planName)
        .single();

      setLimits(limitsData);

      // Calculate usage
      const { data: usageData } = await supabase.rpc('calculate_user_usage', {
        p_user_id: user.id
      });

      setUsage(usageData);
    } catch (error) {
      console.error('Error loading usage:', error);
      toast.error('Failed to load usage data');
    } finally {
      setLoading(false);
    }
  };

  const handleUpgrade = () => {
    navigate('/pricing');
  };

  if (loading) {
    return (
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {[...Array(6)].map((_, i) => (
          <Skeleton key={i} className="h-[200px]" />
        ))}
      </div>
    );
  }

  if (!usage || !limits) return null;

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      <UsageMeterCard
        title="Recordings"
        current={usage.recordings_count}
        max={limits.max_recordings}
        unit="recordings"
        icon={<Mic className="h-4 w-4 text-muted-foreground" />}
        onUpgrade={handleUpgrade}
      />
      <UsageMeterCard
        title="Storage"
        current={usage.storage_used_bytes}
        max={limits.max_storage_gb * 1024 * 1024 * 1024}
        unit="GB"
        icon={<HardDrive className="h-4 w-4 text-muted-foreground" />}
        onUpgrade={handleUpgrade}
      />
      <UsageMeterCard
        title="Family Trees"
        current={usage.family_trees_count}
        max={limits.max_family_trees}
        unit="trees"
        icon={<FolderTree className="h-4 w-4 text-muted-foreground" />}
        onUpgrade={handleUpgrade}
      />
      <UsageMeterCard
        title="Family Members"
        current={usage.family_members_count}
        max={limits.max_family_members}
        unit="members"
        icon={<Users className="h-4 w-4 text-muted-foreground" />}
        onUpgrade={handleUpgrade}
      />
      <UsageMeterCard
        title="Photos"
        current={usage.photos_count}
        max={limits.max_photos}
        unit="photos"
        icon={<Image className="h-4 w-4 text-muted-foreground" />}
        onUpgrade={handleUpgrade}
      />
      <UsageMeterCard
        title="Collections"
        current={usage.collections_count}
        max={limits.max_collections}
        unit="collections"
        icon={<Database className="h-4 w-4 text-muted-foreground" />}
        onUpgrade={handleUpgrade}
      />
    </div>
  );
}