import { AlertTriangle, CheckCircle, Lock, ShieldAlert } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface LicenseVerificationDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  verification: {
    valid: boolean;
    licenseType?: string;
    reason?: string;
    requiresPurchase?: boolean;
    requiresUpgrade?: boolean;
    currentLicense?: string;
  } | null;
  templateName: string;
  onPurchase?: () => void;
  onUpgrade?: () => void;
}

export function LicenseVerificationDialog({
  open,
  onOpenChange,
  verification,
  templateName,
  onPurchase,
  onUpgrade
}: LicenseVerificationDialogProps) {
  if (!verification) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {verification.valid ? (
              <CheckCircle className="h-5 w-5 text-green-600" />
            ) : (
              <ShieldAlert className="h-5 w-5 text-red-600" />
            )}
            License Verification
          </DialogTitle>
          <DialogDescription>
            {templateName}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {verification.valid ? (
            <Alert>
              <CheckCircle className="h-4 w-4" />
              <AlertDescription>
                Valid {verification.licenseType} license detected. You can use this template.
              </AlertDescription>
            </Alert>
          ) : (
            <>
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  {verification.reason}
                </AlertDescription>
              </Alert>

              {verification.requiresUpgrade && (
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">
                    You currently have a <strong>{verification.currentLicense}</strong> license.
                    Commercial use requires a commercial or enterprise license.
                  </p>
                </div>
              )}

              {verification.requiresPurchase && (
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">
                    This template requires a valid license. Purchase a license to use this template.
                  </p>
                </div>
              )}
            </>
          )}
        </div>

        <DialogFooter className="flex-col sm:flex-row gap-2">
          {!verification.valid && verification.requiresUpgrade && (
            <Button onClick={onUpgrade} className="w-full sm:w-auto">
              <Lock className="mr-2 h-4 w-4" />
              Upgrade License
            </Button>
          )}
          {!verification.valid && verification.requiresPurchase && (
            <Button onClick={onPurchase} className="w-full sm:w-auto">
              Purchase License
            </Button>
          )}
          <Button variant="outline" onClick={() => onOpenChange(false)} className="w-full sm:w-auto">
            {verification.valid ? 'Close' : 'Cancel'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}