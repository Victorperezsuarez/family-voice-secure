export interface TrainingPhrase {
  id: number;
  text: string;
  phonemesFocus: string;
  difficulty: 'easy' | 'medium' | 'hard';
}

export interface LanguageTrainingSet {
  code: string;
  name: string;
  nativeName: string;
  flag: string;
  phrases: TrainingPhrase[];
}

export const LANGUAGE_TRAINING_SETS: LanguageTrainingSet[] = [
  {
    code: 'en',
    name: 'English',
    nativeName: 'English',
    flag: '🇺🇸',
    phrases: [
      { id: 1, text: "The quick brown fox jumps over the lazy dog.", phonemesFocus: "Common consonants and vowels", difficulty: 'easy' },
      { id: 2, text: "She sells seashells by the seashore.", phonemesFocus: "S and SH sounds", difficulty: 'medium' },
      { id: 3, text: "Peter Piper picked a peck of pickled peppers.", phonemesFocus: "P sounds and rhythm", difficulty: 'medium' },
      { id: 4, text: "How much wood would a woodchuck chuck?", phonemesFocus: "W and CH sounds", difficulty: 'hard' },
      { id: 5, text: "I scream, you scream, we all scream for ice cream!", phonemesFocus: "Long vowels", difficulty: 'easy' },
      { id: 6, text: "The thirty-three thieves thought they thrilled the throne.", phonemesFocus: "TH sounds", difficulty: 'hard' },
      { id: 7, text: "Red lorry, yellow lorry.", phonemesFocus: "L and R sounds", difficulty: 'medium' },
      { id: 8, text: "Can you imagine an imaginary menagerie manager?", phonemesFocus: "M and N sounds", difficulty: 'hard' }
    ]
  },
  {
    code: 'es',
    name: 'Spanish',
    nativeName: 'Español',
    flag: '🇪🇸',
    phrases: [
      { id: 1, text: "El perro de San Roque no tiene rabo porque Ramón Ramírez se lo ha robado.", phonemesFocus: "R fuerte y suave", difficulty: 'hard' },
      { id: 2, text: "Tres tristes tigres tragaban trigo en un trigal.", phonemesFocus: "TR sounds", difficulty: 'hard' },
      { id: 3, text: "Pablito clavó un clavito en la calva de un calvito.", phonemesFocus: "CL sounds", difficulty: 'medium' },
      { id: 4, text: "Como poco coco como, poco coco compro.", phonemesFocus: "C sounds", difficulty: 'medium' },
      { id: 5, text: "La familia es el tesoro más grande de la vida.", phonemesFocus: "Vowels", difficulty: 'easy' },
      { id: 6, text: "Erre con erre cigarro, erre con erre barril.", phonemesFocus: "RR sounds", difficulty: 'hard' },
      { id: 7, text: "Me han dicho que has dicho un dicho que he dicho yo.", phonemesFocus: "D and CH", difficulty: 'medium' },
      { id: 8, text: "El cielo está enladrillado, quién lo desenladrillará?", phonemesFocus: "LL sounds", difficulty: 'easy' }
    ]
  },
  {
    code: 'fr',
    name: 'French',
    nativeName: 'Français',
    flag: '🇫🇷',
    phrases: [
      { id: 1, text: "Un chasseur sachant chasser doit savoir chasser sans son chien.", phonemesFocus: "CH and S sounds", difficulty: 'hard' },
      { id: 2, text: "Les chaussettes de l'archiduchesse sont-elles sèches?", phonemesFocus: "CH and S", difficulty: 'medium' },
      { id: 3, text: "Je veux et j'exige d'exquises excuses.", phonemesFocus: "J and X sounds", difficulty: 'medium' },
      { id: 4, text: "Panier, piano, panier, piano.", phonemesFocus: "P and nasal sounds", difficulty: 'easy' },
      { id: 5, text: "La famille est le cœur de notre histoire.", phonemesFocus: "Vowels and liaison", difficulty: 'easy' },
      { id: 6, text: "Si six scies scient six cyprès, six cent scies scient six cent cyprès.", phonemesFocus: "S sounds", difficulty: 'hard' },
      { id: 7, text: "Trois petites truites cuites, trois petites truites crues.", phonemesFocus: "TR sounds", difficulty: 'medium' },
      { id: 8, text: "Cinq chiens chassent six chats.", phonemesFocus: "Nasal vowels", difficulty: 'hard' }
    ]
  },
  {
    code: 'de',
    name: 'German',
    nativeName: 'Deutsch',
    flag: '🇩🇪',
    phrases: [
      { id: 1, text: "Fischers Fritz fischt frische Fische.", phonemesFocus: "F and SCH sounds", difficulty: 'medium' },
      { id: 2, text: "Blaukraut bleibt Blaukraut und Brautkleid bleibt Brautkleid.", phonemesFocus: "BL and BR sounds", difficulty: 'hard' },
      { id: 3, text: "Der Cottbuser Postkutscher putzt den Cottbuser Postkutschkasten.", phonemesFocus: "P and K sounds", difficulty: 'hard' },
      { id: 4, text: "Zwischen zwei Zwetschgenzweigen zwitschern zwei Schwalben.", phonemesFocus: "ZW and SCH", difficulty: 'hard' },
      { id: 5, text: "Die Familie ist das wichtigste im Leben.", phonemesFocus: "Vowels and CH", difficulty: 'easy' },
      { id: 6, text: "Schnecken erschrecken wenn sie an Schnecken schlecken.", phonemesFocus: "SCH sounds", difficulty: 'medium' },
      { id: 7, text: "Wir Wiener Waschweiber würden weiße Wäsche waschen.", phonemesFocus: "W sounds", difficulty: 'medium' },
      { id: 8, text: "In Ulm, um Ulm und um Ulm herum.", phonemesFocus: "U sound", difficulty: 'easy' }
    ]
  }
];

export const MIN_REQUIRED_SAMPLES = 5;
export const RECOMMENDED_SAMPLES = 8;
