import React, { createContext, useContext, useState, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { toast } from '@/components/ui/use-toast';

interface AppContextType {
  sidebarOpen: boolean;
  toggleSidebar: () => void;
  language: string;
  setLanguage: (language: string) => void;
}

const defaultAppContext: AppContextType = {
  sidebarOpen: false,
  toggleSidebar: () => {},
  language: 'es-MX',
  setLanguage: () => {},
};

const AppContext = createContext<AppContextType>(defaultAppContext);

export const useAppContext = () => useContext(AppContext);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [language, setLanguageState] = useState<string>(() => {
    return localStorage.getItem('selectedLanguage') || 'es-MX';
  });

  const toggleSidebar = () => {
    setSidebarOpen(prev => !prev);
  };

  const setLanguage = (newLanguage: string) => {
    setLanguageState(newLanguage);
    localStorage.setItem('selectedLanguage', newLanguage);
    toast({
      title: 'Language Updated',
      description: `Language changed to ${newLanguage}`,
    });
  };

  return (
    <AppContext.Provider
      value={{
        sidebarOpen,
        toggleSidebar,
        language,
        setLanguage,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

