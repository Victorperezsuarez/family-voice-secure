// Re-export VelaPersonaContext for backward compatibility
export { VelaPersonaProvider as VelaProvider, useVelaPersona as useVela } from './VelaPersonaContext';
export type { VelaPersona, VelaProactiveSuggestion } from '@/types/vela';
