import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { syncQueue } from '@/utils/syncQueue';
import { SyncQueueItem, SyncStats } from '@/types/sync';

interface OfflineSyncContextType {
  isOnline: boolean;
  isSyncing: boolean;
  syncStats: SyncStats;
  queueItems: SyncQueueItem[];
  addToQueue: (type: any, data: any) => string;
  retrySync: () => void;
  clearQueue: () => void;
}

const OfflineSyncContext = createContext<OfflineSyncContextType | undefined>(undefined);

export function OfflineSyncProvider({ children }: { children: ReactNode }) {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [isSyncing, setIsSyncing] = useState(false);
  const [queueItems, setQueueItems] = useState<SyncQueueItem[]>([]);
  const [syncStats, setSyncStats] = useState<SyncStats>({ pending: 0, syncing: 0, failed: 0 });

  useEffect(() => {
    const updateQueue = () => {
      const items = syncQueue.getQueue();
      setQueueItems(items);
      
      setSyncStats({
        pending: items.filter(i => i.status === 'pending').length,
        syncing: items.filter(i => i.status === 'syncing').length,
        failed: items.filter(i => i.status === 'error' || i.status === 'conflict').length,
        lastSyncTime: items.length > 0 ? Math.max(...items.map(i => i.timestamp)) : undefined
      });
      
      setIsSyncing(items.some(i => i.status === 'syncing'));
    };

    const handleOnline = () => {
      setIsOnline(true);
      syncQueue.processQueue();
    };
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    const unsubscribe = syncQueue.subscribe(updateQueue);
    updateQueue();

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      unsubscribe();
    };
  }, []);

  const addToQueue = (type: any, data: any) => {
    return syncQueue.addToQueue(type, data);
  };

  const retrySync = () => {
    syncQueue.processQueue();
  };

  const clearQueue = () => {
    queueItems.forEach(item => syncQueue.removeFromQueue(item.id));
  };

  return (
    <OfflineSyncContext.Provider value={{
      isOnline,
      isSyncing,
      syncStats,
      queueItems,
      addToQueue,
      retrySync,
      clearQueue
    }}>
      {children}
    </OfflineSyncContext.Provider>
  );
}

export function useOfflineSync() {
  const context = useContext(OfflineSyncContext);
  if (!context) throw new Error('useOfflineSync must be used within OfflineSyncProvider');
  return context;
}
