export interface NotificationABTest {
  id: string;
  name: string;
  description?: string;
  status: 'draft' | 'running' | 'paused' | 'completed' | 'winner_selected';
  template_ids: string[];
  traffic_allocation: Record<string, number>;
  success_metrics: {
    primary: 'delivery_rate' | 'click_rate' | 'action_rate' | 'conversion_rate';
    secondary?: string[];
  };
  target_sample_size: number;
  confidence_level: number;
  minimum_effect_size: number;
  start_date?: string;
  end_date?: string;
  winner_template_id?: string;
  winner_selected_at?: string;
  auto_select_winner: boolean;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface ABTestResult {
  id: string;
  test_id: string;
  template_id: string;
  impressions: number;
  deliveries: number;
  clicks: number;
  actions: number;
  conversions: number;
  total_time_to_click: number;
  total_time_to_action: number;
  total_time_to_conversion: number;
  delivery_rate: number;
  click_rate: number;
  action_rate: number;
  conversion_rate: number;
  avg_time_to_click?: number;
  avg_time_to_action?: number;
  avg_time_to_conversion?: number;
  statistical_significance?: number;
  confidence_interval_lower?: number;
  confidence_interval_upper?: number;
  is_winner: boolean;
  updated_at: string;
}

export interface ABTestVariant {
  template_id: string;
  template_name: string;
  allocation: number;
  result?: ABTestResult;
}
