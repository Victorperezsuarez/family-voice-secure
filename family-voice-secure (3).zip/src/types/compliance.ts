export interface ComplianceReportTemplate {
  id: string;
  name: string;
  standard: 'GDPR' | 'HIPAA' | 'SOC2' | 'ISO27001' | 'CUSTOM';
  description?: string;
  sections: ReportSection[];
  metrics: string[];
  is_active: boolean;
  created_by?: string;
  created_at: string;
  updated_at: string;
}

export interface ReportSection {
  id: string;
  title: string;
  type: 'metrics' | 'chart' | 'table' | 'text';
  content?: string;
  dataSource?: string;
}

export interface ComplianceReport {
  id: string;
  template_id?: string;
  title: string;
  standard: string;
  report_period_start: string;
  report_period_end: string;
  generated_at: string;
  generated_by?: string;
  status: 'generating' | 'completed' | 'failed';
  report_data: any;
  summary: ReportSummary;
  file_url?: string;
  certificate_id?: string;
  emailed_to?: string[];
  created_at: string;
}

export interface ReportSummary {
  complianceScore: number;
  totalAuditLogs: number;
  retentionPolicies: number;
  archivalSuccessRate: number;
}

export interface ComplianceSchedule {
  id: string;
  template_id: string;
  name: string;
  frequency: 'daily' | 'weekly' | 'monthly' | 'quarterly' | 'annually';
  day_of_week?: number;
  day_of_month?: number;
  time_of_day?: string;
  timezone: string;
  email_recipients: string[];
  is_active: boolean;
  last_run_at?: string;
  next_run_at?: string;
  created_by?: string;
  created_at: string;
  updated_at: string;
}

export interface ComplianceCertificate {
  id: string;
  report_id: string;
  certificate_number: string;
  standard: string;
  issued_to: string;
  issued_date: string;
  valid_from: string;
  valid_until: string;
  status: 'valid' | 'expired' | 'revoked';
  compliance_score?: number;
  findings: any;
  digital_signature?: string;
  certificate_data: any;
  file_url?: string;
  created_by?: string;
  created_at: string;
}

export interface ComplianceMetricsHistory {
  id: string;
  metric_date: string;
  total_audit_logs: number;
  archived_logs: number;
  deleted_logs: number;
  retention_policies_count: number;
  compliance_score?: number;
  policy_adherence_rate?: number;
  archival_success_rate?: number;
  storage_used_gb?: number;
  metrics_by_category: Record<string, number>;
  metrics_by_severity: Record<string, number>;
  created_at: string;
}
