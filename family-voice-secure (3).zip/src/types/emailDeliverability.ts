export interface EmailSenderReputation {
  id: string;
  domain: string;
  reputationScore: number;
  senderScore: number;
  complaintRate: number;
  bounceRate: number;
  spamTrapHits: number;
  volumeSent: number;
  volumeDelivered: number;
  checkedAt: string;
  createdAt: string;
}

export interface EmailDomainAuthentication {
  id: string;
  domain: string;
  spfStatus: 'pass' | 'fail' | 'softfail' | 'neutral' | 'none' | 'temperror' | 'permerror';
  spfRecord: string | null;
  dkimStatus: 'pass' | 'fail' | 'neutral' | 'none' | 'temperror' | 'permerror';
  dkimSelector: string | null;
  dkimRecord: string | null;
  dmarcStatus: 'pass' | 'fail' | 'none';
  dmarcPolicy: 'none' | 'quarantine' | 'reject' | null;
  dmarcRecord: string | null;
  bimiStatus: 'pass' | 'fail' | 'none' | null;
  lastChecked: string;
  createdAt: string;
}

export interface EmailBlacklistMonitoring {
  id: string;
  domain: string;
  ipAddress: string | null;
  blacklistName: string;
  isListed: boolean;
  listingReason: string | null;
  detectedAt: string | null;
  resolvedAt: string | null;
  createdAt: string;
}

export interface EmailISPDeliveryRate {
  id: string;
  ispName: string;
  domain: string;
  date: string;
  emailsSent: number;
  emailsDelivered: number;
  emailsBounced: number;
  emailsDeferred: number;
  inboxPlacementRate: number;
  spamFolderRate: number;
  createdAt: string;
}

export interface EmailDeliverabilityAlert {
  id: string;
  alertType: 'blacklist' | 'reputation_drop' | 'auth_failure' | 'high_bounce_rate' | 'high_complaint_rate' | 'isp_blocking';
  severity: 'low' | 'medium' | 'high' | 'critical';
  domain: string;
  title: string;
  description: string | null;
  remediationSteps: string[] | null;
  metricValue: number | null;
  thresholdValue: number | null;
  isResolved: boolean;
  resolvedAt: string | null;
  createdAt: string;
}

export interface EmailDeliverabilityHealth {
  id: string;
  domain: string;
  healthScore: number;
  reputationScore: number;
  authenticationScore: number;
  blacklistScore: number;
  deliveryRateScore: number;
  issuesCount: number;
  criticalIssuesCount: number;
  snapshotDate: string;
  createdAt: string;
}
