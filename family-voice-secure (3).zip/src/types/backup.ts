export type BackupProvider = 'google_drive' | 'dropbox' | 'onedrive';
export type BackupSchedule = 'daily' | 'weekly' | 'monthly' | 'manual';
export type BackupStatus = 'pending' | 'in_progress' | 'completed' | 'failed';

export interface BackupConfig {
  id: string;
  user_id: string;
  family_id: string;
  provider: BackupProvider;
  schedule: BackupSchedule;
  enabled: boolean;
  access_token?: string;
  refresh_token?: string;
  token_expires_at?: string;
  last_backup_at?: string;
  next_backup_at?: string;
  created_at: string;
  updated_at: string;
}

export interface BackupHistory {
  id: string;
  config_id: string;
  user_id: string;
  family_id: string;
  provider: BackupProvider;
  status: BackupStatus;
  file_count: number;
  file_size_bytes: number;
  backup_path?: string;
  error_message?: string;
  started_at: string;
  completed_at?: string;
  created_at: string;
}

export type ConflictResolution = 'skip' | 'overwrite' | 'merge' | 'keep_both';
export type RestoreStatus = 'pending' | 'in_progress' | 'completed' | 'failed';

export interface BackupContent {
  recordings: Array<{
    id: string;
    title: string;
    duration: number;
    created_at: string;
    file_path: string;
  }>;
  transcriptions: Array<{
    id: string;
    recording_id: string;
    text: string;
  }>;
  photos: Array<{
    id: string;
    file_path: string;
    caption?: string;
  }>;
  metadata: {
    backup_date: string;
    total_size: number;
    version: string;
  };
}

export interface RestoreOperation {
  id: string;
  backup_id: string;
  user_id: string;
  family_id: string;
  status: RestoreStatus;
  conflict_resolution: ConflictResolution;
  selected_items: {
    recordings: string[];
    transcriptions: string[];
    photos: string[];
  };
  recordings_restored: number;
  transcriptions_restored: number;
  photos_restored: number;
  conflicts_found: number;
  error_message?: string;
  started_at: string;
  completed_at?: string;
}
