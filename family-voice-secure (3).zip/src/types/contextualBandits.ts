export interface UserContext {
  userId: string;
  locationCountry?: string;
  locationRegion?: string;
  locationCity?: string;
  deviceType?: 'mobile' | 'tablet' | 'desktop';
  deviceOs?: 'ios' | 'android' | 'windows' | 'macos' | 'linux';
  browser?: string;
  timeOfDay?: 'morning' | 'afternoon' | 'evening' | 'night';
  dayOfWeek?: string;
  pastEngagementRate?: number;
  notificationFrequency?: 'high' | 'medium' | 'low';
  userTenureDays?: number;
  lastInteractionDays?: number;
  preferredNotificationTime?: string;
}

export interface ContextualStats {
  id: string;
  testId: string;
  combinationId: string;
  segmentKey: string;
  segmentValue: string;
  impressions: number;
  clicks: number;
  conversions: number;
  alpha: number;
  beta: number;
  expectedReward: number;
  confidenceLower: number;
  confidenceUpper: number;
  lastUpdated: string;
}

export interface SegmentPerformance {
  id: string;
  testId: string;
  segmentDefinition: Record<string, string>;
  segmentName: string;
  winningCombinationId?: string;
  totalUsers: number;
  totalImpressions: number;
  totalClicks: number;
  totalConversions: number;
  avgEngagementRate: number;
  confidenceScore: number;
  statisticalSignificance: boolean;
  updatedAt: string;
}

export interface PersonalizedSelection {
  id: string;
  testId: string;
  userId: string;
  combinationId: string;
  userContext: UserContext;
  selectionScore: number;
  selectionMethod: 'thompson_sampling' | 'ucb' | 'epsilon_greedy';
  explorationFactor: number;
  selectedAt: string;
  delivered: boolean;
  opened: boolean;
  clicked: boolean;
  converted: boolean;
}

export interface SegmentInteraction {
  id: string;
  testId: string;
  segmentKey: string;
  segmentValue: string;
  element1Name: string;
  element1Variant: string;
  element2Name: string;
  element2Variant: string;
  interactionEffect: number;
  pValue: number;
  isSignificant: boolean;
  sampleSize: number;
}
