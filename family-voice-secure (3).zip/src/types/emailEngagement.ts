export interface EmailEngagementPrediction {
  id: string;
  template_id: string;
  prediction_date: string;
  overall_score: number;
  subject_line_score: number;
  content_score: number;
  cta_score: number;
  timing_score: number;
  predicted_open_rate: number;
  predicted_click_rate: number;
  predicted_conversion_rate: number;
  predicted_bounce_rate: number;
  optimal_send_day: string;
  optimal_send_hour: number;
  optimal_send_timezone: string;
  subject_line_analysis: SubjectLineAnalysis;
  content_analysis: ContentAnalysis;
  cta_analysis: CTAAnalysis;
  timing_analysis: TimingAnalysis;
  recommendations: string[];
  suggested_variations: SuggestedVariation[];
  industry_benchmark_comparison?: any;
  historical_performance_comparison?: any;
  created_at: string;
  updated_at: string;
}

export interface SubjectLineAnalysis {
  score: number;
  length_assessment?: string;
  emotional_appeal?: string;
  clarity?: string;
  urgency_level?: string;
  personalization_opportunities?: string[];
}

export interface ContentAnalysis {
  score: number;
  length_assessment?: string;
  readability_score?: number;
  cta_count?: number;
  cta_placement?: string;
  visual_hierarchy?: string;
  mobile_optimization?: string;
}

export interface CTAAnalysis {
  score: number;
  cta_clarity?: string;
  cta_count?: number;
  cta_placement_quality?: string;
  action_verb_strength?: string;
}

export interface TimingAnalysis {
  score: number;
  optimal_day?: string;
  optimal_hour?: number;
  timezone_recommendation?: string;
}

export interface SuggestedVariation {
  element: string;
  current: string;
  suggested: string;
  expected_improvement: string;
}

export interface EmailHistoricalBenchmark {
  id: string;
  benchmark_type: 'industry' | 'organization' | 'template_category';
  category?: string;
  period_start: string;
  period_end: string;
  avg_open_rate: number;
  avg_click_rate: number;
  avg_conversion_rate: number;
  avg_bounce_rate: number;
  best_subject_line_length_min?: number;
  best_subject_line_length_max?: number;
  best_content_length_min?: number;
  best_content_length_max?: number;
  best_send_days?: string[];
  best_send_hours?: number[];
  sample_size: number;
  created_at: string;
  updated_at: string;
}
