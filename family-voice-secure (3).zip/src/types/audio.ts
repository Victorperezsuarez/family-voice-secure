export interface AudioEnhancement {
  noiseReduction: boolean;
  volumeNormalization: boolean;
  voiceEnhancement: boolean;
  restoration: boolean;
}

export interface AudioSegment {
  id: string;
  start: number;
  end: number;
  type: 'keep' | 'remove';
}

export interface AudioEditState {
  duration: number;
  segments: AudioSegment[];
  trimStart: number;
  trimEnd: number;
  enhancements: AudioEnhancement;
}
