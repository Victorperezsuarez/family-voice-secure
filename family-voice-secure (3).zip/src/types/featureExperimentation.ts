export interface FeatureExperiment {
  id: string;
  name: string;
  description?: string;
  status: 'draft' | 'running' | 'paused' | 'completed';
  experiment_type: 'ab_test' | 'multivariate' | 'shadow_mode';
  control_config: FeatureConfig;
  treatment_configs: FeatureConfig[];
  traffic_allocation: TrafficAllocation;
  start_date?: string;
  end_date?: string;
  target_metric: string;
  minimum_sample_size: number;
  confidence_level: number;
  created_by?: string;
  created_at: string;
  updated_at: string;
}

export interface FeatureConfig {
  name: string;
  features: string[];
  generation_params?: Record<string, any>;
}

export interface TrafficAllocation {
  control: number;
  treatments: Record<string, number>;
}

export interface FeatureConfiguration {
  id: string;
  experiment_id: string;
  config_name: string;
  config_type: string;
  feature_set: string[];
  feature_generation_params?: Record<string, any>;
  is_active: boolean;
  is_promoted: boolean;
  promoted_at?: string;
  created_at: string;
}

export interface ExperimentResult {
  id: string;
  experiment_id: string;
  config_id: string;
  metric_name: string;
  metric_value: number;
  sample_size: number;
  confidence_interval?: { lower: number; upper: number };
  statistical_significance?: boolean;
  p_value?: number;
  recorded_at: string;
}

export interface ShadowModeComputation {
  id: string;
  config_id: string;
  user_id?: string;
  feature_values: Record<string, any>;
  prediction_value?: number;
  actual_value?: number;
  error_metric?: number;
  computation_time_ms: number;
  computed_at: string;
}

export interface FeaturePerformance {
  id: string;
  experiment_id: string;
  feature_name: string;
  config_id?: string;
  importance_score?: number;
  contribution_to_metric?: number;
  usage_count: number;
  avg_computation_time_ms?: number;
  tracked_at: string;
}

export interface PromotionHistory {
  id: string;
  experiment_id: string;
  promoted_config_id: string;
  previous_config_id?: string;
  promotion_reason: string;
  metric_improvement?: number;
  approved_by?: string;
  promoted_at: string;
  rollback_at?: string;
}
