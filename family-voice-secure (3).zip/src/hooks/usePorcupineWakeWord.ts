import { useEffect, useRef, useState } from 'react';

interface PorcupineState {
  isListening: boolean;
  isLoaded: boolean;
  error: string | null;
  wakeWordDetected: boolean;
}

export const usePorcupineWakeWord = (onWakeWord: () => void) => {
  const [state, setState] = useState<PorcupineState>({
    isListening: false,
    isLoaded: false,
    error: null,
    wakeWordDetected: false,
  });

  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const detectionIntervalRef = useRef<number | null>(null);

  const initWakeWordDetection = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const audioContext = new AudioContext({ sampleRate: 16000 });
      audioContextRef.current = audioContext;

      const source = audioContext.createMediaStreamSource(stream);
      const analyser = audioContext.createAnalyser();
      analyser.fftSize = 2048;
      analyserRef.current = analyser;
      source.connect(analyser);

      setState(prev => ({ ...prev, isLoaded: true }));
    } catch (error) {
      setState(prev => ({ ...prev, error: (error as Error).message }));
    }
  };

  const startListening = () => {
    if (!analyserRef.current) return;

    setState(prev => ({ ...prev, isListening: true }));

    detectionIntervalRef.current = window.setInterval(() => {
      const bufferLength = analyserRef.current!.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);
      analyserRef.current!.getByteFrequencyData(dataArray);

      const average = dataArray.reduce((a, b) => a + b) / bufferLength;
      
      if (average > 50) {
        setState(prev => ({ ...prev, wakeWordDetected: true }));
        onWakeWord();
        setTimeout(() => {
          setState(prev => ({ ...prev, wakeWordDetected: false }));
        }, 2000);
      }
    }, 100);
  };

  const stopListening = () => {
    if (detectionIntervalRef.current) {
      clearInterval(detectionIntervalRef.current);
    }
    setState(prev => ({ ...prev, isListening: false }));
  };

  const cleanup = () => {
    stopListening();
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
    }
    if (audioContextRef.current) {
      audioContextRef.current.close();
    }
  };

  useEffect(() => {
    return cleanup;
  }, []);

  return {
    ...state,
    initWakeWordDetection,
    startListening,
    stopListening,
    cleanup,
  };
};