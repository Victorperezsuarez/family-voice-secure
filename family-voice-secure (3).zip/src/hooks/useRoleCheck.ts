import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase-client';
import { useAuth } from '@/contexts/AuthContext';

export type UserRole = 'admin' | 'moderator' | 'user';

interface RoleCheckResult {
  hasRole: boolean;
  loading: boolean;
  roles: UserRole[];
}

export function useRoleCheck(requiredRole?: UserRole): RoleCheckResult {
  const { user } = useAuth();
  const [roles, setRoles] = useState<UserRole[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function checkRoles() {
      if (!user) {
        setRoles([]);
        setLoading(false);
        return;
      }

      try {
        const { data, error } = await supabase
          .from('user_roles')
          .select('role')
          .eq('user_id', user.id)
          .or('expires_at.is.null,expires_at.gt.now()');

        if (error) throw error;

        const userRoles = data?.map(r => r.role as UserRole) || [];
        setRoles(userRoles);
      } catch (error) {
        console.error('Error checking roles:', error);
        setRoles([]);
      } finally {
        setLoading(false);
      }
    }

    checkRoles();
  }, [user]);

  const hasRole = requiredRole ? roles.includes(requiredRole) : roles.length > 0;

  return { hasRole, loading, roles };
}
