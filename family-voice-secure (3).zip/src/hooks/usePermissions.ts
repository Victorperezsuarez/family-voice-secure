import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase-client';
import { useAuth } from '@/contexts/AuthContext';

export interface Permission {
  name: string;
  description: string;
  category: string;
}

export function usePermissions(familyId: string | null) {
  const { user } = useAuth();
  const [permissions, setPermissions] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [roleId, setRoleId] = useState<string | null>(null);
  const [roleName, setRoleName] = useState<string>('');

  useEffect(() => {
    if (!user || !familyId) {
      setPermissions(new Set());
      setLoading(false);
      return;
    }

    loadPermissions();
  }, [user, familyId]);

  const loadPermissions = async () => {
    try {
      setLoading(true);
      
      // Get user's role in this family
      const { data: familyUser, error: userError } = await supabase
        .from('family_users')
        .select('role_id, custom_roles(id, name)')
        .eq('family_id', familyId)
        .eq('user_id', user!.id)
        .single();

      if (userError) throw userError;

      if (familyUser?.role_id) {
        setRoleId(familyUser.role_id);
        setRoleName((familyUser as any).custom_roles?.name || '');

        // Get permissions for this role
        const { data: rolePerms, error: permsError } = await supabase
          .from('role_permissions')
          .select('permission_name')
          .eq('role_id', familyUser.role_id);

        if (permsError) throw permsError;

        const permSet = new Set(rolePerms?.map(p => p.permission_name) || []);
        setPermissions(permSet);
      }
    } catch (error) {
      console.error('Error loading permissions:', error);
    } finally {
      setLoading(false);
    }
  };

  const hasPermission = (permission: string): boolean => {
    return permissions.has(permission);
  };

  const hasAnyPermission = (perms: string[]): boolean => {
    return perms.some(p => permissions.has(p));
  };

  const hasAllPermissions = (perms: string[]): boolean => {
    return perms.every(p => permissions.has(p));
  };

  return {
    permissions,
    hasPermission,
    hasAnyPermission,
    hasAllPermissions,
    loading,
    roleId,
    roleName,
    refresh: loadPermissions
  };
}
