# Accessibility Testing Guide

This guide covers automated accessibility testing using axe-core with Playwright to ensure WCAG 2.1 compliance.

## Overview

Our accessibility testing suite includes:
- **WCAG 2.1 AA/AAA compliance testing** using axe-core
- **Keyboard navigation tests** for all interactive elements
- **Screen reader compatibility** through ARIA attribute validation
- **Color contrast validation** for text and UI elements
- **Form accessibility** including labels and error messages
- **Automated CI/CD integration** with GitHub Actions

## Running Tests Locally

### Run All Accessibility Tests
```bash
npm run test:a11y
```

### Run with UI Mode
```bash
npm run test:a11y -- --ui
```

### Generate HTML Report
```bash
npm run test:a11y:report
```

### Run Specific Test File
```bash
npx playwright test e2e/accessibility/keyboard-navigation.spec.ts
```

## Test Categories

### 1. WCAG Compliance Tests
Located in `e2e/accessibility/landing-page.spec.ts`

Tests for:
- WCAG 2.1 Level AA violations
- Heading hierarchy (h1-h6)
- Color contrast ratios
- Image alt text
- Semantic HTML structure

### 2. Keyboard Navigation Tests
Located in `e2e/accessibility/keyboard-navigation.spec.ts`

Tests for:
- Tab navigation through interactive elements
- Enter/Space key activation of buttons
- Visible focus indicators
- Skip links and keyboard shortcuts

### 3. Form Accessibility Tests
Located in `e2e/accessibility/forms.spec.ts`

Tests for:
- Form labels associated with inputs
- Required field indicators
- Error message associations
- Fieldset and legend usage

### 4. ARIA Attributes Tests
Located in `e2e/accessibility/aria-attributes.spec.ts`

Tests for:
- Valid ARIA attributes
- Accessible names for buttons/links
- Proper role usage
- Landmark regions (nav, main, etc.)

## Accessibility Helper

The `e2e/helpers/accessibility.ts` utility provides:

```typescript
await checkAccessibility(page, 'context-name', {
  wcagLevel: 'AA',  // 'A', 'AA', or 'AAA'
  tags: ['cat.color', 'cat.forms'],
  disableRules: ['color-contrast']  // Optional
});
```

## CI/CD Integration

### Automated Testing
The `.github/workflows/accessibility-tests.yml` workflow:
- Runs on push to main/develop branches
- Runs on pull requests
- Runs weekly on schedule
- Generates accessibility reports
- Comments on PRs with test results

### Viewing Reports
1. Go to GitHub Actions tab
2. Select "Accessibility Tests" workflow
3. Download "accessibility-reports" artifact
4. Open HTML reports in browser

## Common WCAG Issues and Fixes

### Missing Alt Text
```html
<!-- ❌ Bad -->
<img src="logo.png">

<!-- ✅ Good -->
<img src="logo.png" alt="Company Logo">
```

### Missing Form Labels
```html
<!-- ❌ Bad -->
<input type="text" name="email">

<!-- ✅ Good -->
<label for="email">Email</label>
<input type="text" id="email" name="email">
```

### Poor Color Contrast
- Minimum contrast ratio: 4.5:1 for normal text
- Minimum contrast ratio: 3:1 for large text (18pt+)
- Use tools like WebAIM Contrast Checker

### Missing ARIA Labels
```html
<!-- ❌ Bad -->
<button><icon /></button>

<!-- ✅ Good -->
<button aria-label="Close dialog"><icon /></button>
```

### Improper Heading Hierarchy
```html
<!-- ❌ Bad -->
<h1>Page Title</h1>
<h3>Section</h3>

<!-- ✅ Good -->
<h1>Page Title</h1>
<h2>Section</h2>
```

## Best Practices

1. **Run tests frequently** during development
2. **Fix violations immediately** - don't let them accumulate
3. **Test with real assistive technology** when possible
4. **Use semantic HTML** before adding ARIA
5. **Ensure keyboard accessibility** for all interactions
6. **Maintain focus management** in dynamic content
7. **Provide text alternatives** for non-text content
8. **Use sufficient color contrast** throughout

## Resources

- [WCAG 2.1 Guidelines](https://www.w3.org/WAI/WCAG21/quickref/)
- [axe-core Rules](https://github.com/dequelabs/axe-core/blob/develop/doc/rule-descriptions.md)
- [WebAIM Resources](https://webaim.org/)
- [A11y Project Checklist](https://www.a11yproject.com/checklist/)

## Troubleshooting

### Tests Failing Locally
1. Ensure Playwright browsers are installed: `npx playwright install`
2. Check that dev server is running
3. Clear test results: `rm -rf test-results`

### False Positives
If a rule produces false positives, disable it:
```typescript
await checkAccessibility(page, 'context', {
  disableRules: ['rule-id']
});
```

### Performance Issues
- Run tests in parallel: `npx playwright test --workers=4`
- Run specific browsers only: `npx playwright test --project=chromium`

## Support

For questions or issues with accessibility testing, please:
1. Check this guide and the official documentation
2. Review existing test examples
3. Open an issue with the accessibility label
